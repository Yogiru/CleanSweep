unit aboutform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls, Graphics,
  Buttons;

type
  TAboutForm = class(TForm)
    btnOK: TBitBtn;
    imgIcon: TImage;
    lblAuthor: TLabel;
    lblCleaner: TLabel;
    lblCmd: TLabel;
    lblDesc: TLabel;
    lblFluent: TLabel;
    lblLicense: TLabel;
    lblMail: TLabel;
    lblName: TLabel;
    lblVersion: TLabel;
    sepAbout: TBevel;
    procedure MailClick(Sender: TObject);
    procedure FluentClick(Sender: TObject);
  public
    constructor CreateDlg(AOwner: TComponent);
  end;

procedure ShowAboutDialog(AOwner: TComponent);

implementation

{$R *.lfm}

uses
  Windows, ShellApi, cs.lang;

procedure ShowAboutDialog(AOwner: TComponent);
var
  F: TAboutForm;
begin
  F := TAboutForm.CreateDlg(AOwner);
  try
    F.ShowModal;
  finally
    F.Free;
  end;
end;

procedure TAboutForm.MailClick(Sender: TObject);
begin
  ShellExecuteW(Handle, 'open', 'mailto:Freetm@my.com', nil, nil, SW_SHOWNORMAL);
end;

procedure TAboutForm.FluentClick(Sender: TObject);
begin
  ShellExecuteW(Handle, 'open',
    'https://github.com/builtbybel/FluentCleaner', nil, nil, SW_SHOWNORMAL);
end;

constructor TAboutForm.CreateDlg(AOwner: TComponent);
begin
  inherited Create(AOwner); // loads aboutform.lfm
  try
    Icon.LoadFromResourceName(HInstance, 'MAINICON');
    imgIcon.Picture.Icon.Assign(Icon);
  except
  end;
  Caption := Lg('О программе', 'Аб праграме', 'Про програму', 'About');
  lblVersion.Caption := Lg('Версия 1.0.1.0', 'Версія 1.0.1.0',
                           'Версія 1.0.1.0', 'Version 1.0.1.0');
  lblDesc.Caption := Lg(
    'Портабельный деинсталлятор: запускает штатный деинсталлятор, ' +
    'находит остатки (файлы, реестр, задачи, службы) и аккуратно ' +
    'убирает их после подтверждения.',
    'Партатыўны дэінсталятар: запускае штатны дэінсталятар, ' +
    'знаходзіць рэшткі (файлы, рэестр, задачы, службы) і акуратна ' +
    'прыбірае іх пасля пацвярджэння.',
    'Портативний деінсталятор: запускає штатний деінсталятор, ' +
    'знаходить залишки (файли, реєстр, задачі, служби) і акуратно ' +
    'прибирає їх після підтвердження.',
    'Portable uninstaller: runs the vendor uninstaller, finds ' +
    'leftovers (files, registry, tasks, services) and cleans them ' +
    'up after your review.');
  lblCleaner.Caption := Lg(
    'Клинер: движок на базе FluentCleaner (базы Winapp2/Winapp3)',
    'Клінер: рухавік на базе FluentCleaner (базы Winapp2/Winapp3)',
    'Клінер: рушій на базі FluentCleaner (бази Winapp2/Winapp3)',
    'Cleaner: engine based on FluentCleaner (Winapp2/Winapp3 bases)');
  lblCmd.Caption := Lg(
    'Параметры: -c — открыть клинер · -h — эта справка · F1 — справка',
    'Параметры: -c — адкрыць клінер · -h — гэта даведка · F1 — даведка',
    'Параметри: -c — відкрити клінер · -h — ця довідка · F1 — довідка',
    'Params: -c — open cleaner · -h — this help · F1 — help');
  lblAuthor.Caption := Lg('Автор: FreeTm', 'Аўтар: FreeTm',
                          'Автор: FreeTm', 'Author: FreeTm');
  lblLicense.Caption := Lg('Лицензия: FreeForAll', 'Ліцэнзія: FreeForAll',
                           'Ліцензія: FreeForAll', 'License: FreeForAll');
end;

end.
