unit cs.pathexpand;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils;

type
  { Expands winapp2 %Var% tokens and resolves wildcard path segments.
    Port of FluentCleaner PathExpander. }
  TPathExpander = class
  private
    FVars: TStringList;    // name=value pairs, names without %
    procedure BuildVarMap;
    procedure ResolveRecursive(const APath: string; AResults: TStrings);
  public
    constructor Create;
    destructor Destroy; override;
    function ExpandVariables(const APath: string): string;
    function ResolvePaths(const ARawPath: string): TStringList;
  end;

  { Disables WOW64 file-system redirection for the current thread while
    alive; restores on Destroy. Resolved dynamically and a no-op when not
    running under WOW64, so identical code serves i386 and x64 builds —
    and the i386 exe still loads on a real 32-bit Windows. }
  TWow64FsGuard = class
  private
    FOld: Pointer;
    FActive: Boolean;
  public
    constructor Create;
    destructor Destroy; override;
  end;

{ True when the OS is 64-bit — regardless of our own process bitness.
  Used to decide whether a second registry-view probe means anything. }
function OsIs64Bit: Boolean;

implementation

uses
  Windows, StrUtils, Types, ShlObj, cs.utils;

{ net48-era .NET had no case-insensitive Replace either; this is the same
  manual IndexOf-and-splice version. Tokens are ASCII %VARS%, so byte-wise
  UpperCase keeps positions aligned on UTF-8 strings. }
function ReplaceIgnoreCase(const ASource, AOld, ANew: string): string;
var
  Pos0, Idx: Integer;
  UpSrc, UpOld: string;
begin
  Result := '';
  UpSrc := UpperCase(ASource);
  UpOld := UpperCase(AOld);
  Pos0 := 1;
  while True do
  begin
    Idx := PosEx(UpOld, UpSrc, Pos0);
    if Idx = 0 then
    begin
      Result := Result + Copy(ASource, Pos0, MaxInt);
      Break;
    end;
    Result := Result + Copy(ASource, Pos0, Idx - Pos0) + ANew;
    Pos0 := Idx + Length(AOld);
  end;
end;

{ Splits on '\' and '/' keeping empty segments, like the C#
  StringSplitOptions.None — needed so UNC paths ('\\srv\share\...')
  survive the join below. }
function SplitPath(const APath: string): TStringDynArray;
var
  Start, I, N: Integer;
begin
  Result := nil;
  N := 0;
  SetLength(Result, Length(APath) + 1);
  Start := 1;
  for I := 1 to Length(APath) do
    if (APath[I] = '\') or (APath[I] = '/') then
    begin
      Result[N] := Copy(APath, Start, I - Start);
      Inc(N);
      Start := I + 1;
    end;
  Result[N] := Copy(APath, Start, MaxInt);
  Inc(N);
  SetLength(Result, N);
end;

{ Joins Parts[From..Till] with '\'. Empty range → ''. }
function JoinSegs(const AParts: TStringDynArray;
  AFrom, ATill: Integer): string;
var
  I: Integer;
begin
  Result := '';
  for I := AFrom to ATill do
  begin
    if I > AFrom then Result := Result + '\';
    Result := Result + AParts[I];
  end;
end;

{ TWow64FsGuard }

type
  TFsDisableFn = function(out OldValue: Pointer): BOOL; stdcall;
  TFsRevertFn = function(OldValue: Pointer): BOOL; stdcall;

var
  GFsDisable: TFsDisableFn = nil;
  GFsRevert: TFsRevertFn = nil;
  GFsChecked: Boolean = False;
  GFsWow64: Boolean = False;

function OsIs64Bit: Boolean;
{$IFDEF CPU64}
begin
  Result := True;
end;
{$ELSE}
var
  B: BOOL;
begin
  B := False;
  Result := IsWow64Process(GetCurrentProcess, @B) and B;
end;
{$ENDIF}

{ Resolves the redirection APIs once. Both live in kernel32 but exist only
  on 64-bit Windows — dynamic lookup keeps a static import from breaking
  program startup on real 32-bit systems. }
procedure InitWow64Fs;
var
  K: HMODULE;
  B: BOOL;
begin
  if GFsChecked then Exit;
  GFsChecked := True;
  B := False;
  GFsWow64 := IsWow64Process(GetCurrentProcess, @B) and B;
  if not GFsWow64 then Exit;
  K := GetModuleHandle('kernel32.dll');
  if K = 0 then Exit;
  Pointer(GFsDisable) := GetProcAddress(K, 'Wow64DisableWow64FsRedirection');
  Pointer(GFsRevert) := GetProcAddress(K, 'Wow64RevertWow64FsRedirection');
end;

constructor TWow64FsGuard.Create;
begin
  InitWow64Fs;
  FActive := False;
  if GFsWow64 and Assigned(GFsDisable) then
    FActive := GFsDisable(FOld);
end;

destructor TWow64FsGuard.Destroy;
begin
  if FActive and Assigned(GFsRevert) then
    GFsRevert(FOld);
  inherited;
end;

{ TPathExpander }

constructor TPathExpander.Create;
begin
  FVars := TStringList.Create;
  BuildVarMap;
end;

destructor TPathExpander.Destroy;
begin
  FVars.Free;
  inherited;
end;

procedure TPathExpander.BuildVarMap;
var
  LocalAppData, WinDir, Tmp: string;

  procedure Add(const AName, AValue: string);
  var
    V: string;
  begin
    V := AValue;
    while (Length(V) > 0) and (V[Length(V)] in ['\', '/']) do
      SetLength(V, Length(V) - 1);
    if V <> '' then
      FVars.Add(UpperCase(AName) + '=' + V);
  end;

begin
  LocalAppData := GetSpecialFolder(CSIDL_LOCAL_APPDATA);
  WinDir := GetSpecialFolder(CSIDL_WINDOWS);
  Tmp := GetTempDir(False);

  Add('AppData', GetSpecialFolder(CSIDL_APPDATA));
  Add('LocalAppData', LocalAppData);
  // ExpandFileName collapses the '..' now — NormalizePath rejects any
  // path still containing '..\', which would silently fail every
  // LocalLow rule's safety check downstream.
  Add('LocalLowAppData', ExpandFileName(LocalAppData + '\..\LocalLow'));
  // %ProgramFiles% means the native (64-bit) PF; ResolvePaths adds the
  // x86 sibling automatically, matching upstream behaviour.
  Add('ProgramFiles', GetProgramFiles64);
  Add('ProgramFiles(x86)', GetSpecialFolder(CSIDL_PROGRAM_FILESX86));
  Add('ProgramFilesX86', GetSpecialFolder(CSIDL_PROGRAM_FILESX86));
  Add('ProgramData', GetSpecialFolder(CSIDL_COMMON_APPDATA));
  Add('CommonAppData', GetSpecialFolder(CSIDL_COMMON_APPDATA));
  Add('UserProfile', GetSpecialFolder(CSIDL_PROFILE));
  Add('Documents', GetSpecialFolder(CSIDL_PERSONAL));
  Add('Desktop', GetSpecialFolder(CSIDL_DESKTOPDIRECTORY));
  Add('Music', GetSpecialFolder(CSIDL_MYMUSIC));
  Add('Pictures', GetSpecialFolder(CSIDL_MYPICTURES));
  Add('Videos', GetSpecialFolder(CSIDL_MYVIDEO));
  Add('SystemRoot', WinDir);
  Add('WinDir', WinDir);
  Add('System', GetSpecialFolder(CSIDL_SYSTEM));
  Add('SystemX86', GetSpecialFolder(CSIDL_SYSTEMX86));
  Add('Temp', Tmp);
  Add('Tmp', Tmp);
  if WinDir <> '' then
    Add('SystemDrive', ExtractFileDrive(WinDir))
  else
    Add('SystemDrive', 'C:');
end;

function TPathExpander.ExpandVariables(const APath: string): string;
var
  I: Integer;
begin
  Result := APath;
  for I := 0 to FVars.Count - 1 do
    Result := ReplaceIgnoreCase(Result, '%' + FVars.Names[I] + '%',
      FVars.ValueFromIndex[I]);

  // the OS takes any %VAR% tokens we don't know
  Result := ExpandEnvVars(Result);

  // %SystemDrive% expands to 'C:' without a trailing separator; on
  // Windows 'C:' means that drive's CWD, not its root — a FileKey like
  // '%SystemDrive%|*.bak|RECURSE' would scan the app's working dir.
  if (Length(Result) = 2) and (Result[1] in ['A'..'Z', 'a'..'z']) and
     (Result[2] = ':') then
    Result := Result + '\';
end;

{ Returns every concrete path matched by a pattern like
  '%LocalAppData%\Google\Chrome*\User Data\*\Cache'.
  %ProgramFiles% automatically also tries the x86 location. }
function TPathExpander.ResolvePaths(const ARawPath: string): TStringList;
var
  Guard: TWow64FsGuard;
  X86: string;
begin
  Result := TStringList.Create;
  Result.CaseSensitive := False;
  Result.Duplicates := dupIgnore;
  Result.Sorted := True;

  Guard := TWow64FsGuard.Create;
  try
    ResolveRecursive(ExpandVariables(ARawPath), Result);

    if Pos('%programfiles%', LowerCase(ARawPath)) > 0 then
    begin
      X86 := ReplaceIgnoreCase(ARawPath, '%ProgramFiles%',
        '%ProgramFiles(x86)%');
      ResolveRecursive(ExpandVariables(X86), Result);
    end;
  finally
    Guard.Free;
  end;
end;

procedure TPathExpander.ResolveRecursive(const APath: string;
  AResults: TStrings);
var
  Parts: TStringDynArray;
  WcIdx, I, R: Integer;
  Base, Remaining, Full: string;
  SR: TSearchRec;
begin
  Parts := SplitPath(APath);

  WcIdx := -1;
  for I := 0 to High(Parts) do
    if (Pos('*', Parts[I]) > 0) or (Pos('?', Parts[I]) > 0) then
    begin
      WcIdx := I;
      Break;
    end;

  if WcIdx < 0 then
  begin
    AResults.Add(APath);   // literal path, add as-is
    Exit;
  end;

  if WcIdx = 0 then
    Base := ExtractFileDrive(APath)
  else
    Base := JoinSegs(Parts, 0, WcIdx - 1);

  if (Base = '') or (not DirectoryExists(Base)) then Exit;

  Remaining := JoinSegs(Parts, WcIdx + 1, High(Parts));

  // With segments after the wildcard only directories matter.
  // FindFirst does the real wildcard match, including 8.3 aliases.
  R := FindFirst(IncludeTrailingPathDelimiter(Base) + Parts[WcIdx],
    faAnyFile, SR);
  try
    while R = 0 do
    begin
      if (SR.Name <> '.') and (SR.Name <> '..') then
      begin
        Full := IncludeTrailingPathDelimiter(Base) + SR.Name;
        if Remaining = '' then
          AResults.Add(Full)
        else if (SR.Attr and faDirectory) <> 0 then
          ResolveRecursive(Full + '\' + Remaining, AResults);
      end;
      R := FindNext(SR);
    end;
  finally
    SysUtils.FindClose(SR);
  end;
end;

end.
