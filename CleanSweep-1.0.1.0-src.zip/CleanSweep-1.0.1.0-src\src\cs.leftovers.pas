unit cs.leftovers;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Windows, cs.models;

{ Leftover scanning — redesigned port of DeepPurge's scanners.

  Differences from the original (cleaner architecture):

  * TScanContext — one shared snapshot per operation: installed-program
    inventory, ownership sets, search terms. Built ONCE, reused by both
    scanners (the original re-read the whole registry per scanner).
  * Token-aware matching instead of raw substring: candidate names are
    split on non-alphanumeric chars and terms match as whole tokens or
    path segments; substring fallback only for terms >= 5 chars.
  * Boundary-aware IsUnder: "C:\Foo" no longer matches "C:\Foobar".
  * Results deduplicated by normalized path.
  * Ownership conflicts are resolved against the snapshot directly —
    no fragile re-parsing of Details strings for evidence. }

type
  { Shared context for one leftover scan. }
  TScanContext = class
  public
    Target: TInstalledProgram;          // not owned
    Others: TProgramList;               // owned — installed minus target
    OtherFolderNames: TStringList;      // CI set: names+folders of others
    SharedParentDirs: TStringList;      // CI set
    PrimaryExact: TStringList;          // lowercase, exact-name terms
    PrimaryContains: TStringList;       // lowercase, len>=5 substring terms
    SecondaryTerms: TStringList;        // lowercase, weak terms
    InstallPath: string;                // normalized target install dir
    ExeName: string;                    // lowercase exe basename, no ext
    constructor Create(ATarget: TInstalledProgram);
    destructor Destroy; override;

    { Name match against terms. False = no match (also rejects names
      owned by other installed programs). }
    function MatchName(const AName: string;
      out AConf: TLeftoverConfidence): Boolean;
    { Full-path-aware variant for file system items. }
    function MatchPath(const AName, AFullPath: string;
      out AConf: TLeftoverConfidence): Boolean;
    { Loose containment for value data (commands, image paths). }
    function MatchesText(const AText: string): Boolean;
    { True when APath sits inside another product's install root or
      registry branch. }
    function OwnedByOther(const APath: string): Boolean;
  end;

  TRegistryLeftoverScanner = class
  private
    FSeen: TStringList; // sorted CI — dedup
    procedure AddReg(AList: TLeftoverList; const APath, ADisplay,
      ADetails: string; AType: TLeftoverType; AConf: TLeftoverConfidence;
      ASelected: Boolean; const ARegKey: string = '');
    procedure ScanSoftwareKeys(ACtx: TScanContext; AList: TLeftoverList;
      AMode: TScanMode);
    procedure ScanAppPaths(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanStartupEntries(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanServices(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanComRegistrations(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanFirewallRules(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanMuiCache(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanStartupApproved(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanBam(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanRecentApps(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanUserAssist(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanPathEnv(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanTaskCache(ACtx: TScanContext; AList: TLeftoverList);
  public
    constructor Create;
    destructor Destroy; override;
    procedure ScanForLeftovers(ACtx: TScanContext; AMode: TScanMode;
      AList: TLeftoverList);
  end;

  TFileLeftoverScanner = class
  private
    FSeen: TStringList;
    procedure AddFile(AList: TLeftoverList; const APath, ADetails: string;
      AConf: TLeftoverConfidence; ASelected: Boolean);
    procedure ScanDir(ACtx: TScanContext; const ADir, ALabel: string;
      AList: TLeftoverList);
    procedure ScanShortcuts(ACtx: TScanContext; const ADir, ALabel: string;
      AList: TLeftoverList);
    procedure ScanTempFolders(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanPrefetch(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanVirtualStore(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanJumpLists(ACtx: TScanContext; AList: TLeftoverList);
    procedure ScanDocuments(ACtx: TScanContext; AList: TLeftoverList);
  public
    constructor Create;
    destructor Destroy; override;
    procedure ScanForLeftovers(ACtx: TScanContext; AMode: TScanMode;
      AList: TLeftoverList);
  end;

{ Splits 'HKLM\SOFTWARE\X' into hive+subkey for cs.registry calls. }
procedure SplitRegPath(const AFullPath: string;
  out AHive: HKEY; out ASub: string; out AAccess: LongWord);

function LooksLikeRegistryPath(const APath: string): Boolean;

implementation

uses
  cs.utils, cs.safety, cs.registry, cs.signatures;

const
  // CSIDL values missing from FPC's ShlObj unit
  CSIDL_PERSONAL_L = $0005;
  CSIDL_SENDTO_L = $0009;
  CSIDL_COMMON_DOCUMENTS_L = $002E;

  StopWords: array[0..72] of string = (
    'desktop', 'windows', 'system', 'system32', 'program', 'programs',
    'application', 'applications', 'software', 'portable', 'update',
    'updater', 'service', 'services', 'driver', 'drivers', 'runtime',
    'framework', 'module', 'components', 'library', 'common',
    'app', 'apps', 'tool', 'tools', 'utility', 'utilities',
    'free', 'pro', 'plus', 'premium', 'lite', 'beta', 'alpha',
    'setup', 'install', 'installer', 'uninstall', 'uninstaller',
    'launcher', 'manager', 'editor', 'viewer', 'player', 'reader',
    'client', 'server', 'host', 'helper', 'agent', 'daemon',
    'studio', 'suite', 'pack', 'kit', 'hub', 'center', 'centre',
    'version', 'edition', 'release', 'build', 'x86', 'x64',
    'media', 'image', 'the', 'for', 'and', 'net', 'new', 'web');

  SharedPublishers: array[0..12] of string = (
    'Microsoft', 'Microsoft Corporation', 'Intel', 'Intel Corporation',
    'NVIDIA', 'NVIDIA Corporation', 'AMD', 'Advanced Micro Devices',
    'Realtek', 'Qualcomm', 'Broadcom', 'Google', 'Apple');


function IsStopWord(const S: string): Boolean;
var
  I: Integer;
begin
  Result := False;
  for I := Low(StopWords) to High(StopWords) do
    if SameText(S, StopWords[I]) then Exit(True);
end;

{ Installer/uninstaller stems carry no info about the app itself and
  would match every other program's "uninst*.exe" (BAM, shortcuts...). }
function IsGenericInstallerName(const S: string): Boolean;
const
  P: array[0..8] of string = ('unins', 'uninst', 'uninstall', 'setup',
    'install', 'installer', 'msiexec', 'wiseun', 'remove');
var
  I: Integer;
  L: string;
begin
  L := LowerCase(Trim(S));
  Result := False;
  for I := Low(P) to High(P) do
    if Pos(P[I], L) = 1 then Exit(True);
end;

function IsSharedPublisher(const S: string): Boolean;
var
  I: Integer;
begin
  Result := False;
  for I := Low(SharedPublishers) to High(SharedPublishers) do
    if SameText(S, SharedPublishers[I]) then Exit(True);
end;

{ A directory that still holds a runnable .exe is a live install or a
  portable copy — NOT a leftover. Installer/uninstaller stubs
  (unins000.exe, setup.exe…) don't count: they are exactly the kind of
  file an incomplete uninstall leaves behind. Reparse points are never
  followed (junction cycles), and the walk is capped so a huge matched
  dir can't stall the scan. }
function DirHasLiveExe(const ADir: string): Boolean;
const
  MAX_VISITED = 4000;
var
  Visited: Integer;

  function Walk(const ADir: string): Boolean;
  var
    SR: TSearchRec;
    R: Integer;
    Full: string;
  begin
    Result := False;
    if Visited >= MAX_VISITED then Exit;
    R := FindFirst(IncludeTrailingPathDelimiter(ADir) + '*',
                   faAnyFile, SR);
    try
      while R = 0 do
      begin
        if (SR.Name <> '.') and (SR.Name <> '..') then
        begin
          Inc(Visited);
          if Visited >= MAX_VISITED then Break;
          Full := IncludeTrailingPathDelimiter(ADir) + SR.Name;
          if (SR.Attr and faDirectory) <> 0 then
          begin
            if ((SR.Attr and FILE_ATTRIBUTE_REPARSE_POINT) = 0) and
               Walk(Full) then
              Exit(True);
          end
          else if SameText(ExtractFileExt(SR.Name), '.exe') and
                  (not IsGenericInstallerName(
                     ChangeFileExt(SR.Name, ''))) then
            Exit(True);
        end;
        R := FindNext(SR);
      end;
    finally
      SysUtils.FindClose(SR);
    end;
  end;

begin
  Visited := 0;
  Result := Walk(ADir);
end;


function LooksLikeRegistryPath(const APath: string): Boolean;
begin
  Result := (Pos('HKLM\', APath) = 1) or (Pos('HKCU\', APath) = 1) or
            (Pos('HKCR\', APath) = 1) or (Pos('HKU\', APath) = 1);
end;

procedure SplitRegPath(const AFullPath: string;
  out AHive: HKEY; out ASub: string; out AAccess: LongWord);
var
  P: Integer;
  Prefix: string;
begin
  P := Pos('\', AFullPath);
  if P = 0 then
  begin
    Prefix := AFullPath;
    ASub := '';
  end
  else
  begin
    Prefix := Copy(AFullPath, 1, P - 1);
    ASub := Copy(AFullPath, P + 1, MaxInt);
  end;
  AAccess := KEY_READ;
  if SameText(Prefix, 'HKLM') then
  begin AHive := HKEY_LOCAL_MACHINE; AAccess := REGVIEW_64; end
  else if SameText(Prefix, 'HKCU') then
    AHive := HKEY_CURRENT_USER
  else if SameText(Prefix, 'HKCR') then
  begin AHive := HKEY_CLASSES_ROOT; AAccess := REGVIEW_64; end
  else if Pos('HKU\', AFullPath) = 1 then
  begin
    AHive := HKEY_USERS;
    ASub := Copy(AFullPath, 5, MaxInt);
  end
  else
    AHive := 0;
end;

{ Boundary-aware "is under": root itself or root + separator prefix. }
function IsUnderPath(const APath, ARoot: string): Boolean;
begin
  Result := SameText(APath, ARoot) or
            (Pos(LowerCase(ARoot) + '\', LowerCase(APath)) = 1);
end;

{ Splits a name into lowercase alphanumeric tokens. }
function Tokenize(const S: string): TStringList;
var
  I, Start: Integer;
  T: string;
begin
  Result := TStringList.Create;
  Start := 0;
  for I := 1 to Length(S) + 1 do
  begin
    if (I > Length(S)) or
       not (S[I] in ['a'..'z', 'A'..'Z', '0'..'9', #128..#255]) then
    begin
      if Start > 0 then
      begin
        T := LowerCase(Copy(S, Start, I - Start));
        if T <> '' then Result.Add(T);
        Start := 0;
      end;
    end
    else if Start = 0 then
      Start := I;
  end;
end;

{ ═══════════════ TScanContext ═══════════════ }

constructor TScanContext.Create(ATarget: TInstalledProgram);
var
  All: TProgramList;
  I: Integer;
  P: TInstalledProgram;
  Folder, OtherParent, TargetParent, W: string;
  Tokens: TStringList;

  procedure AddPrimary(const S: string);
  var
    L: string;
  begin
    L := LowerCase(Trim(S));
    if (Length(L) <= 2) or IsStopWord(L) then Exit;
    if PrimaryExact.IndexOf(L) < 0 then
      PrimaryExact.Add(L);
    if (Length(L) >= 5) and (PrimaryContains.IndexOf(L) < 0) then
      PrimaryContains.Add(L);
  end;

begin
  Target := ATarget;
  Others := TProgramList.Create(True);
  OtherFolderNames := TStringList.Create;
  OtherFolderNames.CaseSensitive := False;
  OtherFolderNames.Sorted := True;
  OtherFolderNames.Duplicates := dupIgnore;
  SharedParentDirs := TStringList.Create;
  SharedParentDirs.CaseSensitive := False;
  SharedParentDirs.Duplicates := dupIgnore;
  PrimaryExact := TStringList.Create;
  PrimaryContains := TStringList.Create;
  SecondaryTerms := TStringList.Create;

  // ── inventory snapshot (single pass) ──
  All := TProgramList.Create(True);
  try
    ScanInstalledPrograms(All, True, True);
    TargetParent := '';
    if ATarget.InstallLocation <> '' then
      TargetParent := ExtractFileDir(
        ExcludeTrailingPathDelimiter(ATarget.InstallLocation));
    for I := 0 to All.Count - 1 do
    begin
      P := All[I];
      if SameText(P.RegistryPath, ATarget.RegistryPath) then
      begin
        P.Free; // the target itself is not an owner
        Continue;
      end;
      Others.Add(P); // ownership moves
      if SameText(P.DisplayName, ATarget.DisplayName) then
        Continue; // same-name twin: owner, but not a blocker
      if P.DisplayName <> '' then
        OtherFolderNames.Add(P.DisplayName);
      if P.InstallLocation <> '' then
      begin
        Folder := ExtractFileName(ExcludeTrailingPathDelimiter(P.InstallLocation));
        if Folder <> '' then OtherFolderNames.Add(Folder);
        OtherParent := ExtractFileDir(
          ExcludeTrailingPathDelimiter(P.InstallLocation));
        if (TargetParent <> '') and (OtherParent <> '') and
           SameText(OtherParent, TargetParent) then
          SharedParentDirs.Add(OtherParent);
      end;
    end;
    All.FreeObjects := False;
  finally
    All.Free;
  end;

  // ── search terms ──
  AddPrimary(ATarget.DisplayName);
  if ATarget.InstallLocation <> '' then
  begin
    InstallPath := NormalizePath(ATarget.InstallLocation);
    AddPrimary(ExtractFileName(InstallPath));
  end;
  W := ChangeFileExt(ExtractExeName(ATarget.UninstallString), '');
  if IsGenericInstallerName(W) then
    W := ''
  else
    AddPrimary(W);
  ExeName := LowerCase(W); // for BAM/UserAssist/JumpList path matching
  if (Length(ATarget.RegistryKeyName) > 3) and
     (ATarget.RegistryKeyName[1] <> '{') then
    AddPrimary(ATarget.RegistryKeyName);

  // Secondary: every significant name token (not just the first — the
  // original was too conservative; tokens still match at Moderate only)
  Tokens := Tokenize(ATarget.DisplayName);
  try
    for I := 0 to Tokens.Count - 1 do
      if (Length(Tokens[I]) > 4) and (not IsStopWord(Tokens[I])) and
         (PrimaryExact.IndexOf(Tokens[I]) < 0) and
         (SecondaryTerms.IndexOf(Tokens[I]) < 0) then
        SecondaryTerms.Add(Tokens[I]);
  finally
    Tokens.Free;
  end;
  if (Length(ATarget.Publisher) > 3) and
     (not IsSharedPublisher(ATarget.Publisher)) and
     (not IsStopWord(ATarget.Publisher)) then
    SecondaryTerms.Add(LowerCase(ATarget.Publisher));
end;

destructor TScanContext.Destroy;
begin
  Others.Free;
  OtherFolderNames.Free;
  SharedParentDirs.Free;
  PrimaryExact.Free;
  PrimaryContains.Free;
  SecondaryTerms.Free;
  inherited;
end;

function TScanContext.MatchName(const AName: string;
  out AConf: TLeftoverConfidence): Boolean;
var
  I, J: Integer;
  N: string;
  Tokens: TStringList;
begin
  Result := False;
  AConf := lcInfo;
  N := Trim(AName);
  if N = '' then Exit;

  // Reject: name belongs to another installed program
  if OtherFolderNames.IndexOf(N) >= 0 then Exit;

  // Exact primary match
  for I := 0 to PrimaryExact.Count - 1 do
    if SameText(N, PrimaryExact[I]) then
    begin AConf := lcSafe; Exit(True); end;

  Tokens := Tokenize(N);
  try
    // Token-level primary match ("VLC Player" ~ token "vlc")
    for I := 0 to Tokens.Count - 1 do
      if PrimaryExact.IndexOf(Tokens[I]) >= 0 then
      begin AConf := lcSafe; Exit(True); end;
    // Secondary: exact token match only — never substring
    for I := 0 to Tokens.Count - 1 do
      for J := 0 to SecondaryTerms.Count - 1 do
        if Tokens[I] = SecondaryTerms[J] then
        begin AConf := lcModerate; Exit(True); end;
  finally
    Tokens.Free;
  end;

  // Whole-name secondary (publisher names may contain spaces)
  for I := 0 to SecondaryTerms.Count - 1 do
    if SameText(N, SecondaryTerms[I]) then
    begin AConf := lcModerate; Exit(True); end;

  // Substring fallback only for longer primary terms
  // (covers "7zip2401", "VLC-3.0.20", avoids "Git"~"Digital")
  for I := 0 to PrimaryContains.Count - 1 do
    if Pos(PrimaryContains[I], LowerCase(N)) > 0 then
    begin AConf := lcSafe; Exit(True); end;
end;

function TScanContext.MatchPath(const AName, AFullPath: string;
  out AConf: TLeftoverConfidence): Boolean;
var
  ParentDir: string;
  I: Integer;
begin
  // Guaranteed match: inside the target's install root
  if (InstallPath <> '') and IsUnderPath(AFullPath, InstallPath) then
  begin
    AConf := lcSafe;
    Exit(True);
  end;

  if not MatchName(AName, AConf) then Exit(False);

  // Shared parent dir (e.g. two versions under "Blender Foundation"):
  // downgrade so the user reviews instead of auto-deleting
  if AConf = lcSafe then
  begin
    ParentDir := ExtractFileDir(AFullPath);
    for I := 0 to SharedParentDirs.Count - 1 do
      if ((ParentDir <> '') and
          (Pos(LowerCase(SharedParentDirs[I]) + '\',
               LowerCase(ParentDir)) = 1)) or
         SameText(ParentDir, SharedParentDirs[I]) then
      begin
        AConf := lcRisky;
        Break;
      end;
  end;
  Result := True;
end;

function TScanContext.MatchesText(const AText: string): Boolean;
var
  I: Integer;
  L: string;
begin
  Result := False;
  if AText = '' then Exit;
  L := LowerCase(AText);
  for I := 0 to PrimaryContains.Count - 1 do
    if Pos(PrimaryContains[I], L) > 0 then Exit(True);
  // short exact terms too, but only as path segments
  for I := 0 to PrimaryExact.Count - 1 do
    if Pos('\' + PrimaryExact[I] + '\', L) > 0 then Exit(True);
end;

function TScanContext.OwnedByOther(const APath: string): Boolean;
var
  I: Integer;
  Root: string;
begin
  Result := False;
  if LooksLikeRegistryPath(APath) then
  begin
    for I := 0 to Others.Count - 1 do
    begin
      Root := Others[I].RegistryPath;
      // A sloppy registry root ('HKCU\SOFTWARE' and the like) must not
      // own everything beneath it — only deletable roots confer ownership.
      if (Root <> '') and IsRegistryPathSafeToDelete(Root) and
         (SameText(APath, Root) or
          (Pos(LowerCase(Root) + '\', LowerCase(APath)) = 1)) then
        Exit(True);
    end;
  end
  else
  begin
    // %TEMP%/%TMP% is scratch space — nothing "owns" it. A program that
    // registers a temp dir (or anything broader) as its install root
    // must not shield the junk living there.
    if IsTempPath(APath) then Exit(False);
    for I := 0 to Others.Count - 1 do
    begin
      Root := Others[I].InstallLocation;
      // Same on the file side: a container root ('C:\', 'Program Files')
      // can't be deleted itself, so it can't own leftovers either.
      if (Root <> '') and IsPathSafeToDelete(Root) and
         IsUnderPath(APath, Root) then
        Exit(True);
    end;
  end;
end;

{ ═══════════════ Registry leftover scanner ═══════════════ }

constructor TRegistryLeftoverScanner.Create;
begin
  FSeen := TStringList.Create;
  FSeen.Sorted := True;
  FSeen.CaseSensitive := False;
  FSeen.Duplicates := dupIgnore;
end;

destructor TRegistryLeftoverScanner.Destroy;
begin
  FSeen.Free;
  inherited;
end;

procedure TRegistryLeftoverScanner.AddReg(AList: TLeftoverList;
  const APath, ADisplay, ADetails: string; AType: TLeftoverType;
  AConf: TLeftoverConfidence; ASelected: Boolean; const ARegKey: string);
var
  I: TLeftoverItem;
begin
  if FSeen.IndexOf(APath) >= 0 then Exit;
  FSeen.Add(APath);
  I := TLeftoverItem.Create;
  I.Path := APath;
  I.DisplayPath := ADisplay;
  I.KeyPath := ARegKey;
  I.ItemType := AType;
  I.Confidence := AConf;
  I.Details := ADetails;
  I.IsSelected := ASelected;
  AList.Add(I);
end;

procedure TRegistryLeftoverScanner.ScanForLeftovers(
  ACtx: TScanContext; AMode: TScanMode; AList: TLeftoverList);
var
  Sig: TLeftoverSignature;
  I: Integer;
  RegPath, Sub: string;
  Hive: HKEY;
  Acc: LongWord;
begin
  FSeen.Clear;

  Sig := FindSignature(ACtx.Target.DisplayName);
  if Sig <> nil then
    for I := 0 to Sig.RegistryPaths.Count - 1 do
    begin
      RegPath := Sig.RegistryPaths[I];
      if not IsRegistryPathSafeToDelete(RegPath) then Continue;
      SplitRegPath(RegPath, Hive, Sub, Acc);
      if RegKeyExists(Hive, Sub, Acc) then
        AddReg(AList, RegPath, RegPath, 'Known leftover (signature match)',
               ltRegistryKey, lcSafe, True);
    end;

  // The uninstall key itself
  if ACtx.Target.RegistryPath <> '' then
    AddReg(AList, ACtx.Target.RegistryPath, ACtx.Target.RegistryPath,
           'Uninstall registry entry', ltRegistryKey, lcSafe, True);

  ScanSoftwareKeys(ACtx, AList, AMode);
  if AMode >= smModerate then
    ScanComRegistrations(ACtx, AList);
  ScanAppPaths(ACtx, AList);
  ScanStartupEntries(ACtx, AList);
  ScanStartupApproved(ACtx, AList);
  ScanBam(ACtx, AList);
  ScanPathEnv(ACtx, AList);
  if AMode >= smModerate then
  begin
    ScanServices(ACtx, AList);
    ScanMuiCache(ACtx, AList);
    ScanRecentApps(ACtx, AList);
    ScanUserAssist(ACtx, AList);
    ScanTaskCache(ACtx, AList);
  end;
  if AMode >= smAdvanced then
    ScanFirewallRules(ACtx, AList);

  // Ownership/safety gate — last word on what may be auto-selected.
  // Registry roots from cs.safety protect real danger zones (Control,
  // Enum, SAM, Policies...); services additionally checked by name.
  for I := 0 to AList.Count - 1 do
    if (not IsRegistryPathSafeToDelete(AList[I].Path)) or
       ACtx.OwnedByOther(AList[I].Path) or
       ((AList[I].ItemType = ltService) and
        (not IsServiceSafeToModify(ExtractFileName(AList[I].Path)))) then
    begin
      AList[I].IsSelected := False;
      if AList[I].Confidence <> lcRisky then
        AList[I].Confidence := lcRisky;
      AList[I].Details := AList[I].Details +
        '; review-only (protected or shared)';
    end;
end;

procedure TRegistryLeftoverScanner.ScanSoftwareKeys(ACtx: TScanContext;
  AList: TLeftoverList; AMode: TScanMode);
const
  SW_HIVE: array[0..2] of HKEY = (HKEY_LOCAL_MACHINE, HKEY_LOCAL_MACHINE,
                                  HKEY_CURRENT_USER);
  SW_PRE:  array[0..2] of string = ('HKLM', 'HKLM', 'HKCU');
  SW_SUB:  array[0..2] of string = ('SOFTWARE', 'SOFTWARE\WOW6432Node',
                                    'SOFTWARE');
  SW_ACC:  array[0..2] of LongWord = (REGVIEW_64, REGVIEW_64, KEY_READ);
var
  I, J, K: Integer;
  Names, SubNames: TStringList;
  Full, Full2: string;
  Conf: TLeftoverConfidence;
begin
  Names := TStringList.Create;
  SubNames := TStringList.Create;
  try
    for I := Low(SW_SUB) to High(SW_SUB) do
    begin
      Names.Clear;
      RegEnumSubKeys(SW_HIVE[I], SW_SUB[I], SW_ACC[I], Names);
      for J := 0 to Names.Count - 1 do
      begin
        if SameText(Names[J], 'Microsoft') or SameText(Names[J], 'Classes') or
           SameText(Names[J], 'Policies') or SameText(Names[J], 'WOW6432Node') then
          Continue;
        if ACtx.MatchName(Names[J], Conf) then
        begin
          Full := SW_PRE[I] + '\' + SW_SUB[I] + '\' + Names[J];
          AddReg(AList, Full, Full, 'Application settings key',
                 ltRegistryKey, Conf, Conf = lcSafe);
        end;
        if AMode >= smModerate then
        begin
          SubNames.Clear;
          RegEnumSubKeys(SW_HIVE[I], SW_SUB[I] + '\' + Names[J],
                         SW_ACC[I], SubNames);
          for K := 0 to SubNames.Count - 1 do
            if ACtx.MatchName(SubNames[K], Conf) then
            begin
              Full2 := SW_PRE[I] + '\' + SW_SUB[I] + '\' +
                       Names[J] + '\' + SubNames[K];
              AddReg(AList, Full2, Full2, 'Application key under ' + Names[J],
                     ltRegistryKey, Conf, Conf = lcSafe);
            end;
        end;
      end;
    end;
  finally
    Names.Free;
    SubNames.Free;
  end;
end;

procedure TRegistryLeftoverScanner.ScanAppPaths(ACtx: TScanContext;
  AList: TLeftoverList);
const
  APPPATHS = 'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths';
var
  Names: TStringList;
  I: Integer;
  Conf: TLeftoverConfidence;
begin
  Names := TStringList.Create;
  try
    RegEnumSubKeys(HKEY_LOCAL_MACHINE, APPPATHS, REGVIEW_64, Names);
    for I := 0 to Names.Count - 1 do
      if ACtx.MatchName(ChangeFileExt(Names[I], ''), Conf) then
        AddReg(AList, 'HKLM\' + APPPATHS + '\' + Names[I],
               'HKLM\' + APPPATHS + '\' + Names[I],
               'App Paths registration', ltRegistryKey, Conf, Conf = lcSafe);
    Names.Clear;
    RegEnumSubKeys(HKEY_CURRENT_USER, APPPATHS, KEY_READ, Names);
    for I := 0 to Names.Count - 1 do
      if ACtx.MatchName(ChangeFileExt(Names[I], ''), Conf) then
        AddReg(AList, 'HKCU\' + APPPATHS + '\' + Names[I],
               'HKCU\' + APPPATHS + '\' + Names[I],
               'App Paths registration', ltRegistryKey, Conf, Conf = lcSafe);
  finally
    Names.Free;
  end;
end;

procedure TRegistryLeftoverScanner.ScanStartupEntries(ACtx: TScanContext;
  AList: TLeftoverList);
const
  RK_HIVE: array[0..3] of HKEY = (HKEY_LOCAL_MACHINE, HKEY_LOCAL_MACHINE,
                                  HKEY_CURRENT_USER, HKEY_CURRENT_USER);
  RK_PRE: array[0..3] of string = ('HKLM', 'HKLM', 'HKCU', 'HKCU');
  RK_SUB: array[0..3] of string = (
    'SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
    'SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce',
    'SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
    'SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce');
  RK_ACC: array[0..3] of LongWord = (REGVIEW_64, REGVIEW_64, KEY_READ, KEY_READ);
var
  I, J: Integer;
  Vals: TStringList;
  Data: string;
  Conf: TLeftoverConfidence;
begin
  Vals := TStringList.Create;
  try
    for I := Low(RK_SUB) to High(RK_SUB) do
    begin
      Vals.Clear;
      RegEnumValues(RK_HIVE[I], RK_SUB[I], RK_ACC[I], Vals);
      for J := 0 to Vals.Count - 1 do
      begin
        Data := RegReadString(RK_HIVE[I], RK_SUB[I], Vals[J], RK_ACC[I]);
        if ACtx.MatchName(Vals[J], Conf) or ACtx.MatchesText(Data) then
          // An autorun command pointing into system-owned dirs or known
          // protected processes must never be auto-selected for deletion.
          if IsAutorunSafeToDelete(Data) then
            AddReg(AList,
                   RK_PRE[I] + '\' + RK_SUB[I] + '\' + Vals[J],
                   RK_PRE[I] + '\' + RK_SUB[I] + ' -> ' + Vals[J],
                   'Startup entry: ' + Data, ltRegistryValue, lcSafe, True,
                   RK_PRE[I] + '\' + RK_SUB[I])
          else
            AddReg(AList,
                   RK_PRE[I] + '\' + RK_SUB[I] + '\' + Vals[J],
                   RK_PRE[I] + '\' + RK_SUB[I] + ' -> ' + Vals[J],
                   'Startup entry (protected target): ' + Data,
                   ltRegistryValue, lcRisky, False,
                   RK_PRE[I] + '\' + RK_SUB[I]);
      end;
    end;
  finally
    Vals.Free;
  end;
end;

procedure TRegistryLeftoverScanner.ScanServices(ACtx: TScanContext;
  AList: TLeftoverList);
const
  SVC = 'SYSTEM\CurrentControlSet\Services';
var
  Names: TStringList;
  I: Integer;
  Img, Full: string;
  Conf: TLeftoverConfidence;
begin
  Names := TStringList.Create;
  try
    RegEnumSubKeys(HKEY_LOCAL_MACHINE, SVC, REGVIEW_64, Names);
    for I := 0 to Names.Count - 1 do
    begin
      Img := RegReadString(HKEY_LOCAL_MACHINE, SVC + '\' + Names[I],
                           'ImagePath', REGVIEW_64);
      if ((Img <> '') and (ACtx.InstallPath <> '') and
          IsUnderPath(StringReplace(Img, '"', '', [rfReplaceAll]),
            ACtx.InstallPath)) or
         ((Img <> '') and ACtx.MatchesText(Img)) or
         ACtx.MatchName(Names[I], Conf) then
      begin
        Full := 'HKLM\' + SVC + '\' + Names[I];
        AddReg(AList, Full, 'Service: ' + Names[I],
               'Service executable: ' + Img, ltService, lcModerate, False);
      end;
    end;
  finally
    Names.Free;
  end;
end;

procedure TRegistryLeftoverScanner.ScanComRegistrations(ACtx: TScanContext;
  AList: TLeftoverList);
var
  Guids: TStringList;
  I: Integer;
  DllPath, Full: string;
begin
  if ACtx.InstallPath = '' then Exit;
  Guids := TStringList.Create;
  try
    RegEnumSubKeys(HKEY_CLASSES_ROOT, 'CLSID', REGVIEW_64, Guids);
    for I := 0 to Guids.Count - 1 do
    begin
      DllPath := RegReadString(HKEY_CLASSES_ROOT,
        'CLSID\' + Guids[I] + '\InprocServer32', '', REGVIEW_64);
      if DllPath = '' then
        DllPath := RegReadString(HKEY_CLASSES_ROOT,
          'CLSID\' + Guids[I] + '\LocalServer32', '', REGVIEW_64);
      if (DllPath <> '') and
         IsUnderPath(NormalizePath(
           StringReplace(DllPath, '"', '', [rfReplaceAll])),
           ACtx.InstallPath) then
      begin
        Full := 'HKCR\CLSID\' + Guids[I];
        AddReg(AList, Full, Full, 'COM registration pointing to: ' + DllPath,
               ltRegistryKey, lcModerate, False);
      end;
    end;
  finally
    Guids.Free;
  end;
end;

procedure TRegistryLeftoverScanner.ScanFirewallRules(ACtx: TScanContext;
  AList: TLeftoverList);
const
  FWP = 'SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules';
var
  Names: TStringList;
  I: Integer;
  Rule: string;
  Conf: TLeftoverConfidence;
begin
  Names := TStringList.Create;
  try
    RegEnumValues(HKEY_LOCAL_MACHINE, FWP, REGVIEW_64, Names);
    for I := 0 to Names.Count - 1 do
    begin
      Rule := RegReadString(HKEY_LOCAL_MACHINE, FWP, Names[I], REGVIEW_64);
      if (Rule <> '') and
         (ACtx.MatchesText(Rule) or ACtx.MatchName(Names[I], Conf)) then
        // Built-in Windows firewall rule prefixes stay protected.
        if IsFirewallRuleSafeToDelete(Names[I]) then
          AddReg(AList, 'HKLM\' + FWP + '\' + Names[I],
                 'Firewall rule: ' + Names[I], 'Rule: ' + Rule,
                 ltRegistryValue, lcModerate, False, 'HKLM\' + FWP)
        else
          AddReg(AList, 'HKLM\' + FWP + '\' + Names[I],
                 'Firewall rule (system): ' + Names[I], 'Rule: ' + Rule,
                 ltRegistryValue, lcRisky, False, 'HKLM\' + FWP);
    end;
  finally
    Names.Free;
  end;
end;

procedure TRegistryLeftoverScanner.ScanMuiCache(ACtx: TScanContext;
  AList: TLeftoverList);
const
  MUIC = 'SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\Shell\MuiCache';
var
  Names: TStringList;
  I: Integer;
begin
  Names := TStringList.Create;
  try
    RegEnumValues(HKEY_CURRENT_USER, MUIC, KEY_READ, Names);
    for I := 0 to Names.Count - 1 do
      if ACtx.MatchesText(Names[I]) then
        AddReg(AList, 'HKCU\' + MUIC + '\' + Names[I],
               'MuiCache: ' + Names[I], 'Shell MUI cache entry',
               ltRegistryValue, lcSafe, True, 'HKCU\' + MUIC);
  finally
    Names.Free;
  end;
end;


{ ROT13 — UserAssist value names are rot13-encoded paths. }
function Rot13(const S: string): string;
var
  I: Integer;
  C: Char;
begin
  Result := S;
  for I := 1 to Length(Result) do
  begin
    C := Result[I];
    if C in ['a'..'z'] then
      Result[I] := Chr(Ord('a') + (Ord(C) - Ord('a') + 13) mod 26)
    else if C in ['A'..'Z'] then
      Result[I] := Chr(Ord('A') + (Ord(C) - Ord('A') + 13) mod 26);
  end;
end;

procedure TRegistryLeftoverScanner.ScanStartupApproved(ACtx: TScanContext;
  AList: TLeftoverList);
const
  SA_HIVE: array[0..5] of HKEY = (HKEY_LOCAL_MACHINE, HKEY_LOCAL_MACHINE,
    HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER, HKEY_CURRENT_USER,
    HKEY_CURRENT_USER);
  SA_PRE: array[0..5] of string = ('HKLM','HKLM','HKLM','HKCU','HKCU','HKCU');
  SA_SUB: array[0..5] of string = (
    'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run',
    'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\RunOnce',
    'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder',
    'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run',
    'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\RunOnce',
    'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder');
  SA_ACC: array[0..5] of LongWord = (REGVIEW_64, REGVIEW_64, REGVIEW_64,
    KEY_READ, KEY_READ, KEY_READ);
var
  I, J: Integer;
  Vals: TStringList;
  Conf: TLeftoverConfidence;
begin
  Vals := TStringList.Create;
  try
    for I := Low(SA_SUB) to High(SA_SUB) do
    begin
      Vals.Clear;
      RegEnumValues(SA_HIVE[I], SA_SUB[I], SA_ACC[I], Vals);
      for J := 0 to Vals.Count - 1 do
        if ACtx.MatchName(Vals[J], Conf) or ACtx.MatchesText(Vals[J]) then
          AddReg(AList, SA_PRE[I] + '\' + SA_SUB[I] + '\' + Vals[J],
                 SA_PRE[I] + '\' + SA_SUB[I] + ' -> ' + Vals[J],
                 'Startup approval shadow entry', ltRegistryValue,
                 lcSafe, True, SA_PRE[I] + '\' + SA_SUB[I]);
    end;
  finally
    Vals.Free;
  end;
end;

procedure TRegistryLeftoverScanner.ScanBam(ACtx: TScanContext;
  AList: TLeftoverList);
const
  BAM_SUB: array[0..1] of string = (
    'SYSTEM\CurrentControlSet\Services\bam\State\UserSettings',
    'SYSTEM\CurrentControlSet\Services\bam\UserSettings');
var
  Sids, Vals: TStringList;
  I, J, K: Integer;
  Base: string;
begin
  Sids := TStringList.Create;
  Vals := TStringList.Create;
  try
    for I := Low(BAM_SUB) to High(BAM_SUB) do
    begin
      Sids.Clear;
      RegEnumSubKeys(HKEY_LOCAL_MACHINE, BAM_SUB[I], REGVIEW_64, Sids);
      for J := 0 to Sids.Count - 1 do
      begin
        Base := BAM_SUB[I] + '\' + Sids[J];
        Vals.Clear;
        RegEnumValues(HKEY_LOCAL_MACHINE, Base, REGVIEW_64, Vals);
        for K := 0 to Vals.Count - 1 do
          if ACtx.MatchesText(Vals[K]) then
            AddReg(AList, 'HKLM\' + Base + '\' + Vals[K],
                   'HKLM\' + Base + ' -> ' + Vals[K],
                   'Background Activity Moderator trace', ltRegistryValue,
                   lcSafe, True, 'HKLM\' + Base);
      end;
    end;
  finally
    Sids.Free;
    Vals.Free;
  end;
end;

procedure TRegistryLeftoverScanner.ScanRecentApps(ACtx: TScanContext;
  AList: TLeftoverList);
const
  RA = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Search\RecentApps';
var
  Guids, Vals: TStringList;
  I, J: Integer;
  Base, Data: string;
begin
  Guids := TStringList.Create;
  Vals := TStringList.Create;
  try
    RegEnumSubKeys(HKEY_CURRENT_USER, RA, KEY_READ, Guids);
    for I := 0 to Guids.Count - 1 do
    begin
      Base := RA + '\' + Guids[I];
      Vals.Clear;
      RegEnumValues(HKEY_CURRENT_USER, Base, KEY_READ, Vals);
      for J := 0 to Vals.Count - 1 do
      begin
        Data := RegReadString(HKEY_CURRENT_USER, Base, Vals[J], KEY_READ);
        if ACtx.MatchesText(Vals[J]) or ACtx.MatchesText(Data) then
        begin
          AddReg(AList, 'HKCU\' + Base, 'HKCU\' + Base,
                 'RecentApps usage record: ' + Data,
                 ltRegistryKey, lcModerate, False);
          Break;
        end;
      end;
    end;
  finally
    Guids.Free;
    Vals.Free;
  end;
end;

procedure TRegistryLeftoverScanner.ScanUserAssist(ACtx: TScanContext;
  AList: TLeftoverList);
const
  UA = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\UserAssist';
var
  Guids, Vals: TStringList;
  I, J: Integer;
  Base, Decoded: string;
begin
  Guids := TStringList.Create;
  Vals := TStringList.Create;
  try
    RegEnumSubKeys(HKEY_CURRENT_USER, UA, KEY_READ, Guids);
    for I := 0 to Guids.Count - 1 do
    begin
      Base := UA + '\' + Guids[I] + '\Count';
      Vals.Clear;
      RegEnumValues(HKEY_CURRENT_USER, Base, KEY_READ, Vals);
      for J := 0 to Vals.Count - 1 do
      begin
        Decoded := Rot13(Vals[J]);
        if ACtx.MatchesText(Decoded) then
          AddReg(AList, 'HKCU\' + Base + '\' + Vals[J],
                 'HKCU\' + Base + ' -> ' + Decoded,
                 'UserAssist run counter', ltRegistryValue, lcSafe, True,
                 'HKCU\' + Base);
      end;
    end;
  finally
    Guids.Free;
    Vals.Free;
  end;
end;

procedure TRegistryLeftoverScanner.ScanPathEnv(ACtx: TScanContext;
  AList: TLeftoverList);
const
  ENV_HIVE: array[0..1] of HKEY = (HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE);
  ENV_PRE: array[0..1] of string = ('HKCU', 'HKLM');
  ENV_SUB: array[0..1] of string = (
    'Environment',
    'SYSTEM\CurrentControlSet\Control\Session Manager\Environment');
  ENV_ACC: array[0..1] of LongWord = (KEY_READ, REGVIEW_64);
var
  I: Integer;
  PathVal: string;
begin
  if ACtx.InstallPath = '' then Exit;
  for I := Low(ENV_SUB) to High(ENV_SUB) do
  begin
    PathVal := RegReadString(ENV_HIVE[I], ENV_SUB[I], 'Path', ENV_ACC[I]);
    if (PathVal <> '') and
       (Pos(LowerCase(ACtx.InstallPath), LowerCase(PathVal)) > 0) then
      AddReg(AList, ENV_PRE[I] + '\' + ENV_SUB[I] + '\Path',
             ENV_PRE[I] + '\' + ENV_SUB[I] + ' -> Path',
             'PATH contains install dir — edit manually, do NOT delete value',
             ltRegistryValue, lcInfo, False, ENV_PRE[I] + '\' + ENV_SUB[I]);
  end;
end;

procedure TRegistryLeftoverScanner.ScanTaskCache(ACtx: TScanContext;
  AList: TLeftoverList);

  procedure ScanTreeLevel(const ASub, APrefix: string; ADepth: Integer);
  var
    Names: TStringList;
    K: Integer;
    TaskName: string;
    Conf: TLeftoverConfidence;
  begin
    if ADepth > 2 then Exit;
    Names := TStringList.Create;
    try
      RegEnumSubKeys(HKEY_LOCAL_MACHINE, ASub, REGVIEW_64, Names);
      for K := 0 to Names.Count - 1 do
      begin
        TaskName := APrefix + Names[K];
        if ACtx.MatchName(Names[K], Conf) and
           IsTaskSafeToDelete('\' + TaskName) then
          AddReg(AList, 'TASK\' + TaskName,
                 'Scheduled task: ' + TaskName,
                 'HKLM\...\Schedule\TaskCache\Tree\' + TaskName,
                 ltScheduledTask, lcModerate, False);
        ScanTreeLevel(ASub + '\' + Names[K], TaskName + '\', ADepth + 1);
      end;
    finally
      Names.Free;
    end;
  end;

begin
  ScanTreeLevel(
    'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree',
    '', 0);
end;

{ ═══════════════ File leftover scanner ═══════════════ }

constructor TFileLeftoverScanner.Create;
begin
  FSeen := TStringList.Create;
  FSeen.Sorted := True;
  FSeen.CaseSensitive := False;
  FSeen.Duplicates := dupIgnore;
end;

destructor TFileLeftoverScanner.Destroy;
begin
  FSeen.Free;
  inherited;
end;

procedure TFileLeftoverScanner.AddFile(AList: TLeftoverList;
  const APath, ADetails: string; AConf: TLeftoverConfidence;
  ASelected: Boolean);
var
  I: TLeftoverItem;
  IsDir, LiveExe: Boolean;
  Norm, Det: string;
begin
  Norm := NormalizePath(APath);
  if Norm = '' then Exit;
  if FSeen.IndexOf(Norm) >= 0 then Exit;
  IsDir := DirectoryExists(Norm);
  if (not IsDir) and (not FileExists(Norm)) then Exit;
  { A dir still containing a runnable .exe (or a matched .exe file
    itself) is a working copy, not a leftover — force review-only.
    lcRisky is a hard barrier: cs.uninstall refuses risky items even
    when checked. }
  if IsDir then
    LiveExe := DirHasLiveExe(Norm)
  else
    LiveExe := SameText(ExtractFileExt(Norm), '.exe') and
               (not IsGenericInstallerName(
                  ChangeFileExt(ExtractFileName(Norm), '')));
  Det := ADetails;
  if LiveExe then
  begin
    AConf := lcRisky;
    ASelected := False;
    Det := Det + '; contains a runnable .exe — likely a live copy';
  end;
  FSeen.Add(Norm);
  I := TLeftoverItem.Create;
  I.Path := Norm;
  I.DisplayPath := Norm;
  if IsDir then I.ItemType := ltFolder else I.ItemType := ltFile;
  I.Confidence := AConf;
  I.IsSelected := ASelected;
  I.Details := Det;
  if IsDir then
    I.SizeBytes := DirectorySize(Norm)
  else
    I.SizeBytes := GetFileSizeBytes(Norm);
  AList.Add(I);
end;

procedure TFileLeftoverScanner.ScanDir(ACtx: TScanContext;
  const ADir, ALabel: string; AList: TLeftoverList);
var
  SR: TSearchRec;
  R: Integer;
  Full: string;
  Conf: TLeftoverConfidence;
begin
  if (ADir = '') or (not DirectoryExists(ADir)) then Exit;
  R := FindFirst(IncludeTrailingPathDelimiter(ADir) + '*', faAnyFile, SR);
  try
    while R = 0 do
    begin
      if (SR.Name <> '.') and (SR.Name <> '..') then
      begin
        Full := IncludeTrailingPathDelimiter(ADir) + SR.Name;
        if ACtx.MatchPath(SR.Name, Full, Conf) or
           ACtx.MatchPath(ChangeFileExt(SR.Name, ''), Full, Conf) then
          AddFile(AList, Full, ALabel, Conf, Conf = lcSafe);
      end;
      R := FindNext(SR);
    end;
  finally
    SysUtils.FindClose(SR);
  end;
end;

procedure TFileLeftoverScanner.ScanShortcuts(ACtx: TScanContext;
  const ADir, ALabel: string; AList: TLeftoverList);
var
  Files: TStringList;
  J: Integer;
  Conf: TLeftoverConfidence;
  Grp, Root: string;
begin
  if (ADir = '') or (not DirectoryExists(ADir)) then Exit;
  Root := ExcludeTrailingPathDelimiter(ADir);
  Files := TStringList.Create;
  try
    SafeEnumFiles(ADir, '*', Files);
    for J := 0 to Files.Count - 1 do
      if (LowerCase(ExtractFileExt(Files[J])) = '.lnk') and
         ACtx.MatchPath(ChangeFileExt(ExtractFileName(Files[J]), ''),
                        Files[J], Conf) then
      begin
        AddFile(AList, Files[J], ALabel, Conf, Conf = lcSafe);
        { If the shortcut sits in a product-named program group
          (Start Menu\Programs\AppName\...), propose the folder too —
          otherwise an empty group folder is left behind. }
        Grp := ExtractFileDir(Files[J]);
        if (Length(Grp) > Length(Root)) and
           ACtx.MatchName(ExtractFileName(Grp), Conf) then
          AddFile(AList, Grp, 'Start Menu program group', Conf,
                  Conf = lcSafe);
      end;
  finally
    Files.Free;
  end;
end;

procedure TFileLeftoverScanner.ScanTempFolders(ACtx: TScanContext;
  AList: TLeftoverList);
var
  TempDir: string;
  SR: TSearchRec;
  R, I, J: Integer;
  L: string;
begin
  // Every temp root: user %TEMP%/%TMP% and Windows\Temp.
  for J := 0 to GTempRoots.Count - 1 do
  begin
    TempDir := GTempRoots[J];
    if not DirectoryExists(TempDir) then Continue;
    R := FindFirst(IncludeTrailingPathDelimiter(TempDir) + '*',
                   faAnyFile, SR);
    try
      while R = 0 do
      begin
        if (SR.Name <> '.') and (SR.Name <> '..') then
        begin
          L := LowerCase(SR.Name);
          for I := 0 to ACtx.PrimaryContains.Count - 1 do
            if Pos(ACtx.PrimaryContains[I], L) > 0 then
            begin
              AddFile(AList, IncludeTrailingPathDelimiter(TempDir) +
                      SR.Name, 'Temporary files', lcSafe, True);
              Break;
            end;
        end;
        R := FindNext(SR);
      end;
    finally
      SysUtils.FindClose(SR);
    end;
  end;
end;

procedure TFileLeftoverScanner.ScanPrefetch(ACtx: TScanContext;
  AList: TLeftoverList);
var
  PF: string;
  SR: TSearchRec;
  R, I: Integer;
  L: string;
begin
  PF := GWinDir + '\Prefetch';
  if not DirectoryExists(PF) then Exit;
  R := FindFirst(PF + '\*.pf', faAnyFile, SR);
  try
    while R = 0 do
    begin
      L := LowerCase(SR.Name);
      for I := 0 to ACtx.PrimaryContains.Count - 1 do
        if Pos(ACtx.PrimaryContains[I] + '-', L) = 1 then
        begin
          AddFile(AList, PF + '\' + SR.Name, 'Prefetch trace',
                  lcModerate, False);
          Break;
        end;
      R := FindNext(SR);
    end;
  finally
    SysUtils.FindClose(SR);
  end;
end;


procedure TFileLeftoverScanner.ScanVirtualStore(ACtx: TScanContext;
  AList: TLeftoverList);
const
  VS_SUB: array[0..3] of string = ('Program Files', 'Program Files (x86)',
                                   'ProgramData', 'Windows');
var
  VS: string;
  I: Integer;
begin
  VS := GetSpecialFolder(CSIDL_LOCAL_APPDATA);
  if VS = '' then Exit;
  VS := IncludeTrailingPathDelimiter(VS) + 'VirtualStore';
  for I := Low(VS_SUB) to High(VS_SUB) do
    ScanDir(ACtx, VS + '\' + VS_SUB[I], 'UAC VirtualStore', AList);
end;

{ True when file bytes contain the needle (ANSI or UTF-16LE, lowercase). }
function FileContainsText(const AFile, ANeedle: string): Boolean;
var
  FS: TFileStream;
  Buf: array of Byte;
  L, Wide: string;
  I: Integer;
begin
  Result := False;
  if Length(ANeedle) < 4 then Exit;
  try
    FS := TFileStream.Create(AFile, fmOpenRead or fmShareDenyNone);
    try
      if FS.Size > 512 * 1024 then Exit; // sanity cap
      SetLength(Buf, FS.Size);
      FS.ReadBuffer(Buf[0], FS.Size);
    finally
      FS.Free;
    end;
  except
    Exit;
  end;
  L := LowerCase(ANeedle);
  // UTF-16LE needle
  Wide := '';
  for I := 1 to Length(L) do
    Wide := Wide + L[I] + #0;
  Result := (Pos(L, PAnsiChar(@Buf[0])) > 0) or
            (Pos(Wide, PAnsiChar(@Buf[0])) > 0);
end;

procedure TFileLeftoverScanner.ScanJumpLists(ACtx: TScanContext;
  AList: TLeftoverList);
const
  JL_SUB: array[0..1] of string = ('AutomaticDestinations',
                                   'CustomDestinations');
var
  RA, D, Full, Needle: string;
  SR: TSearchRec;
  R, I: Integer;
begin
  RA := GetSpecialFolder(CSIDL_APPDATA);
  if RA = '' then Exit;
  // Needle: install path (best) or exe name
  if ACtx.InstallPath <> '' then
    Needle := ACtx.InstallPath
  else
    Needle := ACtx.ExeName;
  if Needle = '' then Exit;
  for I := Low(JL_SUB) to High(JL_SUB) do
  begin
    D := RA + '\Microsoft\Windows\Recent\' + JL_SUB[I];
    if not DirectoryExists(D) then Continue;
    R := FindFirst(D + '\*.*s-ms', faAnyFile, SR);
    try
      while R = 0 do
      begin
        Full := D + '\' + SR.Name;
        if (SR.Name <> '.') and (SR.Name <> '..') and
           FileContainsText(Full, Needle) then
          AddFile(AList, Full, 'Jump list cache', lcSafe, True);
        R := FindNext(SR);
      end;
    finally
      SysUtils.FindClose(SR);
    end;
  end;
end;

procedure TFileLeftoverScanner.ScanDocuments(ACtx: TScanContext;
  AList: TLeftoverList);
var
  SR: TSearchRec;
  R: Integer;
  Docs: array[0..1] of string;
  I: Integer;
  Full: string;
  Conf: TLeftoverConfidence;
begin
  Docs[0] := GetSpecialFolder(CSIDL_PERSONAL_L);
  Docs[1] := GetSpecialFolder(CSIDL_COMMON_DOCUMENTS_L);
  for I := Low(Docs) to High(Docs) do
  begin
    if (Docs[I] = '') or (not DirectoryExists(Docs[I])) then Continue;
    R := FindFirst(IncludeTrailingPathDelimiter(Docs[I]) + '*',
                   faAnyFile, SR);
    try
      while R = 0 do
      begin
        if (SR.Name <> '.') and (SR.Name <> '..') then
        begin
          Full := IncludeTrailingPathDelimiter(Docs[I]) + SR.Name;
          // User data area: never auto-select, cap at Moderate
          if ACtx.MatchPath(SR.Name, Full, Conf) or
             ACtx.MatchPath(ChangeFileExt(SR.Name, ''), Full, Conf) then
            AddFile(AList, Full, 'Documents folder (user data — review)',
                    lcModerate, False);
        end;
        R := FindNext(SR);
      end;
    finally
      SysUtils.FindClose(SR);
    end;
  end;
end;

procedure TFileLeftoverScanner.ScanForLeftovers(
  ACtx: TScanContext; AMode: TScanMode; AList: TLeftoverList);
var
  Sig: TLeftoverSignature;
  I: Integer;
  P, LocalLow: string;
begin
  FSeen.Clear;

  Sig := FindSignature(ACtx.Target.DisplayName);
  if Sig <> nil then
    for I := 0 to Sig.FilePaths.Count - 1 do
    begin
      P := ExpandEnvVars(Sig.FilePaths[I]);
      if not IsPathSafeToDelete(P) then Continue;
      if DirectoryExists(P) or FileExists(P) then
        AddFile(AList, P, 'Known leftover (signature match)', lcSafe, True);
    end;

  // Install location itself
  if (ACtx.InstallPath <> '') and DirectoryExists(ACtx.InstallPath) then
    AddFile(AList, ACtx.InstallPath, 'Install location', lcSafe, True);

  // Install-location area by name — catches orphans with empty
  // InstallLocation and secondary dirs (Geek-style)
  ScanDir(ACtx, GProgramFiles, 'Program Files', AList);
  ScanDir(ACtx, GProgramFilesX86, 'Program Files', AList);
  ScanDir(ACtx, GProgramData, 'ProgramData', AList);
  ScanDir(ACtx, GetSpecialFolder(CSIDL_APPDATA), 'Application data', AList);
  ScanDir(ACtx, GetSpecialFolder(CSIDL_LOCAL_APPDATA), 'Application data', AList);
  // LocalLow has no CSIDL — derive from LocalAppData
  LocalLow := ExtractFileDir(GetSpecialFolder(CSIDL_LOCAL_APPDATA))
              + '\LocalLow';
  ScanDir(ACtx, LocalLow, 'LocalLow app data', AList);
  ScanVirtualStore(ACtx, AList);
  ScanJumpLists(ACtx, AList);
  ScanDocuments(ACtx, AList);
  if AMode >= smModerate then
    ScanTempFolders(ACtx, AList);
  ScanShortcuts(ACtx, GetSpecialFolder(CSIDL_PROGRAMS),
                'Start Menu shortcut', AList);
  ScanShortcuts(ACtx, GetSpecialFolder(CSIDL_COMMON_PROGRAMS),
                'Start Menu shortcut', AList);
  ScanShortcuts(ACtx, GetSpecialFolder(CSIDL_DESKTOPDIRECTORY),
                'Desktop shortcut', AList);
  ScanShortcuts(ACtx, GetSpecialFolder(CSIDL_COMMON_DESKTOPDIRECTORY),
                'Desktop shortcut', AList);
  ScanShortcuts(ACtx, GetSpecialFolder(CSIDL_SENDTO_L),
                'SendTo shortcut', AList);
  ScanShortcuts(ACtx, GetSpecialFolder(CSIDL_APPDATA) +
                '\Microsoft\Internet Explorer\Quick Launch',
                'Quick Launch shortcut', AList);
  if AMode >= smAdvanced then
    ScanPrefetch(ACtx, AList);

  // Ownership/safety gate
  for I := 0 to AList.Count - 1 do
    if (not IsPathSafeToDelete(AList[I].Path)) or
       ACtx.OwnedByOther(AList[I].Path) then
    begin
      AList[I].IsSelected := False;
      if AList[I].Confidence <> lcRisky then
        AList[I].Confidence := lcRisky;
      AList[I].Details := AList[I].Details +
        '; review-only (protected or shared)';
    end;
end;

end.
