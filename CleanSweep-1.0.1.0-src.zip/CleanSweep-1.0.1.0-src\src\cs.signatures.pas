unit cs.signatures;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, fgl;

type
  TLeftoverSignature = class
    Name: string;
    Aliases: TStringList;
    FilePaths: TStringList;      // raw templates with %EnvVars%
    RegistryPaths: TStringList;  // HKLM\..., HKCU\...
    constructor Create;
    destructor Destroy; override;
  end;

  TSignatureList = specialize TFPGObjectList<TLeftoverSignature>;

{ Loads leftover-signatures.json once. Thread-hostile — call from main
  thread at startup. }
procedure LoadSignatures(const AJsonPath: string);

{ Same, but reads the JSON from an RCDATA resource embedded in the exe —
  the single-file fallback when no external file ships. }
procedure LoadSignaturesFromResource(const AResName: string);

{ Finds a signature whose name or any alias matches the display name
  (case-insensitive equality or containment). }
function FindSignature(const ADisplayName: string): TLeftoverSignature;

implementation

uses
  Windows, fpjson, jsonparser, cs.utils;

var
  GSignatures: TSignatureList;

procedure ParseSignatures(AStream: TStream);
var
  Data: TJSONData;
  Arr: TJSONArray;
  Obj: TJSONObject;
  Sig: TLeftoverSignature;
  I: Integer;
  JA: TJSONArray;

  procedure FillList(AField: string; AList: TStringList);
  var
    K: Integer;
  begin
    JA := Obj.Arrays[AField];
    if JA = nil then Exit;
    for K := 0 to JA.Count - 1 do
      AList.Add(JA.Strings[K]);
  end;

begin
  if GSignatures = nil then
    GSignatures := TSignatureList.Create(True);
  try
    Data := GetJSON(AStream);
  except
    // a broken user-edited JSON must not take the app down at startup —
    // signatures are a hint layer, not a dependency
    on E: Exception do
    begin
      LogToFile('leftover-signatures: parse failed: ' + E.Message);
      Exit;
    end;
  end;
  try
    if not (Data is TJSONArray) then Exit;
    Arr := TJSONArray(Data);
    for I := 0 to Arr.Count - 1 do
    begin
      if not (Arr.Items[I] is TJSONObject) then Continue;
      Obj := TJSONObject(Arr.Items[I]);
      Sig := TLeftoverSignature.Create;
      Sig.Name := Obj.Get('name', '');
      FillList('aliases', Sig.Aliases);
      FillList('files', Sig.FilePaths);
      FillList('registry', Sig.RegistryPaths);
      GSignatures.Add(Sig);
    end;
  finally
    Data.Free;
  end;
end;

procedure LoadSignatures(const AJsonPath: string);
var
  FS: TFileStream;
begin
  if not FileExists(AJsonPath) then Exit;
  FS := TFileStream.Create(AJsonPath, fmOpenRead or fmShareDenyNone);
  try
    ParseSignatures(FS);
  finally
    FS.Free;
  end;
end;

procedure LoadSignaturesFromResource(const AResName: string);
var
  RS: TResourceStream;
begin
  if FindResource(HInstance, PChar(AResName), RT_RCDATA) = 0 then Exit;
  RS := TResourceStream.Create(HInstance, AResName, RT_RCDATA);
  try
    ParseSignatures(RS);
  finally
    RS.Free;
  end;
end;

function FindSignature(const ADisplayName: string): TLeftoverSignature;
var
  I, J: Integer;
  N, A: string;
begin
  Result := nil;
  if GSignatures = nil then Exit;
  N := LowerCase(Trim(ADisplayName));
  if N = '' then Exit;
  for I := 0 to GSignatures.Count - 1 do
  begin
    if LowerCase(GSignatures[I].Name) = N then
      Exit(GSignatures[I]);
    for J := 0 to GSignatures[I].Aliases.Count - 1 do
    begin
      A := LowerCase(GSignatures[I].Aliases[J]);
      if (A = N) or ((Length(A) >= 4) and (Pos(A, N) > 0)) then
        Exit(GSignatures[I]);
    end;
  end;
end;

{ TLeftoverSignature }

constructor TLeftoverSignature.Create;
begin
  Aliases := TStringList.Create;
  FilePaths := TStringList.Create;
  RegistryPaths := TStringList.Create;
end;

destructor TLeftoverSignature.Destroy;
begin
  Aliases.Free;
  FilePaths.Free;
  RegistryPaths.Free;
  inherited;
end;

initialization
  GSignatures := nil;

finalization
  GSignatures.Free;

end.
