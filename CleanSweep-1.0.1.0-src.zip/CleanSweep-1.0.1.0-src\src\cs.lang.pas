unit cs.lang;

{$mode objfpc}{$H+}

interface

type
  TLang = (lgRU, lgBE, lgUK, lgEN);

{ UI language detected from the Windows UI language; Russian when the
  system language is anything we do not ship. }
function Lang: TLang;

{ Picks one of four strings for the current language (RU, BE, UK, EN). }
function Lg(const ARu, ABe, AUk, AEn: string): string;

{ Slavic 3-form plural for RU/BE/UK; EN uses F1 for 1, F5 otherwise. }
function PluralForm(N: Integer; const F1, F2, F5: string): string;

implementation

function GetUserDefaultUILanguage: Word; stdcall; external 'kernel32.dll';

var
  GLang: TLang = lgRU;
  GLangInit: Boolean = False;

function Lang: TLang;
begin
  if not GLangInit then
  begin
    GLangInit := True;
    case GetUserDefaultUILanguage and $3FF of // PRIMARYLANGID
      $23: GLang := lgBE; // LANG_BELARUSIAN
      $22: GLang := lgUK; // LANG_UKRAINIAN
      $09: GLang := lgEN; // LANG_ENGLISH
    else
      GLang := lgRU;      // Russian default, incl. LANG_RUSSIAN $19
    end;
  end;
  Result := GLang;
end;

function Lg(const ARu, ABe, AUk, AEn: string): string;
begin
  case Lang of
    lgBE: Result := ABe;
    lgUK: Result := AUk;
    lgEN: Result := AEn;
  else
    Result := ARu;
  end;
end;

function PluralForm(N: Integer; const F1, F2, F5: string): string;
begin
  if Lang = lgEN then
    if N = 1 then Exit(F1) else Exit(F5);
  N := Abs(N) mod 100;
  if (N >= 11) and (N <= 19) then Exit(F5);
  case N mod 10 of
    1: Result := F1;
    2..4: Result := F2;
  else
    Result := F5;
  end;
end;

end.
