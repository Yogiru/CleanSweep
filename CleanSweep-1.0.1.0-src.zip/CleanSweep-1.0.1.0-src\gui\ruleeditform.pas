unit ruleeditform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls, Dialogs, ComCtrls,
  cs.winapp2, cs.cleaner, cs.utils, cs.lang, pickform, previewform;

{ Modal rule editor for Custom\*.ini files. AFilePath='' creates a new
  rule; an existing file is parsed (permissive — detection-less rules
  are legal here), its entries round-trip through EntryToIni on save.
  Preview runs the REAL TCleaningService.Analyze on the edited entry —
  same expansion, exclusions and safety gates as the actual clean. }
function EditRuleDialog(AOwner: TComponent;
  const AFilePath: string): TModalResult;

type
  TRuleEditForm = class(TForm)
    lblName: TLabel;
    edtName: TEdit;
    lblSection: TLabel;
    cmbSection: TComboBox;
    chkDefault: TCheckBox;
    lblWarning: TLabel;
    edtWarning: TEdit;
    pgcMain: TPageControl;
    tabFiles: TTabSheet;
    tabReg: TTabSheet;
    tabExcl: TTabSheet;
    tabDet: TTabSheet;
    lvFK: TListView;
    lblFKPath: TLabel;
    edtFKPath: TEdit;
    btnFKBrowse: TButton;
    lblFKMask: TLabel;
    edtFKMask: TEdit;
    chkFKRecurse: TCheckBox;
    chkFKRemoveSelf: TCheckBox;
    btnFKApply: TButton;
    btnFKDel: TButton;
    lvRK: TListView;
    cmbRKHive: TComboBox;
    lblRKPath: TLabel;
    edtRKPath: TEdit;
    lblRKValue: TLabel;
    edtRKValue: TEdit;
    btnRKApply: TButton;
    btnRKDel: TButton;
    lvEX: TListView;
    cmbEXType: TComboBox;
    lblEXPath: TLabel;
    edtEXPath: TEdit;
    lblEXMask: TLabel;
    edtEXMask: TEdit;
    btnEXApply: TButton;
    btnEXDel: TButton;
    lvDT: TListView;
    cmbDTType: TComboBox;
    edtDTValue: TEdit;
    lblDTHint: TLabel;
    btnDTApply: TButton;
    btnDTDel: TButton;
    lblSpecialDetect: TLabel;
    cmbSpecialDetect: TComboBox;
    lblDetectOS: TLabel;
    edtDetectOS: TEdit;
    btnPreview: TButton;
    btnSave: TButton;
    btnCancel: TButton;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure LvFKSelectItem(Sender: TObject; AItem: TListItem;
      ASelected: Boolean);
    procedure LvRKSelectItem(Sender: TObject; AItem: TListItem;
      ASelected: Boolean);
    procedure LvEXSelectItem(Sender: TObject; AItem: TListItem;
      ASelected: Boolean);
    procedure LvDTSelectItem(Sender: TObject; AItem: TListItem;
      ASelected: Boolean);
    procedure BtnFKBrowseClick(Sender: TObject);
    procedure BtnFKApplyClick(Sender: TObject);
    procedure BtnFKDelClick(Sender: TObject);
    procedure BtnRKApplyClick(Sender: TObject);
    procedure BtnRKDelClick(Sender: TObject);
    procedure BtnEXApplyClick(Sender: TObject);
    procedure BtnEXDelClick(Sender: TObject);
    procedure BtnDTApplyClick(Sender: TObject);
    procedure BtnDTDelClick(Sender: TObject);
    procedure BtnPreviewClick(Sender: TObject);
    procedure BtnSaveClick(Sender: TObject);
  private
    FFilePath: string;             // '' → new rule
    FEntries: TCleanerEntryList;   // all entries of the opened file
    FEditIdx: Integer;             // which one this editor owns
    FSpecial: string;              // Special= carried through untouched
    function UiToEntry: TCleanerEntry;
    procedure PopulateFrom(const AEntry: TCleanerEntry);
    function BuildIniText: string;
    procedure LoadFile(const APath: string);
  end;

implementation

{$R *.lfm}

function EditRuleDialog(AOwner: TComponent;
  const AFilePath: string): TModalResult;
var
  F: TRuleEditForm;
begin
  F := TRuleEditForm.Create(AOwner);
  F.FFilePath := AFilePath;
  try
    if (AFilePath <> '') and FileExists(AFilePath) then
      F.LoadFile(AFilePath);
    Result := F.ShowModal;
  finally
    F.Free;
  end;
end;

{ When the opened file holds several entries the user picks which one
  to edit; the rest round-trip back into the file unchanged
  (ini comments/formatting are regenerated — that is documented). }
function PickEntry(const AEntries: TCleanerEntryList;
  AOwner: TWinControl): Integer;
var
  Names: TStringList;
  E: TCleanerEntry;
begin
  Names := TStringList.Create;
  try
    for E in AEntries do Names.Add(E.Name);
    Result := PickIndex(AOwner,
      Lg('Выбор записи', 'Выбар запісу', 'Вибір запису', 'Pick entry'),
      Names);
  finally
    Names.Free;
  end;
end;

procedure TRuleEditForm.LoadFile(const APath: string);
var
  P: TWinapp2Parser;
begin
  P := TWinapp2Parser.Create(True);   // permissive — same as the merge
  try
    FEntries := P.ParseFile(APath);
  finally
    P.Free;
  end;
  FEditIdx := PickEntry(FEntries, Self);
  if FEditIdx >= 0 then
    PopulateFrom(FEntries[FEditIdx]);
end;

procedure TRuleEditForm.FormCreate(Sender: TObject);
begin
  Caption := Lg('Редактор правила', 'Рэдактар правіла',
                'Редактор правила', 'Rule editor');
  lblName.Caption := Lg('Имя записи', 'Імя запісу', 'Ім''я запису',
                        'Entry name');
  lblSection.Caption := Lg('Категория', 'Катэгорыя', 'Категорія',
                           'Section');
  chkDefault.Caption := Lg('Отмечать по умолчанию', 'Адзначаць па змаўчанні',
                           'Позначати типово', 'Checked by default');
  lblWarning.Caption := Lg('Предупреждение', 'Папярэджанне',
                         'Попередження', 'Warning');
  tabFiles.Caption := Lg('Файлы (FileKey)', 'Файлы (FileKey)',
                         'Файли (FileKey)', 'Files (FileKey)');
  tabReg.Caption := Lg('Реестр (RegKey)', 'Рэестр (RegKey)',
                       'Реєстр (RegKey)', 'Registry (RegKey)');
  tabExcl.Caption := Lg('Исключения (ExcludeKey)', 'Выключэнні (ExcludeKey)',
                        'Виключення (ExcludeKey)', 'Excludes (ExcludeKey)');
  tabDet.Caption := Lg('Детекция', 'Дэтэкцыя', 'Детекція', 'Detection');
  btnPreview.Caption := Lg('Проверить…', 'Праверыць…', 'Перевірити…',
                           'Preview…');
  btnSave.Caption := Lg('Сохранить', 'Захаваць', 'Зберегти', 'Save');
  btnCancel.Caption := Lg('Отмена', 'Адмена', 'Скасувати', 'Cancel');
  cmbRKHive.ItemIndex := 0;
  cmbEXType.ItemIndex := 0;
  cmbDTType.ItemIndex := 0;
  FEntries := nil;
  FEditIdx := -1;
  FSpecial := '';
end;

procedure TRuleEditForm.FormDestroy(Sender: TObject);
begin
  FEntries.Free;
end;

{ --- row helpers ----------------------------------------------------- }

procedure ApplyRow(ALv: TListView; const ACaption: string;
  const ASubs: array of string);
var
  It: TListItem;
  I: Integer;
begin
  It := ALv.Selected;
  if It = nil then
  begin
    It := ALv.Items.Add;
    It.Caption := ACaption;
  end
  else
    It.Caption := ACaption;
  It.SubItems.Clear;
  for I := Low(ASubs) to High(ASubs) do
    It.SubItems.Add(ASubs[I]);
  ALv.Selected := nil;
end;

procedure TRuleEditForm.LvFKSelectItem(Sender: TObject; AItem: TListItem;
  ASelected: Boolean);
begin
  btnFKDel.Enabled := ASelected;
  if not ASelected then Exit;
  edtFKPath.Text := AItem.Caption;
  edtFKMask.Text := AItem.SubItems[0];
  chkFKRecurse.Checked := Pos('RECURSE', AItem.SubItems[1]) > 0;
  chkFKRemoveSelf.Checked := Pos('REMOVESELF', AItem.SubItems[1]) > 0;
end;

procedure TRuleEditForm.LvRKSelectItem(Sender: TObject; AItem: TListItem;
  ASelected: Boolean);
var
  P: Integer;
begin
  btnRKDel.Enabled := ASelected;
  if not ASelected then Exit;
  P := Pos('\', AItem.Caption);
  if (P > 0) and (cmbRKHive.Items.IndexOf(Copy(AItem.Caption, 1, P - 1)) >= 0) then
  begin
    cmbRKHive.ItemIndex := cmbRKHive.Items.IndexOf(Copy(AItem.Caption, 1, P - 1));
    edtRKPath.Text := Copy(AItem.Caption, P + 1, MaxInt);
  end
  else
    edtRKPath.Text := AItem.Caption;
  edtRKValue.Text := AItem.SubItems[0];
end;

procedure TRuleEditForm.LvEXSelectItem(Sender: TObject; AItem: TListItem;
  ASelected: Boolean);
begin
  btnEXDel.Enabled := ASelected;
  if not ASelected then Exit;
  cmbEXType.ItemIndex := cmbEXType.Items.IndexOf(AItem.Caption);
  if cmbEXType.ItemIndex < 0 then cmbEXType.ItemIndex := 0;
  edtEXPath.Text := AItem.SubItems[0];
  edtEXMask.Text := AItem.SubItems[1];
end;

procedure TRuleEditForm.LvDTSelectItem(Sender: TObject; AItem: TListItem;
  ASelected: Boolean);
begin
  btnDTDel.Enabled := ASelected;
  if not ASelected then Exit;
  cmbDTType.ItemIndex := cmbDTType.Items.IndexOf(AItem.Caption);
  if cmbDTType.ItemIndex < 0 then cmbDTType.ItemIndex := 0;
  edtDTValue.Text := AItem.SubItems[0];
end;

procedure TRuleEditForm.BtnFKBrowseClick(Sender: TObject);
var
  D: TSelectDirectoryDialog;
begin
  D := TSelectDirectoryDialog.Create(Self);
  try
    D.Title := Lg('Выбор папки', 'Выбар папкі', 'Вибір папки',
                  'Choose folder');
    if D.Execute then
      edtFKPath.Text := D.FileName;
  finally
    D.Free;
  end;
end;

procedure TRuleEditForm.BtnFKApplyClick(Sender: TObject);
var
  Flags: string;
begin
  if Trim(edtFKPath.Text) = '' then Exit;
  Flags := '';
  if chkFKRecurse.Checked then Flags := 'RECURSE';
  if chkFKRemoveSelf.Checked then Flags := 'REMOVESELF';
  ApplyRow(lvFK, Trim(edtFKPath.Text), [Trim(edtFKMask.Text), Flags]);
  edtFKPath.Text := '';
end;

procedure TRuleEditForm.BtnFKDelClick(Sender: TObject);
begin
  if lvFK.Selected <> nil then lvFK.Selected.Delete;
end;

procedure TRuleEditForm.BtnRKApplyClick(Sender: TObject);
var
  P: string;
begin
  P := Trim(edtRKPath.Text);
  if P = '' then Exit;
  if cmbRKHive.ItemIndex >= 0 then
    P := cmbRKHive.Text + '\' + P;
  ApplyRow(lvRK, P, [Trim(edtRKValue.Text)]);
  edtRKPath.Text := '';
  edtRKValue.Text := '';
end;

procedure TRuleEditForm.BtnRKDelClick(Sender: TObject);
begin
  if lvRK.Selected <> nil then lvRK.Selected.Delete;
end;

procedure TRuleEditForm.BtnEXApplyClick(Sender: TObject);
begin
  if Trim(edtEXPath.Text) = '' then Exit;
  ApplyRow(lvEX, cmbEXType.Text,
    [Trim(edtEXPath.Text), Trim(edtEXMask.Text)]);
  edtEXPath.Text := '';
  edtEXMask.Text := '';
end;

procedure TRuleEditForm.BtnEXDelClick(Sender: TObject);
begin
  if lvEX.Selected <> nil then lvEX.Selected.Delete;
end;

procedure TRuleEditForm.BtnDTApplyClick(Sender: TObject);
begin
  if Trim(edtDTValue.Text) = '' then Exit;
  ApplyRow(lvDT, cmbDTType.Text, [Trim(edtDTValue.Text)]);
  edtDTValue.Text := '';
end;

procedure TRuleEditForm.BtnDTDelClick(Sender: TObject);
begin
  if lvDT.Selected <> nil then lvDT.Selected.Delete;
end;

{ --- UI ↔ entry ------------------------------------------------------- }

procedure TRuleEditForm.PopulateFrom(const AEntry: TCleanerEntry);
var
  FK: TFileKeyEntry;
  RK: TRegKeyEntry;
  XK: TExcludeKeyEntry;
  I: Integer;
  S, Fl: string;
  It: TListItem;

  function OsV(const AV: Integer): string;
  begin
    if (AV mod 100) = 0 then Result := IntToStr(AV div 100)
    else Result := IntToStr(AV div 100) + '.' + IntToStr(AV mod 100);
  end;

begin
  edtName.Text := AEntry.Name;
  cmbSection.Text := AEntry.Section;
  chkDefault.Checked := AEntry.Default;
  edtWarning.Text := AEntry.Warning;
  FSpecial := AEntry.Special;
  if AEntry.DetectOSUsed then
  begin
    S := '';
    if AEntry.DetectOSMin >= 0 then S := OsV(AEntry.DetectOSMin);
    if AEntry.DetectOSMax >= 0 then S := S + '|' + OsV(AEntry.DetectOSMax);
    edtDetectOS.Text := S;
  end;
  cmbSpecialDetect.Text := AEntry.SpecialDetect;
  for I := 0 to AEntry.DetectFiles.Count - 1 do
  begin
    It := lvDT.Items.Add;
    It.Caption := 'DetectFile';
    It.SubItems.Add(AEntry.DetectFiles[I]);
  end;
  for I := 0 to AEntry.DetectKeys.Count - 1 do
  begin
    It := lvDT.Items.Add;
    It.Caption := 'Detect';
    It.SubItems.Add(AEntry.DetectKeys[I]);
  end;
  for FK in AEntry.FileKeys do
  begin
    It := lvFK.Items.Add;
    It.Caption := FK.Path;
    It.SubItems.Add(FK.Pattern);
    Fl := '';
    if FK.Flag = fkRecurse then Fl := 'RECURSE'
    else if FK.Flag = fkRemoveSelf then Fl := 'REMOVESELF';
    It.SubItems.Add(Fl);
  end;
  for RK in AEntry.RegKeys do
  begin
    It := lvRK.Items.Add;
    It.Caption := RK.KeyPath;
    It.SubItems.Add(RK.ValueName);
  end;
  for XK in AEntry.ExcludeKeys do
  begin
    It := lvEX.Items.Add;
    case XK.ExType of
      etPath: S := 'PATH';
      etReg:  S := 'REG';
    else
      S := 'FILE';
    end;
    It.Caption := S;
    It.SubItems.Add(XK.Path);
    It.SubItems.Add(XK.Pattern);
  end;
end;

function TRuleEditForm.UiToEntry: TCleanerEntry;
var
  I: Integer;
  FK: TFileKeyEntry;
  RK: TRegKeyEntry;
  XK: TExcludeKeyEntry;
  It: TListItem;
  Sub: string;
begin
  Result := TCleanerEntry.Create;
  Result.Name := Trim(edtName.Text);
  Result.Section := Trim(cmbSection.Text);
  Result.Default := chkDefault.Checked;
  Result.Warning := Trim(edtWarning.Text);
  Result.Special := FSpecial;
  Result.SpecialDetect := Trim(cmbSpecialDetect.Text);
  if Trim(edtDetectOS.Text) <> '' then
    ParseDetectOS(Trim(edtDetectOS.Text), Result);
  for I := 0 to lvDT.Items.Count - 1 do
  begin
    It := lvDT.Items[I];
    if SameText(It.Caption, 'DetectFile') then
      Result.DetectFiles.Add(It.SubItems[0])
    else
      Result.DetectKeys.Add(It.SubItems[0]);
  end;
  for I := 0 to lvFK.Items.Count - 1 do
  begin
    It := lvFK.Items[I];
    FK := TFileKeyEntry.Create;
    FK.Path := It.Caption;
    if It.SubItems.Count > 0 then FK.Pattern := It.SubItems[0];
    Sub := '';
    if It.SubItems.Count > 1 then Sub := UpperCase(It.SubItems[1]);
    if Sub = 'RECURSE' then FK.Flag := fkRecurse
    else if Sub = 'REMOVESELF' then FK.Flag := fkRemoveSelf;
    Result.FileKeys.Add(FK);
  end;
  for I := 0 to lvRK.Items.Count - 1 do
  begin
    It := lvRK.Items[I];
    RK := TRegKeyEntry.Create;
    RK.KeyPath := It.Caption;
    if It.SubItems.Count > 0 then RK.ValueName := It.SubItems[0];
    Result.RegKeys.Add(RK);
  end;
  for I := 0 to lvEX.Items.Count - 1 do
  begin
    It := lvEX.Items[I];
    XK := TExcludeKeyEntry.Create;
    if SameText(It.Caption, 'PATH') then XK.ExType := etPath
    else if SameText(It.Caption, 'REG') then XK.ExType := etReg
    else XK.ExType := etFile;
    if It.SubItems.Count > 0 then XK.Path := It.SubItems[0];
    if It.SubItems.Count > 1 then XK.Pattern := It.SubItems[1];
    Result.ExcludeKeys.Add(XK);
  end;
end;

function TRuleEditForm.BuildIniText: string;
var
  SL, Lines: TStringList;
  I: Integer;
  E: TCleanerEntry;
begin
  SL := TStringList.Create;
  Lines := nil;
  E := nil;
  try
    for I := 0 to FEntries.Count - 1 do
      if I <> FEditIdx then
      begin
        Lines := EntryToIni(FEntries[I]);
        try
          SL.AddStrings(Lines);
          SL.Add('');
        finally
          Lines.Free;
        end;
      end;
    E := UiToEntry;
    Lines := EntryToIni(E);
    try
      SL.AddStrings(Lines);
    finally
      Lines.Free;
      E.Free;
    end;
    Result := SL.Text;
  finally
    SL.Free;
  end;
end;

{ --- preview + save ---------------------------------------------------- }

procedure TRuleEditForm.BtnPreviewClick(Sender: TObject);
var
  P: TWinapp2Parser;
  EL: TCleanerEntryList;
  Svc: TCleaningService;
  Res: TCleanResult;
  C: TCursor;
begin
  // preview parses the generated ini — exactly what the cleaner will see
  P := TWinapp2Parser.Create(True);
  try
    EL := P.Parse(BuildIniText);
  finally
    P.Free;
  end;
  if (EL = nil) or (EL.Count = 0) then
  begin
    EL.Free;
    MessageDlg(Lg('Нет валидной записи для проверки.',
      'Няма сапраўднага запісу для праверкі.',
      'Немає чинного запису для перевірки.',
      'No valid entry to preview.'), mtWarning, [mbOK], 0);
    Exit;
  end;
  C := Screen.Cursor;
  Screen.Cursor := crHourGlass;
  Svc := TCleaningService.Create;
  try
    // the edited entry is the last one emitted by BuildIniText
    Res := Svc.Analyze(EL[EL.Count - 1]);
    try
      ShowCleanResult(Self, Res);
    finally
      Res.Free;
    end;
  finally
    Screen.Cursor := C;
    Svc.Free;
    EL.Free;
  end;
end;

procedure TRuleEditForm.BtnSaveClick(Sender: TObject);
var
  Path, S, Safe: string;
  I: Integer;
begin
  Safe := Trim(edtName.Text);
  if Safe = '' then
  begin
    MessageDlg(Lg('Укажите имя записи.', 'Пазначце імя запісу.',
      'Вкажіть ім''я запису.', 'Enter an entry name.'),
      mtWarning, [mbOK], 0);
    Exit;
  end;
  for I := 1 to Length(Safe) do
    if Safe[I] in ['[', ']', '*', '\', '/', ':', '?', '"', '<', '>', '|'] then
    begin
      MessageDlg(Lg('Имя содержит недопустимый символ.',
        'Імя ўтрымлівае недапушчальны сімвал.',
        'Ім''я містить неприпустимий символ.',
        'The name contains an invalid character.'),
        mtWarning, [mbOK], 0);
      Exit;
    end;
  if FFilePath <> '' then
    Path := FFilePath
  else
    Path := ExtractFilePath(ParamStr(0)) + 'Custom\' + Safe + '.ini';
  if (FFilePath = '') and FileExists(Path) then
    if MessageDlg(Format(Lg('Файл «%s» уже есть — перезаписать?',
        'Файл «%s» ужо ёсць — перазапісаць?',
        'Файл «%s» уже є — перезаписати?',
        '"%s" exists — overwrite?'), [ExtractFileName(Path)]),
        mtConfirmation, [mbYes, mbNo], 0) <> mrYes then Exit;
  S := BuildIniText;
  try
    ForceDirectories(ExtractFilePath(Path));
    with TFileStream.Create(Path, fmCreate) do
      try
        WriteBuffer(PChar(S)^, Length(S));
      finally
        Free;
      end;
  except
    on E: Exception do
    begin
      MessageDlg(E.Message, mtError, [mbOK], 0);
      Exit;
    end;
  end;
  ModalResult := mrOk;
end;

end.
