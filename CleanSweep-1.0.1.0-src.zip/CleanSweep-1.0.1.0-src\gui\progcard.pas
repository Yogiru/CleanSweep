unit progcard;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls, Dialogs,
  Graphics, Buttons, ImgList, cs.models;

type
  { Mini info-card for a program — shown on double-click.
    mrYes = user pressed the uninstall button. }
  TProgramCard = class(TForm)
    btnCancel: TBitBtn;
    btnUninstall: TBitBtn;
    ilButtons: TImageList;
    imgIcon: TImage;
    lblName: TLabel;
    lblSub: TLabel;
    pnlButtons: TPanel;
    pnlDetails: TPanel;
    pnlHeader: TPanel;
    sepButtons: TBevel;
  private
    procedure AddRow(const ACaption, AValue: string);
  public
    constructor CreateDlg(AOwner: TComponent; P: TInstalledProgram);
  end;

function ShowProgramCard(AOwner: TComponent; P: TInstalledProgram): TModalResult;

implementation

{$R *.lfm}

uses
  Windows, cs.utils, cs.lang;

function ShowProgramCard(AOwner: TComponent; P: TInstalledProgram): TModalResult;
var
  F: TProgramCard;
begin
  F := TProgramCard.CreateDlg(AOwner, P);
  try
    Result := F.ShowModal;
  finally
    F.Free;
  end;
end;

{ Adds HICON to the image list, returns its index (or -1). }
function AddIcon(AImages: TImageList; AHandle: HICON): Integer;
var
  Ico: TIcon;
begin
  Result := -1;
  if AHandle = 0 then Exit;
  Ico := TIcon.Create;
  try
    Ico.Handle := AHandle;
    Result := AImages.AddIcon(Ico);
  finally
    Ico.Free; // adopts & destroys the handle
  end;
end;

{ One "Caption:  value" line, stacked top-down in pnlDetails.
  WordWrap + AutoSize let long values take a second line. }
procedure TProgramCard.AddRow(const ACaption, AValue: string);
var
  L: TLabel;
begin
  if Trim(AValue) = '' then Exit;
  L := TLabel.Create(Self);
  L.Parent := pnlDetails;
  L.Caption := ACaption + '  ' + AValue;
  L.Font.Color := $00505050;
  L.Align := alTop;
  L.BorderSpacing.Left := 16;
  L.BorderSpacing.Right := 16;
  L.BorderSpacing.Top := 7;
  L.WordWrap := True;
  L.AutoSize := True;
end;

constructor TProgramCard.CreateDlg(AOwner: TComponent; P: TInstalledProgram);
var
  IcoPath, S: string;
  IcoIdx, NeedH: Integer;
  Ico: TIcon;
begin
  inherited Create(AOwner); // loads progcard.lfm

  IcoIdx := ProgramIconSource(P, IcoPath);

  Ico := TIcon.Create;
  try
    Ico.Handle := GetShellIconPx(IcoPath, IcoIdx, 64);
    if Ico.Handle <> 0 then
      imgIcon.Picture.Icon := Ico;
  finally
    Ico.Free;
  end;

  Caption := Lg('Свойства программы', 'Уласцівасці праграмы',
                'Властивості програми', 'Program properties');
  btnUninstall.Caption := Lg('Деинсталлировать', 'Дэінсталяваць',
                             'Деінсталювати', 'Uninstall');
  btnCancel.Caption := Lg('Отмена', 'Адмена', 'Скасувати', 'Cancel');

  lblName.Caption := P.DisplayName;
  S := P.Publisher;
  if P.DisplayVersion <> '' then
    S := S + '  ·  v' + P.DisplayVersion;
  if P.SourceDisplay <> '' then
    S := S + '  ·  ' + P.SourceDisplay;
  if P.SizeDisplay <> '' then
    S := S + '  ·  ' + P.SizeDisplay;
  lblSub.Caption := S;

  AddRow(Lg('Установлено:', 'Усталявана:', 'Встановлено:', 'Installed:'),
         NormalizeInstallDate(P.InstallDate));
  AddRow(Lg('Каталог:', 'Каталог:', 'Каталог:', 'Folder:'), P.InstallLocation);
  AddRow(Lg('Деинсталлятор:', 'Дэінсталятар:', 'Деінсталятор:', 'Uninstaller:'),
         P.UninstallString);
  AddRow(Lg('Ключ реестра:', 'Ключ рэестра:', 'Ключ реєстру:', 'Registry key:'),
         P.RegistryPath);

  // Fit the window to however many rows actually appeared.
  NeedH := 8;
  if pnlDetails.ControlCount > 0 then
    NeedH := pnlDetails.Controls[pnlDetails.ControlCount - 1].Top +
             pnlDetails.Controls[pnlDetails.ControlCount - 1].Height + 8;
  ClientHeight := pnlHeader.Height + NeedH + pnlButtons.Height;

  AddIcon(ilButtons, GetShellIconPx(IcoPath, IcoIdx, 48));
  AddIcon(ilButtons, LoadIcon(0, MAKEINTRESOURCE(32513))); // IDI_ERROR
end;

end.
