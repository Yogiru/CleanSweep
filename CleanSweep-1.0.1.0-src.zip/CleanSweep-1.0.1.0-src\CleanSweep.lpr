program CleanSweep;

{$mode objfpc}{$H+}

uses
  {$IFDEF UNIX}
  cthreads,
  {$ENDIF}
  Interfaces, // LCL widgetset
  Forms,
  cs.utils,
  mainform;

{$R *.res} // includes CleanSweep.res with the manifest

begin
  DisablePowerThrottling;   // keep background scans off EcoQoS
  RequireDerivedFormResource := True;
  Application.Scaled := True;
  Application.Initialize;
  Application.CreateForm(TMainForm, MainFormWnd);
  Application.Run;
end.
