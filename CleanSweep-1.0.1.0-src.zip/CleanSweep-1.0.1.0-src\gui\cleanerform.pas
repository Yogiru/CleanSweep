unit cleanerform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, StrUtils, Forms, Controls, ComCtrls, StdCtrls, ExtCtrls,
  Dialogs, Graphics, Menus, Clipbrd, fgl, laz.virtualtrees,
  cs.winapp2, cs.cleaner, cs.closeapps, presetform;

type

  { Per-node payload of the entry trees: the entry plus its resolved
    category string (resolved once at populate — OnGetText/OnCompareNodes
    would otherwise rerun ResolveCategory on every paint). The record
    holds a managed string: EntriesInitNode Initializes it,
    EntriesFreeNode Finalizes it. }
  PEntNode = ^TEntNode;
  TEntNode = record
    E: TCleanerEntry;
    Cat: string;
  end;

  TWorkMode = (wmLoad, wmDetect, wmAnalyze, wmClean, wmDownload);

  { Background worker. wmLoad parses the database texts and merges them
    (dedup by entry name); wmDetect probes a slice of entries for
    'is installed'; wmAnalyze builds deletion plans for a slice of
    checked entries; wmClean executes the plans; wmDownload fetches a
    database update. Detection/analyze run in several workers — each
    has its own engine instance (TDetectionService/TCleaningService are
    self-contained). Status lines travel through a queued callback,
    DoneCount/Total feed the progress bar — the TUninstallThread
    pattern from mainform. }
  TCleanerThread = class(TThread)
  private
    FMode: TWorkMode;
    FDbTexts: TStringList;           // wmLoad in: one ini text per source
    FDestPath: string;               // wmDownload in
    FEntries: TCleanerEntryList;     // wmLoad out: owned here until taken
    FChecked: TList;                 // wmDetect/wmAnalyze in: not owned
    FResults: TCleanResultList;      // wmAnalyze out / wmClean in
    FStats: TCleanStats;
    FDownloadErr: string;            // wmDownload out
    FStatusQueue: TStringList;
    FStatusLock: TRTLCriticalSection;
    FCancelFlag: Boolean;
    FDoneCount: Integer;
    FTotal: Integer;
    FForm: TObject;
    FCookieKeep: TStringList;        // wmClean in: cookie domains to keep
    procedure EngineStatus(const AMsg: string);
    function EngineCancel: Boolean;
    procedure DoStatus;
  protected
    procedure Execute; override;
  public
    constructor Create(AMode: TWorkMode; AForm: TObject);
    destructor Destroy; override;
    procedure Cancel;
    property Mode: TWorkMode read FMode;
    property DbTexts: TStringList read FDbTexts;
    property DestPath: string read FDestPath write FDestPath;
    property Entries: TCleanerEntryList read FEntries write FEntries;
    property CheckedEntries: TList read FChecked write FChecked;
    property Results: TCleanResultList read FResults write FResults;
    property Stats: TCleanStats read FStats;
    property DownloadErr: string read FDownloadErr;
    property DoneCount: Integer read FDoneCount;
    property Total: Integer read FTotal;
    property Form: TObject read FForm write FForm;
    property CookieKeep: TStringList read FCookieKeep;
  end;

  { Row payload for lvResults. Kind drives the colour and the context
    menu; Done greys out rows that Clean already processed — live
    progress inside the review list. }
  TRowKind = (rkFile, rkRegKey, rkRegValue, rkSpecial);

  TRowInfo = class
    Kind: TRowKind;
    Size: Int64;               // files only
    RegItem: TRegDeleteItem;   // reg rows only, not owned
    Done: Boolean;
  end;

  TRowInfoList = specialize TFPGObjectList<TRowInfo>;

  { Modal cleaner dialog: entry checklist → analyze → review → clean.
    Top panel manages the databases: bundled Winapp2, our Default.ini
    (Windows junk baseline), downloadable Winapp3 (experimental) and a
    user-picked ini — all merged. }
  TCleanerForm = class(TForm)
    btnAnalyze: TButton;
    btnBrowse: TButton;
    btnCancel: TButton;
    btnClean: TButton;
    btnClose: TButton;
    btnCookies: TButton;
    btnCustomDir: TButton;
    btnPresets: TButton;
    btnReloadDb: TButton;
    btnResetDef: TButton;
    btnToCustom: TButton;
    btnUpdateW2: TButton;
    btnUpdateW3: TButton;
    cbCCleaner: TCheckBox;
    cbCustom: TCheckBox;
    cbDefault: TCheckBox;
    cbWinapp2: TCheckBox;
    cbWinapp3: TCheckBox;
    edCustomPath: TEdit;
    lblCCInfo: TLabel;
    lblDefInfo: TLabel;
    lblInfo: TLabel;
    lblW2Info: TLabel;
    lblW3Info: TLabel;
    lvEntries: TLazVirtualStringTree;
    lvResults: TListView;
    lvSec: TLazVirtualStringTree;
miCheckAll: TMenuItem;
    miCheckCategory: TMenuItem;
    miCheckNone: TMenuItem;
    miCopyPath: TMenuItem;
    miCopyToCustom: TMenuItem;
    miEditEntry: TMenuItem;
    miOpenFolder: TMenuItem;
    miOpenRegedit: TMenuItem;
    miSepE1: TMenuItem;
    miSepE2: TMenuItem;
    pbProgress: TProgressBar;
    pgEntries: TPageControl;
    pmEntries: TPopupMenu;
    pmResults: TPopupMenu;
    pnlBottom: TPanel;
    pnlDb: TPanel;
    spMain: TSplitter;
    tmrProgress: TTimer;
    tsClean: TTabSheet;
    tsSecurity: TTabSheet;
    procedure BtnAnalyzeClick(Sender: TObject);
    procedure BtnBrowseClick(Sender: TObject);
    procedure BtnCancelClick(Sender: TObject);
    procedure BtnCleanClick(Sender: TObject);
    procedure BtnCookiesClick(Sender: TObject);
    procedure BtnCustomDirClick(Sender: TObject);
    procedure BtnPresetsClick(Sender: TObject);
    procedure BtnReloadDbClick(Sender: TObject);
    procedure BtnResetDefClick(Sender: TObject);
    procedure BtnUpdateW2Click(Sender: TObject);
    procedure BtnUpdateW3Click(Sender: TObject);
    procedure DbSourceChange(Sender: TObject);
    procedure EntriesChecked(Sender: TBaseVirtualTree; Node: PVirtualNode);
    procedure EntriesCompareNodes(Sender: TBaseVirtualTree;
      Node1, Node2: PVirtualNode; Column: TColumnIndex;
      var Result: Integer);
    procedure EntriesFocusChanged(Sender: TBaseVirtualTree;
      Node: PVirtualNode; Column: TColumnIndex);
    procedure EntriesFreeNode(Sender: TBaseVirtualTree; Node: PVirtualNode);
    procedure EntriesGetText(Sender: TBaseVirtualTree; Node: PVirtualNode;
      Column: TColumnIndex; TextType: TVSTTextType; var CellText: String);
    procedure EntriesHeaderClick(Sender: TVTHeader;
      HitInfo: TVTHeaderHitInfo);
    procedure EntriesInitNode(Sender: TBaseVirtualTree;
      ParentNode, Node: PVirtualNode;
      var InitialStates: TVirtualNodeInitStates);
    procedure EntriesPaintText(Sender: TBaseVirtualTree;
      const TargetCanvas: TCanvas; Node: PVirtualNode;
      Column: TColumnIndex; TextType: TVSTTextType);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure FormKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure MenuCheckAllClick(Sender: TObject);
    procedure MenuCheckCategoryClick(Sender: TObject);
    procedure MenuCheckNoneClick(Sender: TObject);
    procedure MenuEditEntryClick(Sender: TObject);
    procedure MenuCopyToCustomClick(Sender: TObject);
    procedure MenuCopyPathClick(Sender: TObject);
    procedure MenuOpenFolderClick(Sender: TObject);
    procedure MenuOpenRegeditClick(Sender: TObject);
    procedure ResultsColumnClick(Sender: TObject; Column: TListColumn);
    procedure ResultsDrawItem(Sender: TCustomListView; AItem: TListItem;
      AState: TCustomDrawState; var ADefaultDraw: Boolean);
    procedure TimerTick(Sender: TObject);
  private
    FWorkers: TList;                 // running TCleanerThread refs
    FEntries: TCleanerEntryList;     // owned
    FResults: TCleanResultList;      // owned
    FRowInfos: TRowInfoList;         // owned, one per results row
    FRowMap: TStringList;            // path → TListItem lookup for Done marks
    FStats: TCleanStats;             // accumulated over clean workers
    FBaseCount: Integer;             // pool size for the picked-count line
    FInstalledCount: Integer;        // detected in pool, same line
    FLoading: Boolean;               // LoadSettings runs → skip DbSource prompts
    FSavedSelection: TStringList;    // last session's checked lvEntries names
    FSavedUnchecked: TStringList;    // entries ticked OFF against Default=
    FSavedSec: TStringList;          // in-session checked lvSec names (never persisted)
    FSelSaved: Boolean;              // live check-state snapshot exists → beats Default=
    FCheckGuard: Integer;            // >0 during mass-check → skip per-node OnChecked
    FShellDown: Boolean;             // explorer.exe stopped for this clean
    procedure LoadSettings;
    procedure SaveSettings;
    procedure SaveSelection;
    procedure ReloadDatabases;
    procedure RefreshDbInfo;
    procedure StartWorkers(AMode: TWorkMode; AUnits: TList;
      const ADbTexts: TStringList = nil; const ADestPath: string = '');
    procedure StartDownload(const AUrl, ADestPath: string);
    procedure WorkerDone(Sender: TObject);
    procedure FinishWork(AMode: TWorkMode);
    procedure PopulateEntries;
    procedure PopulateResults;
    { Offers to close running apps that hold files we're about to
      clean. False = user cancelled the whole clean. }
    function OfferCloseApps: Boolean;
    { Closes each app in its own thread; pumps the GUI loop while
      they run and reports per-app progress. }
    procedure CloseAppsInParallel(const AApps: TRunningAppArray);
    procedure ShowStatus(const AMsg: string);
    procedure SetBusy(ABusy: Boolean);
    procedure SetAllEntries(AChecked: Boolean);
    procedure ApplyPresetSelection(const F: TPresetForm);
    function DbSourceName(ASender: TObject): string;
    function ConfirmEnableDb(const AName: string): Boolean;
    function ConfirmSecurityMark(ACount: Integer): Boolean;
    function ActiveList: TLazVirtualStringTree;
    procedure SnapshotState(const ATree: TBaseVirtualTree;
      const ACheckedInto, AUncheckedInto: TStringList);
    function CheckedEntriesList: TList;
    function CheckedCount: Integer;
    procedure RefreshSelectionInfo;
  public
    constructor CreateDlg(AOwner: TComponent);
    destructor Destroy; override;
  end;

{ Shows the dialog modally. Loads the winapp2 database itself. }
function ShowCleanerDialog(AOwner: TComponent): TModalResult;

implementation

{$R *.lfm}

uses
  Windows, Types, Math, IniFiles,
  aboutform, cookieform, customform, ruleeditform, closeappsform,
  cs.utils, cs.models, cs.detect, cs.download, cs.lang,
  cs.pathexpand;

{ --- entry-tree helpers ------------------------------------------------ }

{ Node payload accessor — every node in lvEntries/lvSec carries a
  TEntNode (set at populate). }
function EntOf(const ATree: TBaseVirtualTree;
  const ANode: PVirtualNode): TCleanerEntry; inline;
begin
  if ANode = nil then Exit(nil);
  Result := PEntNode(ATree.GetNodeData(ANode))^.E;
end;

function NodeCat(const ATree: TBaseVirtualTree;
  const ANode: PVirtualNode): string; inline;
begin
  if ANode = nil then Exit('');
  Result := PEntNode(ATree.GetNodeData(ANode))^.Cat;
end;

{ CheckState fires OnChecked per node — mass updates run under
  FCheckGuard and refresh once at the end. }
procedure CheckNode(const ATree: TBaseVirtualTree;
  const ANode: PVirtualNode; const AChecked: Boolean); inline;
begin
  if AChecked then
    ATree.CheckState[ANode] := csCheckedNormal
  else
    ATree.CheckState[ANode] := csUncheckedNormal;
end;

const
  { Same upstream feeds as FluentCleaner's SettingsPage. }
  URL_WINAPP2 = 'https://raw.githubusercontent.com/builtbybel/FluentCleaner/master/Winapp2.ini';
  URL_WINAPP3 = 'https://raw.githubusercontent.com/MoscaDotTo/Winapp2/master/Winapp3/Winapp3.ini';

  { Our own security entries, always merged into the loaded databases.
    winapp2 covers browser credentials but not these Windows stores.
    The DPAPI master-key dir (Protect) is deliberately NOT included —
    deleting it would brick all encrypted data, not just logins. }
  SEC_EXTRA_INI =
    '[Windows Saved Credentials *]' + sLineBreak +
    'Section=Security' + sLineBreak +
    'DetectFile=%AppData%\Microsoft\Credentials' + sLineBreak +
    'Default=False' + sLineBreak +
    'Warning=Wipes every saved Windows credential (network shares, RDP, mapped drives).' + sLineBreak +
    'FileKey1=%AppData%\Microsoft\Credentials|*.*|REMOVESELF' + sLineBreak +
    'FileKey2=%LocalAppData%\Microsoft\Credentials|*.*|REMOVESELF' + sLineBreak +
    'FileKey3=%AppData%\Microsoft\Vault|*.*|REMOVESELF' + sLineBreak +
    sLineBreak +
    '[Wi-Fi Profiles *]' + sLineBreak +
    'Section=Security' + sLineBreak +
    'DetectFile=%ProgramData%\Microsoft\Wlansvc\Profiles' + sLineBreak +
    'Default=False' + sLineBreak +
    'Warning=Wipes all saved Wi-Fi networks and their passwords.' + sLineBreak +
    'FileKey1=%ProgramData%\Microsoft\Wlansvc\Profiles|*.xml|RECURSE';

  { Always-on system entries, independent of which bases are enabled:
    winapp2 has no %Temp% rules at all (CCleaner cleans it natively,
    not data-driven), and the Recycle Bin entry only ships inside
    Default.ini — which Winapp3 excludes mutually. Same names merge
    harmlessly via first-wins dedup when Default.ini is loaded. }
  SYS_EXTRA_INI =
    '[Recycle Bin *]' + sLineBreak +
    'LangSecRef=3025' + sLineBreak +
    'Section=Windows' + sLineBreak +
    'Special=RecycleBin' + sLineBreak +
    sLineBreak +
    '[User Temp Files *]' + sLineBreak +
    'Section=Windows' + sLineBreak +
    'DetectFile=%Temp%' + sLineBreak +
    'Default=True' + sLineBreak +
    'FileKey1=%Temp%|*|RECURSE' + sLineBreak +
    sLineBreak +
    '[Windows Temp Files *]' + sLineBreak +
    'Section=Windows' + sLineBreak +
    'DetectFile=%WinDir%\Temp' + sLineBreak +
    'Default=True' + sLineBreak +
    'FileKey1=%WinDir%\Temp|*|RECURSE';

{ ═══════════════ Thread ═══════════════ }

constructor TCleanerThread.Create(AMode: TWorkMode; AForm: TObject);
begin
  inherited Create(True);
  FreeOnTerminate := False;
  FMode := AMode;
  FForm := AForm;
  FDbTexts := TStringList.Create;
  // FResults is created lazily in wmAnalyze (or handed in for wmClean)
  // — creating it here would orphan the list on Results := assignment.
  FResults := nil;
  FStatusQueue := TStringList.Create;
  FCookieKeep := TStringList.Create;
  InitCriticalSection(FStatusLock);
end;

destructor TCleanerThread.Destroy;
begin
  FChecked.Free;
  FResults.Free;
  FDbTexts.Free;
  FStatusQueue.Free;
  FCookieKeep.Free;
  DoneCriticalSection(FStatusLock);
  inherited;
end;

procedure TCleanerThread.Cancel;
begin
  FCancelFlag := True;
end;

function TCleanerThread.EngineCancel: Boolean;
begin
  Result := FCancelFlag;
end;

procedure TCleanerThread.EngineStatus(const AMsg: string);
begin
  if Trim(AMsg) = '' then Exit;
  // file/registry-level progress for the clean bar — counted even when
  // the queue is full and the status line itself gets dropped
  if (FMode = wmClean) and
     ((Pos('Deleted: ', AMsg) = 1) or (Pos('Registry: ', AMsg) = 1)) then
    Inc(FDoneCount);
  EnterCriticalSection(FStatusLock);
  try
    // status is cosmetic — drop lines instead of flooding the queue
    if FStatusQueue.Count < 100 then
      FStatusQueue.Add(AMsg);
  finally
    LeaveCriticalSection(FStatusLock);
  end;
  Queue(@DoStatus);
end;

procedure TCleanerThread.DoStatus;
var
  S: string;
begin
  repeat
    EnterCriticalSection(FStatusLock);
    try
      if FStatusQueue.Count = 0 then
        S := ''
      else
      begin
        S := FStatusQueue[0];
        FStatusQueue.Delete(0);
      end;
    finally
      LeaveCriticalSection(FStatusLock);
    end;
    if S = '' then Break;
    if FForm <> nil then TCleanerForm(FForm).ShowStatus(S);
  until False;
end;

procedure TCleanerThread.Execute;
var
  Parser, CParser: TWinapp2Parser;
  Det: TDetectionService;
  Svc: TCleaningService;
  Seen: TStringList;
  Part: TCleanerEntryList;
  I, J, K, R: Integer;
  CDir: string;
  E: TCleanerEntry;
  SR: TSearchRec;
  Rslt: TCleanResult;
  St: TCleanStats;
begin
  try
    case FMode of
      wmLoad:
        begin
          // merge all enabled database texts; first occurrence of a name
          // wins (FDbTexts already priorities: custom/default/w3/w2)
          Parser := TWinapp2Parser.Create;
          Seen := TStringList.Create;
          try
            Seen.CaseSensitive := False;
            Seen.Sorted := True;
            Seen.Duplicates := dupIgnore;
            FEntries := TCleanerEntryList.Create(True);
            for I := 0 to FDbTexts.Count - 1 do
            begin
              Part := Parser.Parse(FDbTexts[I]);
              try
                // backward: Extract shrinks the list, so forward
                // iteration skipped entries and crashed once the
                // list shrank past the cursor (EListError) — the
                // pool silently lost half the database
                for J := Part.Count - 1 downto 0 do
                  if Seen.IndexOf(Part[J].Name) < 0 then
                  begin
                    Seen.Add(Part[J].Name);
                    FEntries.Add(Part.Extract(Part[J]));
                  end
                  else
                    Part.Delete(J);
              finally
                Part.Free;
              end;
            end;

            { Custom folder beside the exe: enabled *.ini files parsed
              permissively — rules may omit detection. A same-name
              custom rule replaces the shipped one (upstream
              CustomEntryService: entries.RemoveAll + Add). Entries
              whose own detection fails are dropped from the pool. }
            CDir := ExtractFilePath(ParamStr(0)) + 'Custom\';
            if DirectoryExists(CDir) then
            begin
              Det := TDetectionService.Create;
              CParser := TWinapp2Parser.Create(True);
              try
                R := FindFirst(CDir + '*.ini', faAnyFile, SR);
                try
                  while R = 0 do
                  begin
                    if ((SR.Attr and faDirectory) = 0) and
                       (not EndsText('.disabled', SR.Name)) then
                    begin
                      Part := CParser.ParseFile(CDir + SR.Name);
                      try
                        // forward is safe: Extract only removes E itself
                        for J := Part.Count - 1 downto 0 do
                        begin
                          E := Part[J];
                          E.IsCustom := True;
                          E.SourceFile := CDir + SR.Name;
                          if EntryHasDetection(E) and
                             (not Det.IsInstalled(E)) then
                            Continue;   // stays in Part → freed below
                          for K := 0 to FEntries.Count - 1 do
                            if SameText(FEntries[K].Name, E.Name) then
                            begin
                              FEntries.Delete(K);
                              Break;
                            end;
                          FEntries.Add(Part.Extract(E));
                          Seen.Add(E.Name);
                        end;
                      finally
                        Part.Free;
                      end;
                    end;
                    R := FindNext(SR);
                  end;
                finally
                  SysUtils.FindClose(SR);
                end;
              finally
                CParser.Free;
                Det.Free;
              end;
            end;
            FTotal := FEntries.Count;
          finally
            Seen.Free;
            Parser.Free;
          end;
        end;
      wmDetect:
        begin
          FTotal := FChecked.Count;
          Det := TDetectionService.Create;
          try
            for I := 0 to FChecked.Count - 1 do
            begin
              if FCancelFlag then Break;
              try
                // workers write disjoint entries — a plain flag is safe.
                // A custom rule without detection counts as installed:
                // upstream skips the probe, it must not render greyed.
                TCleanerEntry(FChecked[I]).Detected :=
                  Det.IsInstalled(TCleanerEntry(FChecked[I])) or
                  (TCleanerEntry(FChecked[I]).IsCustom and
                   not EntryHasDetection(TCleanerEntry(FChecked[I])));
              except
                // an entry with broken criteria is just 'not installed'
              end;
              Inc(FDoneCount);
            end;
          finally
            Det.Free;
          end;
        end;
      wmAnalyze:
        begin
          FTotal := FChecked.Count;
          FResults := TCleanResultList.Create(True);
          Svc := TCleaningService.Create;
          try
            for I := 0 to FChecked.Count - 1 do
            begin
              if FCancelFlag then Break;
              try
                Rslt := Svc.Analyze(TCleanerEntry(FChecked[I]),
                      @EngineStatus, @EngineCancel);
                FResults.Add(Rslt);
              except
                on ECleanCancelled do Break;
                on E: Exception do
                  EngineStatus('Error: ' + E.Message);
              end;
              Inc(FDoneCount);
            end;
          finally
            Svc.Free;
          end;
        end;
      wmClean:
        begin
          FTotal := 0;
          for I := 0 to FResults.Count - 1 do
            FTotal := FTotal + FResults[I].FilesToDelete.Count +
                      FResults[I].RegistryToDelete.Count +
                      FResults[I].SpecialItems.Count;
          Svc := TCleaningService.Create;
          try
            // kept domains survive inside pruned cookie DBs (upstream
            // TryCleanProtectedStore); empty list → plain file deletes
            Svc.CookieKeepList := FCookieKeep;
            for I := 0 to FResults.Count - 1 do
            begin
              if FCancelFlag then Break;
              try
                St := Svc.Clean(FResults[I], @EngineStatus, @EngineCancel);
                FStats.Count := FStats.Count + St.Count;
                FStats.Bytes := FStats.Bytes + St.Bytes;
              except
                on ECleanCancelled do Break;
                on E: Exception do
                  EngineStatus('Error: ' + E.Message);
              end;
            end;
          finally
            Svc.Free;
          end;
        end;
      wmDownload:
        if not DownloadFile(FDbTexts[0], FDestPath, FDownloadErr,
             @FCancelFlag) then
          EngineStatus(FDownloadErr);
    end;
  except
    on E: Exception do
      EngineStatus('Error: ' + E.Message);
  end;
end;

{ ═══════════════ Form ═══════════════ }

function ShowCleanerDialog(AOwner: TComponent): TModalResult;
var
  F: TCleanerForm;
begin
  F := TCleanerForm.CreateDlg(AOwner);
  try
    Result := F.ShowModal;
  finally
    F.Free;
  end;
end;

function DataDir: string;
begin
  Result := ExtractFilePath(ParamStr(0)) + 'data\';
end;

function SettingsPath: string;
begin
  Result := ExtractFilePath(ParamStr(0)) + 'CleanSweep.ini';
end;

function LoadDbFile(const APath: string): string;
begin
  Result := LoadTextFile(APath);   // UTF-8 aware, ANSI fallback
end;

{ File copy wins, embedded resource is the fallback (RCDATA). }
function LoadDbText(const AName, AResName: string): string;
var
  RS: TResourceStream;
  SS: TStringStream;
begin
  Result := LoadDbFile(DataDir + AName);
  if Result = '' then
    Result := LoadDbFile(ExtractFilePath(ParamStr(0)) + AName);
  if Result <> '' then Exit;
  if FindResource(HInstance, PChar(AResName), Windows.RT_RCDATA) = 0 then Exit;
  RS := TResourceStream.Create(HInstance, AResName, Windows.RT_RCDATA);
  try
    SS := TStringStream.Create('');
    try
      SS.CopyFrom(RS, RS.Size);
      Result := SS.DataString;
    finally
      SS.Free;
    end;
  finally
    RS.Free;
  end;
end;

{ Writes the embedded RCDATA copy over data\AName (UTF-8). Used to
  materialize Default.ini when missing and to reset it to factory. }
function RestoreDbFromResource(const AName, AResName: string): Boolean;
var
  RS: TResourceStream;
  FS: TFileStream;
begin
  Result := False;
  if FindResource(HInstance, PChar(AResName), Windows.RT_RCDATA) = 0
    then Exit;
  ForceDirectories(DataDir);
  RS := TResourceStream.Create(HInstance, AResName, Windows.RT_RCDATA);
  try
    FS := TFileStream.Create(DataDir + AName, fmCreate);
    try
      FS.CopyFrom(RS, RS.Size);
      Result := True;
    finally
      FS.Free;
    end;
  finally
    RS.Free;
  end;
end;

{ One-line summary like upstream's BuildFileInfo: entries · KB · date.
  Section headers minus the [Winapp2*]/[version] header blocks count as
  entries. }
function DbFileInfo(const APath: string): string;
var
  SL: TStringList;
  I, Entries: Integer;
  Age: TDateTime;
begin
  Result := '';
  if not FileExists(APath) then Exit;
  SL := TStringList.Create;
  try
    SL.Text := LoadTextFile(APath);
    Entries := 0;
    for I := 0 to SL.Count - 1 do
      if (Length(SL[I]) > 0) and (SL[I][1] = '[') and
         (Pos('[Winapp2', SL[I]) <> 1) and
         (Pos('[version', LowerCase(SL[I])) <> 1) then
        Inc(Entries);
    Age := FileDateToDateTime(FileAge(APath));
    Result := Format('%d · %d KB · %s',
      [Entries, GetFileSizeBytes(APath) div 1024,
       FormatDateTime('yyyy-mm-dd hh:nn', Age)]);
  finally
    SL.Free;
  end;
end;

procedure TCleanerForm.LoadSettings;
var
  Ini: TIniFile;
  Custom: string;
  I, N: Integer;
begin
  Ini := TIniFile.Create(SettingsPath);
  try
    cbWinapp2.Checked := Ini.ReadBool('Cleaner', 'EnableWinapp2', True);
    cbWinapp3.Checked := Ini.ReadBool('Cleaner', 'EnableWinapp3', False);
    cbDefault.Checked := Ini.ReadBool('Cleaner', 'EnableDefault', True);
    cbCCleaner.Checked := Ini.ReadBool('Cleaner', 'EnableCCleaner', True);
    Custom := Ini.ReadString('Cleaner', 'CustomPath', '');
    edCustomPath.Text := Custom;
    cbCustom.Checked := Ini.ReadBool('Cleaner', 'EnableCustom', True) and
                        (Trim(edCustomPath.Text) <> '');
    FSavedSelection.Clear;
    FSavedUnchecked.Clear;
    N := Ini.ReadInteger('Selection', 'Count', 0);
    for I := 0 to N - 1 do
      FSavedSelection.Add(Ini.ReadString('Selection', 'Entry' + IntToStr(I), ''));
    N := Ini.ReadInteger('Unchecked', 'Count', 0);
    for I := 0 to N - 1 do
      FSavedUnchecked.Add(Ini.ReadString('Unchecked', 'Entry' + IntToStr(I), ''));
  finally
    Ini.Free;
  end;
end;

{ Remembers which cleanup-tab entries were checked so the next session
  opens on the same set. The state is stored as a delta against
  Default=: 'Selection' lists everything checked, 'Unchecked' lists
  entries ticked OFF although Default=True would have checked them.
  Entries in neither list (brand-new ones, or plain undetected) fall
  back to 'Default and Detected' on load — a new entry must not appear
  unchecked just because it did not exist when the selection was saved.
  Security-tab checks are deliberately NOT saved — wiping passwords
  must start empty every time and stay a deliberate act. }
procedure TCleanerForm.SaveSelection;
var
  Ini: TIniFile;
  S, U: TStringList;
  I: Integer;
  N: PVirtualNode;
  E: TCleanerEntry;
begin
  S := TStringList.Create;
  U := TStringList.Create;
  try
    N := lvEntries.GetFirst;
    while N <> nil do
    begin
      E := EntOf(lvEntries, N);
      if E <> nil then
      begin
        if lvEntries.CheckState[N] = csCheckedNormal then
          S.Add(E.Name)
        else if E.Default and E.Detected then
          U.Add(E.Name);
      end;
      N := lvEntries.GetNext(N);
    end;
    Ini := TIniFile.Create(SettingsPath);
    try
      Ini.EraseSection('Selection');
      Ini.EraseSection('Unchecked');
      Ini.WriteInteger('Selection', 'Count', S.Count);
      for I := 0 to S.Count - 1 do
        Ini.WriteString('Selection', 'Entry' + IntToStr(I), S[I]);
      Ini.WriteInteger('Unchecked', 'Count', U.Count);
      for I := 0 to U.Count - 1 do
        Ini.WriteString('Unchecked', 'Entry' + IntToStr(I), U[I]);
    finally
      Ini.Free;
    end;
  finally
    S.Free;
    U.Free;
  end;
end;

procedure TCleanerForm.SaveSettings;
var
  Ini: TIniFile;
begin
  Ini := TIniFile.Create(SettingsPath);
  try
    Ini.WriteBool('Cleaner', 'EnableWinapp2', cbWinapp2.Checked);
    Ini.WriteBool('Cleaner', 'EnableWinapp3', cbWinapp3.Checked);
    Ini.WriteBool('Cleaner', 'EnableDefault', cbDefault.Checked);
    Ini.WriteBool('Cleaner', 'EnableCCleaner', cbCCleaner.Checked);
    Ini.WriteBool('Cleaner', 'EnableCustom', cbCustom.Checked);
    // keep the ini clean: a path is stored only once the user picks one
    if Trim(edCustomPath.Text) <> '' then
      Ini.WriteString('Cleaner', 'CustomPath', Trim(edCustomPath.Text))
    else
      Ini.DeleteKey('Cleaner', 'CustomPath');
  finally
    Ini.Free;
  end;
end;

{ Resolves all enabled database sources into texts and re-runs the
  load+detect pipeline. Texts are ordered by priority and merged
  first-wins by entry name: custom > CCleaner > Default > Winapp3 >
  Winapp2. CCleaner.ini is our migrated CCleaner ruleset (724 entries
  covering what winapp2 misses). Winapp2 prefers the external file and
  falls back to the embedded resource, so data\ always wins over the
  built-in copy. }
procedure TCleanerForm.ReloadDatabases;
var
  Texts: TStringList;
  S: string;
begin
  if FWorkers.Count > 0 then Exit;
  RefreshDbInfo;
  Texts := TStringList.Create;
  try
    if cbCustom.Checked and (Trim(edCustomPath.Text) <> '') then
    begin
      S := LoadDbFile(Trim(edCustomPath.Text));
      if S <> '' then
      begin
        ShowStatus(Format('Custom DB: %s, %d bytes',
          [Trim(edCustomPath.Text), Length(S)]));
        Texts.Add(S);
      end
      else
        ShowStatus(Lg('Своя база не найдена: ' + Trim(edCustomPath.Text),
                      'Свая база не знойдзена: ' + Trim(edCustomPath.Text),
                      'Своя база не знайдена: ' + Trim(edCustomPath.Text),
                      'Custom DB not found: ' + Trim(edCustomPath.Text)));
    end;
    if cbCCleaner.Checked then
    begin
      S := LoadDbFile(DataDir + 'CCleaner.ini');
      if S <> '' then Texts.Add(S);
    end;
    if cbDefault.Checked then
    begin
      // Default.ini is the standard 'Windows junk' base: embedded in
      // the exe and restored to disk automatically when missing, so
      // standard cleaning never depends on external files.
      if not FileExists(DataDir + 'Default.ini') then
        RestoreDbFromResource('Default.ini', 'DEFAULTDB');
      S := LoadDbText('Default.ini', 'DEFAULTDB');
      if S <> '' then Texts.Add(S)
      else
        ShowStatus(Lg('Default.ini не найдена — переоткройте окно.',
                      'Default.ini не знойдзена — пераадчыніце акно.',
                      'Default.ini не знайдена — перевідкрийте вікно.',
                      'Default.ini not found — reopen the window.'));
    end;
    if cbWinapp3.Checked then
    begin
      S := LoadDbFile(DataDir + 'Winapp3.ini');
      if S <> '' then Texts.Add(S)
      else
        ShowStatus(Lg('Winapp3.ini не загружена — нажмите «Обновить».',
                      'Winapp3.ini не загружана — націсніце «Абнавіць».',
                      'Winapp3.ini не завантажена — натисніть «Оновити».',
                      'Winapp3.ini not downloaded — press Update.'));
    end;
    if cbWinapp2.Checked then
    begin
      S := LoadDbText('Winapp2.ini', 'WINAPP2');
      if S <> '' then Texts.Add(S);
    end;
    Texts.Add(SEC_EXTRA_INI);
    Texts.Add(SYS_EXTRA_INI);
    if Texts.Count = 0 then
    begin
      Texts.Free;
      ShowStatus(Lg('Нет баз для загрузки.', 'Няма баз для загрузкі.',
                    'Немає баз для завантаження.', 'No databases to load.'));
      Exit;
    end;
    ShowStatus(Lg('Загрузка базы...', 'Загрузка базы...',
                  'Завантаження бази...', 'Loading database...'));
    StartWorkers(wmLoad, nil, Texts);
  except
    on E: Exception do
    begin
      Texts.Free;
      ShowStatus('Error: ' + E.Message);
    end;
  end;
end;

procedure TCleanerForm.RefreshDbInfo;
var
  S: string;
begin
  S := DbFileInfo(DataDir + 'Winapp2.ini');
  if S = '' then S := DbFileInfo(ExtractFilePath(ParamStr(0)) + 'Winapp2.ini');
  if S = '' then
    S := Lg('встроенная', 'убудаваная', 'вбудована', 'built-in');
  lblW2Info.Caption := S;
  S := DbFileInfo(DataDir + 'Default.ini');
  if S = '' then
    S := Lg('встроенная', 'убудаваная', 'вбудована', 'built-in');
  lblDefInfo.Caption := S;
  S := DbFileInfo(DataDir + 'Winapp3.ini');
  if S = '' then
    S := Lg('ещё не загружена', 'яшчэ не загружана',
            'ще не завантажена', 'not downloaded yet');
  lblW3Info.Caption := S;
  S := DbFileInfo(DataDir + 'CCleaner.ini');
  if S = '' then
    S := Lg('не найдена', 'не знойдзена', 'не знайдена', 'not found');
  lblCCInfo.Caption := S;
end;

procedure TCleanerForm.StartDownload(const AUrl, ADestPath: string);
var
  Texts: TStringList;
begin
  if FWorkers.Count > 0 then Exit;
  ForceDirectories(ExtractFileDir(ADestPath));
  Texts := TStringList.Create;
  Texts.Add(AUrl);
  ShowStatus(Lg('Загрузка обновления...', 'Загрузка абнаўлення...',
                'Завантаження оновлення...', 'Downloading update...'));
  StartWorkers(wmDownload, nil, Texts, ADestPath);
end;

procedure TCleanerForm.BtnUpdateW2Click(Sender: TObject);
begin
  StartDownload(URL_WINAPP2, DataDir + 'Winapp2.ini');
end;

procedure TCleanerForm.BtnUpdateW3Click(Sender: TObject);
begin
  StartDownload(URL_WINAPP3, DataDir + 'Winapp3.ini');
end;

{ Restores data\Default.ini to the factory copy embedded in the exe,
  then reloads — the "reset to defaults" for the standard-cleaning base. }
procedure TCleanerForm.BtnResetDefClick(Sender: TObject);
begin
  if MessageDlg(Lg('Восстановить Default.ini до версии, встроенной в программу? Текущие правки файла будут утеряны.',
                   'Аднавіць Default.ini да версіі, убудаванай у праграму? Бягучыя правкі файла будуць страчаны.',
                   'Відновити Default.ini до версії, вбудованої в програму? Поточні правки файлу будуть втрачені.',
                   'Restore Default.ini to the copy bundled in the program? Current edits to the file will be lost.'),
    mtConfirmation, [mbYes, mbNo], 0, mbNo) <> mrYes then Exit;
  if RestoreDbFromResource('Default.ini', 'DEFAULTDB') then
  begin
    ShowStatus(Lg('Default.ini восстановлена.', 'Default.ini адноўлена.',
                  'Default.ini відновлено.', 'Default.ini restored.'));
    ReloadDatabases;
  end
  else
    ShowStatus(Lg('Не удалось восстановить Default.ini.',
                  'Не ўдалося аднавіць Default.ini.',
                  'Не вдалося відновити Default.ini.',
                  'Failed to restore Default.ini.'));
end;

procedure TCleanerForm.BtnBrowseClick(Sender: TObject);
var
  D: TOpenDialog;
begin
  D := TOpenDialog.Create(Self);
  try
    D.Filter := 'Winapp2 ini|*.ini';
    D.Options := [ofFileMustExist];
    if D.Execute then
    begin
      edCustomPath.Text := D.FileName;
      cbCustom.Checked := True;
      SaveSettings;
      ReloadDatabases;
    end;
  finally
    D.Free;
  end;
end;

procedure TCleanerForm.DbSourceChange(Sender: TObject);
begin
  // Default.ini and Winapp3.ini are alternative 'Windows junk' bases,
  // so the two checkboxes are mutually exclusive: enabling one turns
  // the other off. Enabling either is a deliberate act — the rules it
  // adds delete files permanently, so it asks first.
  if (not FLoading) and ((Sender = cbDefault) or (Sender = cbWinapp3)) then
  begin
    if TCheckBox(Sender).Checked then
    begin
      if not ConfirmEnableDb(DbSourceName(Sender)) then
      begin
        TCheckBox(Sender).Checked := False;
        SaveSettings;
        ReloadDatabases;
        Exit;
      end;
      FLoading := True;   // guard against re-entrant OnChange
      try
        if Sender = cbDefault then cbWinapp3.Checked := False
        else cbDefault.Checked := False;
      finally
        FLoading := False;
      end;
    end;
  end;
  SaveSettings;
  ReloadDatabases;
end;

{ Clean base name for the enable warning. }
function TCleanerForm.DbSourceName(ASender: TObject): string;
begin
  if ASender = cbWinapp3 then Result := 'Winapp3.ini'
  else Result := 'Default.ini';
end;

{ Warning shown when Default.ini / Winapp3.ini gets switched on. }
function TCleanerForm.ConfirmEnableDb(const AName: string): Boolean;
begin
  Result := MessageDlg(Format(Lg(
    'Внимание: %s содержит правила удаления файлов (в том числе системных) ' +
    'безвозвратно, без корзины. Продолжить?',
    'Увага: %s змяшчае правілы выдалення файлаў (у тым ліку сістэмных) ' +
    'назаўжды, без сметніцы. Працягнуць?',
    'Увага: %s містить правила видалення файлів (у тому числі системних) ' +
    'назавжди, без кошика. Продовжити?',
    'Warning: %s contains rules that delete files (including system files) ' +
    'permanently, without the recycle bin. Continue?'),
    [AName]),
    mtWarning, [mbYes, mbNo], 0) = mrYes;
end;

{ Ticking the 'Пароли и сессии' tab wipes saved logins/passwords and
  forces re-authorisation afterwards — demand an explicit Yes, once. }
function TCleanerForm.ConfirmSecurityMark(ACount: Integer): Boolean;
begin
  Result := MessageDlg(Format(Lg(
    'На вкладке «Пароли и сессии» будет отмечено %d записей. Их очистка ' +
    'удалит логины и пароли без возможности восстановления; после неё ' +
    'потребуется повторный вход и повторная авторизация. Продолжить?',
    'На ўкладцы «Паролі і сеансы» будзе адзначана %d запісаў. Іх ачыстка ' +
    'выдаліць лагіны і паролі без магчымасці аднаўлення; пасля яе спатрэбіцца ' +
    'паўторны ўваход і паўторная аўтарызацыя. Працягнуць?',
    'На вкладці «Паролі та сесії» буде позначено %d записів. Їх очищення ' +
    'видалить логіни та паролі без можливості відновлення; після нього ' +
    'знадобиться повторний вхід і повторна авторизація. Продовжити?',
    'The «Passwords & sessions» tab will check %d entries. Cleaning them ' +
    'deletes saved logins and passwords with no way to restore them, and ' +
    'you will need to sign in and re-authorise afterwards. Continue?'),
    [ACount]),
    mtWarning, [mbYes, mbNo], 0) = mrYes;
end;

procedure TCleanerForm.BtnReloadDbClick(Sender: TObject);
begin
  ReloadDatabases;
end;

constructor TCleanerForm.CreateDlg(AOwner: TComponent);
begin
  inherited Create(AOwner); // loads cleanerform.lfm
  FWorkers := TList.Create;
  FRowInfos := TRowInfoList.Create(True);
  FSavedSelection := TStringList.Create;
  FSavedSelection.CaseSensitive := False;
  FSavedSelection.Sorted := True;
  FSavedSelection.Duplicates := dupIgnore;
  FSavedSec := TStringList.Create;
  FSavedSec.CaseSensitive := False;
  FSavedSec.Sorted := True;
  FSavedSec.Duplicates := dupIgnore;
  FSavedUnchecked := TStringList.Create;
  FSavedUnchecked.CaseSensitive := False;
  FSavedUnchecked.Sorted := True;
  FSavedUnchecked.Duplicates := dupIgnore;
  FSelSaved := False;
  FRowMap := TStringList.Create;
  FRowMap.CaseSensitive := False;
  FRowMap.Sorted := True;
  FRowMap.Duplicates := dupIgnore;
  FResults := TCleanResultList.Create(True);
  try
    Icon.LoadFromResourceName(HInstance, 'MAINICON');
  except
  end;
  Caption := Lg('CleanSweep — клинер', 'CleanSweep — клінер',
                'CleanSweep — клінер', 'CleanSweep — cleaner');
  btnAnalyze.Caption := Lg('Анализ', 'Аналіз', 'Аналіз', 'Analyze');
  btnClean.Caption   := Lg('Очистить', 'Ачысціць', 'Очистити', 'Clean');
  btnCancel.Caption  := Lg('Отмена', 'Адмена', 'Скасувати', 'Cancel');
  btnClose.Caption   := Lg('Закрыть', 'Закрыць', 'Закрити', 'Close');
  btnPresets.Caption := Lg('Пресеты…', 'Прэсеты…', 'Пресети…', 'Presets…');
  btnCookies.Caption := Lg('Куки…', 'Кукі…', 'Кукі…', 'Cookies…');
  btnCustomDir.Caption := Lg('Правила…', 'Правілы…', 'Правила…', 'Rules…');
  btnUpdateW2.Caption := Lg('Обновить', 'Абнавіць', 'Оновити', 'Update');
  btnUpdateW3.Caption := btnUpdateW2.Caption;
  btnBrowse.Caption := Lg('Обзор…', 'Агляд…', 'Огляд…', 'Browse…');
  btnReloadDb.Caption := Lg('Перезагрузить', 'Перазагрузіць',
                            'Перезавантажити', 'Reload');
  cbWinapp2.Caption := 'Winapp2.ini (FluentCleaner)';
  cbWinapp3.Caption := Lg('Winapp3.ini (FluentCleaner) — эксперим.',
                          'Winapp3.ini (FluentCleaner) — эксперым.',
                          'Winapp3.ini (FluentCleaner) — експерим.',
                          'Winapp3.ini (FluentCleaner) — experim.');
  cbCustom.Caption := Lg('Своя база:', 'Свая база:', 'Своя база:', 'Custom DB:');
  tsClean.Caption := Lg('Очистка', 'Ачыстка', 'Очищення', 'Cleanup');
  tsSecurity.Caption := Lg('Пароли и сессии', 'Паролі і сеансы',
                           'Паролі та сесії', 'Passwords & sessions');
  lvEntries.NodeDataSize := SizeOf(TEntNode);
  lvSec.NodeDataSize := SizeOf(TEntNode);
  lvEntries.Header.MainColumn := 0;
  lvSec.Header.MainColumn := 0;
  lvEntries.Header.Columns[0].Text := Lg('Запись', 'Запіс', 'Запис',
    'Entry');
  lvEntries.Header.Columns[1].Text := Lg('Категория', 'Катэгорыя',
    'Категорія', 'Category');
  lvSec.Header.Columns[0].Text := lvEntries.Header.Columns[0].Text;
  lvSec.Header.Columns[1].Text := lvEntries.Header.Columns[1].Text;
  lvResults.Columns[0].Caption := Lg('Путь', 'Шлях', 'Шлях', 'Path');
  lvResults.Columns[1].Caption := Lg('Тип', 'Тып', 'Тип', 'Type');
  lvResults.Columns[2].Caption := Lg('Размер', 'Памер', 'Розмір', 'Size');
  miCopyPath.Caption := Lg('Копировать путь', 'Капіраваць шлях',
                           'Копіювати шлях', 'Copy path');
  miOpenFolder.Caption := Lg('Открыть содержащую папку', 'Адкрыць папку',
                             'Відкрити папку', 'Open containing folder');
  miOpenRegedit.Caption := Lg('Открыть в реестре', 'Адкрыць у рэестры',
                              'Відкрити в реєстрі', 'Open in registry');
  miCheckAll.Caption := Lg('Отметить всё', 'Адзначыць усё',
                           'Позначити все', 'Check all');
  miCheckNone.Caption := Lg('Снять выбор', 'Зняць выбар',
                            'Зняти вибір', 'Check none');
miCheckCategory.Caption := Lg('Отметить категорию', 'Адзначыць катэгорыю',
                                'Позначити категорію', 'Check this category');

  FLoading := True;
  try
    LoadSettings;
  finally
    FLoading := False;
  end;
  RefreshDbInfo;
  ReloadDatabases;
end;

destructor TCleanerForm.Destroy;
var
  I: Integer;
begin
  // Detach, never WaitFor — see TMainForm.Destroy for the reasoning.
  for I := 0 to FWorkers.Count - 1 do
  begin
    TCleanerThread(FWorkers[I]).OnTerminate := nil;
    TCleanerThread(FWorkers[I]).Form := nil;
    TCleanerThread(FWorkers[I]).Cancel;
    if TCleanerThread(FWorkers[I]).Finished then
      TCleanerThread(FWorkers[I]).Free
    else
      TCleanerThread(FWorkers[I]).FreeOnTerminate := True;
  end;
  FWorkers.Free;
  FRowMap.Free;
  FRowInfos.Free;
  FResults.Free;
  FEntries.Free;
  FSavedSelection.Free;
  FSavedUnchecked.Free;
  FSavedSec.Free;
  if FShellDown then
    StartShell;   // never leave the desktop without a shell
  inherited;
end;

{ Slices AUnits over up-to-4 workers (one engine instance each) and
  starts them. AUnits=nil → a single worker (load/clean/download).
  ADbTexts feeds wmLoad (ini texts) or wmDownload (the url). }
procedure TCleanerForm.StartWorkers(AMode: TWorkMode; AUnits: TList;
  const ADbTexts: TStringList; const ADestPath: string);
var
  N, I, J, Per, From: Integer;
  T: TCleanerThread;
  Slice: TList;
begin
  if AUnits = nil then
    N := 1
  else
    N := Min(4, Max(1, Min(AUnits.Count, TThread.ProcessorCount)));
  Per := 0;
  if AUnits <> nil then Per := AUnits.Count div N;
  SetBusy(True);
  From := 0;
  for I := 0 to N - 1 do
  begin
    T := TCleanerThread.Create(AMode, Self);
    if ADbTexts <> nil then T.DbTexts.Assign(ADbTexts);
    T.DestPath := ADestPath;
    if AUnits <> nil then
    begin
      Slice := TList.Create;
      // last worker takes the remainder so nothing is dropped
      if I = N - 1 then
        for J := From to AUnits.Count - 1 do Slice.Add(AUnits[J])
      else
        for J := From to From + Per - 1 do Slice.Add(AUnits[J]);
      Inc(From, Per);
      T.CheckedEntries := Slice;
    end;
    if AMode = wmClean then
    begin
      T.Results := FResults;
      FResults := nil;   // ownership moved to the worker
      LoadCookieKeepList(SettingsPath, T.CookieKeep);
    end;
    T.OnTerminate := @WorkerDone;
    FWorkers.Add(T);
    T.Start;
  end;
end;

procedure TCleanerForm.WorkerDone(Sender: TObject);
var
  T: TCleanerThread;
begin
  T := TCleanerThread(Sender);
  FWorkers.Remove(T);
  case T.Mode of
    wmLoad:
      begin
        // Tree nodes and review rows still reference the OLD entry
        // objects. Snapshot the checkmarks now — after FEntries.Free
        // the same code in PopulateEntries would read freed memory
        // (garbage names → nothing restores → «выбрано: 0»).
        if lvEntries.RootNodeCount + lvSec.RootNodeCount > 0 then
        begin
          FSelSaved := True;
          SnapshotState(lvEntries, FSavedSelection, FSavedUnchecked);
          SnapshotState(lvSec, FSavedSec, nil);
          lvEntries.Clear;   // D^.E points into the pool we are freeing
          lvSec.Clear;
        end;
        if FResults.Count > 0 then
        begin
          // plans reference old entries (TCleanResult.Entry is unowned)
          FResults.Clear;
          FRowInfos.Clear;
          FRowMap.Clear;
          lvResults.Items.Clear;
        end;
        FEntries.Free;
        FEntries := T.Entries;
        T.Entries := nil;          // ownership transferred
        ShowStatus(Format('Parsed: %d entries', [FEntries.Count]));
      end;
    wmDetect:
      ;   // workers already flagged the entry objects (E.Detected)
    wmAnalyze:
      if T.Results <> nil then
        // Extract moves each plan to the form's list without freeing
        while T.Results.Count > 0 do
          FResults.Add(T.Results.Extract(T.Results[0]));
    wmClean:
      begin
        FStats.Count := FStats.Count + T.Stats.Count;
        FStats.Bytes := FStats.Bytes + T.Stats.Bytes;
      end;
    wmDownload:
      if T.DownloadErr = '' then
        ShowStatus(Lg('База обновлена.', 'База абноўлена.',
                      'Базу оновлено.', 'Database updated.'))
      else
        ShowStatus(Format(Lg('Ошибка загрузки: %s', 'Памылка загрузкі: %s',
                             'Помилка завантаження: %s',
                             'Download failed: %s'), [T.DownloadErr]));
  end;
  if FWorkers.Count = 0 then
    FinishWork(T.Mode);
  T.Free;
end;

procedure TCleanerForm.FinishWork(AMode: TWorkMode);
var
  I, Total: Integer;
  Bytes: Int64;
  All: TList;
begin
  SetBusy(False);
  case AMode of
    wmLoad:
      begin
        // parse done — detect installed entries in parallel slices
        ShowStatus(Lg('Определение установленных...', 'Вызначэнне ўсталяваных...',
                      'Визначення встановлених...', 'Detecting installed...'));
        All := TList.Create;
        try
          for I := 0 to FEntries.Count - 1 do
          begin
            FEntries[I].Detected := False;
            All.Add(FEntries[I]);
          end;
          ShowStatus(Format('Detecting %d entries...', [FEntries.Count]));
          StartWorkers(wmDetect, All);
        finally
          All.Free;   // workers took per-thread slice copies
        end;
        Exit;   // busy again — SetBusy(False) above is transient
      end;
    wmDetect:
      begin
        ShowStatus(Format('Detection done: %d entries in pool', [FEntries.Count]));
        PopulateEntries;
        FBaseCount := FEntries.Count;
        FInstalledCount := 0;
        for I := 0 to FEntries.Count - 1 do
          if FEntries[I].Detected then Inc(FInstalledCount);
        RefreshSelectionInfo;
      end;
    wmAnalyze:
      begin
        PopulateResults;
        Total := 0; Bytes := 0;
        for I := 0 to FResults.Count - 1 do
        begin
          Total := Total + FResults[I].FilesToDelete.Count +
                   FResults[I].RegistryToDelete.Count +
                   FResults[I].SpecialItems.Count;
          Bytes := Bytes + FResults[I].TotalBytes;
        end;
        ShowStatus(Format(Lg(
          'Анализ завершён: %d элементов, %s. Проверьте список и нажмите «Очистить».',
          'Аналіз завершаны: %d элементаў, %s. Праверце спіс і націсніце «Ачысціць».',
          'Аналіз завершено: %d елементів, %s. Перевірте список і натисніть «Очистити».',
          'Analyze done: %d items, %s. Review the list and press Clean.'),
          [Total, FormatBytes(Bytes)]));
      end;
    wmClean:
      begin
        // worker consumed the results — nothing comes back
        FResults := TCleanResultList.Create(True);
        FRowInfos.Clear;
        FRowMap.Clear;
        lvResults.Items.Clear;
        if FShellDown then
        begin
          FShellDown := False;
          StartShell;
        end;
        ShowStatus(Format(Lg(
          'Очистка завершена: удалено %d элементов, освобождено %s.',
          'Ачыстка завершана: выдалена %d элементаў, вызвалена %s.',
          'Очищення завершено: видалено %d елементів, звільнено %s.',
          'Clean done: %d items deleted, %s freed.'),
          [FStats.Count, FormatBytes(FStats.Bytes)]));
      end;
    wmDownload:
      ReloadDatabases;   // a fresh copy on disk → reload everything
  end;
end;

procedure TCleanerForm.ShowStatus(const AMsg: string);
var
  Idx: Integer;
  P: string;
  RI: TRowInfo;
begin
  // live clean progress: grey out the row the engine just deleted
  if (Pos('Deleted: ', AMsg) = 1) then
  begin
    P := Copy(AMsg, 10, MaxInt);
    Idx := FRowMap.IndexOf(P);
    if (Idx >= 0) and (FRowMap.Objects[Idx] <> nil) then
    begin
      RI := TRowInfo(TListItem(FRowMap.Objects[Idx]).Data);
      if RI <> nil then RI.Done := True;
    end;
  end
  else if (Pos('Registry: ', AMsg) = 1) then
  begin
    P := Copy(AMsg, 11, MaxInt);
    Idx := FRowMap.IndexOf(P);
    if (Idx >= 0) and (FRowMap.Objects[Idx] <> nil) then
    begin
      RI := TRowInfo(TListItem(FRowMap.Objects[Idx]).Data);
      if RI <> nil then RI.Done := True;
    end;
  end;
  lblInfo.Caption := AMsg;
  lblInfo.Update;
end;

procedure TCleanerForm.SetBusy(ABusy: Boolean);
begin
  btnAnalyze.Enabled := not ABusy;
  btnClean.Enabled := (not ABusy) and (FResults <> nil) and
                      (FResults.Count > 0);
  btnCancel.Enabled := ABusy;
  btnPresets.Enabled := not ABusy;
  pgEntries.Enabled := not ABusy;
  pnlDb.Enabled := not ABusy;
  tmrProgress.Enabled := ABusy;
  if not ABusy then
    pbProgress.Position := 0;
end;

procedure TCleanerForm.TimerTick(Sender: TObject);
var
  I, Done, Total: Integer;
begin
  Done := 0; Total := 0;
  for I := 0 to FWorkers.Count - 1 do
  begin
    Done := Done + TCleanerThread(FWorkers[I]).DoneCount;
    Total := Total + TCleanerThread(FWorkers[I]).Total;
  end;
  if Total > 0 then
  begin
    pbProgress.Style := pbstNormal;
    pbProgress.Position := Min(100, Done * 100 div Total);
  end
  else
    pbProgress.Style := pbstMarquee;   // parse/download: total unknown
  lvResults.Invalidate;              // refresh Done marks cheaply
end;

{ Copies the live check state of ATree into ACheckedInto (all checked
  names) and, if given, AUncheckedInto (names unticked despite
  Default=True — the deviation list, same semantics as SaveSelection).
  PopulateEntries re-applies the pair after a database reload, so a
  «Правила…»/source-toggle reload can't resurrect Default= checkmarks
  the user just removed — yet entries new to the pool still get their
  factory Default=. }
procedure TCleanerForm.SnapshotState(const ATree: TBaseVirtualTree;
  const ACheckedInto, AUncheckedInto: TStringList);
var
  N: PVirtualNode;
  E: TCleanerEntry;
begin
  ACheckedInto.Clear;
  if AUncheckedInto <> nil then AUncheckedInto.Clear;
  N := ATree.GetFirst;
  while N <> nil do
  begin
    E := EntOf(ATree, N);
    if E <> nil then
    begin
      if ATree.CheckState[N] = csCheckedNormal then
        ACheckedInto.Add(E.Name)
      else if (AUncheckedInto <> nil) and E.Default and E.Detected then
        AUncheckedInto.Add(E.Name);
    end;
    N := ATree.GetNext(N);
  end;
end;

procedure TCleanerForm.PopulateEntries;
var
  Sort: TStringList;
  I, CatOrder: Integer;
  E: TCleanerEntry;
  Cat, Key: string;
  LV: TBaseVirtualTree;
  N: PVirtualNode;
  D: PEntNode;
begin
  // All entries are listed — undetected ones stay visible but grey.
  // One sorted pass split across two tabs: credential-type entries
  // (passwords, sessions, cookies…) go to tsSecurity where they can be
  // nuked deliberately, the rest to tsClean.
  // A reload clears the trees in WorkerDone (wmLoad) AFTER snapshotting
  // the checkmarks into FSavedSelection/FSavedSec — the node data points
  // into the freed entry pool there, so snapshotting here would be a
  // use-after-free. This repopulate therefore only restores the saved
  // snapshot, never re-reads live nodes.
  Sort := TStringList.Create;
  try
    Sort.Sorted := True;
    Sort.Duplicates := dupAccept;
    for I := 0 to FEntries.Count - 1 do
    begin
      E := FEntries[I];
      ResolveCategory(E, Cat, CatOrder);
      Key := Format('%.6d|%s|%s', [CatOrder, Cat, E.Name]);
      Sort.AddObject(Key, E);
    end;
    Inc(FCheckGuard);
    lvEntries.BeginUpdate;
    lvSec.BeginUpdate;
    try
      lvEntries.Clear;
      lvSec.Clear;
      for I := 0 to Sort.Count - 1 do
      begin
        E := TCleanerEntry(Sort.Objects[I]);
        ResolveCategory(E, Cat, CatOrder);
        if IsSecurityEntryFor(E) then
          LV := lvSec
        else
          LV := lvEntries;
        N := LV.AddChild(nil);
        // AddChild does NOT init the node — without ReinitNode the
        // (lazy) OnInitNode would fire later and Initialize() would
        // wipe the data we are about to write. Force init first.
        LV.ReinitNode(N, False);
        D := LV.GetNodeData(N);
        D^.E := E;
        D^.Cat := Cat;
        // A saved session selection wins over the Default= pre-check;
        // without one, Default= only pre-checks what is actually
        // installed — there is nothing to find on a missing app anyway.
        if LV = lvSec then
          // never pre-checked at session start (wiping saved logins is
          // a deliberate act) — but an explicit tick survives reloads
          CheckNode(LV, N, FSavedSec.IndexOf(E.Name) >= 0)
        else if FSelSaved or (FSavedSelection.Count > 0) or
                (FSavedUnchecked.Count > 0) then
          { Saved state is a delta against Default=: in the checked list
            → on; in the unchecked-deviation list → off; in neither →
            factory 'Default and Detected'. A newly added entry lands in
            neither list, so it pre-checks by Default= instead of
            silently appearing unticked. }
          CheckNode(LV, N, (FSavedSelection.IndexOf(E.Name) >= 0) or
            ((FSavedUnchecked.IndexOf(E.Name) < 0) and
             E.Default and E.Detected))
        else
          CheckNode(LV, N, E.Default and E.Detected);
      end;
    finally
      lvSec.EndUpdate;
      lvEntries.EndUpdate;
      Dec(FCheckGuard);
    end;
  finally
    Sort.Free;
  end;
end;

procedure TCleanerForm.PopulateResults;
var
  I, J: Integer;
  R: TCleanResult;
  RI: TRegDeleteItem;
  Row: TRowInfo;
  It: TListItem;
begin
  FRowInfos.Clear;
  FRowMap.Clear;
  lvResults.Items.BeginUpdate;
  try
    lvResults.Items.Clear;
    for I := 0 to FResults.Count - 1 do
    begin
      R := FResults[I];
      for J := 0 to R.FilesToDelete.Count - 1 do
      begin
        Row := TRowInfo.Create;
        Row.Kind := rkFile;
        Row.Size := GetFileSizeBytes(R.FilesToDelete[J]);
        FRowInfos.Add(Row);
        It := lvResults.Items.Add;
        It.Caption := R.FilesToDelete[J];
        It.SubItems.Add(Lg('Файл', 'Файл', 'Файл', 'File'));
        if Row.Size >= 0 then
          It.SubItems.Add(FormatBytes(Row.Size))
        else
          It.SubItems.Add('—');
        It.Data := Row;
        FRowMap.AddObject(It.Caption, It);
      end;
      for J := 0 to R.RegistryToDelete.Count - 1 do
      begin
        RI := R.RegistryToDelete[J];
        Row := TRowInfo.Create;
        if RI.IsDeleteKey then Row.Kind := rkRegKey
                          else Row.Kind := rkRegValue;
        Row.Size := -1;
        Row.RegItem := RI;
        FRowInfos.Add(Row);
        It := lvResults.Items.Add;
        It.Caption := RI.DisplayName;
        if RI.IsDeleteKey then
          It.SubItems.Add(Lg('Ключ реестра', 'Ключ рэестра',
                             'Ключ реєстру', 'Registry key'))
        else
          It.SubItems.Add(Lg('Значение реестра', 'Значэнне рэестра',
                             'Значення реєстру', 'Registry value'));
        It.SubItems.Add('—');
        It.Data := Row;
        FRowMap.AddObject(It.Caption, It);
      end;
      { One row for the recycle-bin wipe — no file inventory exists, and
        dead-shortcut links already appear individually above. }
      if R.SpecialItems.IndexOf(SPECIAL_RECYCLEBIN) >= 0 then
      begin
        Row := TRowInfo.Create;
        Row.Kind := rkSpecial;
        Row.Size := R.SpecialBytes;
        FRowInfos.Add(Row);
        It := lvResults.Items.Add;
        It.Caption := Lg('Корзина', 'Сметніца', 'Кошик', 'Recycle Bin');
        It.SubItems.Add(Lg('Очистка корзины', 'Ачыстка сметніцы',
                           'Очищення кошика', 'Empty recycle bin'));
        if Row.Size > 0 then
          It.SubItems.Add(FormatBytes(Row.Size))
        else
          It.SubItems.Add('—');
        It.Data := Row;
        // the engine reports the wipe as 'Deleted: Recycle Bin' — the map
        // key matches so the live progress greys the row out
        FRowMap.AddObject('Recycle Bin', It);
      end;
    end;
  finally
    lvResults.Items.EndUpdate;
  end;
end;

{ Checked entries come from BOTH tabs — checking passwords on the
  security tab and switching back must not lose them. }
function TCleanerForm.CheckedEntriesList: TList;
var
  N: PVirtualNode;
begin
  Result := TList.Create;
  N := lvEntries.GetFirstChecked;
  while N <> nil do
  begin
    Result.Add(EntOf(lvEntries, N));
    N := lvEntries.GetNextChecked(N);
  end;
  N := lvSec.GetFirstChecked;
  while N <> nil do
  begin
    Result.Add(EntOf(lvSec, N));
    N := lvSec.GetNextChecked(N);
  end;
end;

{ Live 'picked' counter for the status line — CheckedEntriesList allocates,
  this one just walks both lists. }
function TCleanerForm.CheckedCount: Integer;
var
  N: PVirtualNode;
begin
  Result := 0;
  N := lvEntries.GetFirstChecked;
  while N <> nil do
  begin
    Inc(Result);
    N := lvEntries.GetNextChecked(N);
  end;
  N := lvSec.GetFirstChecked;
  while N <> nil do
  begin
    Inc(Result);
    N := lvSec.GetNextChecked(N);
  end;
end;

{ Selection text with the live picked count. Only shown during the
  'pick entries' phase (idle, no review list yet) — once Analyse has
  produced results, the boxes no longer matter until the next round. }
procedure TCleanerForm.RefreshSelectionInfo;
begin
  if (FWorkers.Count > 0) or (FResults.Count > 0) or
     (lvEntries.TotalCount = 0) then Exit;
  ShowStatus(Format(Lg(
    'База: %d записей, установлено: %d, выбрано: %d. Отметьте нужные и нажмите «Анализ».',
    'База: %d запісаў, усталявана: %d, выбрана: %d. Адзначце патрэбныя і націсніце «Аналіз».',
    'База: %d записів, встановлено: %d, вибрано: %d. Позначте потрібні та натисніть «Аналіз».',
    'Database: %d entries, installed: %d, selected: %d. Check entries and press Analyze.'),
    [FBaseCount, FInstalledCount, CheckedCount]));
end;

{ OnChecked fires per node AND per programmatic CheckState change —
  mass updates run under FCheckGuard so this only reacts to real clicks. }
procedure TCleanerForm.EntriesChecked(Sender: TBaseVirtualTree;
  Node: PVirtualNode);
begin
  if FCheckGuard = 0 then RefreshSelectionInfo;
end;

{ The list the context menu was invoked on — used to pick the category.
  Presets themselves now span both tabs. }
function TCleanerForm.ActiveList: TLazVirtualStringTree;
begin
  if pgEntries.ActivePage = tsSecurity then
    Result := lvSec
  else
    Result := lvEntries;
end;

procedure TCleanerForm.BtnAnalyzeClick(Sender: TObject);
var
  Sel: TList;
begin
  if FWorkers.Count > 0 then Exit;
  Sel := CheckedEntriesList;
  if Sel.Count = 0 then
  begin
    Sel.Free;
    MessageDlg(Lg('Отметьте хотя бы одну запись.', 'Адзначце хаця б адзін запіс.',
                  'Позначте хоча б один запис.', 'Check at least one entry.'),
               mtInformation, [mbOK], 0);
    Exit;
  end;
  FResults.Clear;
  FRowInfos.Clear;
  FRowMap.Clear;
  lvResults.Items.Clear;
  ShowStatus(Lg('Анализ...', 'Аналіз...', 'Аналіз...', 'Analyzing...'));
  StartWorkers(wmAnalyze, Sel);
  Sel.Free;   // workers took per-thread slice copies
end;

procedure TCleanerForm.BtnCleanClick(Sender: TObject);
var
  I, N: Integer;
  Total: Int64;
begin
  if (FWorkers.Count > 0) or (FResults.Count = 0) then Exit;
  N := 0; Total := 0;
  for I := 0 to FResults.Count - 1 do
  begin
    N := N + FResults[I].FilesToDelete.Count +
         FResults[I].RegistryToDelete.Count +
         FResults[I].SpecialItems.Count;
    Total := Total + FResults[I].TotalBytes;
  end;
  if N = 0 then
  begin
    MessageDlg(Lg('Нечего удалять.', 'Няма чаго выдаляць.',
                  'Немає чого видаляти.', 'Nothing to delete.'),
               mtInformation, [mbOK], 0);
    Exit;
  end;
  // Direct delete — no recycle bin. Say it plainly, once.
  if MessageDlg(Format(Lg(
      'Удалить %d элементов (%s)? Файлы удалятся насовсем, без корзины.',
      'Выдаліць %d элементаў (%s)? Файлы выдаляцца назаўжды, без сметніцы.',
      'Видалити %d елементів (%s)? Файли видаляться назавжди, без кошика.',
      'Delete %d items (%s)? Files are deleted permanently, no recycle bin.'),
      [N, FormatBytes(Total)]),
      mtConfirmation, [mbYes, mbNo], 0) <> mrYes then Exit;

  if not OfferCloseApps then Exit;

  // shell down for the whole clean — file locks and shell-held
  // handles in user profiles go away with explorer.exe
  ShowStatus(Lg('Завершение оболочки Windows...',
                'Завяршэнне абалонкі Windows...',
                'Завершення оболонки Windows...',
                'Stopping Windows shell...'));
  Application.ProcessMessages;
  FShellDown := StopShell > 0;

  FStats.Count := 0;
  FStats.Bytes := 0;
  ShowStatus(Lg('Очистка...', 'Ачыстка...', 'Очищення...', 'Cleaning...'));
  StartWorkers(wmClean, nil);
end;

function TCleanerForm.OfferCloseApps: Boolean;
var
  Keys, Roots, Resolved: TStringList;
  Exp: TPathExpander;
  Apps: TRunningAppArray;
  I, J: Integer;
  F: TCloseAppsForm;
begin
  Result := True;
  Keys := TStringList.Create;
  Roots := TStringList.Create;
  Exp := TPathExpander.Create;
  try
    ShowStatus(Lg('Подготовка: поиск блокирующих приложений...',
                  'Падрыхтоўка: пошук працэсаў, што блакуюць...',
                  'Підготовка: пошук процесів, що блокують...',
                  'Preparing: scanning for blocking apps...'));
    pbProgress.Style := pbstMarquee;
    Application.ProcessMessages;
    for I := 0 to FResults.Count - 1 do
    begin
      Keys.Add(FResults[I].Entry.Name);
      for J := 0 to FResults[I].Entry.FileKeys.Count - 1 do
      begin
        Resolved := Exp.ResolvePaths(FResults[I].Entry.FileKeys[J].Path);
        try
          Roots.AddStrings(Resolved);
        finally
          Resolved.Free;
        end;
      end;
    end;
    Apps := FindAppsToClose(Keys, Roots);
    if Length(Apps) = 0 then Exit;
    F := TCloseAppsForm.CreateDlg(Self, Apps);
    try
      case F.ShowModal of
        mrYes: CloseAppsInParallel(F.CheckedApps);
        mrNo: ;   // clean anyway, locked files are skipped
      else
        Exit(False);   // mrCancel — abort the whole clean
      end;
    finally
      F.Free;
    end;
  finally
    Exp.Free;
    Roots.Free;
    Keys.Free;
  end;
end;

procedure TCleanerForm.CloseAppsInParallel(const AApps: TRunningAppArray);
var
  Threads: array of TCloseAppThread;
  I, Done, Total: Integer;
  Disp: string;
begin
  Total := Length(AApps);
  if Total = 0 then Exit;
  SetLength(Threads, Total);
  for I := 0 to High(AApps) do
  begin
    Threads[I] := TCloseAppThread.Create(True);
    Threads[I].FreeOnTerminate := False;
    Threads[I].App := AApps[I];
    Threads[I].Start;
  end;
  Done := 0;
  pbProgress.Style := pbstNormal;
  pbProgress.Position := 0;
  for I := 0 to High(Threads) do
  begin
    while not Threads[I].Finished do
    begin
      Application.ProcessMessages;
      Sleep(40);
    end;
    Inc(Done);
    pbProgress.Position := Done * 100 div Total;
    Disp := Threads[I].App.AppName;
    if Disp = '' then Disp := Threads[I].App.ExeName;
    ShowStatus(Format(Lg('Закрыто %d из %d: %s', 'Закрыта %d з %d: %s',
                         'Закрито %d з %d: %s', 'Closed %d of %d: %s'),
                      [Done, Total, Disp]));
    Threads[I].Free;
  end;
  pbProgress.Style := pbstMarquee;
end;

procedure TCleanerForm.BtnCancelClick(Sender: TObject);
var
  I: Integer;
begin
  for I := 0 to FWorkers.Count - 1 do
    TCleanerThread(FWorkers[I]).Cancel;
  btnCancel.Enabled := False;
  ShowStatus(Lg('Отмена...', 'Адмена...', 'Скасування...', 'Cancelling...'));
end;

procedure TCleanerForm.BtnPresetsClick(Sender: TObject);
var
  F: TPresetForm;
begin
  if (FEntries = nil) or (FEntries.Count = 0) then Exit;
  F := TPresetForm.CreateDlg(Self, FEntries);
  try
    if F.ShowModal = mrOk then ApplyPresetSelection(F);
  finally
    F.Free;
  end;
end;

{ Keep-list lives in CleanSweep.ini; it is re-read when a clean starts,
  so edits made in this dialog apply to the next run immediately. }
procedure TCleanerForm.BtnCookiesClick(Sender: TObject);
begin
  ShowCookieDialog(Self);
end;

{ Custom-folder edits (toggles, new files) land in the pool only after
  the databases are re-merged — reload so the change is visible. }
procedure TCleanerForm.BtnCustomDirClick(Sender: TObject);
begin
  ShowCustomDialog(Self);
  ReloadDatabases;
end;

procedure TCleanerForm.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  if FWorkers.Count > 0 then
  begin
    MessageDlg(Lg('Идёт операция — сначала отмените её.',
                  'Ідзе аперацыя — спачатку адмяніце яе.',
                  'Триває операція — спочатку скасуйте її.',
                  'An operation is running — cancel it first.'),
               mtInformation, [mbOK], 0);
    CanClose := False;
  end;
  if CanClose then SaveSelection;
end;

{ ═══════════════ Entries list: checks, presets, sort, colours ═══════════════ }

procedure TCleanerForm.SetAllEntries(AChecked: Boolean);
var
  N: PVirtualNode;
begin
  Inc(FCheckGuard);
  try
    if AChecked then
    begin
      N := lvEntries.GetFirst;
      while N <> nil do
      begin
        CheckNode(lvEntries, N, True);
        N := lvEntries.GetNext(N);
      end;
      // 'Всё' must not silently mark passwords/sessions — ask, once
      if (lvSec.TotalCount > 0) and
         ConfirmSecurityMark(lvSec.TotalCount) then
      begin
        N := lvSec.GetFirst;
        while N <> nil do
        begin
          CheckNode(lvSec, N, True);
          N := lvSec.GetNext(N);
        end;
      end;
    end
    else
    begin
      N := lvEntries.GetFirst;
      while N <> nil do
      begin
        CheckNode(lvEntries, N, False);
        N := lvEntries.GetNext(N);
      end;
      N := lvSec.GetFirst;
      while N <> nil do
      begin
        CheckNode(lvSec, N, False);
        N := lvSec.GetNext(N);
      end;
    end;
  finally
    Dec(FCheckGuard);
  end;
  RefreshSelectionInfo;
end;

{ Applies the preset form's checkbox combo. The cleanup tab is ticked
  straight away; the security tab only after the explicit confirm. }
procedure TCleanerForm.ApplyPresetSelection(const F: TPresetForm);
var
  SecNew: Integer;
  N: PVirtualNode;
begin
  SecNew := 0;
  N := lvSec.GetFirst;
  while N <> nil do
  begin
    if F.CheckedFor(EntOf(lvSec, N)) then Inc(SecNew);
    N := lvSec.GetNext(N);
  end;
  Inc(FCheckGuard);
  try
    N := lvEntries.GetFirst;
    while N <> nil do
    begin
      CheckNode(lvEntries, N, F.CheckedFor(EntOf(lvEntries, N)));
      N := lvEntries.GetNext(N);
    end;
    if (SecNew = 0) or ConfirmSecurityMark(SecNew) then
    begin
      N := lvSec.GetFirst;
      while N <> nil do
      begin
        CheckNode(lvSec, N, F.CheckedFor(EntOf(lvSec, N)));
        N := lvSec.GetNext(N);
      end;
    end;
    // security list left untouched when the confirm was declined
  finally
    Dec(FCheckGuard);
  end;
  RefreshSelectionInfo;
end;

procedure TCleanerForm.MenuCheckAllClick(Sender: TObject);
begin
  SetAllEntries(True);
end;

procedure TCleanerForm.MenuCheckNoneClick(Sender: TObject);
begin
  SetAllEntries(False);
end;

{ Checks every entry in the same category as the selected one — the
  flat ListView has no parent node to check, so this replaces it. }
procedure TCleanerForm.MenuCheckCategoryClick(Sender: TObject);
var
  SelCat: string;
  LV: TLazVirtualStringTree;
  N: PVirtualNode;
begin
  LV := ActiveList;
  if LV.FocusedNode = nil then Exit;
  SelCat := NodeCat(LV, LV.FocusedNode);
  Inc(FCheckGuard);
  try
    N := lvEntries.GetFirst;
    while N <> nil do
    begin
      if NodeCat(lvEntries, N) = SelCat then
        CheckNode(lvEntries, N, True);
      N := lvEntries.GetNext(N);
    end;
    N := lvSec.GetFirst;
    while N <> nil do
    begin
      if NodeCat(lvSec, N) = SelCat then
        CheckNode(lvSec, N, True);
      N := lvSec.GetNext(N);
    end;
  finally
    Dec(FCheckGuard);
  end;
  RefreshSelectionInfo;
end;

{ «Править запись…»: a Custom entry opens its own file in the rule
  editor; a bundled entry is first cloned into Custom\<name>.ini — the
  clone overrides the original on the next merge (custom wins), so the
  shipped databases stay untouched. Reload picks the change up. }
{ Readable ini filename for an entry name: drops the winapp2 ' *'
  suffix and replaces filename-illegal characters. }
function EntryIniFileName(const AEntryName: string): string;
var
  S: string;
  I: Integer;
begin
  S := TrimRight(AEntryName);
  if (S <> '') and (S[Length(S)] = '*') then
    S := TrimRight(Copy(S, 1, Length(S) - 1));
  for I := 1 to Length(S) do
    if S[I] in ['\', '/', ':', '*', '?', '"', '<', '>', '|'] then
      S[I] := '_';
  Result := S;
end;

procedure TCleanerForm.MenuEditEntryClick(Sender: TObject);
var
  LV: TLazVirtualStringTree;
  E: TCleanerEntry;
  Path, Safe: string;
  SL: TStringList;
begin
  LV := ActiveList;
  if LV.FocusedNode = nil then Exit;
  E := EntOf(LV, LV.FocusedNode);
  if E.IsCustom and (E.SourceFile <> '') then
    Path := E.SourceFile
  else
  begin
    if MessageDlg(Lg(
        'Это запись встроенной базы. Скопировать её в Custom и править ' +
        'копию? Она заменит оригинал при загрузке.',
        'Гэта запіс убудаванай базы. Скапіраваць у Custom і правіць ' +
        'копію? Яна заменіць арыгінал пры загрузцы.',
        'Це запис вбудованої бази. Скопіювати у Custom і правити ' +
        'копію? Вона замінить оригінал при завантаженні.',
        'This is a bundled-database entry. Copy it into Custom and edit ' +
        'the copy? It overrides the original on load.'),
        mtConfirmation, [mbYes, mbNo], 0) <> mrYes then Exit;
    Safe := EntryIniFileName(E.Name);
    Path := CustomDir + Safe + '.ini';
    if FileExists(Path) then
      if MessageDlg(Format(Lg('«%s» уже есть в Custom — перезаписать?',
          '«%s» ужо ёсць у Custom — перазапісаць?',
          '«%s» уже є у Custom — перезаписати?',
          '"%s" already exists in Custom — overwrite?'), [Safe + '.ini']),
          mtConfirmation, [mbYes, mbNo], 0) <> mrYes then Exit;
    ForceDirectories(CustomDir);
    SL := EntryToIni(E);
    try
      SL.SaveToFile(Path);
    finally
      SL.Free;
    end;
  end;
  if EditRuleDialog(Self, Path) = mrOk then
    ReloadDatabases;
end;

{ Bulk copy: every selected bundled entry is serialized into its own
  Custom\<name>.ini so it can be studied and tuned in the rule editor.
  Custom copies override the originals on the next database merge. }
procedure TCleanerForm.MenuCopyToCustomClick(Sender: TObject);
var
  LV: TLazVirtualStringTree;
  N: PVirtualNode;
  E: TCleanerEntry;
  Copied, Skipped: Integer;
  Path, LastPath: string;
  SL: TStringList;
  OwAll: Boolean;
  MR: TModalResult;
begin
  LV := ActiveList;
  if LV = nil then Exit;
  Copied := 0;
  Skipped := 0;
  OwAll := False;
  LastPath := '';
  N := LV.GetFirstSelected;
  if N = nil then N := LV.FocusedNode;
  if N = nil then
  begin
    MessageDlg(Lg('Сначала выберите в списке хотя бы одну запись ' +
      '(Ctrl/Shift — несколько).',
      'Спачатку абярыце ў спісе хаця б адзін запіс ' +
      '(Ctrl/Shift — некалькі).',
      'Спочатку оберіть у списку хоча б один запис ' +
      '(Ctrl/Shift — декілька).',
      'Select at least one entry in the list first ' +
      '(Ctrl/Shift for several).'),
      mtInformation, [mbOK], 0);
    Exit;
  end;
  ForceDirectories(CustomDir);
  while N <> nil do
  begin
    E := EntOf(LV, N);
    N := LV.GetNextSelected(N);
    if E = nil then Continue;
    if E.IsCustom then
    begin
      Inc(Skipped);      // already lives in Custom — nothing to copy
      Continue;
    end;
    Path := CustomDir + EntryIniFileName(E.Name) + '.ini';
    if FileExists(Path) and (not OwAll) then
    begin
      MR := MessageDlg(Format(Lg(
        '«%s» уже есть в Custom. Перезаписать её копией из базы?',
        '«%s» ужо ёсць у Custom. Перазапісаць копіяй з базы?',
        '«%s» уже є у Custom. Перезаписати копією з бази?',
        '"%s" already exists in Custom. Overwrite with the DB copy?'),
        [ExtractFileName(Path)]),
        mtConfirmation, [mbYes, mbYesToAll, mbNo, mbCancel], 0);
      if MR = mrCancel then Break;
      if MR = mrNo then
      begin
        Inc(Skipped);
        Continue;
      end;
      if MR = mrYesToAll then OwAll := True;
    end;
    SL := EntryToIni(E);
    try
      SL.SaveToFile(Path);
    finally
      SL.Free;
    end;
    LastPath := Path;
    Inc(Copied);
  end;
  if Copied = 0 then
  begin
    if Skipped > 0 then
      MessageDlg(Lg('Выбранные записи уже в Custom — копировать нечего.',
        'Абраныя запісы ўжо ў Custom — капіраваць няма чаго.',
        'Обрані записи вже у Custom — копіювати нема чого.',
        'The selected entries already live in Custom — nothing to copy.'),
        mtInformation, [mbOK], 0)
    else
      MessageDlg(Lg('В выбранных строках нет записей для копирования.',
        'У абраных радках няма запісаў для капіравання.',
        'В обраних рядках немає записів для копіювання.',
        'The selected rows hold no entries to copy.'),
        mtInformation, [mbOK], 0);
    Exit;
  end;
  ReloadDatabases;
  if Copied = 1 then
  begin
    if MessageDlg(Lg('Запись скопирована в Custom. Открыть в редакторе?',
      'Запіс скапіраваны ў Custom. Адкрыць у рэдактары?',
      'Запис скопійовано у Custom. Відкрити у редакторі?',
      'Entry copied into Custom. Open it in the editor?'),
      mtConfirmation, [mbYes, mbNo], 0) = mrYes then
      if EditRuleDialog(Self, LastPath) = mrOk then
        ReloadDatabases;
  end
  else
    MessageDlg(Format(Lg('Скопировано в Custom: %d записей (пропущено %d).',
      'Скапіравана ў Custom: %d запісаў (прапушчана %d).',
      'Скопійовано у Custom: %d записів (пропущено %d).',
      'Copied into Custom: %d entries (skipped %d).'),
      [Copied, Skipped]), mtInformation, [mbOK], 0);
end;

procedure TCleanerForm.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if Key = VK_F1 then
  begin
    ShowAboutDialog(Self);
    Key := 0;
  end;
end;

{ Entry warnings matter ('deletes saved passwords' etc.) — surface them
  in the status line while nothing else is running. }
procedure TCleanerForm.EntriesFocusChanged(Sender: TBaseVirtualTree;
  Node: PVirtualNode; Column: TColumnIndex);
var
  E: TCleanerEntry;
begin
  if (Node = nil) or (FWorkers.Count > 0) then Exit;
  E := EntOf(Sender, Node);
  if (E <> nil) and (E.Warning <> '') then
    ShowStatus('⚠ ' + E.Name + ': ' + E.Warning);
end;

var
  GEntCol: Integer = 0;
  GEntAsc: Boolean = True;
  GResCol: Integer = 0;
  GResAsc: Boolean = True;

{ SortTree applies the direction itself — this always compares
  ascending (category text for col 1, entry name otherwise/tiebreak). }
procedure TCleanerForm.EntriesCompareNodes(Sender: TBaseVirtualTree;
  Node1, Node2: PVirtualNode; Column: TColumnIndex; var Result: Integer);
var
  D1, D2: PEntNode;
begin
  D1 := Sender.GetNodeData(Node1);
  D2 := Sender.GetNodeData(Node2);
  if Column = 1 then
    Result := CompareText(D1^.Cat, D2^.Cat)
  else
    Result := 0;
  if Result = 0 then
    Result := CompareText(D1^.E.Name, D2^.E.Name);
end;

procedure TCleanerForm.EntriesHeaderClick(Sender: TVTHeader;
  HitInfo: TVTHeaderHitInfo);
var
  LV: TBaseVirtualTree;
begin
  if (HitInfo.Button <> mbLeft) or (HitInfo.Column < 0) then Exit;
  LV := Sender.Treeview;
  if GEntCol = HitInfo.Column then
    GEntAsc := not GEntAsc
  else
  begin
    GEntCol := HitInfo.Column;
    GEntAsc := True;
  end;
  Sender.SortColumn := GEntCol;
  if GEntAsc then
    Sender.SortDirection := sdAscending
  else
    Sender.SortDirection := sdDescending;
  LV.SortTree(GEntCol, Sender.SortDirection);
end;

{ Undetected entries are grey — visible but clearly 'not here'.
  Detected entries with a winapp2 Warning= get the 'check before
  running' colour — same idea as lcModerate in leftoverform.
  Shared by both tabs' lists. }
procedure TCleanerForm.EntriesPaintText(Sender: TBaseVirtualTree;
  const TargetCanvas: TCanvas; Node: PVirtualNode;
  Column: TColumnIndex; TextType: TVSTTextType);
var
  E: TCleanerEntry;
begin
  E := EntOf(Sender, Node);
  if E = nil then Exit;
  if not E.Detected then
    TargetCanvas.Font.Color := clGray
  else if E.Warning <> '' then
    TargetCanvas.Font.Color := RGB(200, 110, 0);
end;

procedure TCleanerForm.EntriesGetText(Sender: TBaseVirtualTree;
  Node: PVirtualNode; Column: TColumnIndex; TextType: TVSTTextType;
  var CellText: String);
var
  D: PEntNode;
begin
  D := Sender.GetNodeData(Node);
  if (D = nil) or (D^.E = nil) then Exit;
  if Column = 0 then
  begin
    CellText := D^.E.Name;
    if D^.E.Warning <> '' then CellText := CellText + ' (!)';
  end
  else
    CellText := D^.Cat;
end;

procedure TCleanerForm.EntriesInitNode(Sender: TBaseVirtualTree;
  ParentNode, Node: PVirtualNode; var InitialStates: TVirtualNodeInitStates);
begin
  Initialize(PEntNode(Sender.GetNodeData(Node))^);
  Sender.CheckType[Node] := ctCheckBox;
end;

procedure TCleanerForm.EntriesFreeNode(Sender: TBaseVirtualTree;
  Node: PVirtualNode);
begin
  Finalize(PEntNode(Sender.GetNodeData(Node))^);
end;

{ ═══════════════ Results list: sort, colours, live progress ═══════════════ }

function CompareResultsDyn(Item1, Item2: TListItem; Data: LPARAM): Integer; stdcall;
var
  R1, R2: TRowInfo;
begin
  R1 := TRowInfo(Item1.Data);
  R2 := TRowInfo(Item2.Data);
  case GResCol of
    1: Result := Ord(R1.Kind) - Ord(R2.Kind);
    2: Result := Sign(R1.Size - R2.Size);
  else
    Result := 0;
  end;
  if Result = 0 then
    Result := CompareText(Item1.Caption, Item2.Caption);
  if not GResAsc then Result := -Result;
end;

procedure TCleanerForm.ResultsColumnClick(Sender: TObject; Column: TListColumn);
begin
  if GResCol = Column.Index then
    GResAsc := not GResAsc
  else
  begin
    GResCol := Column.Index;
    GResAsc := True;
  end;
  lvResults.CustomSort(@CompareResultsDyn, 0);
end;

{ Registry rows in navy, files default; rows already deleted by Clean go
  grey — the list itself shows the live progress. }
procedure TCleanerForm.ResultsDrawItem(Sender: TCustomListView;
  AItem: TListItem; AState: TCustomDrawState; var ADefaultDraw: Boolean);
var
  R: TRowInfo;
begin
  R := TRowInfo(AItem.Data);
  if R = nil then Exit;
  if R.Done then
    Sender.Canvas.Font.Color := clGray
  else if R.Kind in [rkRegKey, rkRegValue] then
    Sender.Canvas.Font.Color := clNavy;
end;

{ ═══════════════ Results context menu ═══════════════ }

procedure TCleanerForm.MenuCopyPathClick(Sender: TObject);
begin
  if lvResults.Selected <> nil then
    Clipboard.AsText := lvResults.Selected.Caption;
end;

procedure TCleanerForm.MenuOpenFolderClick(Sender: TObject);
var
  R: TRowInfo;
begin
  if lvResults.Selected = nil then Exit;
  R := TRowInfo(lvResults.Selected.Data);
  if (R <> nil) and (R.Kind = rkFile) then
    ShowInExplorer(ExtractFileDir(lvResults.Selected.Caption));
end;

procedure TCleanerForm.MenuOpenRegeditClick(Sender: TObject);
var
  R: TRowInfo;
begin
  if lvResults.Selected = nil then Exit;
  R := TRowInfo(lvResults.Selected.Data);
  if (R <> nil) and (R.RegItem <> nil) then
    ShowInRegedit(R.RegItem.KeyPath);
end;

end.
