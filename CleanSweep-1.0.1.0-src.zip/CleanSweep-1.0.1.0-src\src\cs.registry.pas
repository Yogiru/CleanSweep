unit cs.registry;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Windows, Registry, cs.models;

{ Access flags for 64-bit registry view from a 32-bit process. }
const
  REGVIEW_64 = KEY_READ or KEY_WOW64_64KEY;
  REGVIEW_32 = KEY_READ or KEY_WOW64_32KEY;

{ Opens a registry key for reading under an explicit hive.
  Root must be HKEY_LOCAL_MACHINE / HKEY_CURRENT_USER / HKEY_USERS / HKEY_CLASSES_ROOT.
  Returns nil when the key does not exist. }
function RegOpenRead(AHive: HKEY; const APath: string; AAccess: LongWord): TRegistry;

function RegKeyExists(AHive: HKEY; const APath: string; AAccess: LongWord): Boolean;
function RegReadString(AHive: HKEY; const APath, AName: string; AAccess: LongWord): string;
procedure RegEnumSubKeys(AHive: HKEY; const APath: string; AAccess: LongWord; AOut: TStrings);
procedure RegEnumValues(AHive: HKEY; const APath: string; AAccess: LongWord; AOut: TStrings);

{ Recursive key delete (RegDeleteTreeW equivalent via recursive enum). }
function RegDeleteTree(AHive: HKEY; const APath: string; AAccess: LongWord): Boolean;
function RegDeleteValue(AHive: HKEY; const APath, AName: string; AAccess: LongWord): Boolean;
{ Normal delete, then take-ownership fallback for keys writable only by
  SYSTEM (e.g. bam\State\UserSettings). Requires elevation. }
function RegForceDeleteValue(AHive: HKEY; const APath, AName: string; AAccess: LongWord): Boolean;

{ Scans HKLM (native + WOW6432), HKCU and loaded HKU SIDs for
  Uninstall entries. Port of InstalledProgramScanner. }
procedure ScanInstalledPrograms(AOut: TProgramList;
  AIncludeSystem, AIncludeUpdates: Boolean);

implementation

uses
  cs.utils;

function RegOpenRead(AHive: HKEY; const APath: string; AAccess: LongWord): TRegistry;
begin
  Result := nil;
  try
    Result := TRegistry.Create(AAccess);
    Result.RootKey := AHive;
    if not Result.OpenKeyReadOnly(APath) then
      FreeAndNil(Result);
  except
    FreeAndNil(Result);
  end;
end;

function RegKeyExists(AHive: HKEY; const APath: string; AAccess: LongWord): Boolean;
var
  R: TRegistry;
begin
  R := RegOpenRead(AHive, APath, AAccess);
  Result := R <> nil;
  R.Free;
end;

function RegReadString(AHive: HKEY; const APath, AName: string; AAccess: LongWord): string;
var
  R: TRegistry;
begin
  Result := '';
  R := RegOpenRead(AHive, APath, AAccess);
  if R = nil then Exit;
  try
    case R.GetDataType(AName) of
      rdString, rdExpandString, rdMultiString:
        Result := R.ReadString(AName);
      rdInteger:
        Result := IntToStr(R.ReadInteger(AName));
    end;
  except
    Result := '';
  end;
  R.Free;
end;

procedure RegEnumSubKeys(AHive: HKEY; const APath: string; AAccess: LongWord; AOut: TStrings);
var
  R: TRegistry;
  Names: TStringList;
begin
  if APath = '' then
  begin
    // Enumerate root subkeys directly (e.g. HKEY_USERS SIDs)
    try
      R := TRegistry.Create(AAccess);
      try
        R.RootKey := AHive;
        Names := TStringList.Create;
        try
          R.GetKeyNames(Names);
          AOut.AddStrings(Names);
        finally
          Names.Free;
        end;
      finally
        R.Free;
      end;
    except
    end;
    Exit;
  end;
  R := RegOpenRead(AHive, APath, AAccess);
  if R = nil then Exit;
  try
    Names := TStringList.Create;
    try
      R.GetKeyNames(Names);
      AOut.AddStrings(Names);
    finally
      Names.Free;
    end;
  finally
    R.Free;
  end;
end;

procedure RegEnumValues(AHive: HKEY; const APath: string; AAccess: LongWord; AOut: TStrings);
var
  R: TRegistry;
  Names: TStringList;
begin
  R := RegOpenRead(AHive, APath, AAccess);
  if R = nil then Exit;
  try
    Names := TStringList.Create;
    try
      R.GetValueNames(Names);
      AOut.AddStrings(Names);
    finally
      Names.Free;
    end;
  finally
    R.Free;
  end;
end;

function RegDeleteTreeW(hKey: HKEY; lpSubKey: LPCWSTR): LONG; stdcall;
  external 'advapi32.dll' name 'RegDeleteTreeW';
function RegDeleteValueW(hKey: HKEY; lpValueName: LPCWSTR): LONG; stdcall;
  external 'advapi32.dll' name 'RegDeleteValueW';
function RegOpenKeyExW(hKey: HKEY; lpSubKey: LPCWSTR; ulOptions: DWORD;
  samDesired: REGSAM; var phkResult: HKEY): LONG; stdcall;
  external 'advapi32.dll' name 'RegOpenKeyExW';
function RegCloseKey(hKey: HKEY): LONG; stdcall;
  external 'advapi32.dll' name 'RegCloseKey';
function RegQueryValueExW(hKey: HKEY; lpValueName: LPCWSTR; lpReserved: PDWORD;
  lpType: PDWORD; lpData: PByte; lpcbData: PDWORD): LONG; stdcall;
  external 'advapi32.dll' name 'RegQueryValueExW';
function RegEnumKeyExW(hKey: HKEY; dwIndex: DWORD; lpName: LPWSTR;
  var lpcchName: DWORD; lpReserved: PDWORD; lpClass: LPWSTR;
  lpcchClass: PDWORD; lpftLastWriteTime: PFileTime): LONG; stdcall;
  external 'advapi32.dll' name 'RegEnumKeyExW';

{ Unicode-safe raw-W readers. TRegistry is ANSI in FPC — non-ASCII
  value/key names (CJK program names) degrade to '?'. }
function RegValueExistsW(AKey: HKEY; const AName: string): Boolean;
begin
  Result := RegQueryValueExW(AKey, PWideChar(UTF8Decode(AName)),
    nil, nil, nil, nil) = ERROR_SUCCESS;
end;

function RegReadStringW(AKey: HKEY; const AName: string): string;
var
  T, Size: DWORD;
  Buf: array of Byte;
  D: DWORD;
begin
  Result := '';
  Size := 0;
  if RegQueryValueExW(AKey, PWideChar(UTF8Decode(AName)),
       nil, @T, nil, @Size) <> ERROR_SUCCESS then Exit;
  case T of
    REG_SZ, REG_EXPAND_SZ, REG_MULTI_SZ:
      begin
        SetLength(Buf, Size + 2);
        FillChar(Buf[0], Size + 2, 0);
        if RegQueryValueExW(AKey, PWideChar(UTF8Decode(AName)),
             nil, @T, @Buf[0], @Size) = ERROR_SUCCESS then
          Result := UTF8Encode(WideString(PWideChar(@Buf[0])));
      end;
    REG_DWORD:
      begin
        D := 0; Size := SizeOf(D);
        if RegQueryValueExW(AKey, PWideChar(UTF8Decode(AName)),
             nil, @T, @D, @Size) = ERROR_SUCCESS then
          Result := IntToStr(D);
      end;
  end;
end;

function RegReadDwordW(AKey: HKEY; const AName: string;
  out AValue: DWORD): Boolean;
var
  T, Size: DWORD;
begin
  AValue := 0;
  Size := SizeOf(AValue);
  Result := RegQueryValueExW(AKey, PWideChar(UTF8Decode(AName)),
    nil, @T, @AValue, @Size) = ERROR_SUCCESS;
end;

{ Enumerates subkey names of an open key as UTF-8. }
procedure RegEnumKeysW(AKey: HKEY; AOut: TStrings);
var
  Idx, Len: DWORD;
  Buf: array[0..255] of WideChar;
begin
  Idx := 0;
  repeat
    Len := SizeOf(Buf) div 2;
    FillChar(Buf, SizeOf(Buf), 0);
    if RegEnumKeyExW(AKey, Idx, Buf, Len, nil, nil, nil, nil) <>
       ERROR_SUCCESS then Break;
    AOut.Add(UTF8Encode(WideString(Buf)));
    Inc(Idx);
  until False;
end;

function RegDeleteTree(AHive: HKEY; const APath: string; AAccess: LongWord): Boolean;
var
  Parent, Leaf: string;
  Sep: Integer;
  H: HKEY;
  Sam: REGSAM;
begin
  // Open the parent with an explicit WOW64 view, then delete the leaf
  // subtree — otherwise a 32-bit process would be redirected to WOW6432Node.
  Sam := (AAccess and (KEY_WOW64_64KEY or KEY_WOW64_32KEY)) or KEY_ALL_ACCESS;
  Sep := LastDelimiter('\', APath);
  if Sep = 0 then Exit(False);
  Parent := Copy(APath, 1, Sep - 1);
  Leaf := Copy(APath, Sep + 1, MaxInt);
  Result := False;
  if RegOpenKeyExW(AHive, PWideChar(UTF8Decode(Parent)), 0, Sam, H) = ERROR_SUCCESS then
  begin
    Result := RegDeleteTreeW(H, PWideChar(UTF8Decode(Leaf))) = ERROR_SUCCESS;
    RegCloseKey(H);
  end;
end;

function RegDeleteValue(AHive: HKEY; const APath, AName: string; AAccess: LongWord): Boolean;
var
  H: HKEY;
  Sam: REGSAM;
begin
  Sam := (AAccess and (KEY_WOW64_64KEY or KEY_WOW64_32KEY)) or KEY_SET_VALUE;
  Result := False;
  if RegOpenKeyExW(AHive, PWideChar(UTF8Decode(APath)), 0, Sam, H) = ERROR_SUCCESS then
  begin
    Result := RegDeleteValueW(H, PWideChar(UTF8Decode(AName))) = ERROR_SUCCESS;
    RegCloseKey(H);
  end;
end;

const
  CS_WRITE_OWNER = $00080000;
  CS_WRITE_DAC   = $00040000;
  CS_SI_OWNER    = $00000001; // OWNER_SECURITY_INFORMATION
  CS_SI_DACL     = $00000004; // DACL_SECURITY_INFORMATION

function ConvertStringSecurityDescriptorToSecurityDescriptorW(
  StringSecurityDescriptor: LPCWSTR; StringSDRevision: DWORD;
  var SecurityDescriptor: PSecurityDescriptor;
  SecurityDescriptorSize: PULONG): BOOL; stdcall;
  external 'advapi32.dll'
  name 'ConvertStringSecurityDescriptorToSecurityDescriptorW';
function RegSetKeySecurity(hKey: HKEY; SecurityInformation: DWORD;
  pSecurityDescriptor: PSecurityDescriptor): LONG; stdcall;
  external 'advapi32.dll' name 'RegSetKeySecurity';

function EnablePrivilege(const AName: string): Boolean;
var
  Tok: THandle;
  Luid: TLuid;
  TP, Prev: TTokenPrivileges;
  RetLen: DWORD;
begin
  Result := False;
  if not OpenProcessToken(GetCurrentProcess,
       TOKEN_ADJUST_PRIVILEGES or TOKEN_QUERY, Tok) then Exit;
  try
    if not LookupPrivilegeValue(nil, PChar(AName), Luid) then Exit;
    TP.PrivilegeCount := 1;
    TP.Privileges[0].Luid := Luid;
    TP.Privileges[0].Attributes := SE_PRIVILEGE_ENABLED;
    RetLen := 0;
    Result := AdjustTokenPrivileges(Tok, False, TP, 0, Prev, RetLen);
  finally
    CloseHandle(Tok);
  end;
end;

function SDFromSDDL(const S: string): PSecurityDescriptor;
begin
  Result := nil;
  ConvertStringSecurityDescriptorToSecurityDescriptorW(
    PWideChar(UTF8Decode(S)), 1, Result, nil);
end;

function RegForceDeleteValue(AHive: HKEY; const APath, AName: string;
  AAccess: LongWord): Boolean;
var
  H: HKEY;
  Wow: REGSAM;
  SD: PSecurityDescriptor;
begin
  Result := RegDeleteValue(AHive, APath, AName, AAccess);
  if Result then Exit;

  Wow := AAccess and (KEY_WOW64_64KEY or KEY_WOW64_32KEY);
  if not EnablePrivilege('SeTakeOwnershipPrivilege') then Exit(False);
  EnablePrivilege('SeRestorePrivilege');

  // 1) take ownership (owner := Builtin Administrators)
  SD := SDFromSDDL('O:BA');
  if SD = nil then Exit(False);
  try
    if RegOpenKeyExW(AHive, PWideChar(UTF8Decode(APath)), 0,
         Wow or CS_WRITE_OWNER, H) <> ERROR_SUCCESS then Exit(False);
    RegSetKeySecurity(H, CS_SI_OWNER, SD);
    RegCloseKey(H);
  finally
    LocalFree(HLOCAL(SD));
  end;

  // 2) grant Administrators full control (inherited ACEs still apply)
  SD := SDFromSDDL('D:(A;;KA;;;BA)');
  if SD = nil then Exit(False);
  try
    if RegOpenKeyExW(AHive, PWideChar(UTF8Decode(APath)), 0,
         Wow or CS_WRITE_DAC, H) <> ERROR_SUCCESS then Exit(False);
    RegSetKeySecurity(H, CS_SI_DACL, SD);
    RegCloseKey(H);
  finally
    LocalFree(HLOCAL(SD));
  end;

  Result := RegDeleteValue(AHive, APath, AName, AAccess);
end;

procedure ScanInstalledPrograms(AOut: TProgramList;
  AIncludeSystem, AIncludeUpdates: Boolean);
const
  UNINSTALL_PATH = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall';
  UNINSTALL_WOW64 = 'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall';
var
  Seen: TStringList;

  procedure ScanHive(AHive: HKEY; const ABasePath, APrefix: string;
    ASource: TRegistrySource; AAccess: LongWord);
  var
    R, Sub: HKEY;
    Sam: REGSAM;
    Names: TStringList;
    I: Integer;
    D: DWORD;
    Name, Ver, Dedup, Parent: string;
    P: TInstalledProgram;
    IsSys: Boolean;
  begin
    // Raw W calls throughout: TRegistry is ANSI in FPC and mangles
    // non-ASCII DisplayName / subkey names to '?'.
    Sam := (AAccess and (KEY_WOW64_64KEY or KEY_WOW64_32KEY)) or KEY_READ;
    if RegOpenKeyExW(AHive, PWideChar(UTF8Decode(ABasePath)), 0, Sam, R) <>
       ERROR_SUCCESS then Exit;
    Names := TStringList.Create;
    try
      RegEnumKeysW(R, Names);
      for I := 0 to Names.Count - 1 do
      begin
        // subkey of an already-open key inherits the WOW64 view
        if RegOpenKeyExW(R, PWideChar(UTF8Decode(Names[I])), 0,
           KEY_READ, Sub) <> ERROR_SUCCESS then Continue;
        try
          if not RegValueExistsW(Sub, 'DisplayName') then Continue;
          Name := RegReadStringW(Sub, 'DisplayName');
          if Trim(Name) = '' then Continue;
          Ver := RegReadStringW(Sub, 'DisplayVersion');
          Dedup := LowerCase(Name + '|' + Ver);
          if Seen.IndexOf(Dedup) >= 0 then Continue;
          Seen.Add(Dedup);

          IsSys := RegReadDwordW(Sub, 'SystemComponent', D) and (D = 1);
          if IsSys and (not AIncludeSystem) then Continue;
          Parent := RegReadStringW(Sub, 'ParentKeyName');
          if (Parent <> '') and (not AIncludeUpdates) then Continue;

          P := TInstalledProgram.Create;
          P.RegistryKeyName := Names[I];
          P.RegistryPath := APrefix + '\' + ABasePath + '\' + Names[I];
          P.DisplayName := Name;
          P.DisplayVersion := Ver;
          P.Publisher := RegReadStringW(Sub, 'Publisher');
          P.InstallLocation := ExcludeTrailingPathDelimiter(
            RegReadStringW(Sub, 'InstallLocation'));
          P.InstallDate := RegReadStringW(Sub, 'InstallDate');
          P.UninstallString := RegReadStringW(Sub, 'UninstallString');
          P.QuietUninstallString := RegReadStringW(Sub, 'QuietUninstallString');
          P.DisplayIconPath := RegReadStringW(Sub, 'DisplayIcon');
          if RegReadDwordW(Sub, 'EstimatedSize', D) then
            P.EstimatedSizeKB := D;
          P.IsWindowsInstaller := RegReadDwordW(Sub, 'WindowsInstaller', D)
                                  and (D = 1);
          P.IsSystem := IsSys;
          P.ParentKeyName := Parent;
          P.Source := ASource;
          AOut.Add(P);
        finally
          RegCloseKey(Sub);
        end;
      end;
    finally
      Names.Free;
      RegCloseKey(R);
    end;
  end;

var
  Sids: TStringList;
  I: Integer;
begin
  Seen := TStringList.Create;
  try
    // HKLM native view (64-bit when running on x64)
    ScanHive(HKEY_LOCAL_MACHINE, UNINSTALL_PATH, 'HKLM', rsHKLM, REGVIEW_64);
    // HKLM 32-bit view
    ScanHive(HKEY_LOCAL_MACHINE, UNINSTALL_WOW64, 'HKLM', rsHKLM_WOW64, REGVIEW_64);
    // HKCU
    ScanHive(HKEY_CURRENT_USER, UNINSTALL_PATH, 'HKCU', rsHKCU, REGVIEW_64);
    // HKU: per-user installs under loaded hives
    Sids := TStringList.Create;
    try
      RegEnumSubKeys(HKEY_USERS, '', KEY_READ, Sids);
      for I := 0 to Sids.Count - 1 do
        ScanHive(HKEY_USERS, Sids[I] + '\' + UNINSTALL_PATH,
                 'HKU\' + Sids[I], rsHKU, REGVIEW_64);
    finally
      Sids.Free;
    end;
  finally
    Seen.Free;
  end;
end;

end.
