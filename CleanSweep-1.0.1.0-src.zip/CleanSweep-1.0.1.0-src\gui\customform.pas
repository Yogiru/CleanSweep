unit customform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, StrUtils, Forms, Controls, StdCtrls, ExtCtrls, Dialogs,
  ComCtrls, Windows,
  cs.winapp2, cs.utils, cs.lang, ruleeditform;

{ Directory the cleaner scans at load: enabled *.ini files merge into
  the entry pool at top priority; *.ini.disabled are listed but skipped
  (upstream CustomEntryService semantics). }
function CustomDir: string;

type
  { Modal manager for the Custom\ folder: file list with entry counts,
    enable/disable by renaming to .ini.disabled, open the folder,
    create a rule skeleton, delete a file. }
  TCustomForm = class(TForm)
    lvFiles: TListView;
    lblHint: TLabel;
    lblStatus: TLabel;
    btnToggle: TButton;
    btnOpenFolder: TButton;
    btnNew: TButton;
    btnEdit: TButton;
    btnDelete: TButton;
    btnHelp: TButton;
    btnClose: TButton;
    procedure FormCreate(Sender: TObject);
    procedure BtnToggleClick(Sender: TObject);
    procedure BtnOpenFolderClick(Sender: TObject);
    procedure BtnNewClick(Sender: TObject);
    procedure BtnEditClick(Sender: TObject);
    procedure BtnDeleteClick(Sender: TObject);
    procedure BtnHelpClick(Sender: TObject);
    procedure LvFilesSelectItem(Sender: TObject; AItem: TListItem;
      ASelected: Boolean);
    procedure FormDestroy(Sender: TObject);
  private
    FNames: TStringList;             // real file names per list row
    procedure RefreshList;
    function SelectedPath: string;
  end;

function ShowCustomDialog(AOwner: TComponent): TModalResult;

implementation

{$R *.lfm}

function CustomDir: string;
begin
  Result := ExtractFilePath(ParamStr(0)) + 'Custom\';
end;

function ShowCustomDialog(AOwner: TComponent): TModalResult;
var
  F: TCustomForm;
begin
  F := TCustomForm.Create(AOwner);
  try
    Result := F.ShowModal;
  finally
    F.Free;
  end;
end;

function CustomEntryCount(const APath: string): Integer;
var
  P: TWinapp2Parser;
  L: TCleanerEntryList;
begin
  Result := 0;
  P := TWinapp2Parser.Create(True);   // permissive — same as the merge
  try
    L := P.ParseFile(APath);
    try
      Result := L.Count;
    finally
      L.Free;
    end;
  finally
    P.Free;
  end;
end;

procedure TCustomForm.RefreshList;
var
  SR: TSearchRec;
  R: Integer;
  It: TListItem;
  Full, Disp: string;
  Disabled: Boolean;
begin
  lvFiles.Items.BeginUpdate;
  try
    lvFiles.Items.Clear;
    FNames.Clear;
    if DirectoryExists(CustomDir) then
    begin
      // '*.ini*' catches both enabled .ini and toggled .ini.disabled
      R := FindFirst(CustomDir + '*.ini*', faAnyFile, SR);
      try
        while R = 0 do
        begin
          if (SR.Attr and faDirectory) <> 0 then
          begin
            R := FindNext(SR);
            Continue;
          end;
          Disabled := EndsText('.ini.disabled', SR.Name);
          if (not Disabled) and (not EndsText('.ini', SR.Name)) then
          begin
            R := FindNext(SR);
            Continue;
          end;
          Full := CustomDir + SR.Name;
          It := lvFiles.Items.Add;
          if Disabled then
            Disp := Copy(SR.Name, 1, Length(SR.Name) - 9)
          else
            Disp := SR.Name;
          It.Caption := Disp;
          It.SubItems.Add(IntToStr(CustomEntryCount(Full)));
          if Disabled then
            It.SubItems.Add(Lg('выкл.', 'выкл.', 'вимк.', 'off'))
          else
            It.SubItems.Add(Lg('вкл.', 'укл.', 'увімк.', 'on'));
          FNames.Add(SR.Name);
          // 1-based: index 0 would store nil and SelectedPath would
          // silently fail on the first file in the list
          It.Data := Pointer(PtrInt(FNames.Count));
          R := FindNext(SR);
        end;
      finally
        SysUtils.FindClose(SR);
      end;
    end;
  finally
    lvFiles.Items.EndUpdate;
  end;
  lblStatus.Caption := Format(Lg('Папка: %s', 'Папка: %s', 'Папка: %s',
    'Folder: %s'), [CustomDir]);
end;

function TCustomForm.SelectedPath: string;
var
  Idx: PtrUInt;
begin
  Result := '';
  if (lvFiles.Selected = nil) or (lvFiles.Selected.Data = nil) then Exit;
  Idx := PtrUInt(lvFiles.Selected.Data) - 1;
  if Idx < PtrUInt(FNames.Count) then
    Result := CustomDir + FNames[Idx];
end;

procedure TCustomForm.FormCreate(Sender: TObject);
begin
  Caption := Lg('Свои правила очистки', 'Свае правілы ачысткі',
                'Свої правила очищення', 'Custom cleanup rules');
  lvFiles.Columns[0].Caption := Lg('Файл', 'Файл', 'Файл', 'File');
  lvFiles.Columns[1].Caption := Lg('Записей', 'Запісаў', 'Записів',
                                   'Entries');
  lvFiles.Columns[2].Caption := Lg('Состояние', 'Стан', 'Стан', 'State');
  lblHint.Caption := Lg(
    'Файлы *.ini из этой папки добавляются в базу при загрузке.',
    'Файлы *.ini з гэтай папкі дадаюцца ў базу пры загрузцы.',
    'Файли *.ini з цієї папки додаються до бази при завантаженні.',
    '*.ini files from this folder merge into the database on load.');
  btnToggle.Caption := Lg('Вкл/выкл', 'Укл/выкл', 'Увімк/вимк',
                          'Enable/disable');
  btnOpenFolder.Caption := Lg('Открыть папку', 'Адкрыць папку',
                              'Відкрити папку', 'Open folder');
  btnNew.Caption := Lg('Новая запись…', 'Новы запіс…', 'Новий запис…',
                       'New rule…');
  btnEdit.Caption := Lg('Изменить…', 'Змяніць…', 'Змінити…', 'Edit…');
  btnDelete.Caption := Lg('Удалить', 'Выдаліць', 'Видалити', 'Delete');
  btnHelp.Caption := Lg('Справка', 'Даведка', 'Довідка', 'Help');
  btnClose.Caption := Lg('Закрыть', 'Закрыць', 'Закрити', 'Close');
  FNames := TStringList.Create;
  RefreshList;
end;

procedure TCustomForm.FormDestroy(Sender: TObject);
begin
  FNames.Free;
end;

procedure TCustomForm.LvFilesSelectItem(Sender: TObject; AItem: TListItem;
  ASelected: Boolean);
begin
  btnToggle.Enabled := ASelected;
  btnEdit.Enabled := ASelected and not EndsText('.disabled', SelectedPath);
  btnDelete.Enabled := ASelected;
end;

procedure TCustomForm.BtnToggleClick(Sender: TObject);
var
  P, N: string;
begin
  P := SelectedPath;
  if P = '' then Exit;
  if EndsText('.disabled', P) then
    N := Copy(P, 1, Length(P) - 9)
  else
    N := P + '.disabled';
  if not RenameFile(P, N) then
    lblStatus.Caption := Lg('Не удалось переименовать файл.',
      'Не атрымалася перайменаваць файл.',
      'Не вдалося перейменувати файл.', 'Could not rename the file.');
  RefreshList;
end;

procedure TCustomForm.BtnOpenFolderClick(Sender: TObject);
begin
  ForceDirectories(CustomDir);
  ShowInExplorer(CustomDir);
end;

{ New rule → the rule editor (fields + live preview) writes the ini. }
procedure TCustomForm.BtnNewClick(Sender: TObject);
begin
  ForceDirectories(CustomDir);
  if EditRuleDialog(Self, '') = mrOk then
    RefreshList;
end;

procedure TCustomForm.BtnEditClick(Sender: TObject);
var
  P: string;
begin
  P := SelectedPath;
  if (P = '') or EndsText('.disabled', P) then Exit;
  if EditRuleDialog(Self, P) = mrOk then
    RefreshList;
end;

{ Opens the syntax guide (docs\custom-rules.md next to the exe) in the
  associated editor; without the doc file falls back to a compact
  cheat-sheet so the help works in a bare portable install too. }
procedure TCustomForm.BtnHelpClick(Sender: TObject);
var
  Doc: string;
begin
  Doc := ExtractFilePath(ParamStr(0)) + 'docs\custom-rules.md';
  if FileExists(Doc) then
  begin
    ShellExecuteW(0, PWideChar(UTF8Decode('open')),
      PWideChar(UTF8Decode(Doc)), nil, nil, SW_SHOW);
    Exit;
  end;
  MessageDlg(
    '[Name *]' + sLineBreak +
    'Section=Custom' + sLineBreak +
    'Default=False' + sLineBreak +
    'DetectFile=%ProgramFiles%\App   ' +
      Lg('(необязательно — без детекции запись считается установленной)',
         '(неабавязкова — без детэкцыі запіс лічыцца ўсталяваным)',
         '(необов''язково — без детекції запис вважається встановленим)',
         '(optional — undetected entries count as installed)') +
      sLineBreak +
    'FileKey1=<папка>|<маски>|RECURSE|REMOVESELF' + sLineBreak +
    'RegKey1=HKCU\Software\App   ' +
      Lg('(или …|<имя значения>)', '(або …|<імя значэння>)',
         '(або …|<ім''я значення>)', '(or …|<value name>)') + sLineBreak +
    'ExcludeKey1=FILE|PATH|REG|<путь>|<маска>' + sLineBreak + sLineBreak +
    Lg('Полная справка: docs\custom-rules.md в репозитории.',
       'Поўная даведка: docs\custom-rules.md у рэпазітарыі.',
       'Повна довідка: docs\custom-rules.md у репозиторії.',
       'Full guide: docs\custom-rules.md in the repository.'),
    mtInformation, [mbOK], 0);
end;

procedure TCustomForm.BtnDeleteClick(Sender: TObject);
var
  P: string;
begin
  P := SelectedPath;
  if P = '' then Exit;
  if MessageDlg(Format(Lg('Удалить файл «%s»?', 'Выдаліць файл «%s»?',
      'Видалити файл «%s»?', 'Delete file "%s"?'), [ExtractFileName(P)]),
      mtConfirmation, [mbYes, mbNo], 0) <> mrYes then Exit;
  if SysUtils.DeleteFile(P) then
    RefreshList
  else
    lblStatus.Caption := Lg('Не удалось удалить файл.',
      'Не атрымалася выдаліць файл.', 'Не вдалося видалити файл.',
      'Could not delete the file.');
end;

end.
