unit previewform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls, ComCtrls,
  cs.cleaner;

type

  { Read-only view of a TCleanResult (the deletion plan Analyze
    produced) — same list the cleaner's review tab shows, minus the
    checkboxes. Used by the rule editor's «Проверить…» preview. }
  TPreviewForm = class(TForm)
    lvItems: TListView;
    lblSummary: TLabel;
    pnlButtons: TPanel;
    btnClose: TButton;
    procedure FormCreate(Sender: TObject);
  end;

procedure ShowCleanResult(AOwner: TComponent; const ARes: TCleanResult);

implementation

uses
  cs.lang;

{$R *.lfm}

procedure ShowCleanResult(AOwner: TComponent; const ARes: TCleanResult);
var
  F: TPreviewForm;
  I: Integer;
  It: TListItem;
begin
  F := TPreviewForm.Create(AOwner);
  try
    F.lblSummary.Caption := Format(Lg(
      '  Файлов: %d   Реестр: %d   Всего: %s',
      '  Файлаў: %d   Рэестр: %d   Усяго: %s',
      '  Файлів: %d   Реєстр: %d   Усього: %s',
      '  Files: %d   Registry: %d   Total: %s'),
      [ARes.FilesToDelete.Count, ARes.RegistryToDelete.Count,
       ARes.FormattedSize]);
    F.lvItems.Items.BeginUpdate;
    try
      for I := 0 to ARes.FilesToDelete.Count - 1 do
      begin
        It := F.lvItems.Items.Add;
        It.Caption := ARes.FilesToDelete[I];
      end;
      for I := 0 to ARes.RegistryToDelete.Count - 1 do
      begin
        It := F.lvItems.Items.Add;
        It.Caption := ARes.RegistryToDelete[I].DisplayName;
      end;
    finally
      F.lvItems.Items.EndUpdate;
    end;
    F.ShowModal;
  finally
    F.Free;
  end;
end;

procedure TPreviewForm.FormCreate(Sender: TObject);
begin
  Caption := Lg('Предпросмотр (удаление не выполняется)',
    'Перадпрагляд (выдаленне не выконваецца)',
    'Попередній перегляд (видалення не виконується)',
    'Preview (nothing is deleted)');
  lvItems.Columns[0].Caption := 'Path';
  btnClose.Caption := Lg('Закрыть', 'Закрыць', 'Закрити', 'Close');
end;

end.
