unit cs.closeapps;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils;

{ Finds running applications whose data a clean is about to touch and
  closes them on request — locked cookie/cache DBs cannot be deleted
  while the owning app lives.

  Two matching paths:
    1. keyword table — winapp2 entry names ('Mozilla Firefox', 'Steam')
       are mapped to known exe names; needed because browser data dirs
       sit nowhere near the exe.
    2. exe path under a cleaned root — portable apps whose binary lives
       inside a directory a FileKey sweeps. }

type
  { Who the process is, for the close-apps checklist:
    akCritical — killing it crashes/hangs Windows (csrss, wininit…);
    akSystem   — lives under %WinDir% but is safe to close/restart;
    akUser     — a regular application process. }
  TAppKind = (akUser, akSystem, akCritical);

  TRunningApp = record
    PID: DWORD;
    ExeName: string;    // leaf name, e.g. 'firefox.exe'
    ExePath: string;    // full normalized path, '' when access denied
    AppName: string;    // friendly label for the checklist
    Kind: TAppKind;
  end;
  TRunningAppArray = array of TRunningApp;

{ Snapshots running processes and keeps those matching the clean.
  AKeywords: entry names / display strings to grep against the known-app
  table. ARoots: directories the clean will touch (expanded FileKey
  roots; wildcards already resolved). Never returns our own process,
  the system pids 0/4 or explorer.exe — the shell is not closed
  gracefully (WM_CLOSE on it pops the "Shut down Windows" dialog);
  it is hard-killed by StopShell instead. }
function FindAppsToClose(const AKeywords, ARoots: TStrings): TRunningAppArray;

{ Graceful close: WM_CLOSE to every top-level window of the process,
  wait up to ATimeoutMs, then TerminateProcess when still alive.
  Result = the process is gone. Logs the outcome. }
function CloseApp(const AApp: TRunningApp; ATimeoutMs: DWORD): Boolean;

{ Worker that closes one app — the GUI spawns several so independent
  processes shut down in parallel instead of serial 8s timeouts. }
type
  TCloseAppThread = class(TThread)
  private
    FApp: TRunningApp;
    FOk: Boolean;
  protected
    procedure Execute; override;
  public
    property App: TRunningApp read FApp write FApp;
    property Ok: Boolean read FOk;
  end;

{ Kills every running explorer.exe. Result = processes terminated.
  The shell is down until StartShell. }
function StopShell: Integer;

{ Relaunches the session the way logon does: userinit.exe reads the
  Winlogon\Shell registry value and starts the shell (explorer.exe)
  itself — no need to hardcode or re-launch anything by hand. }
procedure StartShell;

implementation

uses
  Windows, JwaTlHelp32, cs.utils;

type
  TKnownApp = record
    Key: string;        // lowercase substring of an entry name
    Exes: string;       // ';'-separated lowercase exe names
    Disp: string;       // label shown in the dialog
  end;

const
  KnownApps: array[0..24] of TKnownApp = (
    (Key: 'chrome';    Exes: 'chrome.exe';                Disp: 'Google Chrome'),
    (Key: 'chromium';  Exes: 'chromium.exe';              Disp: 'Chromium'),
    (Key: 'edge';      Exes: 'msedge.exe';                Disp: 'Microsoft Edge'),
    (Key: 'firefox';   Exes: 'firefox.exe';               Disp: 'Mozilla Firefox'),
    (Key: 'opera';     Exes: 'opera.exe';                 Disp: 'Opera'),
    (Key: 'brave';     Exes: 'brave.exe';                 Disp: 'Brave'),
    (Key: 'vivaldi';   Exes: 'vivaldi.exe';               Disp: 'Vivaldi'),
    (Key: 'yandex';    Exes: 'browser.exe';               Disp: 'Yandex Browser'),
    (Key: 'pale moon'; Exes: 'palemoon.exe';              Disp: 'Pale Moon'),
    (Key: 'waterfox';  Exes: 'waterfox.exe';              Disp: 'Waterfox'),
    (Key: 'librewolf'; Exes: 'librewolf.exe';             Disp: 'LibreWolf'),
    (Key: 'safari';    Exes: 'safari.exe';                Disp: 'Safari'),
    (Key: 'internet explorer'; Exes: 'iexplore.exe';      Disp: 'Internet Explorer'),
    (Key: 'telegram';  Exes: 'telegram.exe';              Disp: 'Telegram'),
    (Key: 'discord';   Exes: 'discord.exe';               Disp: 'Discord'),
    (Key: 'whatsapp';  Exes: 'whatsapp.exe';              Disp: 'WhatsApp'),
    (Key: 'slack';     Exes: 'slack.exe';                 Disp: 'Slack'),
    (Key: 'teams';     Exes: 'ms-teams.exe;teams.exe';    Disp: 'Microsoft Teams'),
    (Key: 'zoom';      Exes: 'zoom.exe';                  Disp: 'Zoom'),
    (Key: 'skype';     Exes: 'skype.exe';                 Disp: 'Skype'),
    (Key: 'vlc';       Exes: 'vlc.exe';                   Disp: 'VLC'),
    (Key: 'foobar';    Exes: 'foobar2000.exe';            Disp: 'foobar2000'),
    (Key: 'winamp';    Exes: 'winamp.exe';                Disp: 'Winamp'),
    (Key: 'itunes';    Exes: 'itunes.exe';                Disp: 'iTunes'),
    (Key: 'steam';     Exes: 'steam.exe;steamwebhelper.exe'; Disp: 'Steam'));

{ ';'-separated AList contains AName (case-insensitive). }
function ExeListed(const AName, AList: string): Boolean;
begin
  Result := Pos(';' + AName + ';', ';' + AList + ';') > 0;
end;

{ Names Windows treats as load-bearing: killing one bluescreens,
  logs the session off, or takes down the service stack. The
  IsProcessCritical flag covers the same set plus protected
  processes — the table is the fallback for names we cannot open. }
const
  CriticalExeNames: array[0..14] of string = (
    'system', 'registry', 'memory compression', 'secure system',
    'smss.exe', 'csrss.exe', 'wininit.exe', 'winlogon.exe',
    'services.exe', 'lsass.exe', 'lsaiso.exe', 'svchost.exe',
    'dwm.exe', 'fontdrvhost.exe', 'sihost.exe');

function ExeInCriticalTable(const AExe: string): Boolean;
var
  I: Integer;
begin
  Result := False;
  for I := Low(CriticalExeNames) to High(CriticalExeNames) do
    if AExe = CriticalExeNames[I] then Exit(True);
end;

var
  IsProcessCriticalFn: function(AProc: THandle;
    out ACritical: BOOL): BOOL; stdcall = nil;
  WinDirLower: string = '';
  { Primary token duplicated from the explorer.exe we killed — the
    shell is restarted under the real user's token, not our
    elevated one. }
  ShellToken: THandle = 0;

type
  TCreateProcessWithTokenW = function(AToken: THandle;
    ALogonFlags: DWORD; AAppName, ACmdLine: PWideChar;
    ACreateFlags: DWORD; AEnv: Pointer; ACurDir: PWideChar;
    const AStartupInfo: TStartupInfoW;
    var AProcInfo: TProcessInformation): BOOL; stdcall;
  TDuplicateTokenEx = function(AExisting: THandle; AAccess: DWORD;
    AAttributes: PSecurityAttributes; ALevel: DWORD;
    ATokenType: DWORD; var ANew: THandle): BOOL; stdcall;

{ Critical verdict: the kernel flag (ProcessBreakOnTermination) or,
  when we could not open the process, the name table. }
function IsCriticalProcess(AProc: THandle; const AExe: string): Boolean;
var
  Flag: BOOL;
begin
  Result := ExeInCriticalTable(AExe);
  if Result then Exit;
  if (AProc <> 0) and Assigned(IsProcessCriticalFn) then
  begin
    Flag := False;
    if IsProcessCriticalFn(AProc, Flag) then Result := Flag;
  end;
end;

{ Exe lives under %WinDir% (covers System32, SysWOW64, WinSxS…). }
function UnderWindowsDir(const AExePath: string): Boolean;
begin
  Result := (WinDirLower <> '') and
            (Pos(WinDirLower + '\', AExePath) = 1);
end;

procedure InitClassifier;
var
  K32: HMODULE;
  Buf: array[0..MAX_PATH] of WideChar;
begin
  if IsProcessCriticalFn = nil then
  begin
    K32 := GetModuleHandleW('kernel32.dll');
    if K32 <> 0 then
      Pointer(IsProcessCriticalFn) :=
        GetProcAddress(K32, 'IsProcessCritical');
  end;
  if WinDirLower = '' then
  begin
    Buf[0] := #0;
    if GetWindowsDirectoryW(Buf, MAX_PATH) > 0 then
      WinDirLower := LowerCase(NormalizePath(
        UTF8Encode(WideString(Buf))));
  end;
end;

function KeyHit(const AKey: string; AKeys: TStrings): Boolean;
var
  I: Integer;
begin
  Result := False;
  for I := 0 to AKeys.Count - 1 do
    if Pos(AKey, AKeys[I]) > 0 then Exit(True);
end;

function FindAppsToClose(const AKeywords, ARoots: TStrings): TRunningAppArray;
var
  Keys, Roots: TStringList;
  Snap, Proc: THandle;
  PE: TProcessEntry32W;
  Buf: array[0..MAX_PATH] of WideChar;
  Sz: DWORD;
  Exe, ExePath, Disp: string;
  I, N: Integer;
  SelfPID: DWORD;
  Matched: Boolean;
begin
  Result := nil;
  Keys := TStringList.Create;
  Roots := TStringList.Create;
  try
    if AKeywords <> nil then
      for I := 0 to AKeywords.Count - 1 do
        Keys.Add(LowerCase(AKeywords[I]));
    if ARoots <> nil then
      for I := 0 to ARoots.Count - 1 do
        Roots.Add(LowerCase(ExcludeTrailingPathDelimiter(
          NormalizePath(ARoots[I]))));

    InitClassifier;
    SelfPID := GetCurrentProcessId;
    Snap := CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if Snap = INVALID_HANDLE_VALUE then Exit;
    try
      PE.dwSize := SizeOf(PE);
      if Process32FirstW(Snap, PE) then
        repeat
          if (PE.th32ProcessID = 0) or (PE.th32ProcessID = 4) or
             (PE.th32ProcessID = SelfPID) then Continue;
          Exe := LowerCase(UTF8Encode(WideString(PE.szExeFile)));
          if Exe = 'explorer.exe' then Continue;   // shell: StopShell only
          ExePath := '';
          Proc := OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False,
                              PE.th32ProcessID);
          try
            if Proc <> 0 then
            begin
              Sz := Length(Buf);
              Buf[0] := #0;
              if QueryFullProcessImageNameW(Proc, 0, Buf, @Sz) then
                ExePath := LowerCase(
                  NormalizePath(UTF8Encode(WideString(Buf))));
            end;

            Matched := False;
            Disp := Exe;
            // exe lives under a cleaned root — portable app
            if ExePath <> '' then
              for I := 0 to Roots.Count - 1 do
                if (Roots[I] <> '') and
                   (Pos(Roots[I] + '\', ExePath) = 1) then
                begin
                  Matched := True;
                  Break;
                end;
            // known-app exe name matched by an entry keyword
            if not Matched then
              for I := Low(KnownApps) to High(KnownApps) do
                if KeyHit(KnownApps[I].Key, Keys) and
                   ExeListed(Exe, KnownApps[I].Exes) then
                begin
                  Matched := True;
                  Disp := KnownApps[I].Disp;
                  Break;
                end;

            if Matched then
            begin
              N := Length(Result);
              SetLength(Result, N + 1);
              Result[N].PID := PE.th32ProcessID;
              Result[N].ExeName := Exe;
              Result[N].ExePath := ExePath;
              Result[N].AppName := Disp;
              if IsCriticalProcess(Proc, Exe) then
                Result[N].Kind := akCritical
              else if (ExePath <> '') and UnderWindowsDir(ExePath) then
                Result[N].Kind := akSystem
              else
                Result[N].Kind := akUser;
            end;
          finally
            if Proc <> 0 then CloseHandle(Proc);
          end;
        until not Process32NextW(Snap, PE);
    finally
      CloseHandle(Snap);
    end;
  finally
    Keys.Free;
    Roots.Free;
  end;
end;

{ EnumWindows callback: posts WM_CLOSE to every top-level window owned
  by the process in lParam. }
function CloseWndCb(AWnd: HWND; AParam: LPARAM): BOOL; stdcall;
var
  PID: DWORD;
begin
  PID := 0;
  GetWindowThreadProcessId(AWnd, PID);
  if PID = DWORD(AParam) then
    PostMessageW(AWnd, WM_CLOSE, 0, 0);
  Result := True;
end;

{ PID still present in the process snapshot? OpenProcess failing alone
  does not prove exit — a protected process can refuse every access
  right we ask for while staying very much alive. }
function PidExists(APID: DWORD): Boolean;
var
  Snap: THandle;
  PE: TProcessEntry32W;
begin
  Result := False;
  Snap := CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if Snap = INVALID_HANDLE_VALUE then Exit;
  try
    PE.dwSize := SizeOf(PE);
    if Process32FirstW(Snap, PE) then
      repeat
        if PE.th32ProcessID = APID then Exit(True);
      until not Process32NextW(Snap, PE);
  finally
    CloseHandle(Snap);
  end;
end;

function CloseApp(const AApp: TRunningApp; ATimeoutMs: DWORD): Boolean;
var
  Proc: THandle;
  Disp: string;
begin
  EnumWindows(@CloseWndCb, LPARAM(AApp.PID));
  Proc := OpenProcess(SYNCHRONIZE or PROCESS_TERMINATE, False, AApp.PID);
  if Proc = 0 then
    // no handle: either already exited or access denied — distinguish
    Exit(not PidExists(AApp.PID));
  try
    Result := WaitForSingleObject(Proc, ATimeoutMs) = WAIT_OBJECT_0;
    if not Result then
    begin
      TerminateProcess(Proc, 1);
      Result := WaitForSingleObject(Proc, 3000) = WAIT_OBJECT_0;
    end;
  finally
    CloseHandle(Proc);
  end;
  if AApp.AppName <> '' then Disp := AApp.AppName
  else Disp := AApp.ExeName;
  if Result then
    LogToFile('Closed app: ' + Disp + ' (pid ' + IntToStr(AApp.PID) + ')')
  else
    LogToFile('FAILED to close app: ' + Disp + ' (pid ' +
              IntToStr(AApp.PID) + ')');
end;

procedure TCloseAppThread.Execute;
begin
  FOk := CloseApp(FApp, 8000);
end;

{ Duplicates the explorer process token into a primary token we can
  later launch the shell with — the standard "run as the logged-on
  user" trick (same path task managers use for limited launches). }
procedure CaptureShellToken(AProc: THandle);
const
  SECURITY_IMPERSONATION = 2;
  TOKEN_PRIMARY = 1;
var
  Tok, Prim: THandle;
  Dup: TDuplicateTokenEx;
  Adv: HMODULE;
begin
  if ShellToken <> 0 then Exit;   // first explorer is enough
  Adv := GetModuleHandleW('advapi32.dll');
  if Adv = 0 then Exit;
  Pointer(Dup) := GetProcAddress(Adv, 'DuplicateTokenEx');
  if not Assigned(Dup) then Exit;
  Prim := 0;
  if not OpenProcessToken(AProc, TOKEN_DUPLICATE, Tok) then Exit;
  try
    if Dup(Tok, MAXIMUM_ALLOWED, nil, SECURITY_IMPERSONATION,
           TOKEN_PRIMARY, Prim) then
      ShellToken := Prim;
  finally
    CloseHandle(Tok);
  end;
end;

{ WM_CLOSE does not kill the shell (its windows are owned by the
  desktop) — TerminateProcess is what taskkill /f does anyway.
  Before killing, the user token is captured for StartShell. }
function StopShell: Integer;
var
  Snap, Proc: THandle;
  PE: TProcessEntry32W;
begin
  Result := 0;
  Snap := CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if Snap = INVALID_HANDLE_VALUE then Exit;
  try
    PE.dwSize := SizeOf(PE);
    if Process32FirstW(Snap, PE) then
      repeat
        if LowerCase(UTF8Encode(WideString(PE.szExeFile))) <>
           'explorer.exe' then
          Continue;
        Proc := OpenProcess(PROCESS_TERMINATE or SYNCHRONIZE or
                            PROCESS_QUERY_INFORMATION, False,
                            PE.th32ProcessID);
        if Proc = 0 then Continue;
        try
          CaptureShellToken(Proc);
          if TerminateProcess(Proc, 0) then
          begin
            WaitForSingleObject(Proc, 3000);
            Inc(Result);
          end;
        finally
          CloseHandle(Proc);
        end;
      until not Process32NextW(Snap, PE);
  finally
    CloseHandle(Snap);
  end;
  if Result > 0 then
    LogToFile('Shell stopped: ' + IntToStr(Result) + ' explorer.exe')
  else
    LogToFile('Shell stop: no explorer.exe running');
end;

procedure StartShell;
const
  LOGON_WITH_PROFILE = $00000001;
var
  SI: TStartupInfoW;
  PI: TProcessInformation;
  Buf: array[0..MAX_PATH] of WideChar;
  Cmd: WideString;
  WithToken: TCreateProcessWithTokenW;
  Adv: HMODULE;
  Started: Boolean;
begin
  FillChar(SI, SizeOf(SI), 0);
  SI.cb := SizeOf(SI);
  Buf[0] := #0;
  if GetSystemDirectoryW(Buf, MAX_PATH) = 0 then
    Cmd := 'userinit.exe'
  else
    Cmd := WideString(Buf) + '\userinit.exe';

  // captured explorer token → shell comes back un-elevated, under
  // the user it was running as
  Started := False;
  if ShellToken <> 0 then
  begin
    Adv := GetModuleHandleW('advapi32.dll');
    WithToken := nil;
    if Adv <> 0 then
      Pointer(WithToken) :=
        GetProcAddress(Adv, 'CreateProcessWithTokenW');
    if Assigned(WithToken) then
      Started := WithToken(ShellToken, LOGON_WITH_PROFILE, nil,
                           PWideChar(Cmd), 0, nil, nil, SI, PI);
    CloseHandle(ShellToken);
    ShellToken := 0;
  end;
  if not Started then
    // no token (access denied on capture) — elevated relaunch, same
    // as before: userinit, then a bare explorer fallback
    Started := CreateProcessW(nil, PWideChar(Cmd), nil, nil, False, 0,
                              nil, nil, SI, PI);
  if not Started then
  begin
    Cmd := 'explorer.exe';
    Started := CreateProcessW(nil, PWideChar(Cmd), nil, nil, False, 0,
                              nil, nil, SI, PI);
  end;
  if Started then
  begin
    CloseHandle(PI.hThread);
    CloseHandle(PI.hProcess);
    LogToFile('Session restarted via userinit.exe');
  end
  else
    LogToFile('FAILED to restart session (userinit.exe + explorer.exe)');
end;

finalization
  if ShellToken <> 0 then CloseHandle(ShellToken);

end.
