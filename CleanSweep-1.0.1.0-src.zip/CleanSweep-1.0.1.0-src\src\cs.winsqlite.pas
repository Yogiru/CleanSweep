unit cs.winsqlite;

{$mode objfpc}{$H+}

{ Minimal dynamic binding to winsqlite3.dll (ships with Windows 10+ as
  the OS SQLite; Microsoft and the browsers use the same engine).

  The DLL is bound lazily via LoadLibrary/GetProcAddress so the exe
  starts fine where it is missing — cookie features then just report
  themselves unavailable. Only the handful of entry points the cleaner
  needs is wrapped: open/prepare/step/column/finalize/close + the
  busy_timeout and changes helpers for the delete workflow.

  UTF-16 entry points (*16) are used throughout, matching the upstream
  C# P/Invoke surface and avoiding codepage juggling on paths/SQL.

  Gotcha: Microsoft's winsqlite3.dll exports stdcall entry points,
  unlike upstream sqlite3 which is cdecl — a cdecl declaration here
  corrupts the stack and segfaults inside the second call. }

interface

uses
  Classes, SysUtils;

type
  ESqliteError = class(Exception);

  { An open SQLite database. Statements are prepared per call;
    QueryStrings returns the first column of each row, Execute runs
    statements discarding rows and returns sqlite3_changes. }
  TWinSqlite = class
  private
    FDb: Pointer;
    function Prepare(const ASql: WideString): Pointer;
    function LastError: string;
  public
    constructor Create(const APath: string);     // raises ESqliteError
    destructor Destroy; override;
    function QueryStrings(const ASql: WideString): TStringList;
    function Execute(const ASql: WideString): Integer;
  end;

{ True once winsqlite3.dll was found and every needed symbol bound. }
function WinSqliteAvailable: Boolean;

implementation

uses
  Windows;

const
  SQLITE_OK         = 0;
  SQLITE_ROW        = 100;
  SQLITE_DONE       = 101;
  SQLITE_BUSY_PAUSE = 250;   // busy_timeout: browsers hold the DB often

type
  TSqliteOpen16 = function(pFileName: PWideChar; out ppDb: Pointer): Integer; stdcall;
  TSqlitePrepare16 = function(db: Pointer; zSql: PWideChar; nByte: Integer;
    out ppStmt: Pointer; pzTail: Pointer): Integer; stdcall;
  TSqliteStep = function(pStmt: Pointer): Integer; stdcall;
  TSqliteColumnText16 = function(pStmt: Pointer; iCol: Integer): PWideChar; stdcall;
  TSqliteFinalize = function(pStmt: Pointer): Integer; stdcall;
  TSqliteChanges = function(db: Pointer): Integer; stdcall;
  TSqliteBusyTimeout = function(db: Pointer; ms: Integer): Integer; stdcall;
  TSqliteErrmsg16 = function(db: Pointer): PWideChar; stdcall;
  TSqliteCloseV2 = function(db: Pointer): Integer; stdcall;

var
  GLib: HMODULE = 0;
  GBound: Boolean = False;
  p_open16: TSqliteOpen16;
  p_prepare16: TSqlitePrepare16;
  p_step: TSqliteStep;
  p_column_text16: TSqliteColumnText16;
  p_finalize: TSqliteFinalize;
  p_changes: TSqliteChanges;
  p_busy_timeout: TSqliteBusyTimeout;
  p_errmsg16: TSqliteErrmsg16;
  p_close_v2: TSqliteCloseV2;

function WinSqliteAvailable: Boolean;
begin
  if not GBound then
  begin
    GBound := True;
    GLib := LoadLibraryW('winsqlite3.dll');
    if GLib <> 0 then
    begin
      p_open16 := TSqliteOpen16(GetProcAddress(GLib, 'sqlite3_open16'));
      p_prepare16 := TSqlitePrepare16(GetProcAddress(GLib, 'sqlite3_prepare16_v2'));
      p_step := TSqliteStep(GetProcAddress(GLib, 'sqlite3_step'));
      p_column_text16 := TSqliteColumnText16(GetProcAddress(GLib, 'sqlite3_column_text16'));
      p_finalize := TSqliteFinalize(GetProcAddress(GLib, 'sqlite3_finalize'));
      p_changes := TSqliteChanges(GetProcAddress(GLib, 'sqlite3_changes'));
      p_busy_timeout := TSqliteBusyTimeout(GetProcAddress(GLib, 'sqlite3_busy_timeout'));
      p_errmsg16 := TSqliteErrmsg16(GetProcAddress(GLib, 'sqlite3_errmsg16'));
      p_close_v2 := TSqliteCloseV2(GetProcAddress(GLib, 'sqlite3_close_v2'));
      if not (Assigned(p_open16) and Assigned(p_prepare16) and
              Assigned(p_step) and Assigned(p_column_text16) and
              Assigned(p_finalize) and Assigned(p_changes) and
              Assigned(p_busy_timeout) and Assigned(p_errmsg16) and
              Assigned(p_close_v2)) then
      begin
        FreeLibrary(GLib);
        GLib := 0;
      end;
    end;
  end;
  Result := GLib <> 0;
end;

{ TWinSqlite }

constructor TWinSqlite.Create(const APath: string);
var
  W: WideString;
begin
  inherited Create;
  if not WinSqliteAvailable then
    raise ESqliteError.Create('winsqlite3.dll not available');
  W := UTF8Decode(APath);
  if p_open16(PWideChar(W), FDb) <> SQLITE_OK then
    raise ESqliteError.Create('sqlite3_open16 failed for ' + APath);
  p_busy_timeout(FDb, SQLITE_BUSY_PAUSE);
end;

destructor TWinSqlite.Destroy;
begin
  if FDb <> nil then
    p_close_v2(FDb);
  inherited;
end;

function TWinSqlite.LastError: string;
var
  P: PWideChar;
begin
  P := p_errmsg16(FDb);
  if P = nil then Exit('sqlite error');
  Result := UTF8Encode(WideString(P));
end;

function TWinSqlite.Prepare(const ASql: WideString): Pointer;
begin
  if p_prepare16(FDb, PWideChar(ASql), -1, Result, nil) <> SQLITE_OK then
    raise ESqliteError.Create(LastError);
end;

function TWinSqlite.QueryStrings(const ASql: WideString): TStringList;
var
  Stmt: Pointer;
  R: Integer;
  P: PWideChar;
begin
  Result := TStringList.Create;
  Stmt := Prepare(ASql);
  try
    while True do
    begin
      R := p_step(Stmt);
      if R = SQLITE_DONE then Break;
      if R <> SQLITE_ROW then
        raise ESqliteError.Create(LastError);
      P := p_column_text16(Stmt, 0);
      if P <> nil then
        Result.Add(UTF8Encode(WideString(P)))
      else
        Result.Add('');
    end;
  finally
    p_finalize(Stmt);
  end;
end;

function TWinSqlite.Execute(const ASql: WideString): Integer;
var
  Stmt: Pointer;
  R: Integer;
begin
  Stmt := Prepare(ASql);
  try
    repeat
      R := p_step(Stmt);
    until R <> SQLITE_ROW;
    if R <> SQLITE_DONE then
      raise ESqliteError.Create(LastError);
    Result := p_changes(FDb);
  finally
    p_finalize(Stmt);
  end;
end;

end.
