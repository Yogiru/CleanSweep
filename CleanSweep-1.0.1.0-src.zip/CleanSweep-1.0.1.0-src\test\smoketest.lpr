program smoketest;

{$mode objfpc}{$H+}

uses
  Classes, SysUtils, Windows, cs.models, cs.utils, cs.safety, cs.registry,
  cs.signatures, cs.leftovers, cs.closeapps;

var
  Progs: TProgramList;
  I, Fails: Integer;
  Target: TInstalledProgram;
  Scan: TScanResult;
  Reg: TRegistryLeftoverScanner;
  Fil: TFileLeftoverScanner;
  Ctx: TScanContext;
  Tmp: string;
  It: TLeftoverItem;
  Keys: TStringList;
  Apps: TRunningAppArray;
  SelfFound: Boolean;

procedure Check(const AOk: Boolean; const AName: string);
begin
  if AOk then WriteLn('  [ok] ', AName)
  else
  begin
    Inc(Fails);
    WriteLn('  [FAIL] ', AName);
  end;
end;

procedure StrToFile(const APath, AText: string);
var
  FS: TFileStream;
  B: RawByteString;
begin
  FS := TFileStream.Create(APath, fmCreate);
  try
    B := AText;
    FS.WriteBuffer(B[1], Length(B));
  finally
    FS.Free;
  end;
end;

{ First leftover item whose Path equals APath (normalized). }
function FindItem(const AScan: TScanResult; const APath: string;
  out AItem: TLeftoverItem): Boolean;
var
  J: Integer;
begin
  Result := False;
  AItem := nil;
  for J := 0 to AScan.FileLeftovers.Count - 1 do
    if SameText(AScan.FileLeftovers[J].Path,
                ExcludeTrailingPathDelimiter(APath)) then
    begin
      AItem := AScan.FileLeftovers[J];
      Exit(True);
    end;
end;

begin
  Fails := 0;
  WriteLn('CleanSweep core smoke test');
  InitSafetyRoots;
  WriteLn('WinDir=', GWinDir, '  PF64=', GProgramFiles,
          '  PFx86=', GProgramFilesX86);

  LoadSignatures(ExtractFilePath(ParamStr(0)) + '..\data\leftover-signatures.json');
  LoadSignatures('data\leftover-signatures.json');

  Progs := TProgramList.Create(True);
  try
    ScanInstalledPrograms(Progs, False, False);
    WriteLn('Installed programs found: ', Progs.Count);
    for I := 0 to 9 do
      if I < Progs.Count then
        WriteLn('  - ', Progs[I].DisplayName, ' | ', Progs[I].Publisher,
                ' | ', Progs[I].SourceDisplay);
  finally
    Progs.Free;
  end;

  // Leftover scan against a program that's almost surely uninstalled:
  // feed a fake entry to exercise search-term + signature paths.
  Target := TInstalledProgram.Create;
  Target.DisplayName := 'VLC media player';
  Target.Publisher := 'VideoLAN';
  Target.RegistryKeyName := 'VLC media player';
  Target.InstallLocation := GProgramFiles + '\VideoLAN\VLC';
  Target.UninstallString := '"C:\Program Files\VideoLAN\VLC\uninstall.exe"';

  Scan := TScanResult.Create;
  Reg := TRegistryLeftoverScanner.Create;
  Fil := TFileLeftoverScanner.Create;
  Ctx := TScanContext.Create(Target);
  try
    WriteLn('Leftover scan for: ', Target.DisplayName);
    Reg.ScanForLeftovers(Ctx, smModerate, Scan.RegistryLeftovers);
    Fil.ScanForLeftovers(Ctx, smModerate, Scan.FileLeftovers);
    WriteLn('Registry leftovers: ', Scan.RegistryLeftovers.Count);
    for I := 0 to Scan.RegistryLeftovers.Count - 1 do
      WriteLn('  [reg] ', Scan.RegistryLeftovers[I].Path,
              ' (', Scan.RegistryLeftovers[I].Details, ')');
    WriteLn('File leftovers: ', Scan.FileLeftovers.Count);
    for I := 0 to Scan.FileLeftovers.Count - 1 do
      WriteLn('  [file] ', Scan.FileLeftovers[I].Path,
              ' (', Scan.FileLeftovers[I].Details, ')');
  finally
    Reg.Free;
    Fil.Free;
    Ctx.Free;
    Scan.Free;
    Target.Free;
  end;

  // Safety guard sanity checks
  WriteLn('Safety: C:\Windows -> ', IsPathSafeToDelete('C:\Windows'));
  WriteLn('Safety: C:\Windows\Temp\x -> ',
          IsPathSafeToDelete(GWinDir + '\Temp\x'));
  WriteLn('Safety: C:\Users -> ', IsPathSafeToDelete(GUsersDir));
  WriteLn('Safety: HKLM\SYSTEM\CurrentControlSet\Control -> ',
          IsRegistryPathSafeToDelete('HKLM\SYSTEM\CurrentControlSet\Control'));
  WriteLn('Safety: HKCU\Software\Foo -> ',
          IsRegistryPathSafeToDelete('HKCU\Software\Foo'));

  // Temp policy: roots are protected, contents are garbage
  Check(GTempRoots.Count >= 2, 'temp roots collected (%TEMP%/%TMP%/WinDir\Temp)');
  Check(IsTempPath(GetTempDir(False) + 'x\y.tmp'),
        'IsTempPath sees a file under %TEMP%');
  Check(IsTempPath(GWinDir + '\Temp\junk.log'),
        'IsTempPath sees a file under Windows\Temp');
  Check(not IsTempPath(GProgramFiles + '\x'), 'IsTempPath rejects PF');
  Check(IsTempRoot(GetTempDir(False)), 'IsTempRoot hits %TEMP%');
  Check(not IsPathSafeToDelete(GetTempDir(False)),
        'temp root itself is never deletable');
  // Software roots: contents are evaluable, the roots themselves are not
  Check(not IsPathSafeToDelete(GProgramFiles),
        'Program Files root itself is protected');
  Check(not IsPathSafeToDelete(GProgramData),
        'ProgramData root itself is protected');
  Check(IsPathSafeToDelete(GProgramFiles + '\DeadApp'),
        'Program Files subdir stays deletable');
  Check(IsRunnableExtension('a.exe') and IsRunnableExtension('b.ps1') and
        (not IsRunnableExtension('c.txt')), 'runnable-extension set');

  { Live-exe guard: a leftover dir that still contains a runnable exe
    is a working copy — must land lcRisky/unselected (cs.uninstall then
    refuses it even when checked). A dir holding only an uninstaller
    stub (unins000.exe) stays a normal leftover. }
  WriteLn('Live-exe guard:');
  Tmp := IncludeTrailingPathDelimiter(GetTempDir(False)) + 'cs_smoke';
  ForceDirectories(Tmp + '\Live');
  ForceDirectories(Tmp + '\Dead');
  Fil := TFileLeftoverScanner.Create;
  Scan := TScanResult.Create;
  try
    StrToFile(Tmp + '\Live\app.exe', 'exe');
    StrToFile(Tmp + '\Dead\unins000.exe', 'exe');

    Target := TInstalledProgram.Create;
    Target.DisplayName := 'ZZZ Smoke Live';
    Target.InstallLocation := Tmp + '\Live';
    Ctx := TScanContext.Create(Target);
    try
      Fil.ScanForLeftovers(Ctx, smSafe, Scan.FileLeftovers);
    finally
      Ctx.Free;
      Target.Free;
    end;
    Check(FindItem(Scan, Tmp + '\Live', It) and
          (It.Confidence = lcRisky) and (not It.IsSelected),
          'dir with live app.exe is review-only');
    Scan.FileLeftovers.Clear;

    Target := TInstalledProgram.Create;
    Target.DisplayName := 'ZZZ Smoke Dead';
    Target.InstallLocation := Tmp + '\Dead';
    Ctx := TScanContext.Create(Target);
    try
      Fil.ScanForLeftovers(Ctx, smSafe, Scan.FileLeftovers);
    finally
      Ctx.Free;
      Target.Free;
    end;
    Check(FindItem(Scan, Tmp + '\Dead', It) and
          (It.Confidence <> lcRisky),
          'dir with only unins000.exe stays a normal leftover');
  finally
    Scan.Free;
    Fil.Free;
    SysUtils.DeleteFile(Tmp + '\Live\app.exe');
    SysUtils.DeleteFile(Tmp + '\Dead\unins000.exe');
    SysUtils.RemoveDir(Tmp + '\Live');
    SysUtils.RemoveDir(Tmp + '\Dead');
    SysUtils.RemoveDir(Tmp);
  end;

  // Close-apps matcher must never offer ourselves or the system pids
  WriteLn('Close-apps self-exclusion:');
  Keys := TStringList.Create;
  try
    Keys.Add('CleanSweep');   // our own process name contains this
    Apps := FindAppsToClose(Keys, nil);
    SelfFound := False;
    for I := 0 to High(Apps) do
      if Apps[I].PID = GetCurrentProcessId then SelfFound := True;
    Check(not SelfFound, 'FindAppsToClose never returns our own pid');
  finally
    Keys.Free;
  end;

  if Fails = 0 then WriteLn('Done.') else WriteLn(Fails, ' CHECK(S) FAILED');
end.
