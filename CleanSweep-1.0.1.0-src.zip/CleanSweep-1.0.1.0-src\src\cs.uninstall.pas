unit cs.uninstall;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Windows, cs.models;

type
  TStatusEvent = procedure(const AMsg: string) of object;
  TProgressEvent = procedure(APercent: Integer) of object;

  TDeleteOptions = record
    DryRun: Boolean;
    UseRecycleBin: Boolean;
  end;

  TUninstallEngine = class
  private
    FOnStatus: TStatusEvent;
    FOnProgress: TProgressEvent;
    FRegScanner: TObject;
    FFileScanner: TObject;
    procedure Status(const AMsg: string);
    procedure Progress(APct: Integer);
    procedure RunLeftoverScan(AProgram: TInstalledProgram;
      AMode: TScanMode; var AScan: TScanResult);
  public
    constructor Create;
    destructor Destroy; override;
    function Uninstall(AProgram: TInstalledProgram; AMode: TScanMode;
      ASilent, ADryRun: Boolean; out AScan: TScanResult): TUninstallResult;
    { Leftover scan without running the uninstaller — preview what a
      removal would leave behind. }
    function ScanOnly(AProgram: TInstalledProgram; AMode: TScanMode;
      out AScan: TScanResult): TUninstallResult;
    function DeleteLeftovers(ARegItems, AFileItems: TLeftoverList;
      const AOptions: TDeleteOptions;
      out ARegDeleted, AFileDeleted: Integer): Boolean;
    property OnStatus: TStatusEvent read FOnStatus write FOnStatus;
    property OnProgress: TProgressEvent read FOnProgress write FOnProgress;
  end;

{ Installer-type detection and silent-switch resolution —
  port of SilentSwitchDatabase + InstalledProgramScanner helpers. }
function DetectInstallerType(AProgram: TInstalledProgram): string;
function ResolveSilentCommand(AProgram: TInstalledProgram): string;

{ Runs a command line, waits up to ATimeoutMs, returns process exit code
  (or -1 on start failure). Uses CreateProcessW so MSI/NSIS/Inno
  uninstallers behave identically to the .NET original.
  The process is placed into a Job Object: Inno/NSIS launchers exit
  immediately after spawning a TEMP-resident child (_iu*.tmp, Au_.exe),
  so after the main process exits we keep waiting until the job —
  i.e. every descendant — drains. }
function RunProcessAndWait(const ACommandLine: string; ATimeoutMs: DWORD;
  out AExitCode: DWORD; AOnStatus: TStatusEvent = nil): Boolean;

{ Moves a file/dir to the Recycle Bin via SHFileOperationW. }
function MoveToRecycleBin(const APath: string): Boolean;

{ Permanent recursive delete, never following reparse points. }
function SafeDeletePath(const APath: string): Boolean;

implementation


uses
  ShellAPI, cs.utils, cs.safety, cs.registry, cs.leftovers;

function ConfName(C: TLeftoverConfidence): string;
begin
  case C of
    lcSafe:     Result := 'SAFE';
    lcModerate: Result := 'MODERATE';
    lcRisky:    Result := 'RISKY';
  else
    Result := 'INFO';
  end;
end;

function TypeName(T: TLeftoverType): string;
begin
  case T of
    ltRegistryKey:   Result := 'RegKey';
    ltRegistryValue: Result := 'RegValue';
    ltFile:          Result := 'File';
    ltFolder:        Result := 'Folder';
    ltService:       Result := 'Service';
    ltScheduledTask: Result := 'Task';
  else
    Result := '?';
  end;
end;

procedure LogProposedItem(const Item: TLeftoverItem);
var
  S: string;
begin
  if Item.IsSelected then S := 'x' else S := ' ';
  LogToFile(Format('  [%s] %-8s %-8s %s | %s',
    [S, TypeName(Item.ItemType), ConfName(Item.Confidence),
     Item.Path, Item.Details]));
end;


const
  UNINSTALLER_TIMEOUT_MS = 30 * 60 * 1000;

procedure SplitRegPathValue(const AFullPath: string;
  out AHive: HKEY; out ASub: string; out AAccess: LongWord);
var
  P: Integer;
  Prefix: string;
begin
  P := Pos('\', AFullPath);
  if P = 0 then
  begin
    Prefix := AFullPath;
    ASub := '';
  end
  else
  begin
    Prefix := Copy(AFullPath, 1, P - 1);
    ASub := Copy(AFullPath, P + 1, MaxInt);
  end;
  AAccess := KEY_READ;
  if SameText(Prefix, 'HKLM') then
  begin AHive := HKEY_LOCAL_MACHINE; AAccess := REGVIEW_64; end
  else if SameText(Prefix, 'HKCU') then
    AHive := HKEY_CURRENT_USER
  else if SameText(Prefix, 'HKCR') then
  begin AHive := HKEY_CLASSES_ROOT; AAccess := REGVIEW_64; end
  else if Pos('HKU\', AFullPath) = 1 then
  begin
    AHive := HKEY_USERS;
    ASub := Copy(AFullPath, 5, MaxInt);
  end
  else
    AHive := 0;
end;

function DetectInstallerType(AProgram: TInstalledProgram): string;
var
  U: string;
begin
  U := LowerCase(AProgram.UninstallString);
  if AProgram.IsWindowsInstaller or (Pos('msiexec', U) > 0) then
    Exit('MSI');
  if (Pos('unins000', U) > 0) or (Pos('unins001', U) > 0) then
    Exit('InnoSetup');
  if (Pos('uninst', U) > 0) and (Pos('nsis', U) > 0) then
    Exit('NSIS');
  if (Pos('au_.exe', U) > 0) or (Pos('\au_', U) > 0) then
    Exit('NSIS');
  if Pos('installshield', U) > 0 then Exit('InstallShield');
  if Pos('wix', U) > 0 then Exit('WiX');
  Result := 'Unknown';
end;

function ResolveSilentCommand(AProgram: TInstalledProgram): string;
var
  T: string;
begin
  if AProgram.QuietUninstallString <> '' then
    Exit(AProgram.QuietUninstallString);
  T := DetectInstallerType(AProgram);
  if T = 'MSI' then
  begin
    Result := AProgram.UninstallString;
    if Pos('/I', Result) > 0 then
      Result := StringReplace(Result, '/I', '/X', [rfIgnoreCase]);
    Result := Result + ' /qn /norestart';
  end
  else if T = 'InnoSetup' then
    Result := AProgram.UninstallString +
              ' /VERYSILENT /SUPPRESSMSGBOXES /NORESTART'
  else if T = 'NSIS' then
    Result := AProgram.UninstallString + ' /S'
  else if T = 'InstallShield' then
    Result := AProgram.UninstallString + ' -s'
  else
    Result := AProgram.UninstallString;
end;

{ Job Object API — missing from FPC's Windows unit (lives in Jedi's
  JwaWinBase; three kernel32 imports are all we need). }
const
  JobObjectBasicProcessIdList = 3;

type
  PJobObjectBasicProcessIdList = ^TJobObjectBasicProcessIdList;
  TJobObjectBasicProcessIdList = record
    NumberOfAssignedProcesses: DWORD;
    NumberOfProcessIdsInList: DWORD;
    ProcessIdList: array[0..0] of ULONG_PTR;
  end;

function CreateJobObjectW(lpJobAttributes: PSecurityAttributes;
  lpName: LPCWSTR): THandle; stdcall;
  external 'kernel32.dll' name 'CreateJobObjectW';
function AssignProcessToJobObject(hJob, hProcess: THandle): BOOL; stdcall;
  external 'kernel32.dll' name 'AssignProcessToJobObject';
function QueryInformationJobObject(hJob: THandle;
  JobObjectInformationClass: DWORD; lpJobObjectInformation: Pointer;
  cbJobObjectInformationLength: DWORD; lpReturnLength: LPDWORD): BOOL;
  stdcall; external 'kernel32.dll' name 'QueryInformationJobObject';

function RunProcessAndWait(const ACommandLine: string; ATimeoutMs: DWORD;
  out AExitCode: DWORD; AOnStatus: TStatusEvent): Boolean;
var
  SI: Windows.TStartupInfoW;
  PI: TProcessInformation;
  Cmd: WideString;
  Wait, N: DWORD;
  Job: THandle;
  Deadline: QWord;
  Told: Boolean;
  Buf: array[0..4095] of Byte;
begin
  Result := False;
  AExitCode := DWORD(-1);
  Cmd := UTF8Decode(ACommandLine);
  FillChar(SI, SizeOf(SI), 0);
  SI.cb := SizeOf(SI);
  SI.dwFlags := STARTF_USESHOWWINDOW;
  SI.wShowWindow := SW_SHOWNORMAL; // uninstallers usually need their UI
  if not CreateProcessW(nil, PWideChar(Cmd), nil, nil, False,
                        NORMAL_PRIORITY_CLASS, nil, nil, SI, PI) then
    Exit;
  Job := 0;
  try
    Job := CreateJobObjectW(nil, nil);
    // Fails when the process is already jobbed on a pre-Win8 box —
    // then we degrade to waiting the main process only.
    if (Job <> 0) and not AssignProcessToJobObject(Job, PI.hProcess) then
    begin
      CloseHandle(Job);
      Job := 0;
    end;
    Deadline := GetTickCount64 + ATimeoutMs;
    Wait := WaitForSingleObject(PI.hProcess, ATimeoutMs);
    if Wait = WAIT_OBJECT_0 then
    begin
      GetExitCodeProcess(PI.hProcess, AExitCode);
      Result := True;
      Told := False;
      if Job <> 0 then
        while GetTickCount64 < Deadline do
        begin
          FillChar(Buf, SizeOf(Buf), 0);
          if not QueryInformationJobObject(Job, JobObjectBasicProcessIdList,
                 @Buf, SizeOf(Buf), @N) then Break;
          if PJobObjectBasicProcessIdList(@Buf)^.NumberOfAssignedProcesses = 0
            then Break;
          if not Told then
          begin
            Told := True;
            if Assigned(AOnStatus) then
              AOnStatus('Ожидание завершения деинсталлятора...');
            LogToFile('Waiting for uninstaller subprocesses to exit...');
          end;
          Sleep(400);
        end;
    end
    else if Wait = WAIT_TIMEOUT then
      TerminateProcess(PI.hProcess, 1);
  finally
    if Job <> 0 then CloseHandle(Job);
    CloseHandle(PI.hThread);
    CloseHandle(PI.hProcess);
  end;
end;

function MoveToRecycleBin(const APath: string): Boolean;
var
  Op: SHFILEOPSTRUCTW;
  W: WideString;
  R: Integer;
begin
  // Double-null-terminated source list
  W := UTF8Decode(APath) + #0;
  FillChar(Op, SizeOf(Op), 0);
  Op.wFunc := FO_DELETE;
  Op.pFrom := PWideChar(W);
  Op.fFlags := FOF_ALLOWUNDO or FOF_NOCONFIRMATION or FOF_SILENT or
               FOF_NOERRORUI;
  R := SHFileOperationW(@Op);
  Result := (R = 0) and (not Op.fAnyOperationsAborted);
end;

function SafeDeletePath(const APath: string): Boolean;
var
  Files, Dirs: TStringList;
  I: Integer;
  W: WideString;
begin
  Result := False;
  if not IsPathSafeToDelete(APath) then Exit;
  if IsReparsePoint(APath) then
  begin
    // Delete the junction itself, never the target
    W := UTF8Decode(APath);
    Result := RemoveDirectoryW(PWideChar(W)) or
              DeleteFileW(PWideChar(W));
    Exit;
  end;

  if FileExists(APath) then
  begin
    SetFileAttributesW(PWideChar(UTF8Decode(APath)), FILE_ATTRIBUTE_NORMAL);
    Exit(DeleteFileW(PWideChar(UTF8Decode(APath))));
  end;

  if not DirectoryExists(APath) then Exit;

  Files := TStringList.Create;
  Dirs := TStringList.Create;
  try
    SafeEnumFiles(APath, '*', Files);
    for I := 0 to Files.Count - 1 do
    begin
      SetFileAttributesW(PWideChar(UTF8Decode(Files[I])), FILE_ATTRIBUTE_NORMAL);
      DeleteFileW(PWideChar(UTF8Decode(Files[I])));
    end;
    SafeEnumDirs(APath, Dirs);
    // deepest-first order from SafeEnumDirs
    for I := 0 to Dirs.Count - 1 do
      RemoveDirectoryW(PWideChar(UTF8Decode(Dirs[I])));
    Result := RemoveDirectoryW(PWideChar(UTF8Decode(APath)));
  finally
    Files.Free;
    Dirs.Free;
  end;
end;

{ ═══════════════ Engine ═══════════════ }

constructor TUninstallEngine.Create;
begin
  FRegScanner := TRegistryLeftoverScanner.Create;
  FFileScanner := TFileLeftoverScanner.Create;
end;

destructor TUninstallEngine.Destroy;
begin
  FRegScanner.Free;
  FFileScanner.Free;
  inherited;
end;

procedure TUninstallEngine.Status(const AMsg: string);
begin
  if Assigned(FOnStatus) then FOnStatus(AMsg);
end;

procedure TUninstallEngine.Progress(APct: Integer);
begin
  if Assigned(FOnProgress) then FOnProgress(APct);
end;

{ Shared tail of Uninstall and ScanOnly: build the scan context and run
  both leftover scanners with full logging. AScan is created here. }
procedure TUninstallEngine.RunLeftoverScan(AProgram: TInstalledProgram;
  AMode: TScanMode; var AScan: TScanResult);
var
  Ctx: TScanContext;
  I: Integer;
begin
  Progress(50);
  Status('Building scan context...');
  Ctx := TScanContext.Create(AProgram);
  try
    AScan := TScanResult.Create;
    AScan.Mode := AMode;
    Status('Scanning for leftover registry entries...');
    TRegistryLeftoverScanner(FRegScanner).ScanForLeftovers(
      Ctx, AMode, AScan.RegistryLeftovers);
    Progress(70);
    Status('Scanning for leftover files and folders...');
    TFileLeftoverScanner(FFileScanner).ScanForLeftovers(
      Ctx, AMode, AScan.FileLeftovers);
  finally
    Ctx.Free;
  end;
  Progress(100);
  Status(Format('Scan complete: %d registry + %d file leftovers',
    [AScan.RegistryLeftovers.Count, AScan.FileLeftovers.Count]));
  LogToFile('=== PROPOSED LEFTOVERS for "' + AProgram.DisplayName +
            '" ===');
  for I := 0 to AScan.RegistryLeftovers.Count - 1 do
    LogProposedItem(AScan.RegistryLeftovers[I]);
  for I := 0 to AScan.FileLeftovers.Count - 1 do
    LogProposedItem(AScan.FileLeftovers[I]);
  LogToFile('=== END PROPOSED ===');
end;

{ Preview path: leftover scan only — no uninstaller, nothing deleted.
  Lets the user inspect what a removal would leave behind first. }
function TUninstallEngine.ScanOnly(AProgram: TInstalledProgram;
  AMode: TScanMode; out AScan: TScanResult): TUninstallResult;
var
  Procs: TStringList;
  I: Integer;
begin
  Result := TUninstallResult.Create;
  AScan := nil;
  LogToFile('=== LEFTOVER SCAN (no uninstall) "' + AProgram.DisplayName +
            '" (mode=' + IntToStr(Ord(AMode)) + ') ===');
  try
    if AProgram.InstallLocation <> '' then
    begin
      Procs := RunningProcessesUnder(AProgram.InstallLocation);
      try
        for I := 0 to Procs.Count - 1 do
          Status('NOTE: still running: ' + Procs[I]);
      finally
        Procs.Free;
      end;
    end;
    Result.Success := True;
    Result.Outcome := uoCompleted;
    Result.Output := 'Scan only — no uninstaller was run.';
    RunLeftoverScan(AProgram, AMode, AScan);
    Result.Scan := AScan;
  except
    on E: Exception do
    begin
      Result.Success := False;
      Result.Outcome := uoFailed;
      Result.ErrorOutput := E.Message;
      Status('Error: ' + E.Message);
    end;
  end;
end;

function TUninstallEngine.Uninstall(AProgram: TInstalledProgram;
  AMode: TScanMode; ASilent, ADryRun: Boolean;
  out AScan: TScanResult): TUninstallResult;
var
  Cmd: string;
  ExitCode: DWORD;
  Procs: TStringList;
  I: Integer;
begin
  Result := TUninstallResult.Create;
  AScan := nil;
  LogToFile('=== UNINSTALL "' + AProgram.DisplayName +
            '" (mode=' + IntToStr(Ord(AMode)) + ', silent=' +
            BoolToStr(ASilent, True) + ') ===');
  try
    // Uninstall Tool-style check: warn if processes still run from the
    // install dir — locked files would silently survive deletion.
    if AProgram.InstallLocation <> '' then
    begin
      Procs := RunningProcessesUnder(AProgram.InstallLocation);
      try
        for I := 0 to Procs.Count - 1 do
          Status('WARNING: still running: ' + Procs[I]);
      finally
        Procs.Free;
      end;
    end;

    if ADryRun then
    begin
      Result.Outcome := uoPreview;
      Result.Success := AProgram.HasUninstaller;
      Result.UninstallerSkipped := True;
      if ASilent then
        Result.Output := 'Would run: ' + ResolveSilentCommand(AProgram)
      else
        Result.Output := 'Would run: ' + AProgram.UninstallString;
      Status(Result.Output);
      Exit;
    end;

    if not AProgram.HasUninstaller then
    begin
      Result.Outcome := uoUnsupported;
      Result.ErrorOutput := 'No uninstall command registered.';
      Status(Result.ErrorOutput);
      // still scan leftovers below
    end
    else
    begin
      if ASilent then
        Cmd := ResolveSilentCommand(AProgram)
      else
        Cmd := AProgram.UninstallString;
      if Trim(Cmd) = '' then
      begin
        Result.Outcome := uoFailed;
        Result.ErrorOutput := 'Empty uninstall command.';
        Result.UninstallerSkipped := True;
        Status(Result.ErrorOutput);
      end
      else
      begin
        Status('Running uninstaller: ' + Cmd);
        LogToFile('RUN: ' + Cmd);
        Progress(20);
        if RunProcessAndWait(Cmd, UNINSTALLER_TIMEOUT_MS, ExitCode,
                             @Status) then
        begin
          Result.ExitCode := Integer(ExitCode);
          Result.Success := (ExitCode = 0) or (ExitCode = 1641) or
                            (ExitCode = 3010);
          if Result.Success then
            Result.Outcome := uoCompleted
          else
            Result.Outcome := uoFailed;
          Result.Output := 'Uninstaller exit code: ' + IntToStr(Result.ExitCode);
          Status(Result.Output);
        end
        else
        begin
          Result.ExitCode := -1;
          Result.Outcome := uoFailed;
          Result.ErrorOutput := 'Failed to start or timed out.';
          Status(Result.ErrorOutput);
        end;
      end;
    end;

    RunLeftoverScan(AProgram, AMode, AScan);
    Result.Scan := AScan;
  except
    on E: Exception do
    begin
      Result.Success := False;
      Result.Outcome := uoFailed;
      Result.ErrorOutput := E.Message;
      Status('Error: ' + E.Message);
    end;
  end;
end;

function TUninstallEngine.DeleteLeftovers(ARegItems, AFileItems: TLeftoverList;
  const AOptions: TDeleteOptions;
  out ARegDeleted, AFileDeleted: Integer): Boolean;
var
  I: Integer;
  Item: TLeftoverItem;
  Hive: HKEY;
  Sub, ValueName, KeyPart: string;
  Acc: LongWord;
  Sep: Integer;
  ExitCode: DWORD;
begin
  ARegDeleted := 0;
  AFileDeleted := 0;

  for I := 0 to ARegItems.Count - 1 do
  begin
    Item := ARegItems[I];
    if (not Item.IsSelected) or (Item.Confidence = lcRisky) or
       (Item.Confidence = lcInfo) then Continue;

    // Scheduled tasks live outside the registry path syntax
    if Item.ItemType = ltScheduledTask then
    begin
      if Pos('TASK\', Item.Path) <> 1 then Continue;
      if not IsTaskSafeToDelete(Copy(Item.Path, 6, MaxInt)) then Continue;
      if not AOptions.DryRun then
      begin
        if RunProcessAndWait('schtasks.exe /delete /tn "' +
           Copy(Item.Path, 6, MaxInt) + '" /f', 30000, ExitCode) and
           (ExitCode = 0) then
        begin
          Inc(ARegDeleted);
          LogToFile('DELETED task: ' + Item.Path);
        end
        else
          LogToFile('FAILED task: ' + Item.Path);
      end
      else
      begin
        Inc(ARegDeleted);
        LogToFile('DRY-RUN task: ' + Item.Path);
      end;
      Continue;
    end;

    if not IsRegistryPathSafeToDelete(Item.Path) then Continue;
    if (Item.ItemType = ltService) and
       (not IsServiceSafeToModify(ExtractFileName(Item.Path))) then Continue;

    if AOptions.DryRun then
    begin
      Inc(ARegDeleted);
      LogToFile('DRY-RUN reg: ' + Item.Path);
      Continue;
    end;

    if Item.ItemType = ltRegistryValue then
    begin
      // Value names can contain backslashes (MuiCache, BAM...), so the
      // parent key is stored explicitly in KeyPath - never re-split Path.
      if Item.KeyPath <> '' then
        KeyPart := Item.KeyPath
      else
      begin
        Sep := LastDelimiter('\', Item.Path);
        KeyPart := Copy(Item.Path, 1, Sep - 1);
      end;
      ValueName := Copy(Item.Path, Length(KeyPart) + 2, MaxInt);
      SplitRegPathValue(KeyPart, Hive, Sub, Acc);
      if RegForceDeleteValue(Hive, Sub, ValueName, Acc) then
      begin
        Inc(ARegDeleted);
        LogToFile('DELETED reg value: ' + Item.Path);
      end
      else
        LogToFile('FAILED reg value: ' + Item.Path);
    end
    else
    begin
      SplitRegPathValue(Item.Path, Hive, Sub, Acc);
      if RegDeleteTree(Hive, Sub, Acc) then
      begin
        Inc(ARegDeleted);
        LogToFile('DELETED reg key: ' + Item.Path);
      end
      else
        LogToFile('FAILED reg key: ' + Item.Path);
    end;
  end;

  for I := 0 to AFileItems.Count - 1 do
  begin
    Item := AFileItems[I];
    if (not Item.IsSelected) or (Item.Confidence = lcRisky) or
       (Item.Confidence = lcInfo) then Continue;
    if not IsPathSafeToDelete(Item.Path) then Continue;

    if (not FileExists(Item.Path)) and (not DirectoryExists(Item.Path)) then
    begin
      Inc(AFileDeleted);
      LogToFile('ALREADY GONE: ' + Item.Path);
      Continue;
    end;

    if AOptions.DryRun then
    begin
      Inc(AFileDeleted);
      LogToFile('DRY-RUN file: ' + Item.Path);
      Continue;
    end;

    if AOptions.UseRecycleBin then
    begin
      if MoveToRecycleBin(Item.Path) then
      begin
        Inc(AFileDeleted);
        LogToFile('RECYCLED: ' + Item.Path);
      end
      else
        LogToFile('FAILED file: ' + Item.Path);
    end
    else if SafeDeletePath(Item.Path) then
    begin
      Inc(AFileDeleted);
      LogToFile('DELETED file: ' + Item.Path);
    end
    else
      LogToFile('FAILED file: ' + Item.Path);
  end;

  Status(Format('Deleted %d registry entries and %d files/folders',
    [ARegDeleted, AFileDeleted]));
  Result := True;
end;

end.
