unit cs.safety;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, cs.utils;

{ Centralized safety validation — port of DeepPurge.Core.Safety.SafetyGuard.
  Every destructive operation MUST pass through this unit first. }

function IsPathSafeToDelete(const APath: string): Boolean;
function IsRegistryPathSafeToDelete(const ARegPath: string): Boolean;
function IsServiceSafeToModify(const AServiceName: string): Boolean;
function IsTaskSafeToDelete(const ATaskPath: string): Boolean;
function IsFirewallRuleSafeToDelete(const ADisplayName: string): Boolean;
function IsAutorunSafeToDelete(const ACommand: string): Boolean;

{ True when APath is under one of the machine/user temp roots:
  %TEMP%/%TMP% and Windows\Temp. Temp content is scratch data and is
  treated as deletable garbage by policy; use IsTempRoot to protect the
  roots themselves. }
function IsTempPath(const APath: string): Boolean;

{ True when APath IS a temp root itself (never deletable). }
function IsTempRoot(const APath: string): Boolean;

{ Runnable/installable file types (.exe/.msi/.com/.scr/.bat/.cmd/.ps1/
  .vbs) — broad cleanup patterns must never stage these. }
function IsRunnableExtension(const APath: string): Boolean;

{ Path roots resolved once at startup. }
procedure InitSafetyRoots;

var
  GWinDir: string;
  GSys32: string;
  GSysWow64: string;
  GProgramFiles: string;     // 64-bit Program Files
  GProgramFilesX86: string;
  GProgramData: string;
  GSystemDrive: string;
  GUsersDir: string;
  GTempRoots: TStringList;   // normalized temp dirs (user TEMP/TMP + WinDir\Temp)

implementation

var
  ProtectedDirs: TStringList;
  ProtectedFiles: TStringList;
  ExactOnlyDirs: TStringList;   // protected themselves, children are fair game

procedure AddExactOnly(const APath: string);
begin
  if APath = '' then Exit;
  ProtectedDirs.Add(APath);
  ExactOnlyDirs.Add(APath);
end;

procedure AddTempRoot(const APath: string);
var
  N: string;
begin
  N := NormalizePath(APath);
  if N <> '' then GTempRoots.Add(N);
end;

const
  ProtectedRegistryRoots: array[0..11] of string = (
    'HKLM\SYSTEM\CurrentControlSet\Control',
    'HKLM\SYSTEM\CurrentControlSet\Enum',
    'HKLM\SYSTEM\CurrentControlSet\Hardware Profiles',
    'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing',
    'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup',
    'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion',
    'HKLM\SOFTWARE\Microsoft\Cryptography',
    'HKLM\SOFTWARE\Policies',
    'HKCU\SOFTWARE\Policies',
    'HKLM\BCD00000000',
    'HKLM\SAM',
    'HKLM\SECURITY');

  ProtectedServiceNames: array[0..47] of string = (
    'wuauserv', 'BITS', 'Winmgmt', 'EventLog', 'PlugPlay', 'RpcSs',
    'RpcEptMapper', 'DcomLaunch', 'LSM', 'SamSs', 'LanmanServer',
    'LanmanWorkstation', 'Dhcp', 'Dnscache', 'CryptSvc', 'TrustedInstaller',
    'msiserver', 'Spooler', 'WinDefend', 'MpsSvc', 'SecurityHealthService',
    'wscsvc', 'WdiServiceHost', 'WdiSystemHost', 'Schedule', 'Themes',
    'AudioEndpointBuilder', 'Audiosrv', 'UserManager', 'StateRepository',
    'StorSvc', 'SystemEventsBroker', 'TimeBrokerSvc', 'TokenBroker',
    'CoreMessagingRegistrar', 'Netman', 'NlaSvc', 'netprofm', 'Wcmsvc',
    'WlanSvc', 'iphlpsvc', 'BFE', 'nsi', 'NTDS', 'W32Time', 'FontCache',
    'gpsvc', 'Power');

  ProtectedTaskPaths: array[0..3] of string = (
    '\Microsoft\Windows\',
    '\Microsoft\Office\',
    '\Microsoft\Edge\',
    '\Microsoft\VisualStudio\');

  ProtectedFirewallPrefixes: array[0..5] of string = (
    'Core Networking',
    'Windows Defender',
    'Remote Desktop',
    'File and Printer Sharing',
    'Network Discovery',
    '@FirewallAPI.dll');

procedure InitSafetyRoots;
begin
  if ProtectedDirs <> nil then Exit;   // idempotent — lists are process-global
  GWinDir := GetSpecialFolder(CSIDL_WINDOWS);
  GSys32 := GetSpecialFolder(CSIDL_SYSTEM);
  GSysWow64 := IncludeTrailingPathDelimiter(GWinDir) + 'SysWOW64';
  GProgramFiles := GetProgramFiles64;
  GProgramFilesX86 := GetSpecialFolder(CSIDL_PROGRAM_FILESX86);
  if GProgramFilesX86 = '' then
    GProgramFilesX86 := GetEnvironmentVariable('ProgramFiles(x86)');
  GProgramData := GetSpecialFolder(CSIDL_COMMON_APPDATA);
  GSystemDrive := ExtractFileDrive(GWinDir);
  if GSystemDrive = '' then GSystemDrive := 'C:';
  GUsersDir := GSystemDrive + '\Users';

  GTempRoots := TStringList.Create;
  GTempRoots.CaseSensitive := False;
  GTempRoots.Sorted := True;
  GTempRoots.Duplicates := dupIgnore;
  AddTempRoot('%TEMP%');
  AddTempRoot('%TMP%');
  AddTempRoot(GetTempDir(False));
  AddTempRoot(GWinDir + '\Temp');

  ProtectedDirs := TStringList.Create;
  ProtectedDirs.CaseSensitive := False;
  ExactOnlyDirs := TStringList.Create;
  ExactOnlyDirs.CaseSensitive := False;
  // Exact-only roots: the directory itself can never be deleted, but
  // descendants are evaluated on their own merits. WinDir already had
  // that status; Program Files / ProgramData join it — a broken or
  // hostile InstallLocation must not wipe the whole software root.
  AddExactOnly(GWinDir);
  AddExactOnly(GProgramData + '\Microsoft\Windows');
  AddExactOnly(GProgramFiles);
  AddExactOnly(GProgramFilesX86);
  AddExactOnly(GProgramData);
  with ProtectedDirs do
  begin
    Add(GSys32);
    Add(GSysWow64);
    Add(GWinDir + '\WinSxS');
    Add(GWinDir + '\Boot');
    Add(GWinDir + '\Fonts');
    Add(GWinDir + '\Globalization');
    Add(GWinDir + '\IME');
    Add(GWinDir + '\rescache');
    Add(GWinDir + '\Resources');
    Add(GWinDir + '\servicing');
    Add(GWinDir + '\SystemResources');
    Add(GProgramFiles + '\Windows Defender');
    Add(GProgramFiles + '\Windows Security');
    Add(GProgramFiles + '\Common Files\microsoft shared');
    Add(GProgramFilesX86 + '\Common Files');
    Add(GProgramData + '\Microsoft\Windows Defender');
    Add(GSystemDrive + '\Recovery');
    Add(GSystemDrive + '\$Recycle.Bin');
  end;

  ProtectedFiles := TStringList.Create;
  ProtectedFiles.CaseSensitive := False;
  with ProtectedFiles do
  begin
    Add(GSys32 + '\config\SYSTEM');
    Add(GSys32 + '\config\SOFTWARE');
    Add(GSys32 + '\config\SAM');
    Add(GSys32 + '\config\SECURITY');
    Add(GSys32 + '\config\DEFAULT');
    Add(GSystemDrive + '\bootmgr');
    Add(GSystemDrive + '\BOOTNXT');
  end;
end;

function IsPathSafeToDelete(const APath: string): Boolean;
var
  Normalized, Dir: string;
  I: Integer;
begin
  Result := False;
  // not initialized → fail closed, never call a path deletable
  if ProtectedDirs = nil then Exit;
  Normalized := NormalizePath(APath);
  if Normalized = '' then Exit;

  // Never delete a protected file
  if ProtectedFiles.IndexOf(Normalized) >= 0 then Exit;

  // Temp roots themselves are infrastructure — their contents are
  // garbage, the directories are not.
  if GTempRoots.IndexOf(Normalized) >= 0 then Exit;

  for I := 0 to ProtectedDirs.Count - 1 do
  begin
    Dir := ProtectedDirs[I];
    if SameText(Normalized, Dir) then Exit;
    // exact-only roots protect themselves; everything else protects
    // the whole subtree
    if (ExactOnlyDirs.IndexOf(Dir) < 0) and
       IsSamePathOrDescendant(Normalized, Dir) then Exit;
  end;

  // Never delete a drive root
  if SameText(Normalized, ExtractFileDrive(Normalized)) then Exit;

  // Never delete Users root or a profile root directly under it
  if SameText(Normalized, GUsersDir) then Exit;
  if SameText(ExtractFileDir(Normalized), GUsersDir) then Exit;

  Result := True;
end;

function IsTempPath(const APath: string): Boolean;
var
  N: string;
  I: Integer;
begin
  Result := False;
  if GTempRoots = nil then Exit;
  N := NormalizePath(APath);
  if N = '' then Exit;
  for I := 0 to GTempRoots.Count - 1 do
    if IsSamePathOrDescendant(N, GTempRoots[I]) then Exit(True);
end;

function IsTempRoot(const APath: string): Boolean;
begin
  Result := (GTempRoots <> nil) and
            (GTempRoots.IndexOf(NormalizePath(APath)) >= 0);
end;

function IsRunnableExtension(const APath: string): Boolean;
const
  Ext: array[0..7] of string = ('.exe', '.msi', '.com', '.scr',
    '.bat', '.cmd', '.ps1', '.vbs');
var
  E: string;
  I: Integer;
begin
  E := LowerCase(ExtractFileExt(APath));
  Result := False;
  for I := Low(Ext) to High(Ext) do
    if E = Ext[I] then Exit(True);
end;

function IsRegistryPathSafeToDelete(const ARegPath: string): Boolean;
var
  I: Integer;
  P: string;
begin
  Result := False;
  P := Trim(ARegPath);
  if P = '' then Exit;
  for I := Low(ProtectedRegistryRoots) to High(ProtectedRegistryRoots) do
    if Pos(LowerCase(ProtectedRegistryRoots[I]), LowerCase(P)) = 1 then Exit;
  Result := True;
end;

function IsServiceSafeToModify(const AServiceName: string): Boolean;
var
  I: Integer;
begin
  Result := False;
  if Trim(AServiceName) = '' then Exit;
  for I := Low(ProtectedServiceNames) to High(ProtectedServiceNames) do
    if SameText(AServiceName, ProtectedServiceNames[I]) then Exit;
  Result := True;
end;

function IsTaskSafeToDelete(const ATaskPath: string): Boolean;
var
  I: Integer;
begin
  Result := False;
  if Trim(ATaskPath) = '' then Exit;
  for I := Low(ProtectedTaskPaths) to High(ProtectedTaskPaths) do
    if Pos(LowerCase(ProtectedTaskPaths[I]), LowerCase(ATaskPath)) = 1 then Exit;
  Result := True;
end;

function IsFirewallRuleSafeToDelete(const ADisplayName: string): Boolean;
var
  I: Integer;
begin
  Result := False;
  if Trim(ADisplayName) = '' then Exit;
  for I := Low(ProtectedFirewallPrefixes) to High(ProtectedFirewallPrefixes) do
    if Pos(LowerCase(ProtectedFirewallPrefixes[I]), LowerCase(ADisplayName)) = 1 then Exit;
  Result := True;
end;

function IsAutorunSafeToDelete(const ACommand: string): Boolean;
var
  C: string;
begin
  Result := False;
  C := LowerCase(ACommand);
  if Trim(C) = '' then Exit;
  if (Pos(LowerCase(GSys32), C) > 0) or
     (Pos(LowerCase(GSysWow64), C) > 0) or
     (Pos('securityhealthsystray', C) > 0) or
     (Pos('windowsdefender', C) > 0) or
     (Pos('ctfmon.exe', C) > 0) or
     (Pos('onedrive', C) > 0) or
     (Pos('msedge', C) > 0) then Exit;
  Result := True;
end;

finalization
  ProtectedDirs.Free;
  ProtectedFiles.Free;
  ExactOnlyDirs.Free;
  GTempRoots.Free;

end.
