unit cookieform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls, Dialogs, IniFiles,
  cs.cookies, cs.winsqlite, cs.utils, cs.lang;

type
  { Modal Cookie Manager — port of upstream's Settings > Cookies view.
    Left list: domains found across browser profiles; right list: the
    keep-list (domains whose cookies survive a clean — the cleaner
    prunes recognized cookie DBs in place instead of deleting them).
    'Delete' removes the selected domains from all browsers at once.
    The keep-list persists in CleanSweep.ini [Cookies]. }
  TCookieForm = class(TForm)
    lblAvail: TLabel;
    lblKept: TLabel;
    edSearchAvail: TEdit;
    edSearchKept: TEdit;
    lbAvail: TListBox;
    lbKept: TListBox;
    btnKeep: TButton;
    btnDelete: TButton;
    btnRemove: TButton;
    btnImport: TButton;
    btnExport: TButton;
    btnRefresh: TButton;
    lblStatus: TLabel;
    btnClose: TButton;
    procedure BtnKeepClick(Sender: TObject);
    procedure BtnDeleteClick(Sender: TObject);
    procedure BtnRemoveClick(Sender: TObject);
    procedure BtnImportClick(Sender: TObject);
    procedure BtnExportClick(Sender: TObject);
    procedure BtnRefreshClick(Sender: TObject);
    procedure SearchChange(Sender: TObject);
    procedure ListDblClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
  private
    FDetected: TStringList;          // normalized domains from the scan
    FKept: TStringList;              // keep-list, sorted unique
    procedure RefreshLists;
    procedure LoadKeepList;
    procedure SaveKeepList;
    procedure Rescan;
    { Offers to close running browsers that hold cookie DBs open.
      False = user cancelled the delete. }
    function OfferCloseBrowsers: Boolean;
    function SelectedDomains(AList: TListBox): TStringList;
  end;

function ShowCookieDialog(AOwner: TComponent): TModalResult;

{ Keep-list persistence — shared with the cleaner, which reads the same
  ini section when a clean run starts (TCleaningService.CookieKeepList). }
procedure LoadCookieKeepList(const AIniPath: string; AOut: TStrings);
procedure SaveCookieKeepList(const AIniPath: string; const AList: TStrings);

implementation

uses
  closeappsform, cs.closeapps;

{$R *.lfm}

const
  SEC_COOKIES = 'Cookies';

procedure LoadCookieKeepList(const AIniPath: string; AOut: TStrings);
var
  Ini: TIniFile;
  I, N: Integer;
  D: string;
begin
  Ini := TIniFile.Create(AIniPath);
  try
    N := Ini.ReadInteger(SEC_COOKIES, 'Count', 0);
    for I := 0 to N - 1 do
    begin
      D := NormalizeCookieDomain(
             Ini.ReadString(SEC_COOKIES, 'Domain' + IntToStr(I), ''));
      if (D <> '') and (AOut.IndexOf(D) < 0) then AOut.Add(D);
    end;
  finally
    Ini.Free;
  end;
end;

procedure SaveCookieKeepList(const AIniPath: string; const AList: TStrings);
var
  Ini: TIniFile;
  I: Integer;
begin
  Ini := TIniFile.Create(AIniPath);
  try
    Ini.EraseSection(SEC_COOKIES);
    Ini.WriteInteger(SEC_COOKIES, 'Count', AList.Count);
    for I := 0 to AList.Count - 1 do
      Ini.WriteString(SEC_COOKIES, 'Domain' + IntToStr(I), AList[I]);
  finally
    Ini.Free;
  end;
end;

function SettingsPath: string;
begin
  Result := ExtractFilePath(ParamStr(0)) + 'CleanSweep.ini';
end;

function ShowCookieDialog(AOwner: TComponent): TModalResult;
var
  F: TCookieForm;
begin
  F := TCookieForm.Create(AOwner);
  try
    Result := F.ShowModal;
  finally
    F.Free;
  end;
end;

{ Filtered view of ASrc into ADst — substring match, case-insensitive,
  like upstream's Filter(). }
procedure FillList(ADst: TListBox; const ASrc, AExclude: TStrings;
  const AFilter: string);
var
  I: Integer;
  F: string;
begin
  F := LowerCase(Trim(AFilter));
  ADst.Items.BeginUpdate;
  try
    ADst.Items.Clear;
    for I := 0 to ASrc.Count - 1 do
      if ((AExclude = nil) or (AExclude.IndexOf(ASrc[I]) < 0)) and
         ((F = '') or (Pos(F, LowerCase(ASrc[I])) > 0)) then
        ADst.Items.Add(ASrc[I]);
  finally
    ADst.Items.EndUpdate;
  end;
end;

procedure TCookieForm.RefreshLists;
begin
  FillList(lbAvail, FDetected, FKept, edSearchAvail.Text);
  FillList(lbKept, FKept, nil, edSearchKept.Text);
end;

procedure TCookieForm.LoadKeepList;
begin
  FKept.Clear;
  LoadCookieKeepList(SettingsPath, FKept);
end;

procedure TCookieForm.SaveKeepList;
begin
  SaveCookieKeepList(SettingsPath, FKept);
end;

procedure TCookieForm.Rescan;
var
  Scan: TCookieScanResult;
  C: TCursor;
begin
  if not WinSqliteAvailable then
  begin
    lblStatus.Caption := Lg(
      'winsqlite3.dll не найдена — функции кук недоступны.',
      'winsqlite3.dll не знойдзена — функцыі кук недаступныя.',
      'winsqlite3.dll не знайдена — функції кук недоступні.',
      'winsqlite3.dll not found — cookie features unavailable.');
    Exit;
  end;
  C := Screen.Cursor;
  Screen.Cursor := crHourGlass;
  lblStatus.Caption := Lg('Сканирование…', 'Сканаванне…',
                          'Сканування…', 'Scanning…');
  lblStatus.Update;
  try
    Scan := CookieScanDomains;
    try
      FDetected.Assign(Scan.Domains);
      RefreshLists;
      if Scan.StoresUnavailable > 0 then
        lblStatus.Caption := Format(Lg(
          'Доменов: %d, хранилищ: %d (недоступно: %d — закройте браузеры)',
          'Даменаў: %d, сховішчаў: %d (недаступна: %d — закрыце браўзеры)',
          'Доменів: %d, сховищ: %d (недоступно: %d — закрийте браузери)',
          'Domains: %d, stores: %d (unavailable: %d — close the browsers)'),
          [Scan.Domains.Count, Scan.StoresFound, Scan.StoresUnavailable])
      else
        lblStatus.Caption := Format(Lg(
          'Доменов: %d, хранилищ: %d',
          'Даменаў: %d, сховішчаў: %d',
          'Доменів: %d, сховищ: %d',
          'Domains: %d, stores: %d'),
          [Scan.Domains.Count, Scan.StoresFound]);
    finally
      Scan.Free;
    end;
  finally
    Screen.Cursor := C;
  end;
end;

{ Currently selected rows of AList as a fresh TStringList (caller frees). }
function TCookieForm.SelectedDomains(AList: TListBox): TStringList;
var
  I: Integer;
begin
  Result := TStringList.Create;
  for I := 0 to AList.Count - 1 do
    if AList.Selected[I] then Result.Add(AList.Items[I]);
end;

procedure TCookieForm.BtnKeepClick(Sender: TObject);
var
  Sel: TStringList;
  I: Integer;
begin
  Sel := SelectedDomains(lbAvail);
  try
    for I := 0 to Sel.Count - 1 do
      FKept.Add(Sel[I]);            // dupIgnore — no dupes to check
  finally
    Sel.Free;
  end;
  SaveKeepList;
  RefreshLists;
end;

procedure TCookieForm.BtnRemoveClick(Sender: TObject);
var
  Sel: TStringList;
  I: Integer;
begin
  Sel := SelectedDomains(lbKept);
  try
    for I := 0 to Sel.Count - 1 do
      FKept.Delete(FKept.IndexOf(Sel[I]));
  finally
    Sel.Free;
  end;
  SaveKeepList;
  RefreshLists;
end;

procedure TCookieForm.BtnDeleteClick(Sender: TObject);
var
  Sel: TStringList;
  Unavail: Integer;
begin
  Sel := SelectedDomains(lbAvail);
  if Sel.Count = 0 then
  begin
    Sel.Free;
    Exit;
  end;
  if MessageDlg(Format(Lg(
      'Удалить куки %d доменов из всех браузеров? Сессии на этих сайтах завершатся.',
      'Выдаліць кукі %d даменаў з усіх браўзераў? Сесіі на гэтых сайтах завершацца.',
      'Видалити кукі %d доменів з усіх браузерів? Сесії на цих сайтах завершаться.',
      'Delete cookies for %d domains from all browsers? Sessions on those sites will end.'),
      [Sel.Count]), mtConfirmation, [mbYes, mbNo], 0) <> mrYes then
  begin
    Sel.Free;
    Exit;
  end;
  if not OfferCloseBrowsers then
  begin
    Sel.Free;
    Exit;
  end;
  Screen.Cursor := crHourGlass;
  try
    Unavail := CookieDeleteDomains(Sel);
  finally
    Screen.Cursor := crDefault;
    Sel.Free;
  end;
  Rescan;
  if Unavail > 0 then
    lblStatus.Caption := Format(Lg(
      'Готово, но %d хранилищ было недоступно — закройте браузеры и повторите.',
      'Гатова, але %d сховішчаў было недаступна — закрыце браўзеры і паўтарыце.',
      'Готово, але %d сховищ було недоступно — закрийте браузери й повторіть.',
      'Done, but %d stores were unavailable — close the browsers and retry.'),
      [Unavail]);
end;

function TCookieForm.OfferCloseBrowsers: Boolean;
const
  // every browser family cs.cookies.DiscoverStores knows about
  BrowserKeys: array[0..6] of string = (
    'Google Chrome', 'Microsoft Edge', 'Brave', 'Chromium',
    'Vivaldi', 'Opera', 'Mozilla Firefox');
var
  Keys: TStringList;
  Apps, ToClose: TRunningAppArray;
  I: Integer;
  F: TCloseAppsForm;
begin
  Result := True;
  Keys := TStringList.Create;
  try
    for I := Low(BrowserKeys) to High(BrowserKeys) do
      Keys.Add(BrowserKeys[I]);
    Apps := FindAppsToClose(Keys, nil);
    if Length(Apps) = 0 then Exit;
    F := TCloseAppsForm.CreateDlg(Self, Apps);
    try
      case F.ShowModal of
        mrYes:
          begin
            ToClose := F.CheckedApps;
            for I := 0 to High(ToClose) do
              CloseApp(ToClose[I], 8000);
          end;
        mrNo: ;   // proceed — locked stores are reported afterwards
      else
        Exit(False);   // mrCancel
      end;
    finally
      F.Free;
    end;
  finally
    Keys.Free;
  end;
end;

procedure TCookieForm.BtnImportClick(Sender: TObject);
var
  D: TOpenDialog;
  SL: TStringList;
  I: Integer;
  S: string;
begin
  D := TOpenDialog.Create(Self);
  try
    D.Filter := Lg('Текстовые файлы|*.txt', 'Тэкставыя файлы|*.txt',
                   'Текстові файли|*.txt', 'Text files|*.txt');
    D.Options := D.Options + [ofFileMustExist];
    if not D.Execute then Exit;
    SL := TStringList.Create;
    try
      SL.Text := LoadTextFile(D.FileName);
      for I := 0 to SL.Count - 1 do
      begin
        S := Trim(SL[I]);
        if (S = '') or (S[1] = '#') or (S[1] = ';') or (S[1] = '[') then
          Continue;
        S := NormalizeCookieDomain(S);
        if S <> '' then FKept.Add(S);   // dupIgnore — no dupes to check
      end;
    finally
      SL.Free;
    end;
  finally
    D.Free;
  end;
  SaveKeepList;
  RefreshLists;
end;

procedure TCookieForm.BtnExportClick(Sender: TObject);
var
  D: TSaveDialog;
begin
  if FKept.Count = 0 then Exit;
  D := TSaveDialog.Create(Self);
  try
    D.FileName := 'cookies.txt';
    D.Filter := Lg('Текстовые файлы|*.txt', 'Тэкставыя файлы|*.txt',
                   'Текстові файли|*.txt', 'Text files|*.txt');
    D.DefaultExt := '.txt';
    if not D.Execute then Exit;
    try
      FKept.SaveToFile(D.FileName);
    except
      on E: Exception do
        lblStatus.Caption := E.Message;
    end;
  finally
    D.Free;
  end;
end;

procedure TCookieForm.BtnRefreshClick(Sender: TObject);
begin
  Rescan;
end;

procedure TCookieForm.SearchChange(Sender: TObject);
begin
  RefreshLists;
end;

procedure TCookieForm.ListDblClick(Sender: TObject);
begin
  // double-click moves a row across, like upstream's DoubleTapped
  if Sender = lbAvail then BtnKeepClick(Sender)
  else BtnRemoveClick(Sender);
end;

procedure TCookieForm.FormCreate(Sender: TObject);
begin
  Caption := Lg('Менеджер кук', 'Менеджар кук', 'Менеджер кук',
                'Cookie manager');
  lblAvail.Caption := Lg('Найденные домены', 'Знойдзеныя дамены',
                         'Знайдені домени', 'Found domains');
  lblKept.Caption := Lg('Сохраняемые', 'Захоўваныя', 'Зберігаються',
                        'Kept');
  btnKeep.Caption := Lg('Оставить →', 'Пакінуць →', 'Залишити →',
                        'Keep →');
  btnDelete.Caption := Lg('Удалить из браузеров', 'Выдаліць з браўзераў',
                          'Видалити з браузерів', 'Delete from browsers');
  btnRemove.Caption := Lg('← Убрать', '← Прыбраць', '← Прибрати',
                          '← Remove');
  btnImport.Caption := Lg('Импорт…', 'Імпарт…', 'Імпорт…', 'Import…');
  btnExport.Caption := Lg('Экспорт…', 'Экспарт…', 'Експорт…', 'Export…');
  btnRefresh.Caption := Lg('Обновить', 'Абнавіць', 'Оновити', 'Refresh');
  btnClose.Caption := Lg('Закрыть', 'Закрыць', 'Закрити', 'Close');
  FDetected := TStringList.Create;
  FDetected.Sorted := True;
  FDetected.Duplicates := dupIgnore;
  FKept := TStringList.Create;
  FKept.Sorted := True;
  FKept.Duplicates := dupIgnore;
  FKept.CaseSensitive := False;
  LoadKeepList;
  Rescan;
end;

procedure TCookieForm.FormDestroy(Sender: TObject);
begin
  FDetected.Free;
  FKept.Free;
end;

end.
