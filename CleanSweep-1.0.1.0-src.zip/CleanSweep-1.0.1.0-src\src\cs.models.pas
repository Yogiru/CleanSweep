unit cs.models;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, fgl;

type
  TRegistrySource = (rsHKLM, rsHKLM_WOW64, rsHKCU, rsHKU, rsPortable);

  TScanMode = (smSafe, smModerate, smAdvanced);

  TLeftoverType = (ltRegistryKey, ltRegistryValue, ltFile, ltFolder,
    ltService, ltScheduledTask);

  TLeftoverConfidence = (lcSafe, lcModerate, lcRisky, lcInfo);

  TUninstallOutcome = (uoPreview, uoCompleted, uoSkipped, uoFailed,
    uoUnsupported, uoCancelled);

  { Installed program record — port of DeepPurge.Core.Models.InstalledProgram,
    trimmed to fields the engine actually uses. }
  TInstalledProgram = class
  public
    RegistryKeyName: string;
    RegistryPath: string;      // full path with hive prefix, e.g. HKLM\SOFTWARE\...\Uninstall\X
    DisplayName: string;
    DisplayVersion: string;
    Publisher: string;
    InstallLocation: string;
    InstallDate: string;
    UninstallString: string;
    QuietUninstallString: string;
    DisplayIconPath: string;
    EstimatedSizeKB: Int64;
    IsWindowsInstaller: Boolean;
    IsSystem: Boolean;         // registry SystemComponent=1
    ParentKeyName: string;     // non-empty = Windows component/update child
    Source: TRegistrySource;
    function HasUninstaller: Boolean;
    function SourceDisplay: string;
    function SizeDisplay: string;
  end;

  TProgramList = specialize TFPGObjectList<TInstalledProgram>;

  TLeftoverItem = class
  public
    Path: string;              // filesystem path or registry path (HKLM\..., HKCU\...)
    DisplayPath: string;
    KeyPath: string;           // ltRegistryValue only: real parent key
                               // (value names may contain backslashes)
    ItemType: TLeftoverType;
    Confidence: TLeftoverConfidence;
    SizeBytes: Int64;
    Details: string;
    IsSelected: Boolean;
    function SizeDisplay: string;
  end;

  TLeftoverList = specialize TFPGObjectList<TLeftoverItem>;

  TScanResult = class
  public
    RegistryLeftovers: TLeftoverList;
    FileLeftovers: TLeftoverList;
    Mode: TScanMode;
    constructor Create;
    destructor Destroy; override;
  end;

  TUninstallResult = class
  public
    Success: Boolean;
    Outcome: TUninstallOutcome;
    ExitCode: Integer;
    Output: string;
    ErrorOutput: string;
    UninstallerSkipped: Boolean;
    Scan: TScanResult;
    destructor Destroy; override;
  end;

function FormatBytes(ABytes: Int64): string;
function CompareProgramsByName(const A, B: TInstalledProgram): Integer;

implementation

function CompareProgramsByName(const A, B: TInstalledProgram): Integer;
begin
  Result := CompareText(A.DisplayName, B.DisplayName);
end;

function FormatBytes(ABytes: Int64): string;
begin
  if ABytes <= 0 then Exit('');
  if ABytes < 1024 then Exit(IntToStr(ABytes) + ' B');
  if ABytes < 1024 * 1024 then
    Exit(FormatFloat('0.0', ABytes / 1024) + ' KB');
  if ABytes < Int64(1024) * 1024 * 1024 then
    Exit(FormatFloat('0.0', ABytes / 1048576) + ' MB');
  Result := FormatFloat('0.00', ABytes / 1073741824) + ' GB';
end;

{ TInstalledProgram }

function TInstalledProgram.HasUninstaller: Boolean;
begin
  Result := UninstallString <> '';
end;

function TInstalledProgram.SourceDisplay: string;
begin
  case Source of
    rsHKLM:       Result := 'System';
    rsHKLM_WOW64: Result := '32-bit';
    rsHKCU:       Result := 'User';
    rsHKU:        Result := 'User';
    rsPortable:   Result := 'Portable';
  else
    Result := '';
  end;
end;

function TInstalledProgram.SizeDisplay: string;
begin
  if EstimatedSizeKB <= 0 then Exit('');
  Result := FormatBytes(EstimatedSizeKB * 1024);
end;

{ TLeftoverItem }

function TLeftoverItem.SizeDisplay: string;
begin
  Result := FormatBytes(SizeBytes);
end;

{ TScanResult }

constructor TScanResult.Create;
begin
  RegistryLeftovers := TLeftoverList.Create(True);
  FileLeftovers := TLeftoverList.Create(True);
end;

destructor TScanResult.Destroy;
begin
  RegistryLeftovers.Free;
  FileLeftovers.Free;
  inherited;
end;

{ TUninstallResult }

destructor TUninstallResult.Destroy;
begin
  Scan.Free;
  inherited;
end;

end.
