@echo off
set FPCBIN=C:\lazarus\fpc\3.2.2\bin\i386-win32
set LAZBUILD=C:\lazarus\lazbuild.exe

"%FPCBIN%\windres.exe" --preprocessor=cat -i CleanSweep.rc -o CleanSweep.res
if errorlevel 1 exit /b 1

if not exist lib mkdir lib
rem --build-all: FPC does not track .lfm as a dependency, an
rem incremental build would keep embedding the stale lib\*.lfm copy.
"%LAZBUILD%" --build-all CleanSweep.lpi
if errorlevel 1 exit /b 1

echo Built CleanSweep.exe
