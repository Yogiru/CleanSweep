unit appxform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls, Dialogs, ComCtrls,
  Windows,
  cs.appx, cs.utils, cs.lang;

type
  { Modal AppX debloat dialog — port of upstream's Winappx flow.
    Only entries of Winappx.ini that are actually installed are shown
    (PowerShell Get-AppxPackage); checked entries are removed via
    Remove-AppxPackage after a confirmation. }
  TAppxForm = class(TForm)
    lvPkgs: TListView;
    lblStatus: TLabel;
    lblHint: TLabel;
    btnRemove: TButton;
    btnRescan: TButton;
    btnAll: TButton;
    btnClose: TButton;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure BtnRemoveClick(Sender: TObject);
    procedure BtnRescanClick(Sender: TObject);
    procedure BtnAllClick(Sender: TObject);
    procedure LvPkgsItemChecked(Sender: TObject; AItem: TListItem);
  private
    FEntries: TAppxEntryList;
    procedure Refresh;
    function CheckedEntries: TAppxEntryList;
  end;

function ShowAppxDialog(AOwner: TComponent): TModalResult;

implementation

{$R *.lfm}

{ File copy wins, embedded WINAPPX resource is the fallback —
  same resolution order as the winapp2 databases. }
function LoadAppxText: string;
var
  Path, ExeDir: string;
  RS: TResourceStream;
  SS: TStringStream;
  Raw: RawByteString;
begin
  ExeDir := ExtractFilePath(ParamStr(0));
  Path := ExeDir + 'data\Winappx.ini';
  if not FileExists(Path) then Path := ExeDir + 'Winappx.ini';
  if FileExists(Path) then Exit(LoadTextFile(Path));

  Result := '';
  if FindResource(HInstance, 'WINAPPX', Windows.RT_RCDATA) = 0 then Exit;
  RS := TResourceStream.Create(HInstance, 'WINAPPX', Windows.RT_RCDATA);
  try
    SS := TStringStream.Create('');
    try
      SS.CopyFrom(RS, RS.Size);
      Raw := SS.DataString;
    finally
      SS.Free;
    end;
  finally
    RS.Free;
  end;
  Result := UTF8Encode(UTF8Decode(Raw));   // RCDATA is UTF-8
end;

function ShowAppxDialog(AOwner: TComponent): TModalResult;
var
  F: TAppxForm;
begin
  F := TAppxForm.Create(AOwner);
  try
    Result := F.ShowModal;
  finally
    F.Free;
  end;
end;

procedure TAppxForm.FormCreate(Sender: TObject);
begin
  Caption := Lg('Удаление AppX-приложений', 'Выдаленне AppX-праграм',
                'Видалення AppX-застосунків', 'Remove AppX apps');
  lvPkgs.Columns[0].Caption := Lg('Запись', 'Запіс', 'Запис', 'Entry');
  lvPkgs.Columns[1].Caption := Lg('Пакет', 'Пакет', 'Пакет', 'Package');
  lblHint.Caption := Lg(
    'Установленные AppX-приложения из списка Winappx.ini.',
    'Усталяваныя AppX-праграмы са спісу Winappx.ini.',
    'Встановлені AppX-застосунки зі списку Winappx.ini.',
    'Installed AppX apps matching the Winappx.ini list.');
  btnRemove.Caption := Lg('Удалить отмеченные', 'Выдаліць адзначаныя',
                          'Видалити позначені', 'Remove checked');
  btnRescan.Caption := Lg('Обновить', 'Абнавіць', 'Оновити', 'Refresh');
  btnAll.Caption := Lg('Отметить всё', 'Адзначыць усё', 'Відзначити все',
    'Select all');
  btnClose.Caption := Lg('Закрыть', 'Закрыць', 'Закрити', 'Close');

  FEntries := ParseAppxDatabase(LoadAppxText);
  if FEntries.Count = 0 then
    lblStatus.Caption := Lg('Winappx.ini не найдена.',
                            'Winappx.ini не знойдзена.',
                            'Winappx.ini не знайдена.',
                            'Winappx.ini not found.')
  else
    Refresh;
end;

procedure TAppxForm.FormDestroy(Sender: TObject);
begin
  FEntries.Free;
end;

{ Queries installed package names, flags the database entries and
  fills the list with the installed subset only — rows that cannot be
  removed anyway are not shown at all. }
procedure TAppxForm.Refresh;
var
  Names: TStringList;
  Err: string;
  It: TListItem;
  E: TAppxEntry;
  Found: Integer;
  C: TCursor;
begin
  C := Screen.Cursor;
  Screen.Cursor := crHourGlass;
  lblStatus.Caption := Lg('Запрос установленных пакетов…',
                          'Запыт усталяваных пакетаў…',
                          'Запит встановлених пакетів…',
                          'Querying installed packages…');
  lblStatus.Update;
  try
    Names := AppxInstalledNames(Err);
    try
      if (Names.Count = 0) and (Err <> '') then
      begin
        lblStatus.Caption := Err;
        Exit;
      end;
      AppxScanInstalled(FEntries, Names);
    finally
      Names.Free;
    end;
  finally
    Screen.Cursor := C;
  end;
  lvPkgs.Items.BeginUpdate;
  try
    lvPkgs.Items.Clear;
    Found := 0;
    for E in FEntries do
      if E.Installed then
      begin
        Inc(Found);
        It := lvPkgs.Items.Add;
        It.Caption := E.Name;
        if E.Warning <> '' then It.Caption := It.Caption + ' (!)';
        It.SubItems.Add(E.PackageName);
        It.Data := E;
        // nothing pre-checked: removing a Store app is a deliberate act
        It.Checked := False;
      end;
  finally
    lvPkgs.Items.EndUpdate;
  end;
  btnRemove.Enabled := False;
  lblStatus.Caption := Format(Lg(
    'Установлено из списка: %d из %d',
    'Усталявана са спісу: %d з %d',
    'Встановлено зі списку: %d з %d',
    'Installed from list: %d of %d'), [Found, FEntries.Count]);
end;

function TAppxForm.CheckedEntries: TAppxEntryList;
var
  I: Integer;
begin
  Result := TAppxEntryList.Create(False);   // references, not owned
  for I := 0 to lvPkgs.Items.Count - 1 do
    if lvPkgs.Items[I].Checked then
      Result.Add(TAppxEntry(lvPkgs.Items[I].Data));
end;

procedure TAppxForm.LvPkgsItemChecked(Sender: TObject; AItem: TListItem);
var
  I: Integer;
begin
  btnRemove.Enabled := False;
  for I := 0 to lvPkgs.Items.Count - 1 do
    if lvPkgs.Items[I].Checked then
    begin
      btnRemove.Enabled := True;
      Exit;
    end;
end;

procedure TAppxForm.BtnRemoveClick(Sender: TObject);
var
  Sel: TAppxEntryList;
  E: TAppxEntry;
  Warn, Err: string;
  Ok, Fail: Integer;
  C: TCursor;
begin
  Sel := CheckedEntries;
  if Sel.Count = 0 then
  begin
    Sel.Free;
    Exit;
  end;
  // surface the database warnings once, before any removal
  Warn := '';
  for E in Sel do
    if E.Warning <> '' then
      Warn := Warn + E.Name + ': ' + E.Warning + sLineBreak;
  if Warn <> '' then
    Warn := sLineBreak + sLineBreak + Warn;
  if MessageDlg(Format(Lg(
      'Удалить %d AppX-приложений для текущего пользователя?%s',
      'Выдаліць %d AppX-праграм для бягучага карыстальніка?%s',
      'Видалити %d AppX-застосунків для поточного користувача?%s',
      'Remove %d AppX apps for the current user?%s'),
      [Sel.Count, Warn]),
      mtConfirmation, [mbYes, mbNo], 0) <> mrYes then
  begin
    Sel.Free;
    Exit;
  end;

  Ok := 0; Fail := 0;
  C := Screen.Cursor;
  Screen.Cursor := crHourGlass;
  try
    for E in Sel do
    begin
      lblStatus.Caption := E.Name;
      lblStatus.Update;
      if AppxRemove(E.PackageName, Err) then
      begin
        Inc(Ok);
        E.Installed := False;
      end
      else
        Inc(Fail);
    end;
  finally
    Screen.Cursor := C;
    Sel.Free;
  end;
  Refresh;
  if Fail = 0 then
    lblStatus.Caption := Format(Lg('Удалено: %d', 'Выдалена: %d',
      'Видалено: %d', 'Removed: %d'), [Ok])
  else
    lblStatus.Caption := Format(Lg(
      'Удалено: %d, ошибок: %d (%s)',
      'Выдалена: %d, памылак: %d (%s)',
      'Видалено: %d, помилок: %d (%s)',
      'Removed: %d, failed: %d (%s)'), [Ok, Fail, Err]);
end;

procedure TAppxForm.BtnRescanClick(Sender: TObject);
begin
  Refresh;
end;

{ Toggle-all: checks every row; if all are checked — clears all.
  Every listed row is installed by construction. }
procedure TAppxForm.BtnAllClick(Sender: TObject);
var
  I, Checked: Integer;
  Check: Boolean;
begin
  Checked := 0;
  for I := 0 to lvPkgs.Items.Count - 1 do
    if lvPkgs.Items[I].Checked then Inc(Checked);
  Check := Checked < lvPkgs.Items.Count;
  lvPkgs.Items.BeginUpdate;
  try
    for I := 0 to lvPkgs.Items.Count - 1 do
      lvPkgs.Items[I].Checked := Check;
  finally
    lvPkgs.Items.EndUpdate;
  end;
  // programmatic Checked does NOT fire OnItemChecked (Win32 ws) —
  // update the button ourselves
  btnRemove.Enabled := Check and (lvPkgs.Items.Count > 0);
end;

end.
