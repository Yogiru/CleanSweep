unit cs.appx;

{$mode objfpc}{$H+}

{ AppX/MSIX debloat — port of upstream AppxService. Standalone: no
  dependency on the winapp2 engine. Entries come from Winappx.ini
  ([Name] + PackageName= + optional Warning=); installed-state and
  removal are delegated to PowerShell's Get-AppxPackage /
  Remove-AppxPackage, same as upstream. }

interface

uses
  Classes, SysUtils, fgl;

type
  TAppxEntry = class
    Name: string;          // ini section, trailing ' *' stripped
    PackageName: string;   // substring matched against package Names
    Warning: string;
    Installed: Boolean;    // runtime: present on this machine
  end;

  TAppxEntryList = specialize TFPGObjectList<TAppxEntry>;

{ Parses Winappx.ini content into entries (both name and PackageName
  required; comment ';' lines skipped). }
function ParseAppxDatabase(const AContent: string): TAppxEntryList;

{ Package Names installed for the current user — PowerShell
  '(Get-AppxPackage).Name'. Empty list on failure (AErr carries the
  reason); callers treat that as 'nothing installed'. }
function AppxInstalledNames(out AErr: string): TStringList;

{ Flags AEntries[i].Installed against AInstalled (case-insensitive
  substring match on the package Name, upstream 'Contains'). }
procedure AppxScanInstalled(const AEntries: TAppxEntryList;
  const AInstalled: TStrings);

{ Removes every package whose Name contains APackageName:
  Get-AppxPackage -Name '*<pkg>*' | Remove-AppxPackage.
  True on PowerShell exit code 0. }
function AppxRemove(const APackageName: string; out AErr: string): Boolean;

implementation

uses
  process, pipes;

{ Runs powershell.exe hidden; returns its exit code, stdout in AOut
  (raw ANSI bytes — package Names are ASCII).
  The pipes are drained WHILE the process runs: reading only after
  poWaitOnExit deadlocks once the child fills the ~4KB pipe buffer
  (Get-AppxPackage emits hundreds of names). A timeout kills a stuck
  PowerShell instead of hanging the UI forever. }
function RunPs(const ACommand: string; out AOut: string): Integer;
const
  TIMEOUT_MS = 120000;
var
  P: TProcess;
  Buf: array[0..8191] of Byte;
  S: RawByteString;
  Waited: DWORD;

  { Stderr must also be drained (it has its own pipe that can fill
    and block the child), but its text is NOT appended to AOut —
    error lines would pollute the parsed package-name list. }
  procedure Drain(const AStream: TInputPipeStream; const AAppend: Boolean);
  var
    Av, M: Integer;
  begin
    while AStream <> nil do
    begin
      Av := AStream.NumBytesAvailable;
      if Av <= 0 then Break;
      if Av > SizeOf(Buf) then Av := SizeOf(Buf);
      M := AStream.Read(Buf[0], Av);
      if M <= 0 then Break;
      if AAppend then
      begin
        SetString(S, PAnsiChar(@Buf[0]), M);
        AOut := AOut + string(S);
      end;
    end;
  end;

begin
  AOut := '';
  P := TProcess.Create(nil);
  try
    P.Executable := 'powershell.exe';
    P.Parameters.Add('-NoProfile');
    P.Parameters.Add('-ExecutionPolicy');
    P.Parameters.Add('Bypass');
    P.Parameters.Add('-Command');
    P.Parameters.Add(ACommand);
    P.Options := [poUsePipes, poNoConsole];
    try
      P.Execute;
    except
      on E: Exception do Exit(-1);
    end;
    Waited := 0;
    while P.Running do
    begin
      Drain(P.Output, True);
      Drain(P.Stderr, False);
      Sleep(20);
      Inc(Waited, 20);
      if Waited >= TIMEOUT_MS then
      begin
        P.Terminate(1);
        Exit(-2);
      end;
    end;
    Drain(P.Output, True);   // what arrived between last poll and exit
    Result := P.ExitCode;
  finally
    P.Free;
  end;
end;

function ParseAppxDatabase(const AContent: string): TAppxEntryList;
var
  Lines: TStringList;
  I, P: Integer;
  Line, Key, Value: string;
  E: TAppxEntry;
  Pending: Boolean;

  procedure Flush;
  begin
    if Pending and (E.Name <> '') and (E.PackageName <> '') then
      Result.Add(E)
    else
      E.Free;
    E := nil;
    Pending := False;
  end;

begin
  Result := TAppxEntryList.Create(True);
  Lines := TStringList.Create;
  E := nil;
  Pending := False;
  try
    Lines.Text := AContent;
    for I := 0 to Lines.Count - 1 do
    begin
      Line := Trim(Lines[I]);
      if (Line = '') or (Line[1] = ';') then Continue;
      if (Line[1] = '[') and (Line[Length(Line)] = ']') then
      begin
        Flush;
        E := TAppxEntry.Create;
        Pending := True;
        // winapp2-style names can carry a trailing ' *' — strip it
        Line := Copy(Line, 2, Length(Line) - 2);
        while (Line <> '') and ((Line[Length(Line)] = '*') or
               (Line[Length(Line)] = ' ')) do
          Delete(Line, Length(Line), 1);
        E.Name := Trim(Line);
        Continue;
      end;
      if E = nil then Continue;
      P := Pos('=', Line);
      if P = 0 then Continue;
      Key := Copy(Line, 1, P - 1);
      Value := Trim(Copy(Line, P + 1, MaxInt));
      if SameText(Key, 'PackageName') then E.PackageName := Value
      else if SameText(Key, 'Warning') then E.Warning := Value;
    end;
    Flush;
  finally
    Lines.Free;
    if E <> nil then E.Free;
  end;
end;

function AppxInstalledNames(out AErr: string): TStringList;
var
  Outp: string;
  SL: TStringList;
  I: Integer;
  S: string;
begin
  AErr := '';
  Result := TStringList.Create;
  Result.CaseSensitive := False;
  Result.Duplicates := dupIgnore;
  Result.Sorted := True;
  if RunPs('(Get-AppxPackage).Name', Outp) <> 0 then
  begin
    if Outp = '' then AErr := 'powershell.exe failed';
    Exit;
  end;
  SL := TStringList.Create;
  try
    SL.Text := Outp;
    for I := 0 to SL.Count - 1 do
    begin
      S := Trim(SL[I]);
      if S <> '' then Result.Add(S);
    end;
  finally
    SL.Free;
  end;
end;

procedure AppxScanInstalled(const AEntries: TAppxEntryList;
  const AInstalled: TStrings);
var
  E: TAppxEntry;
  I: Integer;
  Pkg: string;
begin
  for E in AEntries do
  begin
    E.Installed := False;
    Pkg := LowerCase(E.PackageName);
    if Pkg = '' then Continue;
    for I := 0 to AInstalled.Count - 1 do
      if Pos(Pkg, LowerCase(AInstalled[I])) > 0 then
      begin
        E.Installed := True;
        Break;
      end;
  end;
end;

function AppxRemove(const APackageName: string; out AErr: string): Boolean;
var
  Outp: string;
  Code: Integer;
begin
  Outp := '';
  // escape ' → '' so an ini-crafted PackageName can't break out of the
  // quoted PowerShell string
  Code := RunPs('Get-AppxPackage -Name ''*' +
    StringReplace(APackageName, '''', '''''', [rfReplaceAll]) +
    '*'' | Remove-AppxPackage', Outp);
  Result := Code = 0;
  if not Result then
    AErr := 'exit code ' + IntToStr(Code)
  else
    AErr := '';
end;

end.
