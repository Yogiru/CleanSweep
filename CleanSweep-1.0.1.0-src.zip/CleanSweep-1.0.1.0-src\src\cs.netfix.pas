unit cs.netfix;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils;

{ Network maintenance toolkit — the classic "network doesn't work" set:
  caches flush (DNS/NetBIOS/ARP/BranchCache), Winsock & TCP/IP stack
  reset, route table flush, DHCP release/renew, adapter restart.
  Every op is a console-tool invocation; heavy ones carry flags so the
  UI can warn about a reboot need or a connectivity drop. }

type
  { nfAdmin — the tool needs elevation (netsh/route/net-adapter ops);
    informational: the app already runs with requireAdministrator. }
  TNetOpFlag = (nfReboot, nfDropsLink, nfAdmin);
  TNetOpFlags = set of TNetOpFlag;

const
  NETOP_COUNT = 11;

  { Op ids — indices into the functions below; order is fixed and the
    form relies on it for localized captions. }
  NETOP_DNS        = 0;
  NETOP_NETBIOS    = 1;
  NETOP_ARP        = 2;
  NETOP_BRANCH     = 3;
  NETOP_WINHTTP    = 4;
  NETOP_TCPGLOBAL  = 5;
  NETOP_WINSOCK    = 6;
  NETOP_TCPIP      = 7;
  NETOP_ROUTES     = 8;
  NETOP_RENEW      = 9;
  NETOP_ADAPTERS   = 10;

{ English op key — the form maps it to a localized caption via Lg. }
function NetOpKey(const AIndex: Integer): string;
function NetOpFlags(const AIndex: Integer): TNetOpFlags;
{ Command lines for the op (one op may run several tools in order). }
procedure NetOpCommands(const AIndex: Integer; const AOut: TStrings);

{ Runs one command line through cmd.exe hidden, drains stdout+stderr,
  converts OEM output to UTF-8. Returns the exit code, -1 on launch
  failure, -2 on timeout. }
function RunNetCommand(const ACmdLine: string; out AOut: string): Integer;

implementation

uses
  Windows, process, pipes;

function NetOpKey(const AIndex: Integer): string;
const
  Keys: array[0..NETOP_COUNT - 1] of string = (
    'Flush DNS cache',
    'Flush NetBIOS cache',
    'Flush ARP cache',
    'Flush BranchCache',
    'Reset WinHTTP proxy',
    'Reset TCP global settings',
    'Reset Winsock catalog',
    'Reset TCP/IP stack',
    'Flush routing table',
    'Renew IP configuration',
    'Restart network adapters');
begin
  if (AIndex < 0) or (AIndex >= NETOP_COUNT) then Exit('');
  Result := Keys[AIndex];
end;

function NetOpFlags(const AIndex: Integer): TNetOpFlags;
const
  Flags: array[0..NETOP_COUNT - 1] of TNetOpFlags = (
    [],                       // DNS flush
    [],                       // NetBIOS
    [nfAdmin],                // ARP
    [nfAdmin],                // BranchCache
    [nfAdmin],                // WinHTTP proxy
    [nfAdmin],                // TCP globals
    [nfReboot, nfAdmin],      // Winsock reset
    [nfReboot, nfAdmin],      // TCP/IP reset
    [nfDropsLink, nfAdmin],   // route -f
    [nfDropsLink, nfAdmin],   // release/renew
    [nfDropsLink, nfAdmin]);  // adapter restart
begin
  if (AIndex < 0) or (AIndex >= NETOP_COUNT) then Exit([]);
  Result := Flags[AIndex];
end;

{ Full path to a System32 console tool. This is a 32-bit exe, so a bare
  tool name (or cmd's PATH search) lands in SysWOW64 — nbtstat.exe and
  some others aren't shipped there on every Windows build. Going through
  the Sysnative alias reaches the real 64-bit System32 instead. }
function SysToolExe(const AName: string): string;
var
  Wow: BOOL;
  WinDir: string;
begin
  WinDir := SysUtils.GetEnvironmentVariable('windir');
  if WinDir = '' then WinDir := 'C:\Windows';
  Wow := False;
  IsWow64Process(GetCurrentProcess, @Wow);
  if Wow then
    Result := WinDir + '\Sysnative\' + AName
  else
    Result := WinDir + '\System32\' + AName;
end;

procedure NetOpCommands(const AIndex: Integer; const AOut: TStrings);
begin
  case AIndex of
    NETOP_DNS:
      AOut.Add(SysToolExe('ipconfig.exe') + ' /flushdns');
    NETOP_NETBIOS:
      begin
        AOut.Add(SysToolExe('nbtstat.exe') + ' -R');   // purge + reload NetBIOS cache
        AOut.Add(SysToolExe('nbtstat.exe') + ' -RR');  // release + re-register WINS names
      end;
    NETOP_ARP:
      begin
        AOut.Add(SysToolExe('arp.exe') + ' -d *');
        AOut.Add(SysToolExe('netsh.exe') + ' interface ip delete arpcache');
      end;
    NETOP_BRANCH:
      AOut.Add(SysToolExe('netsh.exe') + ' branchcache flush');
    NETOP_WINHTTP:
      AOut.Add(SysToolExe('netsh.exe') + ' winhttp reset proxy');
    NETOP_TCPGLOBAL:
      AOut.Add(SysToolExe('netsh.exe') + ' int tcp reset');
    NETOP_WINSOCK:
      AOut.Add(SysToolExe('netsh.exe') + ' winsock reset');
    NETOP_TCPIP:
      begin
        AOut.Add(SysToolExe('netsh.exe') + ' int ip reset');
        AOut.Add(SysToolExe('netsh.exe') + ' int ipv6 reset');
      end;
    NETOP_ROUTES:
      AOut.Add(SysToolExe('route.exe') + ' -f');
    NETOP_RENEW:
      begin
        AOut.Add(SysToolExe('ipconfig.exe') + ' /release');
        AOut.Add(SysToolExe('ipconfig.exe') + ' /renew');
      end;
    NETOP_ADAPTERS:
      AOut.Add(SysToolExe('WindowsPowerShell\v1.0\powershell.exe') +
        ' -NoProfile -Command "Get-NetAdapter | ' +
        'Restart-NetAdapter -Confirm:$false"');
  end;
end;

{ Console tools print in the OEM codepage (cp866 on RU systems) —
  decode with CP_OEMCP so the log memo shows real Cyrillic. }
function OemToUtf8(const S: RawByteString): string;
var
  W: WideString;
  N: Integer;
begin
  if S = '' then Exit('');
  N := MultiByteToWideChar(CP_OEMCP, 0, PAnsiChar(S), Length(S), nil, 0);
  SetLength(W, N);
  MultiByteToWideChar(CP_OEMCP, 0, PAnsiChar(S), Length(S), PWideChar(W), N);
  Result := UTF8Encode(W);
end;

{ Same drain-both-pipes loop as cs.appx.RunPs: a child that fills the
  ~4KB buffer blocks forever if we only read after exit. }
function RunNetCommand(const ACmdLine: string; out AOut: string): Integer;
const
  TIMEOUT_MS = 120000;
var
  P: TProcess;
  Buf: array[0..8191] of Byte;
  S: RawByteString;
  Waited: DWORD;

  procedure Drain(const AStream: TInputPipeStream);
  var
    Av, M: Integer;
  begin
    while AStream <> nil do
    begin
      Av := AStream.NumBytesAvailable;
      if Av <= 0 then Break;
      if Av > SizeOf(Buf) then Av := SizeOf(Buf);
      M := AStream.Read(Buf[0], Av);
      if M <= 0 then Break;
      SetString(S, PAnsiChar(@Buf[0]), M);
      AOut := AOut + OemToUtf8(S);
    end;
  end;

begin
  AOut := '';
  P := TProcess.Create(nil);
  try
    P.Executable := 'cmd.exe';
    P.Parameters.Add('/c');
    P.Parameters.Add(ACmdLine);
    P.Options := [poUsePipes, poNoConsole];
    try
      P.Execute;
    except
      on E: Exception do Exit(-1);
    end;
    Waited := 0;
    while P.Running do
    begin
      Drain(P.Output);
      Drain(P.Stderr);
      Sleep(20);
      Inc(Waited, 20);
      if Waited >= TIMEOUT_MS then
      begin
        P.Terminate(1);
        Exit(-2);
      end;
    end;
    Drain(P.Output);
    Drain(P.Stderr);
    Result := P.ExitCode;
  finally
    P.Free;
  end;
end;

end.
