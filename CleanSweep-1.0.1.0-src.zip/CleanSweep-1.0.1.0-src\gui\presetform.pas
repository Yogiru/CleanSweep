unit presetform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls, IniFiles,
  cs.winapp2, cs.lang;

type
  { Modal 'Presets' dialog: two independent axes of checkboxes
    (purpose × safety). Both axes default to fully checked; the target
    set is the union of the checked boxes inside one axis intersected
    across the axes. Quick buttons reproduce the old dropdown presets.
    The last applied combo is remembered in CleanSweep.ini so the next
    session opens on the same selection instead of the all-checked .lfm
    layout; a fresh install opens on 'Recommended'. }
  TPresetForm = class(TForm)
    gpPurpose: TGroupBox;
    gpSafety: TGroupBox;
    cbP0: TCheckBox;
    cbP1: TCheckBox;
    cbP2: TCheckBox;
    cbP3: TCheckBox;
    cbP4: TCheckBox;
    cbP5: TCheckBox;
    cbP6: TCheckBox;
    cbP7: TCheckBox;
    cbP8: TCheckBox;
    cbS0: TCheckBox;
    cbS1: TCheckBox;
    cbS2: TCheckBox;
    cbOnlyInstalled: TCheckBox;
    lblCount: TLabel;
    btnRecommended: TButton;
    btnInstalled: TButton;
    btnAll: TButton;
    btnNone: TButton;
    btnApply: TButton;
    btnCancel: TButton;
    procedure CheckStateChange(Sender: TObject);
    procedure BtnRecommendedClick(Sender: TObject);
    procedure BtnInstalledClick(Sender: TObject);
    procedure BtnAllClick(Sender: TObject);
    procedure BtnNoneClick(Sender: TObject);
    procedure BtnApplyClick(Sender: TObject);
  private
    FEntries: TCleanerEntryList;
    FPurpose: array[0..8] of TCheckBox;   // parallel to PresetPurposeKeys
    FSafety: array[0..2] of TCheckBox;    // parallel to TSafetyLevel
    procedure BindCheckboxes;
    procedure RefreshCount;
    procedure QuickConfig(APurposeAll, ASafetyAll, AOnlySafe,
      AOnlyInstalled: Boolean);
    procedure LoadState;
    procedure SaveState;
  public
    constructor CreateDlg(AOwner: TComponent; AEntries: TCleanerEntryList);
    { True when the checkbox combo picks AEntry (union inside an axis,
      intersection across the axes). }
    function CheckedFor(const E: TCleanerEntry): Boolean;
  end;

implementation

{$R *.lfm}

{ Purpose checkbox captions, one per PresetPurposeKeys entry. }
function PurposeLabel(AIndex: Integer): string;
begin
  case AIndex of
    0: Result := 'Windows';
    1: Result := Lg('Браузеры', 'Браўзэры', 'Браузери', 'Browsers');
    2: Result := Lg('Мультимедиа', 'Мультымедыя', 'Мультимедіа', 'Multimedia');
    3: Result := Lg('Игры', 'Гульні', 'Ігри', 'Games');
    4: Result := Lg('Утилиты', 'Утыліты', 'Утиліти', 'Utilities');
    5: Result := Lg('Приложения', 'Прыкладанні', 'Застосунки', 'Applications');
    6: Result := Lg('Мессенджеры и почта', 'Месэнджары і пошта',
                    'Месенджери та пошта', 'Messaging & mail');
    7: Result := Lg('Языки', 'Мовы', 'Мови', 'Languages');
    8: Result := Lg('Прочее', 'Іншае', 'Інше', 'Other');
  else
    Result := '';
  end;
end;

function SafetyLabel(AIndex: Integer): string;
begin
  case TSafetyLevel(AIndex) of
    slSafe:    Result := Lg('Безопасно', 'Бяспечна', 'Безпечно', 'Safe');
    slCaution: Result := Lg('Осторожно', 'Асцярожна', 'Обережно', 'Caution');
  else
    Result := Lg('Рискованно', 'Рызыкоўна', 'Ризиковано', 'Risky');
  end;
end;

procedure TPresetForm.BindCheckboxes;
var
  I: Integer;
begin
  FPurpose[0] := cbP0; FPurpose[1] := cbP1; FPurpose[2] := cbP2;
  FPurpose[3] := cbP3; FPurpose[4] := cbP4; FPurpose[5] := cbP5;
  FPurpose[6] := cbP6; FPurpose[7] := cbP7; FPurpose[8] := cbP8;
  FSafety[0] := cbS0; FSafety[1] := cbS1; FSafety[2] := cbS2;
  for I := 0 to High(FPurpose) do
    FPurpose[I].Caption := PurposeLabel(I);
  for I := 0 to High(FSafety) do
    FSafety[I].Caption := SafetyLabel(I);
  RefreshCount;
end;

{ An axis with no checked box contributes nothing — as a checkbox form
  that reads as 'nothing selected', so all depth starts fully checked. }
function TPresetForm.CheckedFor(const E: TCleanerEntry): Boolean;
var
  I: Integer;
  PurposeOk, SafetyOk: Boolean;
begin
  Result := False;
  if E = nil then Exit;
  if cbOnlyInstalled.Checked and (not E.Detected) then Exit;
  PurposeOk := False;
  for I := 0 to High(FPurpose) do
    if FPurpose[I].Checked and (PresetPurposeOf(E) = PresetPurposeKeys[I]) then
    begin
      PurposeOk := True;
      Break;
    end;
  if not PurposeOk then Exit;
  SafetyOk := False;
  for I := 0 to High(FSafety) do
    if FSafety[I].Checked and (PresetSafetyOf(E) = TSafetyLevel(I)) then
    begin
      SafetyOk := True;
      Break;
    end;
  Result := PurposeOk and SafetyOk;
end;

procedure TPresetForm.RefreshCount;
var
  I, N: Integer;
begin
  N := 0;
  for I := 0 to FEntries.Count - 1 do
    if CheckedFor(FEntries[I]) then Inc(N);
  lblCount.Caption := Format(
    Lg('Будет отмечено: %d из %d', 'Будзе адзначана: %d з %d',
       'Буде позначено: %d з %d', 'Checked: %d of %d'),
    [N, FEntries.Count]);
end;

procedure TPresetForm.CheckStateChange(Sender: TObject);
begin
  RefreshCount;
end;

procedure TPresetForm.QuickConfig(APurposeAll, ASafetyAll, AOnlySafe,
  AOnlyInstalled: Boolean);
var
  I: Integer;
begin
  for I := 0 to High(FPurpose) do FPurpose[I].Checked := APurposeAll;
  for I := 0 to High(FSafety) do
    FSafety[I].Checked := ASafetyAll or (AOnlySafe and (I = 0));
  cbOnlyInstalled.Checked := AOnlyInstalled;
  RefreshCount;
end;

procedure TPresetForm.BtnRecommendedClick(Sender: TObject);
begin
  QuickConfig(True, False, True, True);
end;

procedure TPresetForm.BtnInstalledClick(Sender: TObject);
begin
  QuickConfig(True, True, False, True);
end;

procedure TPresetForm.BtnAllClick(Sender: TObject);
begin
  QuickConfig(True, True, False, False);
end;

procedure TPresetForm.BtnNoneClick(Sender: TObject);
begin
  QuickConfig(False, False, False, False);
end;

{ Same ini the cleaner dialog uses for its own settings. }
function PresetSettingsPath: string;
begin
  Result := ExtractFilePath(ParamStr(0)) + 'CleanSweep.ini';
end;

{ Restores the last applied combos. First run (no [Presets] section)
  opens on 'Recommended': every purpose, only the Safe safety level,
  installed-only filter. }
procedure TPresetForm.LoadState;
var
  Ini: TIniFile;
  I: Integer;
begin
  Ini := TIniFile.Create(PresetSettingsPath);
  try
    if not Ini.SectionExists('Presets') then
    begin
      QuickConfig(True, False, True, True);
      Exit;
    end;
    for I := 0 to High(FPurpose) do
      FPurpose[I].Checked := Ini.ReadBool('Presets',
        'Purpose' + IntToStr(I), True);
    for I := 0 to High(FSafety) do
      FSafety[I].Checked := Ini.ReadBool('Presets',
        'Safety' + IntToStr(I), False);
    cbOnlyInstalled.Checked := Ini.ReadBool('Presets', 'OnlyInstalled', True);
  finally
    Ini.Free;
  end;
  RefreshCount;
end;

procedure TPresetForm.SaveState;
var
  Ini: TIniFile;
  I: Integer;
begin
  Ini := TIniFile.Create(PresetSettingsPath);
  try
    for I := 0 to High(FPurpose) do
      Ini.WriteBool('Presets', 'Purpose' + IntToStr(I), FPurpose[I].Checked);
    for I := 0 to High(FSafety) do
      Ini.WriteBool('Presets', 'Safety' + IntToStr(I), FSafety[I].Checked);
    Ini.WriteBool('Presets', 'OnlyInstalled', cbOnlyInstalled.Checked);
  finally
    Ini.Free;
  end;
end;

{ Apply remembers the combo for the next session, then closes as OK. }
procedure TPresetForm.BtnApplyClick(Sender: TObject);
begin
  SaveState;
  ModalResult := mrOk;
end;

constructor TPresetForm.CreateDlg(AOwner: TComponent; AEntries: TCleanerEntryList);
begin
  inherited Create(AOwner); // loads presetform.lfm
  FEntries := AEntries;
  Caption := Lg('Пресеты', 'Прэсеты', 'Пресети', 'Presets');
  gpPurpose.Caption := Lg('По назначению', 'Па прызначэнні',
                          'За призначенням', 'By purpose');
  gpSafety.Caption := Lg('По безопасности', 'Па бяспецы',
                         'За безпекою', 'By safety');
  cbOnlyInstalled.Caption := Lg('Только установленные', 'Толькі ўсталяваныя',
                                'Тільки встановлені', 'Only installed');
  btnRecommended.Caption := Lg('Рекомендуемые', 'Рэкамендаваныя',
                               'Рекомендовані', 'Recommended');
  btnInstalled.Caption := Lg('Установленные', 'Усталяваныя',
                             'Встановлені', 'Installed');
  btnAll.Caption := Lg('Всё', 'Усё', 'Все', 'All');
  btnNone.Caption := Lg('Ничего', 'Нічога', 'Нічого', 'None');
  btnApply.Caption := Lg('Применить', 'Прымяніць', 'Застосувати', 'Apply');
  btnCancel.Caption := Lg('Отмена', 'Адмена', 'Скасувати', 'Cancel');
  BindCheckboxes;
  LoadState;   // last session's combo, or 'Recommended' on first run
end;

end.