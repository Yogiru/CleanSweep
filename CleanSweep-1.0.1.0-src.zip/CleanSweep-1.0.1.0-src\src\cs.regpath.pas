unit cs.regpath;

{$mode objfpc}{$H+}

interface

uses
  Windows, SysUtils;

{ Registry-path helpers shared by cs.detect and cs.cleaner.
  Port of FluentCleaner RegistryHelpers + the path-splitting and
  normalization pieces of DetectionService/CleaningService. }

{ Maps a hive abbreviation or full name (HKCU, HKEY_CURRENT_USER, ...) to
  its root key. Returns 0 for unknown hives. }
function HiveFromString(const SHive: string): HKEY;

{ Splits 'HKCU\Software\Foo|ValueName' into hive, subkey and value name.
  The '|' separates an optional value name (last one wins). }
procedure SplitRegPath(const APath: string;
  out AHive, ASubKey, AValue: string);

{ Splits 'HKCU\Software\Foo' into hive and subkey (no value part). }
procedure SplitHiveSubKey(const APath: string; out AHive, ASubKey: string);

{ Canonical form: uppercase abbreviated hive + '\'-separated subkey,
  e.g. 'HKEY_CURRENT_USER\Software\Foo\' -> 'HKCU\Software\Foo'. }
function NormalizeRegistryPath(const APath: string): string;

{ True when WOW64 registry redirection actually splits this path into
  two physical views — i.e. it sits under HKLM\SOFTWARE, HKCR or
  HKCU\SOFTWARE\CLASSES. For HKCU, HKLM\SYSTEM and the rest, both view
  flags open the same physical key, so a second-view probe would just
  duplicate results. }
function ViewSplitApplies(const APath: string): Boolean;

implementation

function HiveFromString(const SHive: string): HKEY;
var
  U: string;
begin
  U := UpperCase(SHive);
  if (U = 'HKCU') or (U = 'HKEY_CURRENT_USER') then
    Result := HKEY_CURRENT_USER
  else if (U = 'HKLM') or (U = 'HKEY_LOCAL_MACHINE') then
    Result := HKEY_LOCAL_MACHINE
  else if (U = 'HKU') or (U = 'HKEY_USERS') then
    Result := HKEY_USERS
  else if (U = 'HKCC') or (U = 'HKEY_CURRENT_CONFIG') then
    Result := HKEY_CURRENT_CONFIG
  else if (U = 'HKCR') or (U = 'HKEY_CLASSES_ROOT') then
    Result := HKEY_CLASSES_ROOT
  else
    Result := 0;
end;

procedure SplitRegPath(const APath: string;
  out AHive, ASubKey, AValue: string);
var
  Pipe, Slash: Integer;
  RegPart: string;
begin
  RegPart := APath;
  AValue := '';
  Pipe := LastDelimiter('|', APath);
  if Pipe > 0 then
  begin
    RegPart := Copy(APath, 1, Pipe - 1);
    AValue := Copy(APath, Pipe + 1, MaxInt);
  end;
  Slash := Pos('\', RegPart);
  if Slash > 0 then
  begin
    AHive := UpperCase(Copy(RegPart, 1, Slash - 1));
    ASubKey := Copy(RegPart, Slash + 1, MaxInt);
  end
  else
  begin
    AHive := UpperCase(RegPart);
    ASubKey := '';
  end;
end;

procedure SplitHiveSubKey(const APath: string; out AHive, ASubKey: string);
var
  Slash: Integer;
begin
  Slash := Pos('\', APath);
  if Slash > 0 then
  begin
    AHive := UpperCase(Copy(APath, 1, Slash - 1));
    ASubKey := Copy(APath, Slash + 1, MaxInt);
  end
  else
  begin
    AHive := UpperCase(APath);
    ASubKey := '';
  end;
end;

function NormalizeRegistryPath(const APath: string): string;
var
  Hive, SubKey: string;
begin
  SplitHiveSubKey(Trim(APath), Hive, SubKey);
  SubKey := Trim(SubKey);
  while (Length(SubKey) > 0) and (SubKey[Length(SubKey)] = '\') do
    SetLength(SubKey, Length(SubKey) - 1);
  while (Length(SubKey) > 0) and (SubKey[1] = '\') do
    Delete(SubKey, 1, 1);

  if Hive = 'HKEY_CURRENT_USER' then Hive := 'HKCU'
  else if Hive = 'HKEY_LOCAL_MACHINE' then Hive := 'HKLM'
  else if Hive = 'HKEY_USERS' then Hive := 'HKU'
  else if Hive = 'HKEY_CURRENT_CONFIG' then Hive := 'HKCC'
  else if Hive = 'HKEY_CLASSES_ROOT' then Hive := 'HKCR';

  if SubKey = '' then
    Result := Hive
  else
    Result := Hive + '\' + SubKey;
end;

function ViewSplitApplies(const APath: string): Boolean;
var
  N: string;
begin
  N := NormalizeRegistryPath(APath);
  Result := (Pos('HKLM\SOFTWARE\', N) = 1) or SameText(N, 'HKLM\SOFTWARE') or
            (Pos('HKCR\', N) = 1) or SameText(N, 'HKCR') or
            (Pos('HKCU\SOFTWARE\CLASSES\', N) = 1) or
            SameText(N, 'HKCU\SOFTWARE\CLASSES');
end;

end.
