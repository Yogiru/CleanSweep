unit cs.cookies;

{$mode objfpc}{$H+}

{ Browser cookie store discovery and selective cleanup — port of
  upstream CookieService.cs. Two distinct jobs:

  1) The Cookie Manager UI: ScanDomains / DeleteDomains enumerate the
     domains stored across every supported browser profile and remove
     the selected ones (a domain takes its subdomains with it).

  2) The cleaner hook: TryCleanProtectedStore is called by
     TCleaningService.Clean for every planned file. A recognized
     cookie database is never deleted wholesale — the matching rows
     are removed inside the database so a kept domain's login survives.
     Sidecar files (Cookies-journal, Device Bound Sessions, …) are
     recognized and skipped silently. }

interface

uses
  Classes, SysUtils;

type
  { Result of ScanDomains — caller owns and frees. }
  TCookieScanResult = class
    Domains: TStringList;            // sorted, unique, normalized
    StoresFound: Integer;
    StoresUnavailable: Integer;
    constructor Create;
    destructor Destroy; override;
  end;

  { What TryCleanProtectedStore decided about a planned file. }
  TCookieCleanAttempt = record
    Handled: Boolean;        // False → caller falls back to plain delete
    Succeeded: Boolean;
    CookiesRemoved: Integer;
    BytesFreed: Int64;
  end;

{ All normalized domains found across supported browser profiles. }
function CookieScanDomains: TCookieScanResult;

{ Deletes every selected domain (and its subdomains) from all stores.
  Returns the number of stores that could not be opened. }
function CookieDeleteDomains(const ADomains: TStrings): Integer;

{ Called by the cleaner for each file in a deletion plan. Handled=True
  means "do not delete this file the ordinary way" — either the cookies
  were cleaned inside the DB (Succeeded, CookiesRemoved) or the store is
  a protected sidecar / could not be opened. }
function TryCleanProtectedStore(const APath: string;
  const ADomainsToKeep: TStrings): TCookieCleanAttempt;

{ 'HTTPS://*.Example.COM/path' → 'example.com'; '' when not a domain.
  Internationalized names are converted to punycode. }
function NormalizeCookieDomain(const AValue: string): string;

implementation

uses
  Windows, fgl,
  cs.utils, cs.winsqlite;

type
  TCookieStoreKind = (ckChromium, ckFirefox);

  TCookieStore = class
    Browser: string;
    DatabasePath: string;
    Kind: TCookieStoreKind;
  end;

  TCookieStoreList = specialize TFPGObjectList<TCookieStore>;

  TNamedDir = record
    Browser: string;
    Root: string;
  end;

{ IDN → punycode (normaliz.dll, Windows Vista+). Returns 0 on failure. }
function IdnToAscii(dwFlags: DWORD; lpUnicodeCharStr: PWideChar;
  cchUnicodeChar: Integer; lpASCIICharStr: PWideChar;
  cchASCIIChar: Integer): Integer; stdcall;
  external 'normaliz.dll' name 'IdnToAscii';

{ --- Domain normalization ------------------------------------------- }

function NormalizeCookieDomain(const AValue: string): string;
var
  D: string;
  W: WideString;
  Buf: array[0..255] of WideChar;
  P, N: Integer;
begin
  Result := '';
  D := Trim(AValue);
  if D = '' then Exit;

  // keep only the host part of scheme://[user[:pass]@]host[:port]/path
  P := Pos('://', D);
  if P > 0 then D := Copy(D, P + 3, MaxInt);
  P := Pos('/', D);
  if P > 0 then D := Copy(D, 1, P - 1);
  P := LastDelimiter('@', D);
  if P > 0 then D := Copy(D, P + 1, MaxInt);
  P := Pos(':', D);
  if P > 0 then D := Copy(D, 1, P - 1);

  // upstream TrimStart('*').TrimStart('.').TrimEnd('.') — same result
  while (D <> '') and ((D[1] = '*') or (D[1] = '.')) do
    Delete(D, 1, 1);
  while (D <> '') and (D[Length(D)] = '.') do
    Delete(D, Length(D), 1);
  D := LowerCase(Trim(D));
  if D = '' then Exit;

  W := UTF8Decode(D);
  N := IdnToAscii(0, PWideChar(W), Length(W), @Buf[0], Length(Buf));
  if N <= 0 then Exit;
  Result := UTF8Encode(WideString(Copy(Buf, 0, N)));
  // upstream's IdnMapping.GetAscii rejects invalid host chars; this
  // IdnToAscii is lenient, so validate the ASCII result ourselves
  for P := 1 to Length(Result) do
    if not (Result[P] in ['a'..'z', '0'..'9', '-', '.']) then
      Exit('');
end;

{ NormalizeCookieDomain over a list: drop empties, dedup. }
function NormalizeDomains(const ADomains: TStrings): TStringList;
var
  I: Integer;
  D: string;
begin
  Result := TStringList.Create;
  Result.CaseSensitive := False;
  Result.Duplicates := dupIgnore;
  Result.Sorted := True;
  for I := 0 to ADomains.Count - 1 do
  begin
    D := NormalizeCookieDomain(ADomains[I]);
    if D <> '' then Result.Add(D);
  end;
end;

{ SQL predicate matching a domain or any subdomain of it, tolerating the
  leading '.' cookie hosts are stored with. }
function BuildDomainExpression(const AColumn: string;
  const ADomains: TStrings): WideString;
var
  Parts: TStringList;
  I: Integer;
  Esc, Col, S: string;
begin
  Parts := TStringList.Create;
  try
    Col := 'lower(ltrim(' + AColumn + ', ''.''))';
    for I := 0 to ADomains.Count - 1 do
    begin
      Esc := StringReplace(ADomains[I], '''', '''''', [rfReplaceAll]);
      Parts.Add(Col + ' = ''' + Esc + '''');
      Parts.Add(Col + ' LIKE ''%.' + Esc + '''');
    end;
    // join explicitly — Parts.Text leaves a trailing line break, which
    // became a dangling ' OR ' and broke the SQL every single time
    S := '';
    for I := 0 to Parts.Count - 1 do
    begin
      if I > 0 then S := S + ' OR ';
      S := S + Parts[I];
    end;
    Result := UTF8Decode(S);
  finally
    Parts.Free;
  end;
end;

{ --- Store discovery ------------------------------------------------- }

procedure AddStore(AStores: TCookieStoreList; ASeen: TStrings;
  const ABrowser, APath: string; AKind: TCookieStoreKind);
var
  Full: string;
  S: TCookieStore;
begin
  if not FileExists(APath) then Exit;
  Full := ExpandFileName(APath);
  if ASeen.IndexOf(Full) >= 0 then Exit;
  ASeen.Add(Full);
  S := TCookieStore.Create;
  S.Browser := ABrowser;
  S.DatabasePath := Full;
  S.Kind := AKind;
  AStores.Add(S);
end;

procedure AddChromiumProfile(AStores: TCookieStoreList; ASeen: TStrings;
  const ABrowser, AProfile: string);
begin
  AddStore(AStores, ASeen, ABrowser, AProfile + '\Network\Cookies', ckChromium);
  AddStore(AStores, ASeen, ABrowser, AProfile + '\Cookies', ckChromium);
end;

{ Chromium: the browser root itself is a profile (Opera) plus each
  subdirectory (Default, Profile 1, …). Firefox: one cookies.sqlite
  per profile directory. }
function DiscoverStores: TCookieStoreList;
var
  Seen: TStringList;
  Local, Roaming: string;
  Roots: array of TNamedDir;
  I, R: Integer;
  Root: TNamedDir;
  SR: TSearchRec;
begin
  Result := TCookieStoreList.Create(True);
  Seen := TStringList.Create;
  Seen.CaseSensitive := False;
  Seen.Duplicates := dupIgnore;
  Seen.Sorted := True;
  try
    Local := GetSpecialFolder(CSIDL_LOCAL_APPDATA);
    Roaming := GetSpecialFolder(CSIDL_APPDATA);
    SetLength(Roots, 16);
    Roots[0].Browser := 'Google Chrome';
    Roots[0].Root := Local + '\Google\Chrome\User Data';
    Roots[1].Browser := 'Google Chrome Beta';
    Roots[1].Root := Local + '\Google\Chrome Beta\User Data';
    Roots[2].Browser := 'Google Chrome Dev';
    Roots[2].Root := Local + '\Google\Chrome Dev\User Data';
    Roots[3].Browser := 'Google Chrome Canary';
    Roots[3].Root := Local + '\Google\Chrome SxS\User Data';
    Roots[4].Browser := 'Microsoft Edge';
    Roots[4].Root := Local + '\Microsoft\Edge\User Data';
    Roots[5].Browser := 'Microsoft Edge Beta';
    Roots[5].Root := Local + '\Microsoft\Edge Beta\User Data';
    Roots[6].Browser := 'Microsoft Edge Dev';
    Roots[6].Root := Local + '\Microsoft\Edge Dev\User Data';
    Roots[7].Browser := 'Microsoft Edge Canary';
    Roots[7].Root := Local + '\Microsoft\Edge SxS\User Data';
    Roots[8].Browser := 'Brave';
    Roots[8].Root := Local + '\BraveSoftware\Brave-Browser\User Data';
    Roots[9].Browser := 'Brave Beta';
    Roots[9].Root := Local + '\BraveSoftware\Brave-Browser-Beta\User Data';
    Roots[10].Browser := 'Brave Nightly';
    Roots[10].Root := Local + '\BraveSoftware\Brave-Browser-Nightly\User Data';
    Roots[11].Browser := 'Chromium';
    Roots[11].Root := Local + '\Chromium\User Data';
    Roots[12].Browser := 'Vivaldi';
    Roots[12].Root := Local + '\Vivaldi\User Data';
    Roots[13].Browser := 'Opera';
    Roots[13].Root := Roaming + '\Opera Software\Opera Stable';
    Roots[14].Browser := 'Opera GX';
    Roots[14].Root := Roaming + '\Opera Software\Opera GX Stable';
    Roots[15].Browser := 'Mozilla Firefox';
    Roots[15].Root := Roaming + '\Mozilla\Firefox\Profiles';

    for I := 0 to 14 do   // Chromium roots
    begin
      Root := Roots[I];
      if not DirectoryExists(Root.Root) then Continue;
      AddChromiumProfile(Result, Seen, Root.Browser, Root.Root);
      R := FindFirst(IncludeTrailingPathDelimiter(Root.Root) + '*',
        faDirectory, SR);
      try
        while R = 0 do
        begin
          if (SR.Name <> '.') and (SR.Name <> '..') and
             ((SR.Attr and faDirectory) <> 0) then
            AddChromiumProfile(Result, Seen, Root.Browser,
              Root.Root + '\' + SR.Name);
          R := FindNext(SR);
        end;
      finally
        SysUtils.FindClose(SR);
      end;
    end;

    Root := Roots[15];   // Firefox
    if DirectoryExists(Root.Root) then
    begin
      R := FindFirst(IncludeTrailingPathDelimiter(Root.Root) + '*',
        faDirectory, SR);
      try
        while R = 0 do
        begin
          if (SR.Name <> '.') and (SR.Name <> '..') and
             ((SR.Attr and faDirectory) <> 0) then
            AddStore(Result, Seen, Root.Browser,
              Root.Root + '\' + SR.Name + '\cookies.sqlite', ckFirefox);
          R := FindNext(SR);
        end;
      finally
        SysUtils.FindClose(SR);
      end;
    end;
  finally
    Seen.Free;
  end;
end;

{ Store table/column names per engine. }
procedure StoreSql(AKind: TCookieStoreKind; out AColumn, ATable: string);
begin
  if AKind = ckChromium then
  begin
    AColumn := 'host_key';
    ATable := 'cookies';
  end
  else
  begin
    AColumn := 'host';
    ATable := 'moz_cookies';
  end;
end;

{ --- Scan / delete ---------------------------------------------------- }

constructor TCookieScanResult.Create;
begin
  Domains := TStringList.Create;
end;

destructor TCookieScanResult.Destroy;
begin
  Domains.Free;
  inherited;
end;

function CookieScanDomains: TCookieScanResult;
var
  Stores: TCookieStoreList;
  Seen: TStringList;
  Store: TCookieStore;
  Db: TWinSqlite;
  Rows: TStringList;
  Col, Tbl, D: string;
  I: Integer;
begin
  Result := TCookieScanResult.Create;
  Seen := TStringList.Create;
  Seen.CaseSensitive := False;
  Seen.Duplicates := dupIgnore;
  Seen.Sorted := True;
  Stores := DiscoverStores;
  try
    Result.StoresFound := Stores.Count;
    for Store in Stores do
    begin
      Db := nil;
      Rows := nil;
      try
        StoreSql(Store.Kind, Col, Tbl);
        Db := TWinSqlite.Create(Store.DatabasePath);
        Rows := Db.QueryStrings(UTF8Decode('SELECT DISTINCT ' + Col +
          ' FROM ' + Tbl));
        for I := 0 to Rows.Count - 1 do
        begin
          D := NormalizeCookieDomain(Rows[I]);
          if D <> '' then Seen.Add(D);
        end;
      except
        Inc(Result.StoresUnavailable);
      end;
      Rows.Free;
      Db.Free;
    end;
    Result.Domains.Assign(Seen);
  finally
    Stores.Free;
    Seen.Free;
  end;
end;

{ BEGIN IMMEDIATE → DELETE → COMMIT, then best-effort checkpoint+VACUUM
  so the freed space actually leaves the file. Returns False when the
  store could not be opened/updated at all. }
function DeleteFromStore(const AStore: TCookieStore;
  const ADomains: TStrings): Boolean;
var
  Db: TWinSqlite;
  Col, Tbl: string;
begin
  Result := False;
  StoreSql(AStore.Kind, Col, Tbl);
  try
    Db := TWinSqlite.Create(AStore.DatabasePath);
    try
      Db.Execute('BEGIN IMMEDIATE');
      try
        Db.Execute(UTF8Decode('DELETE FROM ' + Tbl + ' WHERE ') +
          BuildDomainExpression(Col, ADomains));
        Db.Execute('COMMIT');
      except
        try Db.Execute('ROLLBACK'); except end;
        raise;
      end;
      try
        Db.Execute('PRAGMA wal_checkpoint(TRUNCATE)');
        Db.Execute('VACUUM');
      except
      end;
    finally
      Db.Free;
    end;
    Result := True;
  except
  end;
end;

function CookieDeleteDomains(const ADomains: TStrings): Integer;
var
  Selected: TStringList;
  Stores: TCookieStoreList;
  Store: TCookieStore;
begin
  Result := 0;
  Selected := NormalizeDomains(ADomains);
  Stores := DiscoverStores;
  try
    if Selected.Count = 0 then Exit;
    for Store in Stores do
      if not DeleteFromStore(Store, Selected) then
        Inc(Result);
  finally
    Stores.Free;
    Selected.Free;
  end;
end;

{ The keep-list delete inside a recognized store: rows whose domain is
  NOT in the keep list are removed. Sidecars (Cookies-journal,
  Device Bound Sessions*, …) are Handled+Succeeded no-ops — deleting
  one could invalidate a kept login. }
function TryCleanProtectedStore(const APath: string;
  const ADomainsToKeep: TStrings): TCookieCleanAttempt;

  function MatchStore(out AStore: TCookieStore; out APrimary: Boolean;
    out AStores: TCookieStoreList): Boolean;
  var
    Full, FileName, DbName: string;
    S: TCookieStore;
  begin
    Result := False;
    AStore := nil;
    APrimary := False;
    Full := ExpandFileName(APath);
    FileName := ExtractFileName(Full);
    AStores := DiscoverStores;
    for S in AStores do
    begin
      if SameText(Full, S.DatabasePath) then
      begin
        AStore := S;
        APrimary := True;
        Exit(True);
      end;
      if not SameText(ExtractFileDir(Full), ExtractFileDir(S.DatabasePath)) then
        Continue;
      DbName := ExtractFileName(S.DatabasePath);
      if (Pos(LowerCase(DbName + '-'), LowerCase(FileName)) = 1) or
         (Pos(LowerCase(DbName + '.'), LowerCase(FileName)) = 1) or
         ((S.Kind = ckChromium) and
          (Pos('device bound sessions', LowerCase(FileName)) = 1)) then
      begin
        AStore := S;
        Exit(True);
      end;
    end;
  end;

var
  FileName: string;
  Keep: TStringList;
  Stores: TCookieStoreList;
  Store: TCookieStore;
  Primary: Boolean;
  Db: TWinSqlite;
  Col, Tbl: string;
  Before, After_: Int64;
  Expr: WideString;
begin
  Result.Handled := False;
  Result.Succeeded := False;
  Result.CookiesRemoved := 0;
  Result.BytesFreed := 0;

  FileName := ExtractFileName(APath);
  if (Pos('cookies', LowerCase(FileName)) <> 1) and
     (Pos('device bound sessions', LowerCase(FileName)) <> 1) then
    Exit;
  Result.Handled := True;   // still unconfirmed as a store below

  Keep := NormalizeDomains(ADomainsToKeep);
  Stores := nil;
  try
    if Keep.Count = 0 then
    begin
      Result.Handled := False;   // no keep-list → ordinary delete allowed
      Exit;
    end;
    if not MatchStore(Store, Primary, Stores) then
    begin
      Result.Handled := False;
      Exit;
    end;
    if not Primary then
    begin
      Result.Succeeded := True;   // sidecar: recognized, leave it alone
      Exit;
    end;

    try
      Before := GetFileSizeBytes(APath);
      StoreSql(Store.Kind, Col, Tbl);
      Expr := BuildDomainExpression(Col, Keep);
      Db := TWinSqlite.Create(APath);
      try
        Db.Execute('BEGIN IMMEDIATE');
        try
          Result.CookiesRemoved := Db.Execute(
            UTF8Decode('DELETE FROM ' + Tbl + ' WHERE NOT (') + Expr + ')');
          Db.Execute('COMMIT');
        except
          try Db.Execute('ROLLBACK'); except end;
          raise;
        end;
        try
          Db.Execute('PRAGMA wal_checkpoint(TRUNCATE)');
          Db.Execute('VACUUM');
        except
        end;
      finally
        Db.Free;
      end;
      After_ := GetFileSizeBytes(APath);
      if Before > After_ then
        Result.BytesFreed := Before - After_;
      Result.Succeeded := True;
    except
      Result.Succeeded := False;
      // a recognized store is protected — never fall back to deleting it
    end;
  finally
    Stores.Free;
    Keep.Free;
  end;
end;

end.
