unit closeappsform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls, ComCtrls,
  Graphics, Dialogs, cs.closeapps;

type

  { "Close running applications" prompt shown before a clean touches
    files that live apps may hold open. Checklist of matched processes;
    three outcomes via ModalResult:
      mrYes    — close the checked apps (see CheckedApps)
      mrNo     — clean anyway without closing anything
      mrCancel — abort the clean }
  TCloseAppsForm = class(TForm)
    lblInfo: TLabel;
    lvApps: TListView;
    pnlButtons: TPanel;
    btnClose: TButton;
    btnSkip: TButton;
    btnCancel: TButton;
    procedure FormCreate(Sender: TObject);
    procedure LvAppsItemChecked(Sender: TObject; Item: TListItem);
    procedure LvAppsCustomDrawItem(Sender: TCustomListView;
      Item: TListItem; State: TCustomDrawState; var DefaultDraw: Boolean);
    procedure LvAppsCustomDrawSubItem(Sender: TCustomListView;
      Item: TListItem; SubItem: Integer; State: TCustomDrawState;
      var DefaultDraw: Boolean);
  private
    FApps: TRunningAppArray;
    procedure UpdateButtons;
    procedure PaintKind(AItem: TListItem);
  public
    constructor CreateDlg(AOwner: TComponent;
      const AApps: TRunningAppArray);
    { Apps the user left checked — only meaningful after mrYes. }
    function CheckedApps: TRunningAppArray;
  end;

implementation

uses
  cs.lang;

{$R *.lfm}

constructor TCloseAppsForm.CreateDlg(AOwner: TComponent;
  const AApps: TRunningAppArray);
var
  I, N: Integer;
  It: TListItem;
begin
  inherited Create(AOwner);   // loads closeappsform.lfm
  // user/system apps first, critical processes pushed to the bottom
  SetLength(FApps, Length(AApps));
  N := 0;
  for I := 0 to High(AApps) do
    if AApps[I].Kind <> akCritical then
    begin
      FApps[N] := AApps[I];
      Inc(N);
    end;
  for I := 0 to High(AApps) do
    if AApps[I].Kind = akCritical then
    begin
      FApps[N] := AApps[I];
      Inc(N);
    end;
  for I := 0 to High(FApps) do
  begin
    It := lvApps.Items.Add;
    It.Caption := FApps[I].AppName;
    It.SubItems.Add(FApps[I].ExeName);
    It.SubItems.Add(FApps[I].ExePath);
    // critical stay unchecked; does NOT fire OnItemChecked on win32
    It.Checked := FApps[I].Kind <> akCritical;
  end;
  UpdateButtons;
end;

procedure TCloseAppsForm.PaintKind(AItem: TListItem);
begin
  if (AItem = nil) or (AItem.Index > High(FApps)) then Exit;
  case FApps[AItem.Index].Kind of
    akCritical: lvApps.Canvas.Font.Color := clRed;
    akSystem:   lvApps.Canvas.Font.Color := clBlue;
  end;
end;

procedure TCloseAppsForm.LvAppsCustomDrawItem(Sender: TCustomListView;
  Item: TListItem; State: TCustomDrawState; var DefaultDraw: Boolean);
begin
  PaintKind(Item);
end;

procedure TCloseAppsForm.LvAppsCustomDrawSubItem(Sender: TCustomListView;
  Item: TListItem; SubItem: Integer; State: TCustomDrawState;
  var DefaultDraw: Boolean);
begin
  PaintKind(Item);
end;

function TCloseAppsForm.CheckedApps: TRunningAppArray;
var
  I, N: Integer;
begin
  Result := nil;
  for I := 0 to lvApps.Items.Count - 1 do
    if lvApps.Items[I].Checked and (I <= High(FApps)) then
    begin
      N := Length(Result);
      SetLength(Result, N + 1);
      Result[N] := FApps[I];
    end;
end;

procedure TCloseAppsForm.UpdateButtons;
var
  I: Integer;
begin
  btnClose.Enabled := False;
  for I := 0 to lvApps.Items.Count - 1 do
    if lvApps.Items[I].Checked then
    begin
      btnClose.Enabled := True;
      Break;
    end;
end;

procedure TCloseAppsForm.FormCreate(Sender: TObject);
begin
  Caption := Lg('Закрыть приложения', 'Закрыць прыкладанні',
                'Закрити застосунки', 'Close applications');
  lblInfo.Caption := Lg(
    'Эти приложения запущены и могут держать файлы, которые мы чистим. ' +
    'Закройте их для полной очистки. Синие — системные, безопасные для ' +
    'закрытия; красные — критические процессы Windows (не отмечайте).',
    'Гэтыя прыкладанні запущаны і могуць трымаць файлы, якія мы чысцім. ' +
    'Закрыце іх для поўнай ачысткі. Сінія — сістэмныя, бяспечныя для ' +
    'закрыцця; чырвоныя — крытычныя працэсы Windows (не адзначайце).',
    'Ці застосунки запущені й можуть тримати файли, які ми чистимо. ' +
    'Закрийте їх для повного очищення. Сині — системні, безпечні для ' +
    'закриття; червоні — критичні процеси Windows (не позначайте).',
    'These apps are running and may hold files we are about to clean. ' +
    'Close them for a complete cleanup. Blue — system processes safe ' +
    'to close; red — critical Windows processes (do not check).');
  lvApps.Column[0].Caption := Lg('Приложение', 'Прыкладанне',
                                 'Застосунок', 'Application');
  lvApps.Column[1].Caption := Lg('Процесс', 'Працэс', 'Процес', 'Process');
  lvApps.Column[2].Caption := Lg('Путь', 'Шлях', 'Шлях', 'Path');
  btnClose.Caption := Lg('Закрыть выбранные', 'Закрыць выбраныя',
                         'Закрити вибрані', 'Close selected');
  btnSkip.Caption := Lg('Не закрывать', 'Не закрываць',
                        'Не закривати', 'Don''t close');
  btnCancel.Caption := Lg('Отмена', 'Адмена', 'Скасування', 'Cancel');
end;

procedure TCloseAppsForm.LvAppsItemChecked(Sender: TObject; Item: TListItem);
begin
  // ticking a critical process is allowed, but only through a
  // crash-warning confirmation — killing it can bluescreen Windows
  if Item.Checked and (Item.Index <= High(FApps)) and
     (FApps[Item.Index].Kind = akCritical) then
    if MessageDlg(Format(Lg(
        '"%s" — критический процесс Windows. Его завершение может ' +
        'вызвать сбой или перезагрузку системы. Всё равно закрыть?',
        '"%s" — крытычны працэс Windows. Яго завяршэнне можа ' +
        'выклікаць збой або перазагрузку сістэмы. Усё роўна закрыць?',
        '"%s" — критичний процес Windows. Його завершення може ' +
        'спричинити збій або перезавантаження системи. Все одно закрити?',
        '"%s" is a critical Windows process. Killing it may crash or ' +
        'reboot the system. Close it anyway?'),
        [FApps[Item.Index].AppName]),
        mtWarning, [mbYes, mbNo], 0) <> mrYes then
      Item.Checked := False;   // silent set — no re-entry
  UpdateButtons;
end;

end.
