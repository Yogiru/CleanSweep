# Порт FluentCleaner → CleanSweep

Цель: перенести движок winapp2-очистки из эталонного репозитория
`FluentCleaner-classic\` (C#/.NET) в CleanSweep (Free Pascal/Lazarus),
чтобы клинер жил внутри одной программы и не требовал .NET.

Эталон: https://github.com/builtbybel/FluentCleaner (снапшот ~6 сен 2026,
версия 26.08.03). Правила работы — `AGENTS.md`.

## Фаза 1 — движок парсинга (готово, 2026-09-17)

| Юнит | Порт чего | Статус |
|---|---|---|
| `src/cs.winapp2.pas` | `Models/*` + `Winapp2Parser` + `CategoryResolver` | done |
| `src/cs.pathexpand.pas` | `Services/PathExpander` + `TWow64FsGuard` | done |
| `test/winapp2test.lpr` | смоук-тест против `FluentCleaner-classic\Winapp2.ini` | done |

Результат смоук-теста (i386): **4075 записей** (совпадает с шапкой базы),
14151 FileKey / 3678 RegKey / 86 ExcludeKey; экспандер: %Var%, wildcard,
голый `C:\`, фолбэк ProgramFiles→x86 — всё ок.

Сборка теста: `cd test && fpc -Fu"..\src" -FE. winapp2test.lpr`

## Фаза 2 — детекция, анализ и чистка (готово, 2026-09-17)

| Юнит | Порт чего | Статус |
|---|---|---|
| `src/cs.regpath.pas` | общие reg-хелперы: `SplitRegPath`, `SplitHiveSubKey`, `NormalizeRegistryPath`, `ViewSplitApplies` | done |
| `src/cs.detect.pas` | `DetectionService` (Detect/DetectFile/SpecialDetect, оба regview) | done |
| `src/cs.cleaner.pas` | `CleaningService` — **Analyze**: enum по FileKey/RegKey, exclusions, protected paths, probe `CreateFileW(DELETE)`, dedup, прогресс/отмена | done |
| `src/cs.cleaner.pas` | `CleaningService` — **Clean**: прямое удаление по плану, REMOVESELF-прунинг, `DeleteRegistryTreeExcept` (структурные reg-исключения), safety-гейт `cs.safety` | done |

Разрядность решена универсально: 64-view всегда, 32-view — только где WOW64
реально разделяет ключ (`HKLM\SOFTWARE`, `HKCR`, `HKCU\SOFTWARE\CLASSES`) —
иначе дубли. Файловые пути — под `TWow64FsGuard`.

Тест `winapp2test` (i386): парсинг 4075, детекция 310/4075, Analyze + Clean
на временном дереве (flat/recurse/exclusions/reg/REMOVESELF-прунинг) —
**ALL CHECKS PASSED**.

## Фаза 3 — UI и интеграция (готово, 2026-09-17)

- `gui/cleanerform.pas` — отдельная модальная форма (меню → «Клинер»):
  слева `lvEntries` (список с чекбоксами, Запись|Категория), справа
  `lvResults` (Путь|Тип|Размер). С 2026-09-21 списки записей —
  `TLazVirtualStringTree` (TListView тормозил на 5000+ записей).
- `TCleanerThread` с режимами wmLoad/wmAnalyze/wmClean — очередь
  статусов через critical-section + Queue, паттерн `TUninstallThread`.
- Загрузка базы: `data\Winapp2.ini` → `Winapp2.ini` → ресурс `WINAPP2`
  (вшит в `.rc`, exe вырос до ~4 МБ). Паттерн LEFTOVERSIG.
- Контекстное меню результатов: копировать путь / открыть папку /
  открыть в реестре. Строки через `Lg()` (RU/BE/UK/EN).
- Подтверждение перед Clean честно говорит «насовсем, без корзины».

Сборка: `lazbuild --build-all` — OK, `winapp2test` — ALL CHECKS PASSED.

## Фаза 4 — сближение с актуальным upstream (готово, 2026-09-21)

| Фича upstream | Порт | Статус |
|---|---|---|
| `CookieService` + `WinSqlite` | `cs.winsqlite` (динам. `winsqlite3.dll`, stdcall!), `cs.cookies`, `gui/cookieform`, хук в `TCleaningService.Clean` | done |
| `CustomEntryService` + CustomPage | Custom-папка `Custom\*.ini` (`.disabled`), permissive-парсер, `gui/customform` | done |
| `AppxService` + Winappx.ini | `cs.appx`, `data\Winappx.ini` (46 записей), `gui/appxform`, PowerShell `Get/Remove-AppxPackage` | done |
| UTF-8 без BOM в базах | `LoadTextFile` (cs.utils) в парсере и loader'е формы | done |
| ССleaner-миграция | `data\CCleaner.ini` — 5-й источник баз (724 записи) | done |
| `/AUTO` + `/SHUTDOWN` (SilentRunner) | — | не портируем |
| CLI-модуль (TerminalPage) | — | не портируем |
| AI-объяснения (AiExplainer) | — | не портируем |

Детали и найденные грабли — `docs\decisions.md` (запись 2026-09-21).

## После фазы 4 (2026-09-23)

Продолжение работ над клинером/деинсталлятором сверх плана:

- списки записей — мультивыбор + «Копировать в Custom» (клонирование
  записей базы в `Custom\*.ini` через `EntryToIni` для изучения/правки);
- визуальный редактор правил + «Проверить…» (previewform, реальный
  Analyze); менеджер Custom (customform); примеры правил в поставке;
- live-exe guard в сканере остатков: папка с живым `.exe` — review-only;
- «Найти остатки (без удаления)…» — ScanOnly-превью хвостов без
  запуска деинсталлятора; подменю режимов переименовано в «Глубина
  поиска остатков»;
- снимок ручных галочек перед пересборкой списка (reload баз больше
  не сбрасывает выбор пользователя);
- грабли LFM: поле + `uses` для каждого класса из `.lfm` (smartlink),
  VST-ленивая инициализация нод, Win32 `OnItemChecked`.

Всё задокументировано в `docs\decisions.md` под датой 2026-09-23 и в
`DEVELOPER.md` / `docs\user-guide.md`.

## Что НЕ переносим

- WinUI 3 UI — заменяется LCL-формой.
- Обновление базы из сети — сделано: `cs.download.pas` (WinINet), панель баз в cleanerform, Winapp3 + своя база, мердж с дедупом.
