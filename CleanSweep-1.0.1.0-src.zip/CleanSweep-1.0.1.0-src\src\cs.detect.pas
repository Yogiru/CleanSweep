unit cs.detect;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, cs.winapp2, cs.pathexpand;

type
  { Answers 'is this app even installed?' — port of DetectionService.
    Multiple Detect/DetectFile entries use OR logic; one hit is enough.
    A DetectOS version gate (winapp2 min/max spec) is evaluated first
    and hides the entry when the host OS falls outside it.
    Entries without any detection criteria return False (hidden) —
    winapp2.ini always provides them, a custom DB may not.

    Universality: registry checks try the 64-bit view first, then 32-bit;
    file checks run under the WOW64 FS guard. Same outcome on i386 and
    x64 builds, and 32-bit apps registered under WOW6432Node are found.

    Performance: registry/file existence probes are cached for the
    service lifetime (one detection pass). A merged pool re-asks the
    same Detect key dozens of times; the cache turns that into two
    sorted lookups. Cache lives per-instance so one scan never leaks
    a stale result into the next. }
  TDetectionService = class
  private
    FExpander: TPathExpander;
    FRegYes, FRegNo: TStringList;      // keys known present / absent
    FFileYes, FFileNo: TStringList;    // same for file probes
    function GetCached(const AYes, ANo: TStringList; const AKey: string;
      out AState: Boolean): Boolean;
    function DetectOsSatisfied(AEntry: TCleanerEntry): Boolean;
    function CheckRegistry(const ARegPath: string): Boolean;
    function CheckRegistryView(const ARegPath: string;
      AAccess: LongWord): Boolean;
    function CheckFile(const ARawPath: string): Boolean;
    function TryCheckSpecialDetect(const ACode: string;
      out AResult: Boolean): Boolean;
  public
    constructor Create;
    destructor Destroy; override;
    function IsInstalled(AEntry: TCleanerEntry): Boolean;
  end;

implementation

uses
  Registry, Windows, cs.registry, cs.regpath;

constructor TDetectionService.Create;
begin
  FExpander := TPathExpander.Create;
  FRegYes := TStringList.Create;
  FRegYes.Sorted := True;
  FRegYes.CaseSensitive := False;
  FRegYes.Duplicates := dupIgnore;
  FRegNo := TStringList.Create;
  FRegNo.Sorted := True;
  FRegNo.CaseSensitive := False;
  FRegNo.Duplicates := dupIgnore;
  FFileYes := TStringList.Create;
  FFileYes.Sorted := True;
  FFileYes.CaseSensitive := False;
  FFileYes.Duplicates := dupIgnore;
  FFileNo := TStringList.Create;
  FFileNo.Sorted := True;
  FFileNo.CaseSensitive := False;
  FFileNo.Duplicates := dupIgnore;
end;

destructor TDetectionService.Destroy;
begin
  FExpander.Free;
  FRegYes.Free;
  FRegNo.Free;
  FFileYes.Free;
  FFileNo.Free;
  inherited;
end;

{ Cached answer for AKey from two mutually-exclusive pools. Returns False
  (calling a live probe) unless the key was already classified. }
function TDetectionService.GetCached(const AYes, ANo: TStringList;
  const AKey: string; out AState: Boolean): Boolean;
var
  Idx: Integer;
begin
  if AYes.Find(AKey, Idx) then
  begin
    AState := True;
    Exit(True);
  end;
  if ANo.Find(AKey, Idx) then
  begin
    AState := False;
    Exit(True);
  end;
  Result := False;
end;

function TDetectionService.IsInstalled(AEntry: TCleanerEntry): Boolean;
var
  S: string;
begin
  Result := False;

  { Special-action entries (recycle bin, dead desktop shortcuts) probe
    live state at Analyze time — nothing to "install", so always found. }
  if AEntry.Special <> '' then Exit(True);

  // DetectOS gate first: an unsatisfied version constraint hides the
  // entry regardless of what Detect/DetectFile/SupportDetect say.
  if AEntry.DetectOSUsed then
  begin
    if not DetectOsSatisfied(AEntry) then Exit;
    // DetectOS-only entry: OS match alone is the whole detection
    if (AEntry.DetectKeys.Count = 0) and
       (AEntry.DetectFiles.Count = 0) and
       (AEntry.SpecialDetect = '') then
      Exit(True);
  end;

  if AEntry.SpecialDetect <> '' then
    // known code → trust its result; unknown → fall through below
    if TryCheckSpecialDetect(AEntry.SpecialDetect, Result) then
      Exit;

  for S in AEntry.DetectKeys do
    if CheckRegistry(S) then Exit(True);
  for S in AEntry.DetectFiles do
    if CheckFile(S) then Exit(True);
end;

{ Windows version as major*100+minor (10.0 → 1000) via RtlGetVersionW.
  GetVersionEx reports 6.2 on Win8.1+ when the manifest lacks the
  supportedOS block, so the ntdll call is the reliable source. Resolved
  once and cached. Returns -1 when the API cannot be reached. }
type
  TRtlOsVersionInfo = record
    dwOSVersionInfoSize: DWORD;
    dwMajorVersion: DWORD;
    dwMinorVersion: DWORD;
    dwBuildNumber: DWORD;
    dwPlatformId: DWORD;
    szCSDVersion: array[0..127] of WideChar;
  end;

var
  GWinVer: Integer = -2;   // -2 = not probed yet
  GVerChecked: Boolean = False;

function GetWindowsVersion100: Integer;
var
  Fn: function(var AInfo: TRtlOsVersionInfo): LongInt; stdcall;
  H: HMODULE;
  Info: TRtlOsVersionInfo;
begin
  if GVerChecked then Exit(GWinVer);
  GVerChecked := True;
  GWinVer := -1;
  H := GetModuleHandle('ntdll.dll');
  if H <> 0 then
  begin
    Pointer(Fn) := GetProcAddress(H, 'RtlGetVersion');
    if Assigned(Fn) then
    begin
      FillChar(Info, SizeOf(Info), 0);
      Info.dwOSVersionInfoSize := SizeOf(Info);
      if Fn(Info) = 0 then
        GWinVer := Integer(Info.dwMajorVersion) * 100 +
                   Integer(Info.dwMinorVersion);
    end;
  end;
  Result := GWinVer;
end;

function TDetectionService.DetectOsSatisfied(AEntry: TCleanerEntry): Boolean;
var
  V: Integer;
begin
  V := GetWindowsVersion100;
  // Unknown OS version → fail closed: never clean when the constraint
  // cannot be verified. RtlGetVersion only misses on an exotic system.
  if V < 0 then Exit(False);
  Result := True;
  if (AEntry.DetectOSMin >= 0) and (V < AEntry.DetectOSMin) then Exit(False);
  if (AEntry.DetectOSMax >= 0) and (V > AEntry.DetectOSMax) then Exit(False);
end;

function TDetectionService.CheckRegistry(const ARegPath: string): Boolean;
var
  State: Boolean;
begin
  if GetCached(FRegYes, FRegNo, ARegPath, State) then Exit(State);
  Result := CheckRegistryView(ARegPath, REGVIEW_64);
  // 32-bit view probe only where WOW64 actually splits the key —
  // HKCU/HKLM\SYSTEM etc. resolve to the same physical key either way
  if (not Result) and OsIs64Bit and ViewSplitApplies(ARegPath) then
    Result := CheckRegistryView(ARegPath, REGVIEW_32);
  if Result then FRegYes.Add(ARegPath) else FRegNo.Add(ARegPath);
end;

function TDetectionService.CheckRegistryView(const ARegPath: string;
  AAccess: LongWord): Boolean;
var
  Hive, SubKey, ValueName: string;
  R: TRegistry;
  Key: HKEY;
begin
  Result := False;
  try
    SplitRegPath(ARegPath, Hive, SubKey, ValueName);
    Key := HiveFromString(Hive);
    if Key = 0 then Exit;
    if SubKey = '' then
      // bare hive always 'exists'; a root value is queried on the hive itself
      Exit((ValueName = '') or
        (RegQueryValueExW(Key, PWideChar(UTF8Decode(ValueName)),
          nil, nil, nil, nil) = ERROR_SUCCESS));
    R := RegOpenRead(Key, SubKey, AAccess);
    if R = nil then Exit;
    try
      Result := (ValueName = '') or R.ValueExists(ValueName);
    finally
      R.Free;
    end;
  except
    Result := False;
  end;
end;

function TDetectionService.CheckFile(const ARawPath: string): Boolean;
var
  Expanded, Key: string;
  Resolved: TStringList;
  Guard: TWow64FsGuard;
  State: Boolean;
begin
  Result := False;
  Guard := TWow64FsGuard.Create;
  try
    try
      if (Pos('*', ARawPath) > 0) or (Pos('?', ARawPath) > 0) then
      begin
        // wildcard key is the raw macro path: the same ResolvePaths
        // input always yields the same result within one scan
        Key := ARawPath;
        if GetCached(FFileYes, FFileNo, Key, State) then Exit(State);
        Resolved := FExpander.ResolvePaths(ARawPath);
        try
          Result := Resolved.Count > 0;
        finally
          Resolved.Free;
        end;
      end
      else
      begin
        Expanded := FExpander.ExpandVariables(ARawPath);
        Key := Expanded;
        if GetCached(FFileYes, FFileNo, Key, State) then Exit(State);
        Result := FileExists(Expanded) or DirectoryExists(Expanded);
      end;
      if Result then FFileYes.Add(Key) else FFileNo.Add(Key);
    except
      Result := False;
    end;
  finally
    Guard.Free;
  end;
end;

{ SpecialDetect shorthand — port of TryCheckSpecialDetect.
  Returns True when the code is known (result filled); False = caller
  falls back to Detect/DetectFile. }
function TDetectionService.TryCheckSpecialDetect(const ACode: string;
  out AResult: Boolean): Boolean;
var
  C: string;
begin
  Result := True;
  C := UpperCase(ACode);
  if C = 'DET_CHROME' then
    AResult := CheckFile('%LocalAppData%\Google\Chrome\User Data')
  else if C = 'DET_FIREFOX' then
    AResult := CheckFile('%AppData%\Mozilla\Firefox')
  else if C = 'DET_IE' then
    AResult := CheckRegistry(
      'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\IEXPLORE.EXE')
  else if C = 'DET_THUNDERBIRD' then
    AResult := CheckFile('%AppData%\Thunderbird')
  else if C = 'DET_OPERA' then
    AResult := CheckFile('%AppData%\Opera Software\Opera Stable')
  else if C = 'DET_EDGE' then
    AResult := CheckFile('%LocalAppData%\Microsoft\Edge\User Data')
  else if C = 'DET_WINSTORE' then
    // Packages exists on every Win10+ machine
    AResult := CheckFile('%LocalAppData%\Packages')
  else
  begin
    AResult := False;
    Result := False;
  end;
end;

end.
