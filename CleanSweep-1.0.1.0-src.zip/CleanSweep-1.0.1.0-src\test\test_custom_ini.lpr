program test_custom_ini;

{$mode objfpc}{$H+}

uses
  SysUtils, Classes, Math, cs.winapp2;

var
  Parser: TWinapp2Parser;
  L1, L2, L3: TCleanerEntryList;
  I, J, Overlap: Integer;
  Set1, Set2: TStringList;
begin
  Parser := TWinapp2Parser.Create;
  Set1 := TStringList.Create;
  Set2 := TStringList.Create;
  Set1.Sorted := True;
  Set1.Duplicates := dupIgnore;
  Set2.Sorted := True;
  Set2.Duplicates := dupIgnore;

  WriteLn('--- Winapp2 vs WinappCS overlap ---');
  L1 := Parser.ParseFile('..\data\Winapp2.ini');
  L3 := Parser.ParseFile('WinappCS.ini');
  for I := 0 to L1.Count - 1 do
    Set1.Add(L1[I].Name);
  for I := 0 to L3.Count - 1 do
    Set2.Add(L3[I].Name);
  Overlap := 0;
  for I := 0 to Set1.Count - 1 do
    if Set2.IndexOf(Set1[I]) >= 0 then Inc(Overlap);
  WriteLn('Winapp2 entries: ', L1.Count);
  WriteLn('WinappCS entries: ', L3.Count);
  WriteLn('Overlap (same name): ', Overlap);
  if Overlap > 0 then
  begin
    WriteLn('Overlapping names (first 10):');
    J := 0;
    for I := 0 to Set1.Count - 1 do
      if Set2.IndexOf(Set1[I]) >= 0 then
      begin
        WriteLn('  ', Set1[I]);
        Inc(J);
        if J >= 10 then Break;
      end;
  end;
  L1.Free;
  L3.Free;

  WriteLn;
  WriteLn('--- Winapp3 vs WinappCS overlap ---');
  Set1.Clear;
  Set2.Clear;
  L2 := Parser.ParseFile('..\data\Winapp3.ini');
  L3 := Parser.ParseFile('WinappCS.ini');
  for I := 0 to L2.Count - 1 do
    Set1.Add(L2[I].Name);
  for I := 0 to L3.Count - 1 do
    Set2.Add(L3[I].Name);
  Overlap := 0;
  for I := 0 to Set1.Count - 1 do
    if Set2.IndexOf(Set1[I]) >= 0 then Inc(Overlap);
  WriteLn('Winapp3 entries: ', L2.Count);
  WriteLn('WinappCS entries: ', L3.Count);
  WriteLn('Overlap (same name): ', Overlap);
  if Overlap > 0 then
  begin
    WriteLn('Overlapping names (first 10):');
    J := 0;
    for I := 0 to Set1.Count - 1 do
      if Set2.IndexOf(Set1[I]) >= 0 then
      begin
        WriteLn('  ', Set1[I]);
        Inc(J);
        if J >= 10 then Break;
      end;
  end;
  L2.Free;
  L3.Free;

  Set1.Free;
  Set2.Free;
  Parser.Free;
end.
