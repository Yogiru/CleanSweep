# Решения по проекту

Лог принятых решений. Новые — сверху по датам, старые не трём.

## 2026-09-25 — раздел «Сеть»: форма сетевого сброса/очистки

- Новый пункт меню «Сеть» (между «Очистка» и «?») → `netform`.
- `src/cs.netfix.pas` — 11 операций: flush DNS/NetBIOS/ARP/BranchCache,
  сброс прокси WinHTTP, сброс TCP-глобалов, сброс Winsock и TCP/IP
  стека (⚠ребут), route -f, ipconfig release/renew, рестарт адаптеров
  через PowerShell (⚠сеть упадёт). Флаги nfReboot/nfDropsLink
  определяют маркеры и предупреждение перед запуском.
- `RunNetCommand` — cmd.exe /c скрыто, дренаж обоих pipe-ов во время
  работы (анти-дедлок ~4KB буфера, как RunPs), OEM→UTF8 для лога,
  таймаут 120 с.
- `netform`: TCheckListBox (CheckLst! не StdCtrls), «Отметить всё»/
  «Снять все»/«Инвертировать», безопасные flush-и предотмечены,
  выполнение в TNetThread с пер-операционным Synchronize-флашем лога;
  итоговое сообщение о ребуте при nfReboot-операциях.
- **Цветовая схема (rich)**: чек-лист переведён на VST (`OnPaintText`,
  как в cleanerform) — красный = ⚠связь (nfDropsLink), тёмно-жёлтый
  (olive) = ⚠ребут (nfReboot), синий = ⚠админ (nfAdmin — новый флаг,
  помечены netsh/route/adapter-операции), чёрный = безопасные.
  Легенда цветов — в lblStatus. Лог переведён с TMemo на owner-drawn
  TListBox: цвет и bold упакованы в Items.Objects (PtrInt); ошибки и
  ненулевые exit-коды — красным, блоки rebоot-операций — тёмно-жёлтым,
  остальное — тёмно-серым.

## 2026-09-25 — аудит заглушек/мёртвого кода

- Полный проход: TODO/FIXME/not-implemented/пустых тел в src+gui нет;
  хинты FPC — только безобидные (5057 uninit out-параметры WinAPI,
  4055 ordinal↔pointer); ни одного unused unit/var.
- 7 интерфейсных функций без внешних вызовов проверены — все живые
  (используются внутри своих юнитов).
- `src/cs.download.pas` был не зарегистрирован в `CleanSweep.lpi` —
  добавлен `<Unit>` (правило AGENTS).
- Удалено по подтверждению: `gui/backup/` (старые копии
  mainform/progcard от 17.09), артефакты сборки `src/*.o|*.ppu|*.a`.

## 2026-09-25 — temp-контент: исключение из runnable-guard'а

- **Конфликт**: защита от случайного удаления `.exe` (`IsRunnableExtension`
  + `ExplicitlyTargetsExt` в `TCleaningService.FindFiles`) скипала
  бинарники под широким `*`-паттерном — в т.ч. мусор внутри %TEMP%.
- **Решение**: внутри temp-корней (`IsTempPath` — user TEMP/TMP +
  WinDir\Temp) runnable-guard не применяется: временные каталоги по
  политике — scratch-мусор, подтверждённая очистка забирает и
  exe/msi-обломки. `IsProtectedPath`/`IsPathSafeToDelete` и лок-проба
  продолжают работать.
- Вне temp-корней защита бинарников сохраняется в полном объёме.

## 2026-09-25 — новые записи не должны приходить снятыми (фикс %TEMP%)

- **Симптом**: добавленные SYS_EXTRA_INI-записи (TEMP ×2, корзина)
  появились в списке без галок, хотя `Default=True` — %TEMP% «не
  чистился».
- **Причина**: сохранённый выбор `[Selection]` в CleanSweep.ini
  применялся как абсолютное состояние — запись вне списка → снята.
  Новых записей в списке не было → Default= игнорировался.
- **Фикс**: состояние хранится дельтой — `[Selection]` (все
  отмеченные) + новая секция `[Unchecked]` (снятые вопреки
  `Default and Detected`). При populate: в Selection → галка,
  в Unchecked → без, вне обоих → `Default and Detected`.
  Ту же пару списков заполняет in-session снимок
  `SnapshotChecked` → `SnapshotState`.
- Старый ini чинится сам: записей нет ни в одном списке → заводская
  отметка. Ничего чистить руками не нужно.

## 2026-09-25 — Default.ini как несгораемая стандартная база

- **Проблема**: «стандартная» очистка зависела от внешнего
  `data\Default.ini` — удалил файл, и база пропала бесследно.
  По образцу CCleaner стандартный набор обязан быть всегда.
- **Решение**: Default.ini вшит в exe ресурсом `DEFAULTDB`
  (CleanSweep.rc), грузится через `LoadDbText` — файл имеет
  приоритет, ресурс — фолбэк. Если файл отсутствует, он
  **автоматически материализуется** из ресурса
  (`RestoreDbFromResource`) — пользователь снова имеет
  редактируемую копию.
- **Кнопка «Сбросить»** рядом с Default.ini перезаписывает файл
  заводской копией из ресурса (с подтверждением) — сброс правок.
- **Почему не перенос в `Custom\`** (рассматривалось): Custom —
  пространство пользовательских правил с permissive-парсером и
  `.disabled`-механикой; база там теряла бы статус источника
  (перестала бы исключать Winapp3, управлялась бы общим чекбоксом
  cbCustom). Embedded+auto-restore даёт ту же «нерушимость»,
  не смешивая слои.
- Аналогично уже работает Winapp2.ini (ресурс `WINAPP2`).
  Ресурс + внешний файл + кнопка сброса = CCleaner-модель
  «стандартная чистка всегда есть».

## 2026-09-25 — TEMP и корзина: встроенные записи SYS_EXTRA_INI

- **Почему не чистились**: `[Recycle Bin *]` (Special=RecycleBin)
  существует только в `Default.ini`, а он взаимоисключает Winapp3 —
  при Winapp3 корзины в списке нет вообще. Записи на `%Temp%` /
  `%WinDir%\Temp` нет ни в одной базе (в CCleaner TEMP — нативная
  чистка, не data-driven, поэтому winapp2 её не содержит).
- **Фикс**: `SYS_EXTRA_INI` в cleanerform — встроенные записи,
  добавляемые в пул всегда (как SEC_EXTRA_INI): `[Recycle Bin *]`
  (дедуп first-wins → с Default.ini не конфликтует),
  `[User Temp Files *]` (%Temp%|*|RECURSE, Default=True),
  `[Windows Temp Files *]` (%WinDir%\Temp|*|RECURSE, Default=True).
- Без REMOVESELF — сам каталог Temp остаётся; залоченные файлы
  отсеивает проба TryGetDeletableSize, как у всех.

## 2026-09-25 — подготовка к чистке: прогресс, параллельное закрытие, оболочка

- **Проблема**: «Закрыть выбранные» шёл серийно — до 8 с ожидания на
  каждый процесс, GUI мёрз без уведомления.
- **Параллельное закрытие**: `TCloseAppThread` (cs.closeapps) — поток
  на приложение; `CloseAppsInParallel` (cleanerform) спавнит все
  разом, ждёт `Finished` с `Application.ProcessMessages`, ведёт
  прогресс-бар и статус «Закрыто N из M: имя».
- **Уведомление подготовки**: статус «Подготовка: поиск блокирующих
  приложений…» + marquee-прогресс на время `FindAppsToClose`.
- **Оболочка**: перед `StartWorkers(wmClean)` — `StopShell` (убивает
  все explorer.exe через TerminateProcess; WM_CLOSE на шелл не
  работает), флаг `FShellDown`. После завершения wmClean —
  `StartShell` запускает **`userinit.exe` (System32)**, а не
  explorer напрямую: userinit читает `Winlogon\Shell` и поднимает
  оболочку сам, как при обычном входе — не нужно запускать всё
  вручную. Деструктор формы — страховочный рестарт, если флаг
  остался.
- **Запуск под токеном пользователя** (решение пользователя):
  `StopShell` до убийства захватывает токен explorer —
  `OpenProcessToken(TOKEN_DUPLICATE)` → `DuplicateTokenEx` в
  primary token (оба вызова — динамический advapi32, их нет в
  FPC-Windows). `StartShell` пускает userinit через
  `CreateProcessWithTokenW(LOGON_WITH_PROFILE)` → оболочка
  возвращается **непривилегированной**, под тем пользователем,
  под которым работала. Захват не удался → фолбэк: userinit
  elevated → explorer.exe. Токен закрывается после использования
  и в finalization.
- Логика: shell останавливаем только после всех подтверждений
  (отмена в диалоге → explorer не трогается); отмена чистки тоже
  доводит до FinishWork → рестарт.
- **explorer.exe исключён из FindAppsToClose**: как akSystem он
  попадал в чек-лист и `CloseApp` слал ему WM_CLOSE → диалог
  «Завершение работы Windows». Шелл только жёстко убивается
  (`StopShell`, TerminateProcess) и перезапускается после чистки
  или при закрытии формы — грациозного пути нет.

## 2026-09-25 — TC-плагин: корень из 4 папок + поиск + AppX

- **Корень**: `_refresh.cmd` + `Приложения` / `Системные` /
  `Компоненты Windows` / `AppX` (каждая — только если непустая).
  Категория программы: `ParentKeyName<>''` → Компоненты Windows;
  `SystemComponent=1` → Системные; иначе Приложения. В
  `TInstalledProgram` добавлено поле `ParentKeyName`.
- **AppX**: `csun_vfs` грузит `data\Winappx.ini` из папки плагина
  (шипится в dist-зипе вместе с `leftover-signatures.json`),
  ленивый `AppxInstalledNames` через PowerShell, кэш до `_refresh`.
  В папке пакета: `!remove.cmd` (Remove-AppxPackage), `!rescan.cmd`.
- **Поиск (Alt+F7)**: последний сегмент пути с `*`/`?` — маска
  (`PathMatchSpecW` по именам записей). TC сам ходит по каталогам.
- **Дев-выгрузка исправлена**: `FindWindow('TTOTAL_CMD')` возвращал 0
  при запуске из нашего шелла — `unload_tc.ps1` переведён на
  `EnumWindows`+фильтр по классу; `SendMessage(hwnd, WM_USER+51, 2913, 2)`
  реально выгружает WFX, линкер пишет файл при открытом TC.

## 2026-09-25 — TC-плагин: продвинутая модель + фикс юникода в инвентаре

- **Структура VFS**: системные компоненты (`IsSystem`) вынесены в
  `\[System]\`, корень показывает только пользовательские программы.
- **`!protected.cmd`** в папке программы — тоггл видимости review-only
  остатков (lcRisky/lcInfo; DEL на них по-прежнему отказывается).
- **`FsExtractCustomIconW`** — иконки программ из `DisplayIconPath`
  (формат `path.exe,N` и `.ico`), `ExtractIconExW` + фолбэк
  `SHGetFileInfoW`.
- **Кастомные колонки** `FsContentGetSupportedField`/`FsContentGetValueW`:
  Version, Publisher, Size (bytes), Source.
- **`cs.registry` — юникод-фикс**: `ScanHive` переписан с `TRegistry`
  (ANSI в FPC, теряет CJK → `?`) на прямые `RegEnumKeyExW`/
  `RegQueryValueExW`. Бонус: сабкеи с юникодными именами раньше вообще
  не открывались — программы пропадали из инвентаря. Фикс работает и в
  основном GUI, и в плагине.
- **Дев-цикл без закрытия TC**: `build.bat` теперь сначала шлёт TC
  `cm_UnloadPlugins` (2913) через `WM_USER+51` (`unload_tc.ps1`,
  lParam=2 — только FS-плагины), затем линкует; TC может оставаться
  открытым. Плюс `pluginst.inf` + `dist\csuninst.zip` — устанавливаемый
  TC-пакет (открытие zip в TC предлагает автоустановку).

## 2026-09-25 — TC-плагин csuninst.wfx64 (деинсталлятор без клинера)

- **x64-блокер снят**: проблемой был только LCL — а WFX-плагину LCL
  не нужен, UI рисует сам TC. Движок cs.* чистый, win64-юниты RTL/FCL
  лежат в `C:\lazarus\fpc\3.2.2\units\x86_64-win64` — `c:\fpc-x64`
  оказался не нужен, `fpc -Px86_64 -Twin64` справляется.
- **`tcplugin\csuninst.dpr` + `csun_vfs.pas`**: виртуальная ФС —
  `\` программы как папки; `\<Prog>\` — `_info.txt` (карточка),
  `!uninstall.cmd` (асинхронный запуск деинсталлятора, CreateProcess
  без ожидания — TC не блокируется), `!rescan.cmd` (сброс кэша скана),
  `files\` и `registry\` — кандидаты остатков. Удаление через
  `DeleteLeftovers` (корзина, все safety-гейты); lcRisky/lcInfo —
  READONLY-атрибут + суффикс «(!)»/«(i)» + отказ на DEL.
- Скан — `ScanOnly(smModerate)` лениво при входе в папку программы,
  кэшируется; `_refresh.cmd` в корне — перечитать инвентарь.
- Владение: `ScanOnly` кладёт скан и в out-param, и в Result.Scan —
  `Res.Scan := nil` перед `Res.Free`, иначе двойное владение.
- Имя элемента: `NNNN <leaf>` — индекс в scan-листе = устойчивое
  разрешение при DEL; `_map.txt` — соответствие индекс → полный путь.
- Экспорты: только W-варианты + `FsGetDefRootName` (он ANSI-only).
- Сборка: `tcplugin\build.bat` → `bin\csuninst.wfx64` + `.wfx`.
- Заготовка/defs — по образцу SafeNovaTC (`fsplugin_defs.pas`).

## 2026-09-24 — диалог «Закрыть приложения»: классификация процессов

- **Проблема**: при очистке список «блокирующих» процессов содержал
  почти все системные — exe-under-root матчил `Pos(Root+'\',ExePath)=1`,
  и широкий корень FileKey (`%WinDir%`, `%ProgramFiles%`…) втягивал
  csrss/svchost/explorer. `CloseApp` после 8 с делал TerminateProcess —
  на критическом процессе это BSOD.
- **Решение (пользователя)**: не прятать, а классифицировать.
  `TRunningApp.Kind`: `akUser` — обычное приложение (чёрный, отмечен);
  `akSystem` — exe под `%WinDir%`, не критический (синий, отмечен);
  `akCritical` — флаг `IsProcessCritical` (kernel32, динамический
  импорт) ИЛИ имя в таблице CriticalExeNames (smss/csrss/wininit/
  winlogon/services/lsass/lsaiso/svchost/dwm/fontdrvhost/sihost +
  pseudo 'system'/'registry'/'memory compression'/'secure system') —
  красный, **без галки**, уходит вниз списка.
- **Предупреждение**: отметка красной строки → MessageDlg «критический
  процесс, возможен крах — всё равно закрыть?»; отказ снимает галку
  обратно. Явное согласие — закрываем (решение пользователя, не
  жёсткий запрет).
- Легенда цветов добавлена в текст lblInfo на 4 языках.
- Сортировка списка: user+system в исходном порядке, critical — внизу.

## 2026-09-24 — «DRM Data»-записи: оставить апстрим-семантику

- **Вопрос**: клинер в плане Analyze показывал рабочие бинарники —
  `...\WidevineCdm\4.10.3050.0\_platform_specific\win_x64\widevinecdm.dll`
  (Opera Neon, Яндекс, Vivaldi и др.).
- **Разбор**: это записи `[Браузер DRM Data *]` самого Winapp2
  (`FileKey=...\WidevineCdm|*|REMOVESELF`, 72 вхождения в базе) —
  апстрим-очистка «сброса DRM-данных». `widevinecdm.dll` — НЕ мусор,
  а живой CDM-модуль: после удаления браузер перекачает его (~10 МБ),
  до этого DRM-контент не играет, скачанные лицензии слетают.
  Записи без `Default=` → не предотмечены; в план попали только при
  явной отметке (вручную/пресетом).
- **Рассмотрено и отклонено**: глобальный запрет на удаление
  `*.exe/*.dll` в движке — в базах есть легитимные цели-бинарники
  (`vcredist*.exe`, `*setup*.exe`, языковые `*.resources.dll` Winapp3);
  встроенное исключение на `_platform_specific` — решение пользователя:
  не менять.
- **Решение**: поведение upstream сохраняем — запись штатная,
  выключена по умолчанию, эффект (перескачивание CDM) обратим.

## 2026-09-23 — примеры Custom-правил в поставке
- Custom\Пример 1/2 — реальные записи (кэш Windows Update, журналы
  CBS/DISM, WER, CrashDumps, Minidump, RecentDocs) с комментариями:
  открываются в редакторе («Изменить…») как готовый пример формы.
- Default=False; цели — классический клинеровский мусор. Примечание:
  без elevation Analyze по %WinDir% честно покажет 0 (TryGetDeletableSize
  требует DELETE-доступ) — в приложении манифест requireAdministrator.

## 2026-09-23 — грабля: .lfm vs uses/поля (Class 'TPanel' not found)
- LFM-стример находит классы по RegisterClass — юнит контрола обязан
  быть в uses формы (TPanel→ExtCtrls и т.п.), иначе runtime-ошибка
  "Class 'X' not found" при открытии формы.
- Было: pickform.lfm содержал TPanel, pickform.pas без ExtCtrls и поля;
  previewform тоже — ExtCtrls был, но поля pnlButtons нет → смартлинковка
  выкинула TPanel. Лечится ТОЛЬКО объявлением поля в классе формы.
- Проверка: grep классов из .lfm vs uses .pas.

## 2026-09-23 — «Копировать в Custom» + мультивыбор
- Списки записей теперь мультивыборочные (toMultiSelect): Ctrl/Shift.
- Кнопка «В Custom» + пункт контекстного меню: каждая выбранная
  запись базы сериализуется EntryToIni в свой Custom\<имя>.ini —
  для изучения/правки в редакторе. Custom-записи пропускаются,
  коллизии — один диалог с «Да для всех». После копирования —
  ReloadDatabases (копия переопределяет оригинал при мёрдже).
- EntryIniFileName: обрезает хвост ' *' и чистит запрещённые символы.

## 2026-09-23 — перезагрузка баз стирала ручные галочки
- Симптом: «Снять выбор» → «Правила…» → Закрыть → галочки вернулись.
  ReloadDatabases → PopulateEntries пересобирал список по Default=;
  FSavedSelection жил только на старте сессии.
- Фикс: перед пересборкой списка SnapshotChecked снимает живое состояние
  отметок (обе вкладки); FSelSaved=True → снимок перекрывает Default=
  даже когда пуст («снять всё» переживает reload).
- lvSec: по-прежнему не отмечается на старте и не пишется в ini —
  но явные отметки внутри сессии переживают reload.

## 2026-09-23 — «Найти остатки (без удаления)» — ScanOnly
- Контекстное меню программы: прогоняет TUninstallEngine.ScanOnly —
  тот же RunLeftoverScan (общий хвост Uninstall), но без запуска
  деинсталлятора и без удаления. Та же глубина, что и в меню.
- Подменю режимов переименовано в «Глубина поиска остатков» — чтобы
  не путать настройку с действием.
- ScanOnly-ветка в UninstallDone: лог «Поиск остатков завершён»,
  StartInventory не дёргается (ничего не удалялось).

## 2026-09-20 — память пресета и выбора, специальная очистка

- **Пресет запоминается** (`gui/presetform.pas`): последний применённый
  набор (`Purpose0..8`, `Safety0..2`, `OnlyInstalled`) пишется в
  `CleanSweep.ini` секции `[Presets]` при нажатии «Применить». При
  открытии форма восстанавливает его; если секции нет (первый запуск /
  старая версия) — открывается «Рекомендуемые»
  (`QuickConfig(True, False, True, True)`).
- **Отметки запоминаются** (`cleanerform`): `SaveSelection` при закрытии
  клинера (когда `CanClose`) пишет в `[Selection]` имена отмеченных
  записей вкладки «Очистка» (`Entry0..N`). Вкладка «Пароли и сессии»
  **никогда не восстанавливается** — рискованные отметки живут только
  явным выбором внутри сессии.
- **Специальные действия** (`Special=` в базе): записи без FileKey/RegKey,
  которые движок обрабатывает как операции уровня ОС. `IsValidEntry`
  принимает `Special` и как критерий детекции, и как критерий
  содержимого; `cs.detect:IsInstalled` для них всегда True. Константы
  `SPECIAL_RECYCLEBIN`/`SPECIAL_DEADSHORTCUTS` — в интерфейсе cs.cleaner;
  Analyze копит их в `Result.SpecialItems` + `SpecialBytes`/`SpecialCount`
  (видны UI-строкой «Корзина» и в счётчиках). `PresetSafetyOf` = Safe,
  `PresetPurposeOf` = Windows.
- **Корзина**: Analyze → `SHQueryRecycleBinW(nil,…)` (пустая корзина —
  запись не ставится в очередь, как пустая файловая маска); Clean →
  `SHEmptyRecycleBinW(0, nil, SHERB_NOCONFIRMATION or SHERB_NOPROGRESSUI
  or SHERB_NOSOUND)`. Строка результата «Recycle Bin», прогресс —
  «Deleted: Recycle Bin».
- **Мёртвые ярлыки рабочего стола**: `FindDeadShortcuts` — только
  `%USERPROFILE%\Desktop` и `%PUBLIC%\Desktop`, верхний уровень `*.lnk`;
  цель резолвится через COM `IShellLinkW` (`GetPath(..., SLGP_RAWPATH)`)
  + `IPersistFile.Load` (свой минимальный `IPersistFileX`,
  `{0000010B-...}`), в очередь — только ярлыки с физически отсутствующей
  целью (нераспознанные оставляем). Unsafe/protected пропускаются;
  `CoInitialize` локально и сбалансировано `CoUninitialize`.
- **COM без comobj**: `ole32.dll` — прямые импорты (`CoInitialize`/
  `CoUninitialize`/`CoCreateInstance`); `S_OK`=0 и `S_FALSE`=1 объявлены
  локально — в RTL `Windows` их нет (проверено); `STGM_READ`/
  `CLSCTX_INPROC_SERVER` есть только в `activex` — его не подключаем.
  `IShellLinkW`/`CLSID_ShellLink`/`SLGP_RAWPATH` — из `shlobj`.
- **Env-переменные**: в cs.cleaner win32 `GetEnvironmentVariable`
  (PChar-сигнатура из `Windows`) перекрывает RTL-версию — вызываем явно
  `SysUtils.GetEnvironmentVariable`.
- **Default.ini**: добавлены `[Recycle Bin *]` и `[Desktop Dead Shortcuts *]`
  (`LangSecRef=3025`, `Section=Windows`, `Special=…`); «Windows Icon/Thumbnail
  Cache Extended» и «Windows Event Viewer Log Files» переклассифицированы из
  `Dangerous Windows` в `Windows` (Safe) — кэш иконок делаем безопасным
  (решение пользователя).
- **Тесты**: новый `test/specialtest.lpr` — парсинг `Special`, детекция,
  пресетные оси новых записей, Analyze корзины и мёртвых ярлыков
  **(read-only, Clean не вызывается — корзину не опустошаем!)**, отсутствие
  ложных Special у обычной записи. На живой машине нашлись реальные мёртвые
  ярлыки (2 шт., 3220 Б) — очередь и счётчики сошлись. ALL CHECKS PASSED.
- **Сборка/проверка**: `lazbuild --build-all` — чисто (только pre-existing
  warning на `presetform:PurposeLabel`); winapp2test — без регрессий.

## 2026-09-20 — убран честный «инверт», парольная вкладка стартует пустой

- **«Инвертировать результат» убран из пресетов** (решение пользователя:
  «пресет — фильтр что чистить / что оставить»). `CheckedFor` был
  `PurposeOk and (SafetyOk xor cbInvert.Checked)` — это не комплемент
  выбранного подмножества, а выбор «назначения И хвоста от безопасности»:
  на пуле 5271 запись при цели {Windows ∩ Safe}+инверсия получалось 42
  записи вместо ожидаемого комплемента 5160. Фикс до комплемента через
  `not (PurposeOk and SafetyOk)` не применили — по решению пользователя
  просто удалили чекбокс. Ось теперь: `Result := PurposeOk and SafetyOk`.
  `QuickConfig` сокращена до 4 параметров.
- **Вкладка «Пароли и сессии» всегда стартует пустой** (решение
  пользователя): раньше `PopulateEntries` предотмечал обе вкладки по
  `E.Default and E.Detected`, и отказ в `ConfirmSecurityMark` «ничего не
  менял» — а свежие рискованные галки уже стояли с открытия клинера,
  выглядело как «запрос игнорируется». Теперь записи ней не
  предотмечены: безопасность заполняется только явным выбором
  (пресет/ПКМ/вручную, всё через подтверждение).
- **При отказе в подтверждении пресета** вкладка «Пароли и сессии» не
  трогается, остальное (вкладка «Очистка») применяется — поведение из
  2026-09-19 без изменения; с пустой стартовой отмеченностью оно стало
  честным и замечаемым.

## 2026-09-19 — пресеты-форма, взаимоисключение баз, path-классификация

- **Пресеты — отдельная модальная форма** `gui/presetform.pas`: выпадающее
  меню «Пресеты ▾» заменено формой с двумя осями «По назначению × По
  безопасности» (решение пользователя). Ось назначения — 9 групп
  `PresetPurposeKeys` (Windows, Browsers, Multimedia, Games, Utilities,
  Applications, Messaging, Languages, Other), ось безопасности — слайдер
  `slSafe/slCaution/slRisky` с чекбоксами. Семантика: **объединение внутри
  оси, пересечение между осями**; пустая ось = пустое множество. Быстрые
  кнопки: Рекомендуемые (все назначения ∧ только Safe ∧ OnlyInstalled),
  Установленные (все ∧ OnlyInstalled), Всё, Ничего (снять все чекбоксы оси,
  не просто «всё снять»); «Инвертировать результат» — комплемент; живой
  счётчик выбранных записей. Применение через `ApplyPresetSelection(F)`
  по `F.CheckedFor(E)`.
- **Классификация по назначению** `PresetPurposeOf` в `cs.winapp2`:
  сначала токены языка/игр по Name+Section — они перекрывают LangSecRef
  (баг-кейс «Language Files + 3021» теперь Languages, не Applications),
  затем case по `LangSecRef` (браузеры 3006/3022/3026–3029/3033–3035/
  3037–3039/3043/3044, мессенджеры 3030/3042, медиа 3023/3036/3040,
  утилиты 3024, Windows 3025, приложения 3021/3031), иначе текстовые
  токены, иначе Other.
- **Классификация по безопасности** `PresetSafetyOf`: Risky =
  Section с 'dangerous' ∨ purpose=Languages ∨ (Warning≠'' ∧ ¬Default);
  Caution = Warning≠'' ∨ ¬Default; иначе Safe.
- **Парольная вкладка — имя + пути** (решение пользователя):
  `IsSecurityEntryFor` = `IsSecurityEntry` по имени (SKIP-список первым,
  как раньше) ИЛИ совпадение токенов в `FileKey`/`RegKey` (`login data`,
  cookies, session storage, web data, autofill, passwords, password
  manager, keychain, credential). `PopulateEntries` фильтрует обе вкладки
  через `IsSecurityEntryFor`.
- **Аудит реальных баз**: merged-пул Def+W3+W2 = 5566; «Пароли и сессии»
  по имени 355, по имени+путям 503 — **+148 записей ушли из «Очистки»**
  (совпало с прогнозом, вкладка стала честнее).
- **Взаимоисключение источников**: `cbDefault` и `cbWinapp3` — связанные
  radio-стиль: включение любого из двух выключает другой с подтверждением
  (файлы удаляются безвозвратно, без корзины — решение пользователя,
  Default.ini остаётся «переработанным Winapp3» с обоими языками, дублей
  не объединяем). `LoadSettings` обёрнут в флаг `FLoading`, чтобы guard
  при загрузке не срабатывал.
- **Подтверждение «Всё»/пресета для парольной вкладки**:
  `ConfirmSecurityMark` — предупреждение о потере логинов/паролей,
  повторная авторизация; при отказе вкладка «Пароли и сессии» не трогается,
  остальные записи всё же применяются. ПКМ «Отметить всё» идёт через тот
  же путь (`SetAllEntries(True)`).
- **Тесты**: в `winapp2test.lpr` — пул из 9 синтетических записей
  (WebStorageN/LoginDataN/RegCredsN → security, CleanCacheN/RecoveryTool →
  нет, LangRule → Languages/risky, DangerWin → Windows/risky, SafeRule →
  safe, GameTrack → Games). ALL CHECKS PASSED.
- **Сборка**: `build.bat` в этой сессии падает на `windres --preprocessor=cat`
  (`cat` нет в PATH) — рабочая команда `lazbuild --build-all CleanSweep.lpi`
  (EXIT=0). Вопрос про обход в build.bat — при желании можно поправить.

## 2026-09-17 — старт порта FluentCleaner

- **Золотые правила** зафиксированы в `AGENTS.md` (не навреди / не упрощай /
  не гадай / чистый код / заметки / справка / творчество).
- **Разрядность**: собираем обе — i386-win32 и x64. Движок пишется с
  WOW64-обработкой (regview через `cs.registry`, FS-редирект через
  guard в `cs.pathexpand`), на x64 код просто работает нативно.
- **База Winapp2.ini**: внешний файл рядом с exe + вшитая копия в ресурсах
  (паттерн `leftover-signatures.json`). Вшивание — на фазе интеграции.
- **Заметки**: папка `docs/` — тематические .md (`port-plan.md`,
  `decisions.md`).
- **UI клинера**: отдельная форма `gui/cleanerform` (решено заранее).
- **Смоук-тест**: отдельный `test/winapp2test.lpr`, `smoketest.lpr`
  не трогаем — он про движок деинсталляции.

## 2026-09-17 — фаза 1 завершена

- **Модели как классы** в `cs.winapp2` (не record) — списки через
  `specialize TFPGObjectList` по конвенции `cs.models`.
- **`LangSecRef` = -1** означает «нет кода» (аналог `int?` в C#).
- **`%ProgramFiles%` → 64-bit PF** через `GetProgramFiles64`
  (`ProgramW6432`), фолбэк x86 — как в оригинале. В i386-сборке
  `CSIDL_PROGRAM_FILES` вернул бы x86-путь и сломал семантику.
- **WOW64 FS-редирект**: `TWow64FsGuard` грузит
  `Wow64Disable/RevertWow64FsRedirection` динамически — статический
  импорт убил бы запуск i386-exe на чистой 32-битной Windows.
- **Сплиттер путей ручной**, с пустыми сегментами (как `StringSplitOptions.None`)
  — иначе ломаются UNC `\\srv\share`.
- **RawText** собирается из обрезанных строк (как C# `AppendLine(line)`),
  хранится для «Show source».

## 2026-09-17 — фаза 2: Analyze готов

- **Реестровые виды — 64+32, но с фильтром разделения.** Второй (32-й)
  вид пробуется только где WOW64 реально разделяет ключ:
  `HKLM\SOFTWARE*`, `HKCR*`, `HKCU\SOFTWARE\CLASSES*` (`ViewSplitApplies`
  в `cs.regpath`). Для `HKCU`, `HKLM\SYSTEM` и пр. оба флага открывают
  один физический ключ → вторая проверка давала бы дубли в результате
  Analyze (баг пойман тестом `HKCU\Software → 2 вместо 1`). На x64
  поведение то же + находит 32-битные приложения; на i386 — то же самое.
  RegKey-цель тащит с собой `Access` вида, в котором найдена.
- **`TExclusionRule` — класс, не record**: `TFPGList<T>` для record
  требует оператор `=` (fgl.pp), а `TFPGObjectList` + класс — конвенция
  `cs.models`, чище.
- **Detect — OR, с early-out**: Detect/DetectFile/SpecialDetect
  проверяются по одному до первого совпадения (как оригинал).
- **SpecialDetect маппинг** на конкретные пути (Chrome/Firefox/Edge/…) —
  точный порт; `DET_WINSTORE` → наличие `%LocalAppData%\Packages`
  (как оригинал — есть на каждой Win10+).
- **Probe удаляемости**: `CreateFileW` с `FILE_SHARE_DELETE` — залоченные
  файлы не попадают в отчёт Analyze (как оригинал).

## 2026-09-17 — фаза 2: Clean готов

- **Прямое удаление** (`DeleteFile`, без корзины) — решение пользователя,
  как в оригинале и CCleaner.
- **Двойной safety-гейт**: `IsPathSafeToDelete`/`IsRegistryPathSafeToDelete`
  проверяются и в Analyze (честный отчёт), и повторно в Clean — план мог
  устареть между фазами.
- **Reg-delete через `cs.registry`**: `RegDeleteTree`/`RegDeleteValue`
  сами выставляют SAM (WOW64-биты из `Item.Access` + FULL/SET_VALUE) —
  отдельных write-хелперов не понадобилось.
- **`DeleteRegistryTreeExcept`** — точный порт: values чистятся всегда,
  ветка с защищённым потомком чистится рекурсивно, остальные — целиком
  через `RegDeleteTree`. Protected-список фильтруется по реально
  существующим ключам (быстрый путь целого дерева).
- **REMOVESELF-прунинг**: сбор всех подкаталогов → сортировка по убыванию
  длины пути → удаление пустых → корень последним. Reparse-точки не
  обходятся (защита от junction-петель).
- **Прогресс Clean**: строки `'Deleted: <path>'` / `'Registry: <item>'`
  без локализации — финальный текст решится на фазе UI через `cs.lang`.
- **`InitSafetyRoots` обязателен** перед использованием движка — тест
  вызывает его первым делом; GUI уже делает это при старте.

## 2026-09-17 — фаза 3: UI клинера

- **Форма модальная** (`ShowCleanerDialog` из меню «Клинер») — один
  движок, никакой конкуренции с деинсталлятором.
- **ListView вместо TreeView**: LCL TTreeView без чекбоксов (нужен
  TVS_CHECKBOXES-хак — против правил). Плоский список «запись|категория»,
  сортировка по (CatOrder, имя). Минус: нет чекбокса «вся категория» —
  потенциальное улучшение (спросить).
- **Результат = display-only**: как у оригинала — чекбоксы на записях,
  а не на файлах. Ревью = просмотр списка, выбор = на уровне записей.
- **Статусная очередь с отсеканием**: прогресс Clean идёт по файлу —
  очередь ограничена 100 строками, лишние статусы дропаются (косметика).
- **Владение результатами**: Analyze отдаёт `TCleanResultList` форме,
  Clean забирает его у формы (`FResults := nil`) — никаких двойных
  владельцев, паттерн `FScanThread.List := nil` из mainform.
- **`(!)` в имени записи** = есть `Warning=` в базе; полный текст —
  в статусной строке при выделении, сама запись — оранжевой
  (`OnCustomDrawItem`, цвет как lcModerate).
- **Параллельный движок**: детекция и Analyze режутся на слайсы —
  до 4 воркеров `TCleanerThread` (по числу CPU), у каждого свой
  `TDetectionService`/`TCleaningService` (они self-contained). Результаты
  мёржатся в форму через `Extract` (fgl без `OwnsObjects`). Clean
  остаётся однопоточным — удаление параллелить не стали.
- **Живой прогресс**: `DoneCount`/`Total` в воркерах + `tmrProgress`
  (150 мс) → реальный прогресс-бар; при чистке удалённые строки сереют
  вживую (`FRowMap` путь→item, `TRowInfo.Done`, серый цвет).
- **Сортировка колонок**: `CustomSort` + stdcall-компараторы (patтерн
  leftoverform), сортировка по размеру — по байтам из `TRowInfo`.
- **Пресеты**: кнопка «Пресеты ▾» — Рекомендуемые (`Default=`),
  Всё, Ничего; ПКМ по записям — + «Отметить категорию».

## Открытые вопросы

- Автопроверка обновлений при старте — пока только вручную?
- Winappx.ini (AppX-деблоатер) — пока только в планах.
- Чекбокс «вся категория» — решено меню «Отметить категорию».

## 2026-09-18 — обновление баз из сети

- **`src/cs.download.pas`** — загрузка через WinINet (`InternetOpenUrlW`,
  `INTERNET_FLAG_RELOAD | NO_CACHE_WRITE`, таймаут 30 с — как
  `HttpClient` в оригинале). Без OpenSSL — в отличие от fphttpclient.
  Скачивание в `<file>.part` + rename: обрыв не портит рабочую базу.
  Флаг отмены проверяется между чанками.
- **URL — те же, что у FluentCleaner** (`SettingsPageViewModel.cs`):
  Winapp2 и Winapp3 с raw.githubusercontent.com.
- **Мердж источников** — порядок `ResolveDatabasePaths`: сначала
  встроенные (winapp2: `data\` → exe-dir → ресурс; winapp3: только
  `data\`), потом пользовательская база; дедуп по имени записи —
  первая побеждает.
- **Настройки**: `CleanSweep.ini` рядом с exe (portable-стиль,
  как у оригинала): EnableWinapp2/3, EnableCustom, CustomPath.
- **UI**: панель баз вверху cleanerform — чекбоксы включения,
  инфо (записи · KB · дата — как `BuildFileInfo`), кнопки
  «Обновить»/«Обзор…»/«Перезагрузить». После успешной загрузки —
  автоматический reload + повторная детекция.

## 2026-09-18 — CLI, security-вкладка, пресеты

- **CLI**: `-c`/`/c` открывает клинер, `-h`/`/h`/`-?` — «О программе».
  Короткие флаги (`HasParam` в mainform), открытие отложено через
  `QueueAsyncCall` — метод объекта, не plain-процедура (ошибка 4025).
- **F1** → «О программе» (`miHelp.ShortCut=112` в главной форме,
  `FormKeyDown`+`KeyPreview` в cleanerform — там нет главного меню).
- **Меню**: «Очистка» вынесена из «Меню» на верхний уровень (между
  «Меню» и «?»).
- **Security-вкладка** «Пароли и сессии»: `IsSecurityEntry` в
  cs.winapp2 — эвристика по имени (password/credential/login/session/
  cookie/autolog/autofill/token/account) с исключениями ложных
  срабатываний (recovery, kracker, wi-fi drivers, accounting и т.д.).
  Анализ собирает чекнутые записи из ОБЕИХ вкладок.
- **Свои записи**: `SEC_EXTRA_INI` в cleanerform — «Windows Saved
  Credentials» (Credentials+Vault dirs, расширяет winapp2-запись) и
  «Wi-Fi Profiles» (Wlansvc\Profiles\*.xml). DPAPI-каталог `Protect`
  сознательно НЕ трогаем — его удаление ломает всё шифрование.
- **Все записи видны**: неопределённые (не установленные) — серые,
  пресеты: Рекомендуемые (Detected ∧ Default ∧ Warning='' — максимально
  безопасно), Установленные, Инвертировать, Всё, Ничего. Пресеты и ПКМ
  действуют на активную вкладку.
- **`TCleanerEntry.Detected`** — флаг пишется воркерами напрямую вместо
  отдельного списка FInstalled.
- **About**: кредит «движок на базе FluentCleaner» + кликабельная
  ссылка + строка параметров; чекбоксы баз подписаны «(FluentCleaner)».

## 2026-09-19 — DetectOS, Default.ini как источник, приоритет баз

- **Семантика DetectOS по ветке master winapp2ool** (README + `Trim.vb`,
  `checkDetOS`): `num|` = минимум, `|num` = максимум, `num1|num2` =
  диапазон (равные границы — строго). Оценка версии ОС — первая, провал
  отменяет Detect/DetectFile/SpecialDetect; при успехе и отсутствии
  остальных ключей запись видима. Версия считается как major*100+minor
  (10.0 → 1000). Форма без `|` (`DetectOS=6.0`) в спеке отсутствует
  (winapp2ool упал бы с IndexOutOfRange) — у нас lenient: читается как
  минимум. Гейт закрывается при невозможности получить версию ОС.
- **Определили** (не гадали): распарсено из данных — parser + гейт в
  `cs.winapp2.pas` / `cs.detect.pas`; кэш `RtlGetVersionW` (GetVersionEx
  на Win8.1+ без supportedOS в манифесте врёт и вернул бы 6.2 на Win10).
- **IsValidEntry**: DetectOS теперь считается критерием детекции —
  иначе «Search Charm History» и др. OS-only записи молча отфильтровались.
- **Default.ini — отдельный источник** (4-я строка панели баз, свой
  чекбокс `cbDefault`, `EnableDefault`, по умолчанию вкл, инфо-лейбл).
  Проверено: 1275/1284 секций проходят IsValidEntry; 3 OS-gated записи
  (Search Charm History, Windows Error Reporting, Thumbnail Cache);
  9 секций (RegEdit, Network Passwords, Memory Dumps и др.) не имеют
  детекции — отфильтрованы как неопределяемые, это by-design.
- **Приоритет источников при мёрдже (first-wins по имени), изменён**:
  Custom → Default → Winapp3 → Winapp2. Раньше было built-ins first,
  custom last. Внешние файлы идут до вшитого фолбэка (`data\` →
  exe-dir → RCDATA). Пересечение Default.ini с Winapp2.ini — 1 имя
  (`ApowerSoft Streaming Audio Recorder *`).
- **Фантом WinappCS.ini убран**: дефолтный CustomPath был
  `data\WinappCS.ini` (файла нет — при старте всегда «Custom DB not
  found»). Теперь путь пуст, пока пользователь не выберет базу.
- **Починены 4 строки данных** в `data\Default.ini`: `DetectOS=6.0` →
  по смыслу записи Game Explorer `6.0|6.0` (функция была только в Vista),
  WER / Thumbnail Cache `6.0|` (пути — Vista+); `DetectFile=%%LocalAppData%`
  (двойной `%` на 5458 → один `%`); заголовок «58 entries» → 1284.
- **Тесты**: в `winapp2test.lpr` добавлены парсинг-кейсы DetectOS
  (6.3|6.3→603, 6.0|→600, |10.0→1000, 6.0→min 600, 6.2.9200→602) и гейт
  (провал min/max скрывает, провал DetectOS сильнее живого Detect).
  ALL CHECKS PASSED против `data\Winapp2.ini`.
- **Живой счётчик «выбрано»**: статус после детекции
  «База: N · установлено: M · выбрано: K»; K пересчитывается при каждом
  изменении галочек (`OnItemChecked` обоих списков) и после пресетов.
  После Analyse счётчик не трогается — результаты уже посчитаны.
- **Пресеты и ПКМ — на обе вкладки** (решение пользователя): «Всё/Ничего/
  Рекомендуемые/Установленные/Инвертировать» и «Отметить категорию»
  применяются к обоим спискам сразу, а не к активной вкладке (ранее
  2026-09-18 было по-вкладкам). Counter показывал «выбрано» по двум
  вкладкам, а пресет — по одной: «Отметить всё» давало число меньше
  базы → выглядело как поломка.

## 2026-09-19 — главный баг: мёрдж терял половину базы

- **Симптом пользователя**: при одном источнике статус показывал
  2038 (W2) / 428 (W3) / 636 (Default) — ровно половину реальных
  чисел (4075 / 855 / 1275); при нескольких — только числа последней
  базы, объединения не было.
- **Корень**: цикл мёрджа в `wmLoad` (`gui/cleanerform.pas`) шёл
  **вперёд по индексу и одновременно вытаскивал записи через
  `Part.Extract(Part[J])`**. Extract сдвигает хвост списка влево,
  итератор перепрыгивал записи и догонял уменьшившуюся `Count` →
  цикл молча заканчивался на ~половине, либо падал `EListError:
  List index (2038) out of bounds` при парсинге следующего файла
  (2038 = «хвост» уже сокращённого списка). Парсинг одиночных
  файлов это не трогало, поэтому тесты (по одному файлу) всё не
  видели.
- **Фикс**: цикл идёт **назад** (`for J := Part.Count - 1 downto 0`),
  Extract/Delete с конца не ломает индексы оставшихся элементов;
  дубликаты отбрасываются через `Seen` (first-wins) и освобождаются
  `Part.Delete(J)`. Проверено: W2+W3 → 4930 уникальных, W2+W2 → 4075
  (дедуп), Default+W2 → 5271, крэшей нет.
- **Регрессия**: в `winapp2test.lpr` добавлен блок «Merge regression» —
  мёрдж одного и того же файла обязан вернуть все записи
  (`4075/4075`, раньше `2038/4075`), второй источник обязан добавить
  уникальные (`M23 > M22`). ALL CHECKS PASSED.

## 2026-09-19 — кэш детекции, custom-база, x64 движка

- **Кэш существования в `cs.detect`**: `CheckRegistry`/`CheckFile`
  теперь кэшируют вердикты (4 списка «есть»/«нет» для реестра и файлов,
  sorted-case-insensitive, O(log n) lookup). Срок жизни — один экземпляр
  `TDetectionService`, а он создаётся на каждый `wmDetect` →
  один скан, никакого протухания между прогонами. Объединённый пул
  (4930 записей) переспрашивает один и тот же Detect-ключ десятки раз.
- **Регрессия кэша**: повторный проход тем же сервисом обязан дать ту
  же картину — `cached repeat scan agrees (112=112)`. ALL CHECKS.
- **Custom-база под тестами**: `test\WinappCS.ini` (1275 записей)
  парсится и проверяется на пустые имена в `winapp2test.lpr`.
- **X64 движка**: кросс-компиляция движка в x86_64 раньше падала на
  `Masks` (unit из LazUtils, для win64 в окружении нет ни ppu, ни LCL).
  Решение: собрать нужные unit'ы LazUtils (`masks`, `lazutf8`,
  `lazunicode`, `lazutilsstrconsts`) из исходников под win64 в отдельный
  каталог (как это и делается для i386-версии lazutils почтампа) и
  компилировать движок с `-Px86_64 -Fu<каталог>`. `winapp2test_x64.exe`
  даёт **ALL CHECKS PASSED** нативно (4075/4930/1275/112, кэш 112=112).
- **GUI x64 — открыто**: бинарник GUI под win64 невозможен в текущем
  окружении — для него нужен win64-build LCL (в `C:\lazarus` его нет,
  только i386). Требует доустановки Lazarus/LCL под win64.

## 2026-09-21 — фаза 4: cookies, custom-правила, AppX, CCleaner-база, UTF-8

Сближение клинера с актуальным FluentCleaner (`main`, снапшот сент. 2026).
`/AUTO`/CLI/AI — осознанно не портируем (не запрошено, у нас свой UX).

- **UTF-8 без BOM**: `LoadTextFile` в `cs.utils` — BOM → UTF-8,
  валидный UTF-8 без BOM → UTF-8, иначе ANSI. Применена в
  `TWinapp2Parser.ParseFile` и загрузке/инфо баз в cleanerform
  (раньше `TStringList.LoadFromFile` читал базу как ANSI → кракозябры
  в именах записей с кириллицей).
- **`cs.winsqlite`** — динамическая обёртка `winsqlite3.dll`
  (LoadLibrary + GetProcAddress, UTF-16 API). **Грабля**: DLL
  экспортирует stdcall, а не cdecl как обычный sqlite3 — cdecl-
  декларация портит стек и падает со второго вызова. Без DLL
  (старше Win10) функции просто отчитываются «недоступно».
- **`cs.cookies`** — порт `CookieService.cs`: DiscoverStores
  (15 Chromium-корней + Firefox-профили), ScanDomains,
  DeleteDomains, TryCleanProtectedStore для клинера. Домены
  нормализуются (схема/юзеринфо/порт/точки срезаются, IDN →
  punycode через `IdnToAscii` + своя валидация STD3 — API сам
  невалидные имена не режет). Cookie-БД никогда не удаляется файлом:
  чистка только SELECT/DELETE внутри SQLite, сайдкары
  (`Cookies-wal/shm`, `Device Bound Sessions*`) защищены.
- **`cs.cleaner`**: свойство `CookieKeepList` + в `Clean` каждый
  плановый файл сначала идёт через `TryCleanProtectedStore` —
  распознанная БД чистится точечно (keep-list живёт), прочее —
  как раньше.
- **`gui/cookieform`** — менеджер кук: скан доменов по всем сторам,
  чек-лист keep-list, «Удалить не выбранные», импорт/экспорт
  списка в txt. Кнопка «Куки…» в cleanerform, список хранится в
  `CleanSweep.ini` `[Cookies] Keep=`.
- **Custom-папка**: `Custom\*.ini` рядом с exe (`.ini.disabled` —
  выключено). Парсер в permissive-режиме: записи без Detect* —
  легальны (always-true), с Detect* — фильтруются обычной
  детекцией. `gui/customform` — менеджер: вкл/выкл, новая запись,
  правка в INI-виде, открыть папку.
- **`cs.appx` + `data\Winappx.ini` + `gui/appxform`** — деблоатер
  UWP/MSIX: 46 записей из апстримного Winappx.ini, детект через
  `Get-AppxPackage`, удаление `Remove-AppxPackage` —
  powershell.exe `-NoProfile -ExecutionPolicy Bypass`, вывод
  читается из pipe.
- **CCleaner-база**: `data\CCleaner.ini` (724 мигрированные записи)
  — пятый источник с чекбоксом в панели баз; приоритет
  Custom → CCleaner → Default → Winapp3 → Winapp2, first-wins дедуп
  по имени. Состояние в `CleanSweep.ini`.
- **Тесты** (`winapp2test`): UTF-8 с BOM/без BOM/имена записей,
  permissive/strict парсинг записей без детекции, нормализация
  доменов (схема/wildcard/порт/юзеринфо/мусор), Winappx — 46/46.
  В specialtest проверка dead-shortcut смягчена до
  «action ⇔ есть ссылки» (на чистом десктопе 0 — не фейл).
- **Сборка**: `lazbuild` — OK, `winapp2test`/`specialtest`/
  `smoketest` — ALL CHECKS PASSED.

### 2026-09-21 — фикс: AppX-скан висел на дедлоке пайпа

`RunPs` (cs.appx) вызывал `TProcess.Execute` с `poWaitOnExit` и читал
stdout только ПОСЛЕ завершения процесса. `Get-AppxPackage` выводит
сотни имён — буфер пайпа (~4 КБ) переполнялся, PowerShell блокировался
на записи, а мы ждали его выхода → вечный дедлок, форма висла.

Фикс: `poWaitOnExit` убран; stdout и stderr дренажатся в цикле
`while P.Running` (`NumBytesAvailable` → `Read`, сон 20 мс), хвост
дочитывается после выхода. stderr дренажится, но не попадает в AOut —
строки ошибок иначе засорили бы список имён пакетов. Таймаут 120 с →
`P.Terminate`, возврат -2. Проверено: `(Get-AppxPackage).Name`
отрабатывает за ~1.9 с, 51 имя.

### 2026-09-21 — фикс customform + справка по синтаксису

- **Баг удаления**: `ListItem.Data` хранил индекс файла с 0 — у первого
  файла `Data=nil`, `SelectedPath` возвращал '' и «Удалить»/«Вкл-выкл»
  молча не работали. Храним индекс 1-based.
- **`docs\custom-rules.md`** — справка по синтаксису Custom-правил
  (все ключи, FileKey/RegKey/ExcludeKey, %vars%, RECURSE/REMOVESELF,
  примеры, безопасность).
- Кнопка **«Справка»** в диалоге «Свои правила» открывает этот .md
  ассоциированным приложением; без файла — встроенная шпаргалка
  в MessageDlg (портабельность).

### 2026-09-21 — визуальный редактор правил (ruleeditform)

- **`gui/ruleeditform`** — модальный редактор записи: имя, категория,
  Default, Warning, 4 вкладки (FileKey / RegKey / ExcludeKey /
  детекция). Кнопка **«Проверить…»** собирает ini-текст, парсит его
  и прогоняет настоящий `TCleaningService.Analyze` — предпросмотр
  показывает ровно то, что попадёт в план (файлы, реестр, байты),
  с теми же safety-гейтами; удаление не выполняется.
- **`EntryToIni`** (cs.winapp2) — сериализатор записи обратно в ini
  (канонический вид, комментарии/форматирование не сохраняются);
  `ParseDetectOS` вынесен в интерфейс.
- **customform**: «Новая запись…» теперь открывает редактор (старый
  skeleton-генератор удалён); новая кнопка **«Изменить…»** открывает
  выбранный файл. Файл с несколькими записями — выбор записи, остальные
  сериализуются обратно без изменений семантики (комментарии теряются).
- Регрессия: round-trip тест в `winapp2test` — все поля записи
  переживают сериализацию и повторный парсинг. ALL CHECKS PASSED.

### 2026-09-21 — AppX в главном меню + правка записей из клинера

- **Вид «Системные» инвертирован**: галка показывает ТОЛЬКО системные
  компоненты, без неё — обычные программы. Скан всегда идёт с
  IncludeSystem=True, фильтрация — в PopulatePrograms
  (`TInstalledProgram.IsSystem`).
- **AppX — пункт верхнего меню** между «Меню» и «Очистка»: открывает
  готовую `appxform` (та же, что была в клинере — кнопка оттуда
  убрана). Вариант с синтетическими `TInstalledProgram` в общем списке
  был собран и откачен: дублировал форму, где уже есть чекбоксы,
  массовое удаление и статусы установленности; список деинсталлятора
  оставлен однородным. В `appxform` добавлена кнопка «Отметить всё»
  (toggle: только установленные строки; повторное нажатие снимает всё).
- **«Править запись…»** в контекстном меню списка клинера: custom-
  запись открывает свой файл в редакторе (`TCleanerEntry.SourceFile`),
  встроенная — клонируется в `Custom\<имя>.ini` через `EntryToIni`
  (custom побеждает при мёрдже → оригинал базы не трогаем) и правится.
  После редактора — ReloadDatabases.

### 2026-09-21 — appxform: только установленные + баг OnItemChecked

- **appxform показывает только установленные записи** Winappx.ini:
  колонка «Статус» удалена, форма 520×430. Скан + заполнение слиты в
  `Refresh`; неустановленные строки в таблицу не попадают (удалять там
  нечего). «Отметить всё» — простой toggle всех строк.
- **Баг «Отметить всё» → «Удалить» неактивна**: на Win32 программный
  `Item.Checked :=` НЕ вызывает `OnItemChecked` (его шлёт виджетсет
  только на клик пользователя) — `btnRemove` обновляется вручную после
  цикла. В cleanerform такого бага нет — там после массовых отметок
  всегда вызывается `RefreshSelectionInfo`.
- **Диалоги переведены на .lfm** (правило: все формы редактируются в
  визуальном дизайнере, `TForm.CreateNew` в gui/ не используем):
  - `pickform` — выбор записи при правке ini с несколькими секциями;
  - `previewform` — предпросмотр плана Analyze в редакторе правил.
- **CleanSweep.lpi**: зарегистрированы юниты, которые добавлялись без
  записей (cookieform, customform, appxform, ruleeditform, pickform,
  previewform, cs.winsqlite, cs.cookies, cs.appx) — теперь видны в
  инспекторе проекта и открываются дизайнером из дерева.

### 2026-09-21 — списки записей клинера на TVirtualStringTree

- `lvEntries` и `lvSec` переведены с TListView на **TLazVirtualStringTree**
  (пакет `laz.virtualtreeview_package` — штатный компонент Lazarus,
  без OPM-зависимостей; зарегистрирован в RequiredPackages .lpi).
  Мотив: TListView тормозит на 5000+ записей, VST рисует только
  видимые строки.
- Узел несёт `TEntNode{E, Cat}` — категория резолвится один раз при
  наполнении (раньше сортировка дёргала ResolveCategory на каждое
  сравнение). Строка в NodeData → `Initialize`/`Finalize` в
  OnInitNode/OnFreeNode.
- Сортировка: `SortTree` сам применяет направление — `OnCompareNodes`
  всегда сравнивает ascending (категория для колонки 1, имя — tiebreak).
- Грабли: `CheckState[Node] :=` вызывает `OnChecked` на КАЖДУю ноду —
  массовые отметки под `FCheckGuard`, `RefreshSelectionInfo` один раз
  в конце (в отличие от TListView, где программный Checked молчит —
  см. баг выше: ровно противоположное поведение!).
- Поведение сохранено: сортировка по клику на колонку, серые
  недетектированные, оранжевые с Warning=, предупреждение в статусе
  по фокусу, pmEntries, saved-selection, security-таб без предотметки.
- exe вырос 1.69 → 1.95 МБ (VST влинкован).

  Дополнение (тот же день): первая версия дала ПУСТОЙ список —
  `AddChild` создаёт ноду лениво, `OnInitNode` срабатывал при первой
  отрисовке и `Initialize` затирал уже записанные `E`/`Cat`. Фикс:
  `ReinitNode(N, False)` сразу после `AddChild` — нода инициализируется
  до записи данных. Правило: в VST данные ноды либо пишутся внутри
  OnInitNode, либо после явной инициализации — между AddChild и
  GetNodeData ничего «само» не происходит.

### 2026-09-21 — live-exe guard в сканере остатков

- **Проблема**: совпавшая по имени папка (InstallLocation, ProgramData
  и т.п.) удалялась целиком — даже когда внутри лежал рабочий `.exe`
  программы (незавершённая/неудачная деинсталляция или портабельная
  копия). Наличие запускаемого exe = «это не хвосты».
- **Правило** (`DirHasLiveExe` в cs.leftovers): каталог, содержащий
  хотя бы один «живой» `.exe`, принудительно уходит в `lcRisky` +
  снятая отметка. Имена-заглушки инсталляторов не считаются живыми:
  `unins*`, `uninst*`, `uninstall*`, `setup*`, `install*`, `msiexec`,
  `wiseun*`, `remove*` (уже есть `IsGenericInstallerName`) — каталог
  с одним лишь `unins000.exe` остаётся обычным хвостом.
- Отдельно найденный `.exe`-файл (не installer-имя) — тоже review-only.
- Заслон двойной: `lcRisky` не только снимает галку — `cs.uninstall`
  (строки ~503/579) отказывается удалять risky даже при выставленной
  отметке.
- Обход каталога: рекурсивно, без reparse-точек, кап 4000 узлов —
  ранний выход на первом живом exe.
- Тест: smoketest создаёт %TEMP%\cs_smoke\Live (app.exe) и \Dead
  (unins000.exe) — проверяет risky/safe вердикты.

### 2026-09-24 — temp-политика, runnable-гард, close-apps, DPI/EcoQoS

**Temp = мусорное пространство** (`cs.safety`):

- `GTempRoots` собирает `%TEMP%`, `%TMP%` (каждый через `ExpandEnvVars` —
  могут указывать на разные каталоги), `GetTempDir(False)` и
  `Windows\Temp`. `IsTempPath`/`IsTempRoot` — хелперы поверх списка.
- `TScanContext.OwnedByOther` не признаёт владельца под Temp: программа
  вроде Commfort с `InstallLocation = %TEMP%` больше не «владеет» всей
  временной папкой и не щитит чужой мусор (реальный фейл smoketest).
- `ScanTempFolders` итерирует ВСЕ Temp-корни, не только текущий `%TEMP%`.
- Сами корни Temp неудаляемы: ни `IsPathSafeToDelete`, ни REMOVESELF-
  прюнинг (`TryPruneEmptyDirs`) их не тронут.
- Логины/пароли/сессии — только вкладка «Пароли и сессии» со своим
  keep-list пайплайном; общие Temp-правила их не трогают.

**Runnable-гард** (`cs.cleaner.FindFiles`):

- Файл с расширением `.exe .msi .com .scr .bat .cmd .ps1 .vbs`
  стейджится только если паттерн FileKey ЯВНО кончается этим
  расширением (`*.exe`, `setup.exe` — `ExplicitlyTargetsExt`).
  `*.*`/`*` больше не захватывают бинарники — портабельные и
  установленные программы не попадают под чистку (был реальный
  инцидент у пользователя).
- Live-exe guard сканера остатков сохранён и работает выше по стеку.

**Close-apps** (`cs.closeapps` + `closeappsform`):

- Перед чисткой (BtnCleanClick клинера и удаление доменов в менеджере
  кук) снапшот процессов сопоставляется с чистимым: таблица
  keyword→exe (браузеры, мессенджеры, медиа, Steam) + exe внутри
  чистимого корня (портабельки).
- Модальный диалог с чекбоксами: «Закрыть выбранные» / «Не закрывать» /
  «Отмена». Закрытие: `WM_CLOSE` всем окнам → 8 с → `TerminateProcess`.
  Каждое закрытие пишется в лог (`Closed app:` / `FAILED to close app:`).
- Свой pid и pid 0/4 исключены всегда (проверка в smoketest).
- Таблица покрывает частые случаи; приложение вне таблицы и вне
  чистимых корней не предлагается — расширение = одна строка.

**EcoQoS / фоновое сканирование** (`cs.utils.DisablePowerThrottling`):

- Windows паркует фоновый процесс на E-ядра (Efficiency Mode) — долгий
  скан выглядел «приостановленным». Фикс: `SetProcessInformation(
  ProcessPowerThrottling, ControlMask=EXECUTION_SPEED, StateMask=0)`
  из `.lpr` до `Application.Initialize`. Через `GetProcAddress` — на
  старой Windows no-op.

**DPI**:

- Манифест: `dpiAwareness=permonitorv2` + `dpiAware=true/pm` (фолбэк).
  Раньше пара `true/pm` + `system` давала приоритет `system` — окно
  мыло на мониторах с нестандартным DPI.
- `GetShellIconPx` (SHDefExtractIconW, Vista+): иконки в реальных
  пикселях — список 48px, карточка 64px, кнопки 48px; фолбэк на
  SHGetFileInfo. `Scaled=True` у `ilPrograms`/`ilButtons`.
- `.lpi`: `AboutForm` получил `ComponentName`/`ResourceBaseClass` —
  виден в дизайнере как форма, а не юнит.

### 2026-09-24 — use-after-free: слетали отметки после «Правила…»

- **Симптом**: пресет «Рекомендуемые» → «выбрано: 303» → открыть
  «Правила…» → «Закрыть» → «выбрано: 0», причём недетерминированно.
- **Причина**: `WorkerDone` (wmLoad) делал `FEntries.Free`, а ноды
  `lvEntries`/`lvSec` продолжали хранить `D^.E` на освобождённые
  записи. `PopulateEntries` вызывал `SnapshotChecked` → `EntOf(N).Name`
  читал висячий указатель → в `FSavedSelection` попадал мусор →
  при восстановлении не совпало ни одно имя → все галки сняты.
  Недетерминизм: освобождённая heap-память иногда ещё содержит
  старые строки, и баг маскировался.
- **Фикс**: снапшот отметок (`SnapshotChecked` → FSavedSelection/
  FSavedSec, `FSelSaved := True`) делается в `WorkerDone` ДО
  `FEntries.Free`, сразу после — `lvEntries.Clear`/`lvSec.Clear`
  (ноды ссылаются на умирающий пул). Блок снапшота из
  `PopulateEntries` убран — при входе деревья всегда пусты.
- **Попутно**: `FResults[].Entry` — тоже невладеющий указатель в тот
  же пул. Перезагрузка баз теперь сбрасывает список ревью
  (`FResults.Clear` + `lvResults` + `FRowInfos`/`FRowMap`) — план
  анализа от старого поколения баз всё равно невалиден.
- **Правило**: любое представление, держащее указатели в FEntries
  (ноды VST, TCleanResult.Entry), должно умирать ДО или ВМЕСТЕ с
  пулом. Снапшоты — только пока пул жив.

### 2026-09-24 — глубокий аудит логики: найденные баги и фиксы

Полный проход по движку и GUI: заглушек и TODO не найдено
(`TForm.CreateNew` — легитимный вызов базового конструктора для
`TProgCard`, у которого нет ресурса-формы).

- **Cookie-SQL (cs.cookies)**: `BuildDomainExpression` строил
  OR-цепочку через `Parts.Text` — завершающий CRLF превращался в
  хвостовой ` OR ` → `incomplete input` → каждое удаление кук молча
  проваливалось (except → False). Переписано явной конкатенацией.
- **Прюнинг пустых каталогов (cs.cleaner)**: `TryPruneEmptyDirs`
  ходил по всему поддереву REMOVESELF-корня и проверял root только
  по IsTempRoot. Теперь: корень неудаляем → вся его ветвь не
  трогается; сам корень проверяется через IsPathSafeToDelete.
- **Exact-only safety roots (cs.safety)**: добавлен список
  `GExactRoots` — C:\Windows, Program Files, Program Files (x86),
  ProgramData, ProgramData\Microsoft\Windows защищены сами, но
  содержимое оценивается. Битый InstallLocation=C:\Program Files
  больше не может стать целью очистки.
- **Идемпотентность и fail-closed (cs.safety)**: `InitSafetyRoots`
  ретурнит при повторном вызове (раньше утекали списки);
  `IsPathSafeToDelete`/`IsTempPath`/`IsTempRoot` возвращают
  безопасное-значение до инициализации вместо AV.
- **%LocalLowAppData% (cs.pathexpand)**: раньше раскрывался в
  `Local\..\LocalLow` — `NormalizePath` отвергал `..\` → все
  LocalLow-правила молча не работали. Теперь резолвится через
  родителя LocalAppData.
- **OwnedByOther (cs.leftovers)**: корень-владелец валидируется
  через IsPathSafeToDelete — кривой InstallLocation вроде C:\ или
  C:\Program Files у чужой программы больше не щитит остатки.
- **AppX-инъекция (cs.appx)**: `AppxRemove` экранирует `'` в
  PackageName — значение приходит из пользовательского Winappx.ini.
- **CloseApp (cs.closeapps)**: OpenProcess=0 больше не означает
  «уже завершён» — access denied на живом процессе теперь
  отличается от реально мёртвого (проверка через лёгкий OpenProcess).
- **Исключения в потоках (gui/mainform)**: `TUninstallThread` и
  `TScanThread.Execute` ловят Exception и пишут её в лог — раньше
  крах движка уходил в FatalException молча, а UI рисовал
  «завершено».
- **LoadSignatures (cs.signatures)**: битый пользовательский JSON
  теперь не роняет FormCreate — GetJSON в try/except.
- **ruleeditform.lfm**: привязан OnDestroy — FEntries раньше утекал
  при каждом открытии диалога.
- **Версия**: 1.0.0.1 → 1.0.1.0 (CleanSweep.rc, CleanSweep.manifest,
  aboutform.pas).

Покрытие: smoketest — exact-only корни; winapp2test —
%LocalLowAppData% резолвится в реальный каталог без `..\`.
