unit cs.utils;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Windows, cs.models;

{ Returns a known folder (CSIDL) — replaces .NET SpecialFolder.
  Note: in a 32-bit process CSIDL_PROGRAM_FILES resolves to the x86 folder;
  use GetProgramFiles64 for the native 64-bit root. }
function GetSpecialFolder(ACsidl: Integer): string;

{ Real 64-bit Program Files even from a 32-bit process. }
function GetProgramFiles64: string;

{ Expands %VAR% environment strings (Unicode-safe). }
function ExpandEnvVars(const S: string): string;

{ Reads a whole text file with explicit encoding detection: UTF-8 BOM,
  UTF-8 without BOM (validated — cleaner databases are saved that way),
  legacy ANSI otherwise. TStringList.LoadFromFile is unreliable here:
  its default encoding depends on the runtime codepage. Returns '' when
  the file is missing. }
function LoadTextFile(const APath: string): string;

{ Normalizes a filesystem path: expands env vars, resolves to absolute,
  trims trailing separator. Returns '' for invalid input. }
function NormalizePath(const APath: string): string;

{ True when APath equals ARoot or sits inside it (case-insensitive). }
function IsSamePathOrDescendant(const APath, ARoot: string): Boolean;

{ Extracts the executable file name from a command line,
  handling quoted and unquoted forms. }
function ExtractExeName(const ACommandLine: string): string;

{ True when the attributes mark a reparse point (junction/symlink). }
function IsReparsePoint(const APath: string): Boolean;

{ Recursive file enumeration that never follows reparse points.
  Appends full paths to AOut. }
procedure SafeEnumFiles(const ARoot, AMask: string; AOut: TStrings);

{ Recursive subdirectory enumeration, deepest-first, skipping reparse
  points — suitable for bottom-up deletion. }
procedure SafeEnumDirs(const ARoot: string; AOut: TStrings);

{ Directory size in bytes, skipping reparse points; -1 on failure. }
function DirectorySize(const ARoot: string): Int64;

{ Single file size in bytes; 0 on failure. }
function GetFileSizeBytes(const APath: string): Int64;

{ Exe paths of processes running under ADir (TLHelp32 snapshot). }
function RunningProcessesUnder(const ADir: string): TStringList;

{ Audit trail: appends a timestamped UTF-8 line to CleanSweep.log
  next to the exe (falls back to %TEMP% if the dir is read-only). }
procedure LogToFile(const AMsg: string);

{ Resolves the program's icon source: DisplayIcon value (may contain
  ",index" and %env% vars), else the uninstaller exe. Returns file path
  and icon index. }
function ProgramIconSource(AProgram: TInstalledProgram;
  out APath: string): Integer;

{ Small shell icon for APath (uses the exe's own icon for executables;
  generic file icon as fallback). Caller must DestroyIcon. }
function GetShellSmallIcon(const APath: string; AIndex: Integer): HICON;
{ Same but the large (32px) icon. }
function GetShellLargeIcon(const APath: string; AIndex: Integer): HICON;
{ Icon rendered at exactly APx pixels (SHDefExtractIcon, Vista+).
  Falls back to small/large shell icons when the API is missing.
  Caller must DestroyIcon. }
function GetShellIconPx(const APath: string; AIndex: Integer;
  APx: Integer): HICON;

{ Opts this process out of Windows EcoQoS power throttling so
  background scans are not parked on E-cores / efficiency mode.
  No-op when SetProcessInformation is unavailable (pre-Win8). }
procedure DisablePowerThrottling;

{ Normalizes InstallDate from registry to 'YYYY.MM.DD';
  understands 'YYYYMMDD' and 'Mon DD, YYYY' formats. }
function NormalizeInstallDate(const S: string): string;

{ Opens Explorer on a file/folder (selects the file). }
procedure ShowInExplorer(const APath: string);

{ Opens regedit positioned at APath (HKLM\... style). }
procedure ShowInRegedit(const APath: string);

const
  CSIDL_APPDATA      = $001A;
  CSIDL_LOCAL_APPDATA= $001C;
  CSIDL_COMMON_APPDATA = $0023;
  CSIDL_PROGRAM_FILES= $0026;
  CSIDL_PROGRAM_FILESX86 = $002A;
  CSIDL_PROGRAM_FILES_COMMON = $002B;
  CSIDL_PROGRAM_FILES_COMMONX86 = $002C;
  CSIDL_WINDOWS      = $0024;
  CSIDL_SYSTEM       = $0025;
  CSIDL_PROGRAMS     = $0002;
  CSIDL_COMMON_PROGRAMS = $0017;
  CSIDL_DESKTOPDIRECTORY = $0010;
  CSIDL_COMMON_DESKTOPDIRECTORY = $0019;
  CSIDL_PROFILE      = $0028;

implementation

uses
  ShlObj, StrUtils, ActiveX, JwaTlHelp32, Registry, ShellApi;

function GetSpecialFolder(ACsidl: Integer): string;
var
  Buf: array[0..MAX_PATH] of WideChar;
  PIDL: PItemIDList;
begin
  Result := '';
  Buf[0] := #0;
  if SHGetSpecialFolderLocation(0, ACsidl, PIDL) <> S_OK then Exit;
  try
    if SHGetPathFromIDListW(PIDL, Buf) then
      Result := UTF8Encode(WideString(Buf));
  finally
    CoTaskMemFree(PIDL);
  end;
end;

function GetProgramFiles64: string;
begin
  Result := SysUtils.GetEnvironmentVariable('ProgramW6432');
  if Result = '' then
    Result := SysUtils.GetEnvironmentVariable('ProgramFiles');
end;

function ExpandEnvVars(const S: string): string;
var
  WS: WideString;
  Buf: array[0..32767] of WideChar;
  N: DWORD;
begin
  WS := UTF8Decode(S);
  Buf[0] := #0;
  N := ExpandEnvironmentStringsW(PWideChar(WS), Buf, Length(Buf));
  if (N > 0) and (N <= DWORD(Length(Buf))) then
    Result := UTF8Encode(WideString(Buf))
  else
    Result := S;
end;

{ Strict UTF-8 validator: rejects stray continuation bytes, overlong
  forms (C0/C1), truncated sequences and >U+10FFFF lead bytes. Pure
  ASCII validates too — it decodes identically either way. }
function IsValidUtf8(const S: RawByteString): Boolean;
var
  I, N: Integer;
  B: Byte;

  function Cont(AIdx: Integer): Boolean;
  begin
    Result := (AIdx <= N) and (Byte(S[AIdx]) and $C0 = $80);
  end;

begin
  I := 1;
  N := Length(S);
  while I <= N do
  begin
    B := Byte(S[I]);
    if B < $80 then
      Inc(I)
    else if (B >= $C2) and (B <= $DF) then
    begin
      if not Cont(I + 1) then Exit(False);
      Inc(I, 2);
    end
    else if (B >= $E0) and (B <= $EF) then
    begin
      if (not Cont(I + 1)) or (not Cont(I + 2)) then Exit(False);
      Inc(I, 3);
    end
    else if (B >= $F0) and (B <= $F4) then
    begin
      if (not Cont(I + 1)) or (not Cont(I + 2)) or
         (not Cont(I + 3)) then Exit(False);
      Inc(I, 4);
    end
    else
      Exit(False);
  end;
  Result := True;
end;

function LoadTextFile(const APath: string): string;
var
  FS: TFileStream;
  Raw: RawByteString;
begin
  Result := '';
  if not FileExists(APath) then Exit;
  FS := TFileStream.Create(APath, fmOpenRead or fmShareDenyNone);
  try
    SetLength(Raw, FS.Size);
    if FS.Size > 0 then
      FS.ReadBuffer(Raw[1], FS.Size);
  finally
    FS.Free;
  end;
  if Raw = '' then Exit;
  if (Length(Raw) >= 3) and (Raw[1] = #$EF) and (Raw[2] = #$BB) and
     (Raw[3] = #$BF) then
    Exit(UTF8Encode(UTF8Decode(Copy(Raw, 4, MaxInt))));
  if IsValidUtf8(Raw) then
    Result := UTF8Encode(UTF8Decode(Raw))
  else
    Result := AnsiToUtf8(Raw);
end;

function NormalizePath(const APath: string): string;
var
  Expanded: string;
begin
  Result := '';
  if Trim(APath) = '' then Exit;
  Expanded := ExpandEnvVars(APath);
  if Length(Expanded) < 3 then Exit;
  if not ((Expanded[2] = ':') or
          ((Expanded[1] = '\') and (Expanded[2] = '\'))) then Exit;
  if Pos('..\', Expanded) > 0 then Exit;
  if (Length(Expanded) >= 3) and
     (Copy(Expanded, Length(Expanded) - 2, 3) = '\..') then Exit;
  Result := ExcludeTrailingPathDelimiter(ExpandFileName(Expanded));
end;

function IsSamePathOrDescendant(const APath, ARoot: string): Boolean;
var
  P, R: string;
begin
  P := NormalizePath(APath);
  R := NormalizePath(ARoot);
  if (P = '') or (R = '') then Exit(False);
  if SameText(P, R) then Exit(True);
  Result := Pos(LowerCase(R) + '\', LowerCase(P)) = 1;
end;

function ExtractExeName(const ACommandLine: string): string;
var
  S: string;
  P, I: Integer;
begin
  Result := '';
  S := Trim(ACommandLine);
  if S = '' then Exit;

  if S[1] = '"' then
  begin
    P := PosEx('"', S, 2);
    if P > 1 then
      Result := Copy(S, 2, P - 2);
  end
  else
  begin
    P := Pos(' ', S);
    if P = 0 then P := Length(S) + 1;
    Result := Copy(S, 1, P - 1);
    if Pos('.exe', LowerCase(Result)) = 0 then
    begin
      I := Pos('.exe', LowerCase(S));
      if I > 0 then
        Result := Copy(S, 1, I + 3);
    end;
  end;
  Result := ExtractFileName(Result);
end;

function IsReparsePoint(const APath: string): Boolean;
var
  Attr: DWORD;
begin
  Attr := GetFileAttributesW(PWideChar(UTF8Decode(APath)));
  Result := (Attr <> INVALID_FILE_ATTRIBUTES) and
            ((Attr and FILE_ATTRIBUTE_REPARSE_POINT) <> 0);
end;

procedure SafeEnumFiles(const ARoot, AMask: string; AOut: TStrings);
var
  SR: TSearchRec;
  R: Integer;
  SubDirs: TStringList;
  I: Integer;
  Full: string;
begin
  if not DirectoryExists(ARoot) then Exit;
  SubDirs := TStringList.Create;
  try
    R := FindFirst(IncludeTrailingPathDelimiter(ARoot) + '*', faAnyFile, SR);
    try
      while R = 0 do
      begin
        if (SR.Name <> '.') and (SR.Name <> '..') then
        begin
          Full := IncludeTrailingPathDelimiter(ARoot) + SR.Name;
          if (SR.Attr and faDirectory) <> 0 then
          begin
            if (SR.Attr and FILE_ATTRIBUTE_REPARSE_POINT) = 0 then
              SubDirs.Add(Full);
          end
          else if (AMask = '*') or
                  (Pos(LowerCase(AMask), LowerCase(SR.Name)) > 0) then
            AOut.Add(Full);
        end;
        R := FindNext(SR);
      end;
    finally
      SysUtils.FindClose(SR);
    end;
    for I := 0 to SubDirs.Count - 1 do
      SafeEnumFiles(SubDirs[I], AMask, AOut);
  finally
    SubDirs.Free;
  end;
end;

procedure SafeEnumDirs(const ARoot: string; AOut: TStrings);
var
  SR: TSearchRec;
  R: Integer;
  Full: string;
begin
  if not DirectoryExists(ARoot) then Exit;
  R := FindFirst(IncludeTrailingPathDelimiter(ARoot) + '*', faDirectory, SR);
  try
    while R = 0 do
    begin
      if (SR.Name <> '.') and (SR.Name <> '..') and
         ((SR.Attr and faDirectory) <> 0) then
      begin
        Full := IncludeTrailingPathDelimiter(ARoot) + SR.Name;
        if (SR.Attr and FILE_ATTRIBUTE_REPARSE_POINT) = 0 then
        begin
          SafeEnumDirs(Full, AOut);
          AOut.Add(Full);
        end;
      end;
      R := FindNext(SR);
    end;
  finally
    SysUtils.FindClose(SR);
  end;
end;

function DirectorySize(const ARoot: string): Int64;
var
  Files: TStringList;
  I: Integer;
  SR: TSearchRec;
begin
  Result := 0;
  Files := TStringList.Create;
  try
    SafeEnumFiles(ARoot, '*', Files);
    for I := 0 to Files.Count - 1 do
    begin
      if FindFirst(Files[I], faAnyFile, SR) = 0 then
      begin
        Inc(Result, SR.Size);
        SysUtils.FindClose(SR);
      end;
    end;
  finally
    Files.Free;
  end;
end;

function GetFileSizeBytes(const APath: string): Int64;
var
  SR: TSearchRec;
begin
  Result := 0;
  if FindFirst(APath, faAnyFile, SR) = 0 then
  begin
    Result := SR.Size;
    SysUtils.FindClose(SR);
  end;
end;

var
  GLogPath: string = '';
  GLogCS: TRTLCriticalSection;

procedure LogToFile(const AMsg: string);
var
  F: TextFile;
begin
  EnterCriticalSection(GLogCS);
  try
    if GLogPath = '' then
    begin
      GLogPath := ChangeFileExt(ParamStr(0), '.log');
      try
        AssignFile(F, GLogPath);
        if FileExists(GLogPath) then Append(F) else Rewrite(F);
        CloseFile(F);
      except
        GLogPath := SysUtils.GetEnvironmentVariable('TEMP') +
                    '\CleanSweep.log';
      end;
    end;
    try
      AssignFile(F, GLogPath);
      if FileExists(GLogPath) then Append(F) else Rewrite(F);
      SetTextCodePage(F, CP_UTF8);
      WriteLn(F, FormatDateTime('yyyy-mm-dd hh:nn:ss', Now) + '  ' + AMsg);
      CloseFile(F);
    except
      // logging must never break the app
    end;
  finally
    LeaveCriticalSection(GLogCS);
  end;
end;

function ProgramIconSource(AProgram: TInstalledProgram;
  out APath: string): Integer;
var
  S, T: string;
  P: Integer;
  W: WideString;
  Buf: array[0..4095] of WideChar;
begin
  Result := 0;
  S := Trim(AProgram.DisplayIconPath);
  if S = '' then
    S := Trim(ExtractExeName(AProgram.UninstallString));
  S := StringReplace(S, '"', '', [rfReplaceAll]);
  if Pos('%', S) > 0 then
  begin
    W := UTF8Decode(S);
    FillChar(Buf, SizeOf(Buf), 0);
    if ExpandEnvironmentStringsW(PWideChar(W), Buf, 4096) > 0 then
      S := UTF8Encode(WideString(Buf));
  end;
  P := LastDelimiter(',', S);
  if (P > 0) and (P < Length(S)) then
  begin
    T := Copy(S, P + 1, MaxInt);
    if StrToIntDef(T, MaxInt) <> MaxInt then
    begin
      Result := StrToInt(T);
      S := Copy(S, 1, P - 1);
    end;
  end;
  APath := S;
end;

function GetShellSmallIcon(const APath: string; AIndex: Integer): HICON;
var
  FI: TSHFileInfoW;
  W: WideString;
  Ic: HICON;
  Num: UINT;
begin
  Result := 0;
  W := UTF8Decode(APath);
  if AIndex <> 0 then
  begin
    Ic := 0;
    Num := ExtractIconExW(PWideChar(W), AIndex, nil, @Ic, 1);
    if (Num > 0) and (Ic <> 0) then Exit(Ic);
  end;
  if FileExists(APath) then
  begin
    if SHGetFileInfoW(PWideChar(W), 0, FI, SizeOf(FI),
         SHGFI_ICON or SHGFI_SMALLICON) <> 0 then
      Exit(FI.hIcon);
  end;
  if SHGetFileInfoW(PWideChar(W), FILE_ATTRIBUTE_NORMAL, FI, SizeOf(FI),
       SHGFI_ICON or SHGFI_SMALLICON or SHGFI_USEFILEATTRIBUTES) <> 0 then
    Result := FI.hIcon;
end;

function GetShellLargeIcon(const APath: string; AIndex: Integer): HICON;
var
  FI: TSHFileInfoW;
  W: WideString;
  Ic: HICON;
  Num: UINT;
begin
  Result := 0;
  W := UTF8Decode(APath);
  if AIndex <> 0 then
  begin
    Ic := 0;
    Num := ExtractIconExW(PWideChar(W), AIndex, @Ic, nil, 1);
    if (Num > 0) and (Ic <> 0) then Exit(Ic);
  end;
  if FileExists(APath) then
  begin
    if SHGetFileInfoW(PWideChar(W), 0, FI, SizeOf(FI),
         SHGFI_ICON or SHGFI_LARGEICON) <> 0 then
      Exit(FI.hIcon);
  end;
  if SHGetFileInfoW(PWideChar(W), FILE_ATTRIBUTE_NORMAL, FI, SizeOf(FI),
       SHGFI_ICON or SHGFI_LARGEICON or SHGFI_USEFILEATTRIBUTES) <> 0 then
    Result := FI.hIcon;
end;

type
  TSHDefExtractIconW = function(pszIconFile: LPCWSTR; iIndex: Integer;
    uFlags: UINT; phiconLarge, phiconSmall: PHICON;
    nIconSize: UINT): HRESULT; stdcall;

function GetShellIconPx(const APath: string; AIndex: Integer;
  APx: Integer): HICON;
var
  Fn: TSHDefExtractIconW;
  W: WideString;
  HR: HRESULT;
begin
  Result := 0;
  Fn := TSHDefExtractIconW(GetProcAddress(GetModuleHandle('shell32.dll'),
    'SHDefExtractIconW'));
  if @Fn <> nil then
  begin
    W := UTF8Decode(APath);
    HR := Fn(PWideChar(W), AIndex, 0, @Result, nil, APx);
    if (HR = S_OK) and (Result <> 0) then Exit;
    if Result <> 0 then
    begin
      DestroyIcon(Result);
      Result := 0;
    end;
  end;
  if APx >= 32 then
    Result := GetShellLargeIcon(APath, AIndex)
  else
    Result := GetShellSmallIcon(APath, AIndex);
end;

procedure DisablePowerThrottling;
const
  ProcessPowerThrottling = 4;
  PROCESS_POWER_THROTTLING_EXECUTION_SPEED = $1;
type
  TSetProcessInformation = function(hProcess: THandle;
    ProcessInformationClass: DWORD; ProcessInformation: Pointer;
    ProcessInformationSize: DWORD): BOOL; stdcall;
  TProcPowerThrottlingState = record
    Version: ULONG;
    ControlMask: ULONG;
    StateMask: ULONG;
  end;
var
  Fn: TSetProcessInformation;
  St: TProcPowerThrottlingState;
begin
  Fn := TSetProcessInformation(GetProcAddress(GetModuleHandle('kernel32.dll'),
    'SetProcessInformation'));
  if @Fn = nil then Exit;
  St.Version := 0;
  St.ControlMask := PROCESS_POWER_THROTTLING_EXECUTION_SPEED;
  St.StateMask := 0;
  Fn(GetCurrentProcess, ProcessPowerThrottling, @St, SizeOf(St));
end;

function NormalizeInstallDate(const S: string): string;
const
  Mon: array[1..12] of string = ('jan','feb','mar','apr','may','jun',
    'jul','aug','sep','oct','nov','dec');
var
  D, M, Y, P: Integer;
  T: string;
begin
  Result := S;
  T := Trim(S);
  if (Length(T) = 8) and (StrToIntDef(T, -1) >= 19000101) then
    Exit(Copy(T, 1, 4) + '.' + Copy(T, 5, 2) + '.' + Copy(T, 7, 2));
  // 'Sep 16, 2026' style
  for M := 1 to 12 do
    if Pos(Mon[M], LowerCase(T)) = 1 then
    begin
      P := Pos(' ', T);
      if P = 0 then Break;
      T := Copy(T, P + 1, MaxInt);
      T := StringReplace(T, ',', '', [rfReplaceAll]);
      P := Pos(' ', T);
      if P = 0 then Break;
      D := StrToIntDef(Copy(T, 1, P - 1), 0);
      Y := StrToIntDef(Copy(T, P + 1, MaxInt), 0);
      if (D > 0) and (Y > 1900) then
        Result := Format('%.4d.%.2d.%.2d', [Y, M, D]);
      Exit;
    end;
end;

procedure ShowInExplorer(const APath: string);
var
  W: WideString;
begin
  if DirectoryExists(APath) then
    ShellExecuteW(0, 'open', PWideChar(UTF8Decode(APath)), nil, nil, SW_SHOW)
  else if FileExists(APath) then
  begin
    W := UTF8Decode('/select,"' + APath + '"');
    ShellExecuteW(0, 'open', 'explorer.exe', PWideChar(W), nil, SW_SHOW);
  end;
end;

procedure ShowInRegedit(const APath: string);
var
  R: TRegistry;
begin
  // regedit has no path CLI arg; it opens at "LastKey" written here.
  try
    R := TRegistry.Create(KEY_WRITE);
    try
      R.RootKey := HKEY_CURRENT_USER;
      if R.OpenKey('SOFTWARE' + '\' + 'Microsoft' + '\' + 'Windows' + '\' +
                   'CurrentVersion' + '\' + 'Applets' + '\' + 'Regedit',
                   True) then
      try
        R.WriteString('LastKey', APath);
      finally
        R.CloseKey;
      end;
    finally
      R.Free;
    end;
  except
  end;
  ShellExecuteW(0, 'open', 'regedit.exe', nil, nil, SW_SHOW);
end;

function RunningProcessesUnder(const ADir: string): TStringList;
var
  Snap, Proc: THandle;
  PE: TProcessEntry32W;
  Buf: array[0..MAX_PATH] of WideChar;
  Sz: DWORD;
  Root, ExePath: string;
begin
  Result := TStringList.Create;
  Result.Duplicates := dupIgnore;
  Result.CaseSensitive := False;
  Result.Sorted := True;
  Root := LowerCase(ExcludeTrailingPathDelimiter(NormalizePath(ADir)));
  if Root = '' then Exit;
  Snap := CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if Snap = INVALID_HANDLE_VALUE then Exit;
  try
    PE.dwSize := SizeOf(PE);
    if Process32FirstW(Snap, PE) then
      repeat
        Proc := OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False,
                            PE.th32ProcessID);
        if Proc <> 0 then
        try
          Sz := Length(Buf);
          Buf[0] := #0;
          if QueryFullProcessImageNameW(Proc, 0, Buf, @Sz) then
          begin
            ExePath := LowerCase(NormalizePath(UTF8Encode(WideString(Buf))));
            if (ExePath = Root) or (Pos(Root + '', ExePath) = 1) then
              Result.Add(ExePath);
          end;
        finally
          CloseHandle(Proc);
        end;
      until not Process32NextW(Snap, PE);
  finally
    CloseHandle(Snap);
  end;
end;


initialization
  InitCriticalSection(GLogCS);

finalization
  DoneCriticalSection(GLogCS);

end.
