unit pickform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls;

type

  { Generic "pick one of N" dialog — used when a custom ini holds
    several entries and the user chooses which to edit. }
  TPickForm = class(TForm)
    lbItems: TListBox;
    pnlButtons: TPanel;
    btnOk: TButton;
    btnCancel: TButton;
    procedure FormCreate(Sender: TObject);
    procedure LbItemsDblClick(Sender: TObject);
  end;

{ Returns the chosen index or -1 on cancel/empty. }
function PickIndex(AOwner: TComponent; const ACaption: string;
  const AItems: TStrings): Integer;

implementation

uses
  cs.lang;

{$R *.lfm}

function PickIndex(AOwner: TComponent; const ACaption: string;
  const AItems: TStrings): Integer;
var
  F: TPickForm;
begin
  Result := -1;
  if AItems.Count = 0 then Exit;
  if AItems.Count = 1 then Exit(0);
  F := TPickForm.Create(AOwner);
  try
    if ACaption <> '' then F.Caption := ACaption;
    F.lbItems.Items.Assign(AItems);
    F.lbItems.ItemIndex := 0;
    if F.ShowModal = mrOk then
      Result := F.lbItems.ItemIndex;
  finally
    F.Free;
  end;
end;

procedure TPickForm.FormCreate(Sender: TObject);
begin
  btnOk.Caption := Lg('Выбрать', 'Выбраць', 'Обрати', 'Select');
  btnCancel.Caption := Lg('Отмена', 'Адмена', 'Скасувати', 'Cancel');
end;

procedure TPickForm.LbItemsDblClick(Sender: TObject);
begin
  if lbItems.ItemIndex >= 0 then ModalResult := mrOk;
end;

end.
