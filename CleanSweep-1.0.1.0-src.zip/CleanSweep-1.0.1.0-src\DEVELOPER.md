# CleanSweep — руководство разработчика

Портабельный деинсталлятор для Windows: запускает штатный деинсталлятор
программы, находит остатки (файлы, реестр, задачи, службы, автозагрузка,
ярлыки) и удаляет их после ручного ревью. Одним exe-файлом, без
внешних зависимостей.

- **Стек**: Free Pascal 3.2.2 + Lazarus (LCL, виджетсет Win32)
- **Цель**: `i386-win32` (32-бит; WOW64-доступ к 64-битному реестру через
  `KEY_WOW64_64KEY`)
- **Артефакт**: `CleanSweep.exe` (~4.5 МБ), требует админ-права
  (`requireAdministrator` в манифесте)

---

## 1. Сборка

```bat
build.bat
```

Скрипт делает два шага:

1. `windres` собирает `CleanSweep.res` из `CleanSweep.rc` (манифест,
   иконка, version info, вшитый JSON сигнатур).
2. `lazbuild --build-all CleanSweep.lpi` — **полная** пересборка.

> ⚠️ `--build-all` обязателен: FPC не считает `.lfm` зависимостью юнита,
> поэтому инкрементальная сборка вшивает устаревшую копию формы из
> `lib\*.lfm`. Полная сборка занимает ~3 сек — инкрементальность не нужна.

**Зависимости**: только LCL + `laz.virtualtreeview_package` (Virtual
String Tree — штатный пакет в составе Lazarus, не OPM). Списки записей
клинера (`lvEntries`, `lvSec`) — `TLazVirtualStringTree`: нода несёт
`TEntNode{E, Cat}`, программный `CheckState` стреляет `OnChecked`
(массовые отметки — под `FCheckGuard`), направление сортировки
применяет сам `SortTree`. Остальные списки — обычный `TListView`.

**Smoke-тест** (логика без GUI):

```bat
cd test
fpc -Fu"..\src" -Fu"C:\lazarus\components\lazutils\lib\i386-win32" -FE. smoketest.lpr
smoketest.exe
fpc -Fu"..\src" -Fu"C:\lazarus\components\lazutils\lib\i386-win32" -FE. winapp2test.lpr
winapp2test.exe ..\data\Winapp2.ini
fpc -Fu"..\src" -Fu"C:\lazarus\components\lazutils\lib\i386-win32" -FE. specialtest.lpr
specialtest.exe
```

`specialtest` проверяет специальную очистку (`Special=RecycleBin` /
`Special=DeadShortcuts`) и работает **только в режиме Analyze** — он не
вызывает `Clean`, чтобы не опустошить реальную корзину.

**Залоченный exe**: если CleanSweep запущен (он админский — убить его
из обычной сессии нельзя), сборка падает с `Can't create object file ...
error code: 5`. Обход: `mv CleanSweep.exe CleanSweep_prev.exe` — запущенный
файл можно переименовать, сборка создаст новый.

---

## 2. Структура репозитория

```
CleanSweep\
├─ CleanSweep.lpr        — точка входа
├─ CleanSweep.lpi        — проект Lazarus
├─ CleanSweep.rc         — ресурсы (см. §4)
├─ CleanSweep.manifest   — манифест: requireAdministrator + DPI + longPath
├─ build.bat             — сборка
├─ icon.ico              — иконка приложения (MAINICON)
├─ data\
│  ├─ leftover-signatures.json — сигнатуры остатков (см. §4.3)
│  ├─ Winapp2.ini            — база клинера (см. §4.4)
│  ├─ Winapp3.ini            — база клинера (winapp3)
│  ├─ Default.ini            — переработанный Winapp3 с дополнениями (RU+EN)
│  ├─ CCleaner.ini           — мигрированные записи CCleaner (724)
│  └─ Winappx.ini            — база AppX-деблоатера (46 UWP-пакетов)
├─ gui\
│  ├─ mainform.pas/.lfm      — главное окно: список, меню, потоки
│  ├─ progcard.pas/.lfm      — карточка программы (даблклик)
│  ├─ leftoverform.pas/.lfm  — ревью найденных остатков
│  ├─ cleanerform.pas/.lfm   — клинер: записи → анализ → ревью → чистка
│  ├─ presetform.pas/.lfm    — пресеты: оси «назначение × безопасность»
│  ├─ cookieform.pas/.lfm    — менеджер кук: домены, keep-list, чистка
│  ├─ customform.pas/.lfm    — менеджер Custom\*.ini (вкл/выкл/удалить)
│  ├─ ruleeditform.pas/.lfm  — визуальный редактор правила + preview
│  ├─ pickform.pas/.lfm      — диалог «выбрать запись» (мульти-запись ini)
│  ├─ previewform.pas/.lfm   — read-only просмотр плана Analyze
│  ├─ appxform.pas/.lfm      — AppX-деблоатер (Winappx.ini)
│  ├─ closeappsform.pas/.lfm — диалог «закрыть приложения» перед чисткой
│  └─ aboutform.pas/.lfm     — «О программе»
├─ src\
│  ├─ cs.models.pas      — модели данных, без логики
│  ├─ cs.registry.pas    — реестр: чтение/удаление, WOW64, инвентарь
│  ├─ cs.leftovers.pas   — сканеры остатков (файлы + реестр)
│  ├─ cs.safety.pas      — белые списки: что удалять ЗАПРЕЩЕНО
│  ├─ cs.signatures.pas  — загрузка/матчинг сигнатур JSON
│  ├─ cs.uninstall.pas   — движок: запуск деинсталлятора, удаление
│  ├─ cs.utils.pas       — пути, shell-иконки, процессы, лог
│  ├─ cs.lang.pas        — локализация RU/BE/UK/EN (см. §6)
│  ├─ cs.winapp2.pas     — winapp2-порт: модели + парсер + категории
│  ├─ cs.pathexpand.pas  — winapp2-порт: %Var% + wildcard-пути, WOW64-guard
│  ├─ cs.regpath.pas     — winapp2-порт: reg-пути, hive-парсинг, WOW64-виды
│  ├─ cs.detect.pas      — winapp2-порт: Detect/DetectFile/SpecialDetect
│  ├─ cs.cleaner.pas     — winapp2-порт: Analyze/Clean движок + exclusions
│  ├─ cs.download.pas    — загрузка обновлений баз через WinINet
│  ├─ cs.winsqlite.pas   — динам. обёртка winsqlite3.dll (stdcall!)
│  ├─ cs.cookies.pas     — cookie-сторы браузеров, keep-list, чистка
│  ├─ cs.closeapps.pas   — «закрыть приложения»: поиск блокирующих
│  │                      процессов + классификация user/system/critical
│  ├─ cs.netfix.pas      — сетевой ремонт: 11 операций (flush DNS/ARP/
│  │                      NetBIOS, сброс Winsock/TCP/IP, route -f,
│  │                      release/renew, рестарт адаптеров), RunNetCommand
│  └─ cs.appx.pas        — парсер Winappx.ini + Remove-AppxPackage
├─ tcplugin\             — WFX-плагин для Total Commander (деинсталлятор,
│  │                      без клинера): csuninst.dpr, csun_vfs.pas,
│  │                      build.bat → bin\csuninst.wfx64 + .wfx.
│  │                      LCL не нужен — UI рисует TC; движок cs.* общий.
├─ docs\
│  ├─ user-guide.md      — справка пользователя
│  ├─ port-plan.md       — план порта FluentCleaner, фазы и статус
│  ├─ decisions.md       — лог решений и изменений (по датам)
│  ├─ cleaner-comparison.md — сравнение с FluentCleaner/CCleaner
│  └─ custom-rules.md    — справка по синтаксису Custom\*.ini
└─ test\
   ├─ smoketest.lpr      — консольный смоук движка деинсталляции
   ├─ winapp2test.lpr    — смоук-тест winapp2-парсера и экспандера
   └─ specialtest.lpr    — специальная очистка: корзина + мёртвые ярлыки
```

Порт движка winapp2-очистки из эталона `FluentCleaner-classic\` ведётся
по плану в `docs\port-plan.md`; правила работы — в `AGENTS.md`.

Игнорируется git: `lib/` (объекты), `*.res`, `*.exe`, `*.lps`,
`CleanSweep.log`, `backup/` (бэкапы IDE).

---

## 3. Архитектура и поток данных

```
СТАРТ
  │  ScanInstalledPrograms()        — реестр → TProgramList (в TScanThread)
  ▼
СПИСОК ──даблклик──▶ TProgramCard ──«Деинсталлировать»──▶
  ▼
TUninstallThread
  │  TUninstallEngine.Uninstall()
  │    1. RunProcessAndWait(vendor uninstaller)   — Job Object (см. ниже)
  │    2. TScanContext                            — снимок инвентаря
  │    3. TRegistryLeftoverScanner + TFileLeftoverScanner → TScanResult
  ▼
TLeftoverForm (модальный ревью: чекбоксы, confidence-цвета)
  │  «Удалить выбранное»
  ▼
TUninstallEngine.DeleteLeftovers()
  │  файлы → корзина (SHFileOperationW), реестр → RegDeleteTree/Value
  ▼
перескан инвентаря
```

### Потоки

- `TScanThread` — инвентаризация реестра в фоне, `OnTerminate` →
  `InventoryDone` переносит `List` в `FPrograms`.
- `TUninstallThread` — обёртка над `TUninstallEngine`. Статусы копятся в
  `FStatusQueue` под `TRTLCriticalSection` и сливаются в GUI через
  `Queue()`; прогресс — `Queue()` на `pbProgress`.
- **Никогда не вызывай `WaitFor`** из главного потока: в `OnTerminate`
  поток уже заблокирован внутри `DoTerminate` — дедлок. В деструкторе
  формы потоки только отцепляются (`OnTerminate := nil`,
  `FreeOnTerminate := True`).

### Job Object — почему

Деинсталляторы Inno (`unins*.exe` → `%TEMP%\_iu*.tmp`) и NSIS (`Au_.exe`)
копируют себя во временную папку, запускают копию и **немедленно
завершаются**. `WaitForSingleObject` на главный процесс отпускал бы
раньше времени — скан остатков стартовал при ещё открытом окне
деинсталлятора. Поэтому процесс назначается в Job Object
(`CreateJobObjectW` + `AssignProcessToJobObject`), после выхода главного
ждём опустения `JobObjectBasicProcessIdList` — ловит всех потомков.
Общий дедлайн: `UNINSTALLER_TIMEOUT_MS` = 30 мин.

### Скан-превью без деинсталляции

Контекстное меню программы → **«Найти остатки (без удаления)…»** —
прогоняет `TUninstallEngine.ScanOnly`: тот же `RunLeftoverScan`
(общий хвост `Uninstall`), но без запуска деинсталлятора и без
удаления — предпросмотр того, что останется. Глубина берётся из меню
**«Глубина поиска остатков»** (Быстрый/Стандартный/Глубокий →
smSafe/smModerate/smAdvanced). ScanOnly-ветка `UninstallDone` пишет
«Поиск остатков завершён» и не обновляет инвентарь.

---

## 4. Ресурсы (`CleanSweep.rc`)

```rc
1 24 "CleanSweep.manifest"        ; манифест
MAINICON ICON "icon.ico"          ; иконка
LEFTOVERSIG RCDATA "data\leftover-signatures.json"  ; вшитые сигнатуры
WINAPP2 RCDATA "data\Winapp2.ini"  ; вшитая база клинера (см. §4.4)
DEFAULTDB RCDATA "data\Default.ini" ; вшитая стандартная база (см. §4.4)
1 VERSIONINFO ...                 ; FreeTm / 1.0.1.0 / FreeForAll
```

### 4.1. `{$R *.res}` в `.lpr` — не трогать

Всё вышеперечисленное линкуется только через `{$R *.res}` в
`CleanSweep.lpr`. Удалишь строку — потеряешь манифест (админ-права!),
иконку, версию и сигнатуры.

> ⚠️ **Не включай галочку «Use manifest / DPI awareness» в опциях
> проекта Lazarus** (`<XPManifest>` в `.lpi`). IDE сгенерирует свой
> `CleanSweep.manifest` поверх нашего — и `requireAdministrator`,
> и `dpiAware`, и `{$R *.res}` посыпятся. DPI уже работает через наш
> манифест + `Application.Scaled := True`.

### 4.2. Манифест

- `requireAdministrator` — нужен для HKLM, служб, чужих HKU.
- `dpiAware=true/pm` + `dpiAwareness=system` — Win10+ использует
  `system`; в паре с `Application.Scaled` интерфейс масштабируется
  чётко, без блюра.
- `longPathAware` — пути > 260 символов.
- common-controls v6 — темы оформления.

### 4.3. Сигнатуры остатков

`data\leftover-signatures.json` вшит в exe как RCDATA `LEFTOVERSIG`.
При старте (`TMainForm.Create`) приоритет отдаётся **внешнему** файлу
рядом с exe (`data\...` или `leftover-signatures.json`) — сигнатуры
можно править без пересборки; нет файла → читается вшитая копия
(`TResourceStream`, как в DocSigner). Формат:

```json
[{ "name": "...", "aliases": [...],
   "filePaths": ["%APPDATA%\\..."], "registryPaths": ["HKCU\\..."] }]
```

### 4.4. База клинера Winapp2.ini

`data\Winapp2.ini` вшит в exe как RCDATA `WINAPP2` (порт движка
FluentCleaner — см. `docs\port-plan.md`). При открытии формы клинера
(`cleanerform`) приоритет отдаётся **внешнему** файлу рядом с exe
(`data\Winapp2.ini`, затем `Winapp2.ini`) — базу можно обновить без
пересборки; нет файла → читается вшитая копия.

Тот же механизм у `data\Default.ini` (RCDATA `DEFAULTDB`): файл имеет
приоритет, ресурс — фолбэк. Отличие в восстановлении: если файл
отсутствует, при загрузке баз он **автоматически записывается** на
диск из ресурса (`RestoreDbFromResource`), а кнопка «Сбросить» рядом
с `cbDefault` перезаписывает файл заводской копией (подтверждение
`MessageDlg`) — сброс пользовательских правок стандартной базы.

Движок: `cs.winapp2` (парсер), `cs.pathexpand` (%Var% + wildcard),
`cs.regpath` (hive-сплит + WOW64-виды), `cs.detect` (установлено ли),
`cs.cleaner` (Analyze → ревью → Clean). Реестр проверяется в 64-битном
виде всегда и в 32-битном — только там, где WOW64 реально разделяет
ключ (`HKLM\SOFTWARE`, `HKCR`, `HKCU\SOFTWARE\CLASSES`). Файловые
операции — под `TWow64FsGuard`. Удаление прямое, без корзины, через
двойной гейт `cs.safety` (в Analyze и повторно в Clean).

Базы читаются через `LoadTextFile` (cs.utils): UTF-8 BOM, UTF-8 без
BOM (все базы сохранены так), фолбэк ANSI — `TStringList.LoadFromFile`
здесь ненадёжен, его кодировка зависит от runtime codepage.

Обновление баз — `cs.download` (WinINet, без OpenSSL): кнопки
«Обновить» на панели баз в cleanerform качают Winapp2/Winapp3 с тех же
URL, что и FluentCleaner, пишут в `data\*.ini` через `.part`-файл.
Источники: Custom-папка, CCleaner, Default, Winapp3, Winapp2 (дедуп
по имени записи, первый побеждает; приоритет Custom → CCleaner →
Default → Winapp3 → Winapp2).
**Default и Winapp3 взаимоисключают друг друга** — включение одного
выключает второй с подтверждением (они пересекаются; Default = переработанный
Winapp3 с RU/EN-языками, дедуплицировать их нельзя). Настройки в
`CleanSweep.ini` рядом с exe.

Вкладка «Пароли и сессии»: `IsSecurityEntryFor` (cs.winapp2) отсекает
записи про пароли/логины/сессии/cookies/токены/креденшелы в отдельную
вкладку — по имени записи **и по токенам в FileKey/RegKey** (`login data`,
`session storage`, `web data`, `autofill`, `keychain`, `credential` и т.д.),
так что путь-классификация ловит и те, что маскируются по имени. Свои
записи добавляются константой `SEC_EXTRA_INI` в cleanerform (сейчас:
Windows Credentials + Wi-Fi Profiles; `Protect` DPAPI-каталог не трогаем
нарочно). Рядом живёт `SYS_EXTRA_INI` — встроенные записи, всегда в
пуле независимо от источников: `[Recycle Bin *]` (Special=RecycleBin —
в базах есть только в Default.ini, который исключает Winapp3),
`[User Temp Files *]` и `[Windows Temp Files *]` (записей на TEMP
в winapp2 нет вообще — у CCleaner это нативная чистка). Вкладка **всегда стартует пустой** — записи ней не
предотмечены, их выбирают только явно (пресетом или вручную). Любой путь,
который её отметил (пресет, «Отметить всё»), идёт через подтверждение
`ConfirmSecurityMark`; при отказе вкладка «Пароли и сессии» не трогается,
остальное (вкладка «Очистка») применяется. Без подтверждения пароли/логины
не становятся отмеченными никогда.

**Специальная очистка** (`Special=` в базе): записи без FileKey/RegKey,
которые движок (`cs.cleaner`) обрабатывает как операции уровня ОС. Коды —
`SPECIAL_RECYCLEBIN` ('RecycleBin') и `SPECIAL_DEADSHORTCUTS`
('DeadShortcuts'), приходят из `data\Default.ini` (`[Recycle Bin *]`,
`[Desktop Dead Shortcuts *]`, обе — Windows/Safe). Analyze зондирует живое
состояние: корзина через `SHQueryRecycleBinW` (пустая → запись не ставится
в очередь), ярлыки — только верхний уровень `%USERPROFILE%\Desktop` и
`%PUBLIC%\Desktop`, резолв цели через COM `IShellLinkW` + `IPersistFile`
(прямые импорты `ole32`, локальные `S_OK`/`S_FALSE` в cs.cleaner,
`IShellLinkW` из RTL `shlobj`); в очередь попадают только ярлыки с
физически отсутствующей целью. Clean опустошает корзину одним вызовом
`SHEmptyRecycleBinW` (без диалога/прогресса/звука); мёртвые ярлыки
удаляются как обычные файлы плана. «Корзина» показывается отдельной
строкой в результатах Analyze; отметки вкладки «Очистка» и последний
применённый пресет запоминаются в `CleanSweep.ini`
(`[Selection]`/`[Unchecked]`/`[Presets]`), вкладка «Пароли и сессии»
не сохраняется никогда. Выбор хранится **дельтой от `Default=`**:
`[Selection]` — все отмеченные, `[Unchecked]` — снятые вопреки
`Default and Detected`; запись вне обоих списков получает заводскую
отметку — иначе новые записи базы приходили бы без галки (баг с
%TEMP%-записями, 2026-09-25). Ручные галочки переживают
`ReloadDatabases`: перед пересборкой списка `SnapshotState` снимает
живое состояние в ту же пару списков (флаг `FSelSaved`), так что
«снять всё» не откатывается на `Default=` — сессионный снимок, в ini
пишется только при закрытии формы.

**Куки** (`cs.cookies` + `cs.winsqlite`): cookie-базы браузеров не
удаляются файлом — `TCleaningService.Clean` прогоняет каждый плановый
путь через `TryCleanProtectedStore`, распознанная БД чистится DELETE'ом
внутри SQLite с учётом keep-list (`CookieKeepList`, хранится в
`CleanSweep.ini`), сайдкары (`Cookies-wal`, `Device Bound Sessions*`)
защищены от удаления вообще. `winsqlite3.dll` подключается динамически
(LoadLibrary) — на системах без неё фича молча недоступна, обычная
чистка работает. **Внимание: entry points stdcall, не cdecl.**
Менеджер кук — `cookieform` (кнопка «Куки…» в cleanerform): скан
доменов по всем сторам, keep-list, импорт/экспорт txt.

**Custom-правила**: `Custom\*.ini` рядом с exe — записи без
Detect*/DetectFile легальны (считаются установленными всегда);
с критериями — фильтруются обычной детекцией. `*.ini.disabled` —
выключенный файл. Редактор — `customform` (кнопка «Правила…»).
Записи баз можно массово склонировать в Custom для изучения/правки:
Ctrl/Shift-выбор в списке → «В Custom» / контекстное «Копировать в
Custom» — каждая запись в свой `Custom\<имя>.ini` (EntryToIni),
мёрж перекрывает оригинал.

**Закрытие приложений перед Clean** (`cs.closeapps` + `closeappsform`):
`FindAppsToClose` матчит запущенные процессы по keyword-таблице имён
записей (браузеры/Steam…) и по exe под чистимым корнем FileKey. Каждый
процесс классифицируется `TAppKind`: **akUser** — обычное приложение
(чёрный, отмечен); **akSystem** — exe под `%WinDir%`, но не критический
(синий, отмечен); **akCritical** — флаг `IsProcessCritical` (kernel32,
динамически) или имя в `CriticalExeNames` (smss/csrss/wininit/winlogon/
services/lsass/lsaiso/svchost/dwm/fontdrvhost/sihost…) — **красный, без
галки, внизу списка**; попытка отметить → предупреждение о крахе
системы с подтверждением. `CloseApp` — WM_CLOSE всем окнам, 8 с,
затем TerminateProcess. Закрытие идёт параллельно
(`TCloseAppThread` на приложение, `CloseAppsInParallel` ведёт
прогресс-бар и статус «Закрыто N из M»). Перед `wmClean`
останавливается оболочка — `StopShell` убивает все `explorer.exe`,
предварительно продублировав её токен (`DuplicateTokenEx` →
primary). После чистки `StartShell` запускает **`userinit.exe`**
через `CreateProcessWithTokenW` — оболочка возвращается
непривилегированной, под токеном пользователя (фолбэк:
elevated-запуск → explorer.exe; страховка в деструкторе формы).

**AppX** (`cs.appx` + `appxform`, пункт «AppX» в верхнем меню главного
окна): база `data\Winappx.ini` (46 пакетов), детект/удаление через
`powershell.exe -NoProfile -ExecutionPolicy Bypass`
(`Get-AppxPackage`/`Remove-AppxPackage`), вне плана файлов/реестра.
Форма показывает только записи, установленные у текущего пользователя
(неустановленные не выводятся — удалять там нечего): чекбоксы,
«Отметить всё», удаление отмеченных.

Пресеты — модальная форма `presetform`: две оси «назначение ×
безопасность» (+OnlyInstalled): объединение внутри оси, пересечение
между осями (`CheckedFor = PurposeOk and SafetyOk`; «Инвертировать
результат» удалён 2026-09-20, см. decisions.md). Классификация —
`PresetPurposeOf`/`PresetSafetyOf`
(распределение реальных баз: 5566 записей, «Пароли и сессии» = 503 = 355
по имени + 148 пойманных путями).

Параметры командной строки: `-c` — сразу открыть клинер,
`-h` — «О программе». F1 открывает «О программе» из любой формы.
```

---

## 5. Движок — ключевые юниты

### `cs.models` — модели

| Тип | Назначение |
|---|---|
| `TInstalledProgram` | запись Uninstall-ветки: пути, размер, `Source` |
| `TLeftoverItem` | кандидат на удаление: `Path`, `ItemType`, `Confidence`, `IsSelected` |
| `TScanResult` | `RegistryLeftovers` + `FileLeftovers` (owning lists) |
| `TUninstallResult` | `Outcome`, `ExitCode`, `Output`, `Scan` |

Особенность: для `ltRegistryValue` реальный родительский ключ лежит в
`KeyPath` — **имена значений могут содержать `\`**, поэтому `Path`
нельзя резать по последнему бэкслэшу.

### `cs.registry` — реестр

- `REGVIEW_64` / `REGVIEW_32` — явные виды для 32-битного процесса
  (`KEY_WOW64_64KEY`).
- `RegOpenRead` возвращает `nil`, если ключа нет — везде проверка.
- `ScanInstalledPrograms` обходит `HKLM` (native + WOW6432), `HKCU`,
  загруженные `HKU`-SID; `AIncludeSystem` фильтрует SystemComponent.
- `RegForceDeleteValue` — фолбэк с `takeown`-логикой для ключей,
  доступных только SYSTEM.

### `cs.leftovers` — сканеры

Архитектурно отличается от исходного DeepPurge:

- **`TScanContext`** — единый снимок на операцию: инвентарь без цели,
  наборы владения, термы поиска. Строится один раз, используется обоими
  сканерами (оригинал перечитывал реестр на каждый сканер).
- **Токен-матчинг**: имена бьются по не-букво-цифрам; термы сравниваются
  как целые токены/сегменты пути; substring-фолбэк только для термов
  ≥ 5 символов.
- **`IsUnder` с границами** — `C:\Foo` не матчит `C:\Foobar`.
- Дедуп по нормализованному пути, разрешение конфликтов владения —
  прямо по снимку, без парсинга строк `Details`.

Уровни `Confidence`: `lcSafe` (предвыбран), `lcModerate` (предвыбран,
оранжевый), `lcRisky` (красный, не предвыбран, не удаляется),
`lcInfo` (серый, только информация).

**Live-exe guard** (`AddFile` в cs.leftovers): каталог, содержащий
«живой» `.exe` (`DirHasLiveExe` — рекурсивно, без reparse-точек, кап
4000 узлов), — это рабочая копия, а не хвост → принудительно `lcRisky`
+ снятая отметка. Имена-заглушки инсталляторов (`unins*`, `setup*`…
— `IsGenericInstallerName`) не считаются живыми: `unins000.exe` —
легитимный хвост. Точно так же review-only получает одиночный `.exe`
не-installer'ского имени.

### `cs.safety` — контракт безопасности

**Каждая деструктивная операция обязана пройти проверку здесь.**
`InitSafetyRoots` резолвит корни при старте; списки защищённого —
константные массивы в implementation:

- `ProtectedRegistryRoots` — Control/Enum/Setup/SAM/SECURITY/…
- `ProtectedServiceNames` — 48 системных сервисов
- `ProtectedTaskPaths` — `\Microsoft\...`
- `ProtectedFirewallPrefixes` — Core Networking и т.п.
- `IsAutorunSafeToDelete` — автозагрузка, ведущая в System32/Defender/
  ctfmon/OneDrive → `lcRisky`.
- `IsReparsePoint` проверяется везде — junction'ы не трогаем.

### `cs.uninstall` — движок

- `Uninstall()` → `TUninstallResult` + out `TScanResult`.
- `DetectInstallerType` / `ResolveSilentCommand` — MSI/Inno/NSIS/
  InstallShield → тихие флаги (`/S`, `/VERYSILENT`, `msiexec /qn`…).
- `DeleteLeftovers` — файлы в корзину (`UseRecycleBin`,
  `SHFileOperationW` + `FOF_ALLOWUNDO`), реестр — `RegDeleteTree`.
  Пропускает: невыбранные, `lcRisky`, `lcInfo`, не прошедшие
  `cs.safety`.
- `OnStatus` → строки аудита в `CleanSweep.log` (см. §8); `OnProgress`
  → процент в прогрессбар.

### `cs.utils` — утилиты

`GetSpecialFolder`, `ExpandEnvVars`, `NormalizePath`,
`IsSamePathOrDescendant`, `RunningProcessesUnder` (ToolHelp32),
`LogToFile`, `GetShellSmallIcon/LargeIcon` (`SHGetFileInfoW`),
`NormalizeInstallDate` (`YYYYMMDD`/`Sep 16, 2026` → `2026.09.16`),
`LoadTextFile` (UTF-8 с/без BOM + ANSI-фолбэк — для всех ini-баз),
`ShowInExplorer`, `ShowInRegedit`.

---

## 6. Локализация (`cs.lang`)

Язык определяется из `GetUserDefaultUILanguage` (импорт объявлен вручную —
в FPC 3.2.2 его нет): `0x19`→RU, `0x23`→BE, `0x22`→UK, `0x09`→EN,
всё остальное → **RU**.

```pascal
uses cs.lang;

Caption := Lg('О программе', 'Аб праграме', 'Про програму', 'About');
//            RU            BE              UK              EN
```

- `Lg(ru, be, uk, en)` — выбор строки по текущему языку.
- `PluralForm(n, f1, f2, f5)` — славянская трёхформа для RU/BE/UK
  (`программа/программы/программ`); для EN — `f1` при 1, иначе `f5`.

Конвенция: в `.lfm` подписи остаются русскими (дефолт для дизайнера),
реальные строки ставятся кодом — `TMainForm.ApplyLanguage`, аналогичные
блоки в `CreateDlg` карточки/остатков/about. Новую UI-строку → только
через `Lg(...)`. Строки аудит-лога в `cs.uninstall` сознательно на
русском — это содержимое `CleanSweep.log`, а не UI.

Форсировать язык при отладке — присвоить `GLang` в `cs.lang` до первого
вызова `Lang`.

---

## 7. GUI — правила работы с `.lfm`

Все формы — дизайнерские. Правила:

- **Каждый `object Foo: TClass` в `.lfm` обязан иметь поле `Foo` в
  классе формы И юнит его класса в `uses`.** Только `uses` недостаточно:
  смартлинковка FPC выкидывает класс без статической ссылки →
  `Class 'TPanel' not found` при открытии формы. Реальный кейс:
  `pnlButtons` в pickform/previewform (2026-09-23).
- `RequireDerivedFormResource := True` в `.lpr` — побитая `.lfm` падает
  сразу и громко, а не тихо.
- После правки формы в дизайнере собирай `build.bat` (или `lazbuild -B`)
  — инкрементально `.lfm` не перевшивается.
- Динамическое в коде: строки списков, иконки программ (shell),
  строки-«пункты» карточки (`pnlDetails`, `alTop` + `WordWrap`),
  подгонка высоты карточки под число строк.
- Главная форма: `bsSizeable` + `BorderIcons=[biSystemMenu]` — только
  крестик, но ресайз и меню работают. **Нельзя `bsDialog`** — win32-
  виджетсет не рисует `TMainMenu` на диалоговых окнах.
- «Поверх всех окон» — `FormStyle := fsStayOnTop/fsNormal` по чекбоксу
  меню.
- Иконки на кнопках — только через `TBitBtn.Images`/`ImageIndex`
  (`Glyph := bitmap` LCL молча игнорирует).
- **VST**: `AddChild` создаёт ноду лениво — данные ноды пишутся либо
  внутри `OnInitNode`, либо после `ReinitNode(N, False)`, иначе
  `Initialize` затрёт их при первой отрисовке. `CheckState[Node] :=`
  стреляет `OnChecked` на каждую ноду — массовые отметки под
  `FCheckGuard` + `RefreshSelectionInfo` один раз в конце.
- **TListView наоборот**: программный `Item.Checked :=` НЕ вызывает
  `OnItemChecked` — зависимый UI обновлять вручную (см. баг appxform
  «Отметить всё → Удалить неактивна», 2026-09-21).

---

## 8. Логирование

`CleanSweep.log` рядом с exe (игнорируется git). Пишется через
`LogToFile` в `cs.utils`:

- `RUN:` командная строка деинсталлятора + результат/код выхода;
- `Waiting for uninstaller subprocesses to exit...` — Job Object не пуст;
- предложенные остатки: `[x] Type  CONF  path | details`;
- факт удаления: что удалено / пропущено и почему.

UI-мемо (3 строки) показывает те же строки через `OnStatus` →
`FStatusQueue` → `Queue()`. Формат лог-строк менять аккуратно —
пользовательские парсинги/сравнения уже опираются на него.

---

## 9. Конвенции кода

- `{$mode objfpc}{$H+}` в каждом юните.
- Префикс движка `cs.*`; GUI-юниты без префикса (`mainform`, `progcard`…).
- Комментарии — только там, где неочевидно *почему* (Job Object,
  KeyPath, потоки); не добавлять/не удалять чужие комментарии.
- Владение списками: `TProgramList.Create(True)` владеет элементами;
  `TLeftoverList.Create(False)` — нет. Передача владения через
  `List := nil` в источнике.
- Ошибки — на правильных границах: `try/except` вокруг shell/registry
  вызовов, без лесенки `try` на каждую строку.
- Мёртвый код удаляем: последний аудит выкосил ~105 строк неиспользуемых
  функций и write-only полей.

---

## 10. Типичные задачи

**Добавить зону сканирования файлов** → новый блок в
`TFileLeftoverScanner` (`cs.leftovers`), корень через
`GetSpecialFolder`/`ExpandEnvVars`, обязательно `IsReparsePoint`-чек.

**Добавить зону реестра** → блок в `TRegistryLeftoverScanner`; hive +
subkey + `REGVIEW_*`. Значения с `\` в имени — через `KeyPath`.

**Новая защита** → константный массив в `cs.safety` + проверка на этапе
скана (пометить `lcRisky`), НЕ на этапе удаления — пусть пользователь
видит причину.

**Новая UI-строка** → `Lg('…','…','…','…')` в `ApplyLanguage`/`CreateDlg`
соответствующей формы.

**Сигнатуры** → правка `data\leftover-signatures.json` + пересборка
(вшивается) или просто положить рядом с exe — приоритет у внешнего.

**Поднять версию** → `VERSIONINFO` в `.rc` **и** `assemblyIdentity` в
`.manifest` — держать синхронно.

---

## 11. Известные грабли — шпаргалка

| Симптом | Причина | Лечение |
|---|---|---|
| Форма в exe старая | FPC не следит за `.lfm` | всегда `--build-all` |
| `Class 'TPanel' not found` при открытии формы | нет поля/юнита в форме — смартлинковка выкинула класс | поле `Foo: TClass` + юнит в `uses` |
| VST-список пустой, ноды есть | данные записаны до ленивой инициализации | `ReinitNode` сразу после `AddChild` |
| Массовые отметки VST подвешивают | `CheckState:=` → `OnChecked` на каждую ноду | `FCheckGuard` + один `RefreshSelectionInfo` |
| TListView: «Отметить всё» не активирует кнопку | программный `Checked:=` молчит | обновить UI вручную после цикла |
| PowerShell-скан висит | чтение stdout после `poWaitOnExit` — дедлок пайпа | дренаж pipe в `while P.Running` (RunPs) |
| i386-линкер падает `Illegal COFF Magic` | в -FU лежат x64-объекты | развести -FU по архитектурам |
| `Can't create object file CleanSweep.exe` | запущен админский exe | `mv` старый exe, пересобрать |
| Новая форма пустая (нет items, «…» в статусе) | `OnCreate`/`OnDestroy` не привязаны в `.lfm` — `FormCreate` молча не зовётся | добавить `OnCreate = FormCreate` в объект формы |
| VST без чекбоксов при `toCheckSupport` | `CheckType` ноды по умолчанию `ctNone` | в `OnInitNode`: `Sender.CheckType[Node] := ctCheckBox` |
| «команда не найдена» для nbtstat/route и т.п. | exe 32-битный → cmd уходит в SysWOW64, где часть системных утилит отсутствует | полный путь через `Sysnative` (`cs.netfix.SysToolExe`) |
| Пропало меню | `BorderStyle=bsDialog` | `bsSizeable` + `biSystemMenu` |
| Пропал манифест/иконка | удалили `{$R *.res}` или включили XPManifest в IDE | вернуть `{$R *.res}`, снять галочку |
| Остатки сканируются при открытом деинсталляторе | Inno/NSIS самоподмена | уже лечено Job Object — не убирать |
| Удалилось значение не того ключа | `\` в имени значения | использовать `KeyPath`, не резать `Path` |
| Диалог «О программе» без иконки | `Icon.LoadFromResourceName` в try/except | иконка должна быть `MAINICON` в `.rc` |
