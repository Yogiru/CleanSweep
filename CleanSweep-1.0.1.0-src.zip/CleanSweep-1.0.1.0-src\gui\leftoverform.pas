unit leftoverform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, ComCtrls, StdCtrls, ExtCtrls,
  Dialogs, Graphics, ImgList, Menus, Clipbrd,
  cs.models, cs.uninstall;

type
  TLogEvent = procedure(const AMsg: string) of object;

  { Modal "found leftovers" dialog — Geek-style review before cleanup. }
  TLeftoverForm = class(TForm)
    btnAll: TButton;
    btnClose: TButton;
    btnDelete: TButton;
    btnNone: TButton;
    ilLeftovers: TImageList;
    lblInfo: TLabel;
    lvLeftovers: TListView;
    miCopyPath: TMenuItem;
    miOpenFolder: TMenuItem;
    miOpenRegedit: TMenuItem;
    miSelectAll: TMenuItem;
    miSelectNone: TMenuItem;
    miSep1: TMenuItem;
    pmLeftovers: TPopupMenu;
    pnlBottom: TPanel;
    procedure BtnAllClick(Sender: TObject);
    procedure BtnDeleteClick(Sender: TObject);
    procedure BtnNoneClick(Sender: TObject);
    procedure ColumnClick(Sender: TObject; Column: TListColumn);
    procedure DrawItem(Sender: TCustomListView; AItem: TListItem;
      AState: TCustomDrawState; var ADefaultDraw: Boolean);
    procedure MenuCopyPathClick(Sender: TObject);
    procedure MenuOpenFolderClick(Sender: TObject);
    procedure MenuOpenRegeditClick(Sender: TObject);
  private
    FScan: TScanResult;
    FDryRun: Boolean;
    FOnLog: TLogEvent;
    FSortCol: Integer;
    FSortAsc: Boolean;
    procedure Populate;
    procedure DoLog(const AMsg: string);
    procedure SetAll(AChecked: Boolean);
    function IconIndexFor(LI: TLeftoverItem): Integer;
  public
    constructor CreateDlg(AOwner: TComponent; AScan: TScanResult;
      ADryRun: Boolean; AOnLog: TLogEvent);
  end;

{ Shows the dialog modally. The caller keeps ownership of AScan. }
function ShowLeftoverDialog(AOwner: TComponent; AScan: TScanResult;
  ADryRun: Boolean; AOnLog: TLogEvent): TModalResult;

implementation

{$R *.lfm}

uses
  Windows, ShellApi, Math, cs.utils, cs.lang;

function LeftoverTypeName(T: TLeftoverType): string;
begin
  case T of
    ltRegistryKey:   Result := Lg('Ключ реестра', 'Ключ рэестра',
                                  'Ключ реєстру', 'Registry key');
    ltRegistryValue: Result := Lg('Значение реестра', 'Значэнне рэестра',
                                  'Значення реєстру', 'Registry value');
    ltFile:          Result := Lg('Файл', 'Файл', 'Файл', 'File');
    ltFolder:        Result := Lg('Папка', 'Папка', 'Папка', 'Folder');
    ltService:       Result := Lg('Сервис', 'Сервіс', 'Сервіс', 'Service');
    ltScheduledTask: Result := Lg('Задача', 'Задача', 'Задача', 'Task');
  else
    Result := '?';
  end;
end;

function ConfidenceName(C: TLeftoverConfidence): string;
begin
  case C of
    lcSafe:     Result := Lg('Безопасно', 'Бяспечна', 'Безпечно', 'Safe');
    lcModerate: Result := Lg('Проверьте', 'Праверце', 'Перевірте', 'Review');
    lcRisky:    Result := Lg('Опасно', 'Небяспечна', 'Небезпечно', 'Risky');
    lcInfo:     Result := Lg('Инфо', 'Інфа', 'Інфо', 'Info');
  else
    Result := '?';
  end;
end;

function ShowLeftoverDialog(AOwner: TComponent; AScan: TScanResult;
  ADryRun: Boolean; AOnLog: TLogEvent): TModalResult;
var
  F: TLeftoverForm;
begin
  F := TLeftoverForm.CreateDlg(AOwner, AScan, ADryRun, AOnLog);
  try
    Result := F.ShowModal;
  finally
    F.Free;
  end;
end;

constructor TLeftoverForm.CreateDlg(AOwner: TComponent; AScan: TScanResult;
  ADryRun: Boolean; AOnLog: TLogEvent);
begin
  inherited Create(AOwner); // loads leftoverform.lfm
  FScan := AScan;
  FDryRun := ADryRun;
  FOnLog := AOnLog;
  FSortCol := -1;
  FSortAsc := True;
  try
    Icon.LoadFromResourceName(HInstance, 'MAINICON');
  except
  end;
  Caption := Lg('CleanSweep — найдены остатки', 'CleanSweep — знойдзены рэшткі',
                'CleanSweep — знайдено залишки', 'CleanSweep — leftovers found');
  btnDelete.Caption := Lg('Удалить выбранное', 'Выдаліць выбранае',
                          'Видалити вибране', 'Delete selected');
  btnAll.Caption    := Lg('Выбрать всё', 'Выбраць усё', 'Вибрати все', 'Select all');
  btnNone.Caption   := Lg('Снять выбор', 'Зняць выбар', 'Зняти вибір', 'Select none');
  btnClose.Caption  := Lg('Пропустить', 'Прапусціць', 'Пропустити', 'Skip');
  miSelectAll.Caption  := btnAll.Caption;
  miSelectNone.Caption := btnNone.Caption;
  miCopyPath.Caption   := Lg('Копировать путь', 'Капіраваць шлях',
                             'Копіювати шлях', 'Copy path');
  miOpenFolder.Caption := Lg('Открыть содержащую папку', 'Адкрыць папку',
                             'Відкрити папку', 'Open containing folder');
  miOpenRegedit.Caption := Lg('Открыть в реестре', 'Адкрыць у рэестры',
                              'Відкрити в реєстрі', 'Open in registry');
  lvLeftovers.Columns[0].Caption := Lg('Путь', 'Шлях', 'Шлях', 'Path');
  lvLeftovers.Columns[1].Caption := Lg('Тип', 'Тып', 'Тип', 'Type');
  lvLeftovers.Columns[2].Caption := Lg('Уверенность', 'Упэўненасць',
                                       'Впевненість', 'Confidence');
  lvLeftovers.Columns[3].Caption := Lg('Размер', 'Памер', 'Розмір', 'Size');
  lvLeftovers.Columns[4].Caption := Lg('Причина', 'Прычына', 'Причина', 'Reason');
  lblInfo.Caption := Format(Lg(
    'Найдено остатков: %d в реестре, %d в файлах. Отметьте, что удалить:',
    'Знойдзена рэшткаў: %d у рэестры, %d у файлах. Адзначце, што выдаліць:',
    'Знайдено залишків: %d у реєстрі, %d у файлах. Позначте, що видалити:',
    'Leftovers found: %d in registry, %d in files. Check what to delete:'),
    [FScan.RegistryLeftovers.Count, FScan.FileLeftovers.Count]);
  Populate;
end;

procedure TLeftoverForm.DoLog(const AMsg: string);
begin
  if Assigned(FOnLog) then FOnLog(AMsg);
end;

function TLeftoverForm.IconIndexFor(LI: TLeftoverItem): Integer;
var
  FI: TSHFileInfoW;
  Ico: TIcon;
  H: HICON;
  Attr: DWORD;
  W: WideString;
begin
  // Shell-appropriate icon per item type; never touches the disk for
  // attributes (USEFILEATTRIBUTES) except real files/folders.
  H := 0;
  case LI.ItemType of
    ltFolder:
      if DirectoryExists(LI.Path) then
        W := UTF8Decode(LI.Path) else W := '';
    ltFile:
      if FileExists(LI.Path) then
        W := UTF8Decode(LI.Path) else W := '';
  else
    W := '';
  end;
  if W <> '' then
  begin
    if SHGetFileInfoW(PWideChar(W), 0, FI, SizeOf(FI),
         SHGFI_ICON or SHGFI_SMALLICON or SHGFI_SYSICONINDEX) <> 0 then
      H := FI.hIcon;
  end;
  if H = 0 then
  begin
    case LI.ItemType of
      ltFolder:     Attr := FILE_ATTRIBUTE_DIRECTORY;
      ltFile:       Attr := FILE_ATTRIBUTE_NORMAL;
      ltRegistryKey, ltRegistryValue:
        W := 'C:\Windows\regedit.exe';
      ltService:    Attr := FILE_ATTRIBUTE_NORMAL;
      ltScheduledTask: Attr := FILE_ATTRIBUTE_NORMAL;
    else
      Attr := FILE_ATTRIBUTE_NORMAL;
    end;
    if (LI.ItemType in [ltRegistryKey, ltRegistryValue]) and
       FileExists(W) then
    begin
      if SHGetFileInfoW(PWideChar(W), 0, FI, SizeOf(FI),
           SHGFI_ICON or SHGFI_SMALLICON) <> 0 then
        H := FI.hIcon;
    end
    else if SHGetFileInfoW('x', Attr, FI, SizeOf(FI),
        SHGFI_ICON or SHGFI_SMALLICON or SHGFI_USEFILEATTRIBUTES) <> 0 then
      H := FI.hIcon;
  end;
  if H = 0 then Exit(-1);
  Ico := TIcon.Create;
  try
    Ico.Handle := H;
    Result := ilLeftovers.AddIcon(Ico);
  finally
    Ico.Free;
  end;
end;

procedure TLeftoverForm.Populate;

  procedure AddItems(L: TLeftoverList);
  var
    I: Integer;
    LI: TLeftoverItem;
    It: TListItem;
  begin
    for I := 0 to L.Count - 1 do
    begin
      LI := L[I];
      It := lvLeftovers.Items.Add;
      It.Caption := LI.Path;
      It.SubItems.Add(LeftoverTypeName(LI.ItemType));
      It.SubItems.Add(ConfidenceName(LI.Confidence));
      It.SubItems.Add(LI.SizeDisplay);
      It.SubItems.Add(LI.Details);
      It.Checked := LI.IsSelected;
      It.Data := LI;
      It.ImageIndex := IconIndexFor(LI);
    end;
  end;

begin
  lvLeftovers.Items.BeginUpdate;
  try
    lvLeftovers.Items.Clear;
    AddItems(FScan.RegistryLeftovers);
    AddItems(FScan.FileLeftovers);
  finally
    lvLeftovers.Items.EndUpdate;
  end;
end;

procedure TLeftoverForm.DrawItem(Sender: TCustomListView; AItem: TListItem;
  AState: TCustomDrawState; var ADefaultDraw: Boolean);
var
  LI: TLeftoverItem;
begin
  LI := TLeftoverItem(AItem.Data);
  if LI = nil then Exit;
  case LI.Confidence of
    lcModerate: Sender.Canvas.Font.Color := RGB(200, 110, 0);
    lcRisky:    Sender.Canvas.Font.Color := clRed;
    lcInfo:     Sender.Canvas.Font.Color := clGray;
  end;
end;

var
  GLCol: Integer;
  GLAsc: Boolean;

function CompareLeftoversDyn(const A, B: TLeftoverItem): Integer;
begin
  case GLCol of
    0: Result := CompareText(A.Path, B.Path);
    1: Result := Ord(A.ItemType) - Ord(B.ItemType);
    2: Result := Ord(A.Confidence) - Ord(B.Confidence);
    3: Result := Sign(A.SizeBytes - B.SizeBytes);
    4: Result := CompareText(A.Details, B.Details);
  else
    Result := 0;
  end;
  if not GLAsc then Result := -Result;
end;

procedure TLeftoverForm.ColumnClick(Sender: TObject; Column: TListColumn);
begin
  if FSortCol = Column.Index then
    FSortAsc := not FSortAsc
  else
  begin
    FSortCol := Column.Index;
    FSortAsc := True;
  end;
  GLCol := FSortCol;
  GLAsc := FSortAsc;
  FScan.RegistryLeftovers.Sort(@CompareLeftoversDyn);
  FScan.FileLeftovers.Sort(@CompareLeftoversDyn);
  Populate;
end;

procedure TLeftoverForm.SetAll(AChecked: Boolean);
var
  I: Integer;
begin
  for I := 0 to lvLeftovers.Items.Count - 1 do
    if TLeftoverItem(lvLeftovers.Items[I].Data).Confidence < lcRisky then
      lvLeftovers.Items[I].Checked := AChecked;
end;

procedure TLeftoverForm.BtnAllClick(Sender: TObject);
begin
  SetAll(True);
end;

procedure TLeftoverForm.BtnNoneClick(Sender: TObject);
begin
  SetAll(False);
end;

procedure TLeftoverForm.MenuCopyPathClick(Sender: TObject);
begin
  if lvLeftovers.Selected <> nil then
    Clipboard.AsText := TLeftoverItem(lvLeftovers.Selected.Data).Path;
end;

procedure TLeftoverForm.MenuOpenFolderClick(Sender: TObject);
var
  LI: TLeftoverItem;
  Dir: string;
begin
  if lvLeftovers.Selected = nil then Exit;
  LI := TLeftoverItem(lvLeftovers.Selected.Data);
  Dir := LI.Path;
  if LI.ItemType in [ltFile] then
    Dir := ExtractFileDir(Dir);
  if (LI.ItemType in [ltFile, ltFolder]) then
    ShowInExplorer(Dir);
end;

procedure TLeftoverForm.MenuOpenRegeditClick(Sender: TObject);
var
  LI: TLeftoverItem;
begin
  if lvLeftovers.Selected = nil then Exit;
  LI := TLeftoverItem(lvLeftovers.Selected.Data);
  if LI.ItemType in [ltRegistryKey, ltService] then
    ShowInRegedit(LI.Path)
  else if (LI.ItemType = ltRegistryValue) and (LI.KeyPath <> '') then
    ShowInRegedit(LI.KeyPath);
end;

procedure TLeftoverForm.BtnDeleteClick(Sender: TObject);
var
  RegItems, FileItems: TLeftoverList;
  I, RegDel, FileDel, Sel: Integer;
  Engine: TUninstallEngine;
  Opts: TDeleteOptions;
  LI: TLeftoverItem;
begin
  Sel := 0;
  for I := 0 to lvLeftovers.Items.Count - 1 do
    if lvLeftovers.Items[I].Checked then Inc(Sel);
  if Sel = 0 then
  begin
    MessageDlg(Lg('Ничего не выбрано.', 'Нічога не выбрана.',
                  'Нічого не вибрано.', 'Nothing selected.'),
               mtInformation, [mbOK], 0);
    Exit;
  end;
  if MessageDlg(Format(Lg('Удалить выбранные элементы: %d? Файлы уйдут ' +
      'в корзину, ключи реестра удалятся насовсем.',
      'Выдаліць выбраныя элементы: %d? Файлы пойдуць у сметніцу, ' +
      'ключы рэестра выдаляцца назаўжды.',
      'Видалити вибрані елементи: %d? Файли підуть у кошик, ' +
      'ключі реєстру видаляться назавжди.',
      'Delete %d selected item(s)? Files go to the recycle bin, ' +
      'registry keys are deleted permanently.'),
      [Sel]), mtConfirmation, [mbYes, mbNo], 0) <> mrYes then Exit;

  RegItems := TLeftoverList.Create(False);
  FileItems := TLeftoverList.Create(False);
  try
    for I := 0 to lvLeftovers.Items.Count - 1 do
    begin
      LI := TLeftoverItem(lvLeftovers.Items[I].Data);
      LI.IsSelected := lvLeftovers.Items[I].Checked;
      // Tasks are handled by the registry branch (schtasks), keep together.
      if LI.ItemType in [ltRegistryKey, ltRegistryValue, ltService,
                         ltScheduledTask] then
        RegItems.Add(LI)
      else
        FileItems.Add(LI);
    end;

    Screen.Cursor := crHourGlass;
    Engine := TUninstallEngine.Create;
    try
      Engine.OnStatus := @DoLog;
      Opts.DryRun := FDryRun;
      Opts.UseRecycleBin := True;
      Engine.DeleteLeftovers(RegItems, FileItems, Opts, RegDel, FileDel);
      DoLog(Format(Lg('Удалено: %d в реестре, %d файлов',
                      'Выдалена: %d у рэестры, %d файлаў',
                      'Видалено: %d у реєстрі, %d файлів',
                      'Deleted: %d registry, %d file(s)'),
                   [RegDel, FileDel]));
    finally
      Engine.Free;
      Screen.Cursor := crDefault;
    end;
  finally
    RegItems.Free;
    FileItems.Free;
  end;

  ModalResult := mrOk;
end;

end.
