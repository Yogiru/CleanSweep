﻿program specialtest;

{ Analyzes the built-in special cleanup actions (recycle bin, dead desktop
  shortcuts) and the reclassified Default.ini entries. Analyze-only: the
  real OS recycle bin must never be emptied here. }

{$mode objfpc}{$H+}

uses
  Classes, SysUtils, cs.winapp2, cs.safety, cs.detect, cs.cleaner;

var
  IniPath: string;
  Parser: TWinapp2Parser;
  Entries: TCleanerEntryList;
  I: Integer;
  E: TCleanerEntry;
  Detect: TDetectionService;
  Cleaner: TCleaningService;
  Res: TCleanResult;
  Failures: Integer;
  S: string;

procedure Check(ACond: Boolean; const AMsg: string);
begin
  if ACond then
    WriteLn('  [ok] ', AMsg)
  else
  begin
    Inc(Failures);
    WriteLn('  [FAIL] ', AMsg);
  end;
end;

function Find(const AName: string): TCleanerEntry;
var
  I: Integer;
begin
  Result := nil;
  for I := 0 to Entries.Count - 1 do
    if SameText(Entries[I].Name, AName) then Exit(Entries[I]);
end;

begin
  Failures := 0;
  InitSafetyRoots;
  IniPath := ExtractFilePath(ParamStr(0)) + '..\data\Default.ini';
  WriteLn('special actions test');
  WriteLn('Database: ', IniPath);
  Check(FileExists(IniPath), 'Default.ini exists');

  Parser := TWinapp2Parser.Create;
  try
    Entries := Parser.ParseFile(IniPath);
    WriteLn('Entries parsed: ', Entries.Count);
    Check(Entries.Count > 1200, 'Default.ini parses in full');
  finally
    Parser.Free;
  end;

  { --- [Recycle Bin *] --- }
  WriteLn('--- Recycle Bin ---');
  E := Find('Recycle Bin');
  Check(E <> nil, 'entry exists');
  if E <> nil then
  begin
    Check(E.Special = 'RecycleBin', 'Special parsed = RecycleBin');
    Check(E.FileKeys.Count = 0, 'no FileKeys');
    Check(E.RegKeys.Count = 0, 'no RegKeys');
    Check(PresetPurposeOf(E) = 'Windows', 'purpose = Windows');
    Check(PresetSafetyOf(E) = slSafe, 'safety = Safe');
  end;

  { --- [Desktop Dead Shortcuts *] --- }
  WriteLn('--- Dead Shortcuts ---');
  E := Find('Desktop Dead Shortcuts');
  Check(E <> nil, 'entry exists');
  if E <> nil then
  begin
    Check(E.Special = 'DeadShortcuts', 'Special parsed = DeadShortcuts');
    Check(PresetPurposeOf(E) = 'Windows', 'purpose = Windows');
    Check(PresetSafetyOf(E) = slSafe, 'safety = Safe');
  end;

  { --- reclassified Default.ini entries back to Safe --- }
  WriteLn('--- Reclassified entries ---');
  E := Find('Windows Icon/Thumbnail Cache Extended');
  Check(E <> nil, 'icon cache entry exists');
  if E <> nil then
    Check(PresetSafetyOf(E) = slSafe, 'icon cache is Safe now');

  E := Find('Windows Event Viewer Log Files');
  Check(E <> nil, 'event log entry exists');
  if E <> nil then
    Check(PresetSafetyOf(E) = slSafe, 'event logs are Safe now');

  { --- detection treats special entries as installed --- }
  WriteLn('--- Detection ---');
  Detect := TDetectionService.Create;
  try
    E := Find('Recycle Bin');
    if E <> nil then Check(Detect.IsInstalled(E), 'recycle bin detected');
    E := Find('Desktop Dead Shortcuts');
    if E <> nil then Check(Detect.IsInstalled(E), 'dead shortcuts detected');
  finally
    Detect.Free;
  end;

  { --- Analyze: recycle bin (read-only, nothing is emptied) --- }
  WriteLn('--- Analyze: Recycle Bin ---');
  Cleaner := TCleaningService.Create;
  try
    E := Find('Recycle Bin');
    if E <> nil then
    begin
      Res := Cleaner.Analyze(E);
      try
        WriteLn('  bin status: ', Res.SpecialBytes, ' bytes, ',
                Res.SpecialCount, ' items');
        Check((Res.SpecialItems.IndexOf(SPECIAL_RECYCLEBIN) >= 0) =
              (Res.SpecialCount > 0),
              'bin action queued exactly when the bin is non-empty');
        Check(Res.SpecialItems.IndexOf(SPECIAL_DEADSHORTCUTS) < 0,
              'no dead-shortcut action on a bin entry');
        Check(Res.FilesToDelete.Count = 0, 'no files staged');
        Check(Res.RegistryToDelete.Count = 0, 'no registry staged');
        Check(Res.TotalBytes >= Res.SpecialBytes,
              'total bytes include the bin bytes');
      finally
        Res.Free;
      end;
    end;

    { --- Analyze: dead desktop shortcuts (read-only) --- }
    WriteLn('--- Analyze: Dead Shortcuts ---');
    E := Find('Desktop Dead Shortcuts');
    if E <> nil then
    begin
      Res := Cleaner.Analyze(E);
      try
        WriteLn('  links found: ', Res.SpecialCount, ' (',
                Res.FilesToDelete.Count, ' staged, ', Res.SpecialBytes,
                ' bytes)');
        Check(Res.SpecialItems.IndexOf(SPECIAL_DEADSHORTCUTS) >= 0 =
              (Res.SpecialCount > 0),
              'dead-shortcut action queued exactly when links exist');
        Check(Res.FilesToDelete.Count = Res.SpecialCount,
              'staged links match the counted links');
        if Res.SpecialCount > 0 then
        begin
          S := Res.FilesToDelete[0];
          Check((Pos('\desktop\', LowerCase(S)) > 0) or
                (Pos('\public\desktop\', LowerCase(S)) > 0),
                'links come from the Desktop folders: ' + S);
        end;
      finally
        Res.Free;
      end;
    end;

    { --- a plain entry must not queue special actions --- }
    WriteLn('--- No false specials ---');
    E := TCleanerEntry.Create;
    try
      E.Name := 'PlainProbe';
      E.LangSecRef := 3025;
      E.FileKeys.Add(TFileKeyEntry.Parse('%Temp%|*.nonexistentprobe'));
      Res := Cleaner.Analyze(E);
      try
        Check(Res.SpecialItems.Count = 0,
              'plain entry queues no special actions');
        Check(Res.FilesToDelete.Count = 0, 'non-existent mask finds nothing');
      finally
        Res.Free;
      end;
    finally
      E.Free;
    end;
  finally
    Cleaner.Free;
  end;

  Entries.Free;

  WriteLn('---');
  if Failures = 0 then
    WriteLn('ALL CHECKS PASSED')
  else
    WriteLn(Failures, ' CHECK(S) FAILED');
  if Failures > 0 then Halt(1);
end.
