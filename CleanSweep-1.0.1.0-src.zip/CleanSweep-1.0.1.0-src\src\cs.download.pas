unit cs.download;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils;

{ Downloads AUrl to ADestPath via WinINet (system TLS, proxy-aware, zero
  external dependencies — fphttpclient would drag OpenSSL DLLs in).
  Writes to <dest>.part first, renames on success so a failed download
  never leaves a half-written database behind.
  ACancel: optional flag polled between reads; aborts the download. }
function DownloadFile(const AUrl, ADestPath: string; out AErr: string;
  ACancel: PBoolean = nil): Boolean;

implementation

uses
  Windows, WinINet;

const
  TIMEOUT_MS = 30000;   // same as upstream's HttpClient timeout

function DownloadFile(const AUrl, ADestPath: string; out AErr: string;
  ACancel: PBoolean): Boolean;
var
  HInet, HUrl: HINTERNET;
  Buf: array[0..16383] of Byte;
  Got, Tmo: DWORD;
  Tmp: string;
  FS: TFileStream;
begin
  Result := False;
  AErr := '';
  HInet := InternetOpenW(PWideChar(UTF8Decode('CleanSweep/1.0')),
           INTERNET_OPEN_TYPE_PRECONFIG, nil, nil, 0);
  if HInet = nil then
  begin
    AErr := SysErrorMessage(GetLastError);
    Exit;
  end;
  try
    Tmo := TIMEOUT_MS;
    InternetSetOptionW(HInet, INTERNET_OPTION_CONNECT_TIMEOUT, @Tmo, 4);
    InternetSetOptionW(HInet, INTERNET_OPTION_RECEIVE_TIMEOUT, @Tmo, 4);
    InternetSetOptionW(HInet, INTERNET_OPTION_SEND_TIMEOUT, @Tmo, 4);
    // RELOAD+NO_CACHE: update checks must not get a cached copy
    HUrl := InternetOpenUrlW(HInet, PWideChar(UTF8Decode(AUrl)), nil, 0,
            INTERNET_FLAG_RELOAD or INTERNET_FLAG_NO_CACHE_WRITE, 0);
    if HUrl = nil then
    begin
      AErr := SysErrorMessage(GetLastError);
      Exit;
    end;
    try
      Tmp := ADestPath + '.part';
      FS := TFileStream.Create(Tmp, fmCreate);
      try
        repeat
          if (ACancel <> nil) and ACancel^ then
          begin
            AErr := 'cancelled';
            Exit;
          end;
          if not InternetReadFile(HUrl, @Buf, SizeOf(Buf), Got) then
          begin
            AErr := SysErrorMessage(GetLastError);
            Exit;
          end;
          if Got > 0 then
            FS.WriteBuffer(Buf, Got);
        until Got = 0;
      finally
        FS.Free;
      end;
    finally
      InternetCloseHandle(HUrl);
    end;
  finally
    InternetCloseHandle(HInet);
  end;
  SysUtils.DeleteFile(ADestPath);
  Result := RenameFile(Tmp, ADestPath);
  if not Result then
    AErr := 'cannot rename ' + Tmp;
end;

end.
