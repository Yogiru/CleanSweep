unit cs.cleaner;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Types, Windows, shlobj, shellapi, fgl,
  cs.winapp2, cs.pathexpand;

const
  { Built-in action codes a Special= entry can carry. The engine probes
    live system state for these — the rules engine deals with file/reg
    keys, these two are OS-level operations. }
  SPECIAL_RECYCLEBIN    = 'RecycleBin';
  SPECIAL_DEADSHORTCUTS = 'DeadShortcuts';

type
  { One rule parsed from an ExcludeKeyN= line.
    DirPrefix ends with '\' so 'Cache\' can't swallow 'CacheExtra\'.
    Pattern='' → whole subtree; wildcard → filename match anywhere
    below; literal → direct child only. }
  TExclusionRule = class
    DirPrefix: string;
    Pattern: string;
  end;

  TExclusionRuleList = specialize TFPGObjectList<TExclusionRule>;

type
  { Raised when the cancel callback asks to abort; mirrors upstream's
    OperationCanceledException propagating out of Analyze/Clean. }
  ECleanCancelled = class(Exception);

  TCleanProgress = procedure(const AMsg: string) of object;
  TCleanCancelCheck = function: Boolean of object;

  { One registry key or value queued for deletion.
    ValueName='' → whole key tree; Access remembers the registry view
    the item was found in (universal bitness handling). }
  TRegDeleteItem = class
    KeyPath: string;
    ValueName: string;
    Access: LongWord;
    function IsDeleteKey: Boolean;
    function DisplayName: string;
  end;

  TRegDeleteList = specialize TFPGObjectList<TRegDeleteItem>;

  { Result of one Analyze — the deletion plan consumed later by Clean.
    (Named TCleanResult to avoid clashing with cs.models.TScanResult.) }
  TCleanResult = class
    Entry: TCleanerEntry;          // not owned
    FilesToDelete: TStringList;
    RegistryToDelete: TRegDeleteList;
    TotalBytes: Int64;
    SpecialItems: TStringList;     // built-in actions queued ('RecycleBin', 'DeadShortcuts')
    SpecialBytes: Int64;           // bytes attributed to the special actions
    SpecialCount: Int64;           // items the actions remove (links / bin items)
    constructor Create;
    destructor Destroy; override;
    function FormattedSize: string;
  end;

  TCleanResultList = specialize TFPGObjectList<TCleanResult>;

  { What Clean managed to actually remove. }
  TCleanStats = record
    Count: Integer;
    Bytes: Int64;
  end;

  { Two-phase clean engine — port of CleaningService.
    Analyze walks FileKeys/RegKeys and builds a deletion list without
    touching anything. Files locked without FILE_SHARE_DELETE are
    skipped up front so the promised size stays honest.
    Clean consumes that list and deletes directly (no recycle bin —
    same as upstream and CCleaner). Every delete is re-checked against
    cs.safety at execution time: the plan may be stale by then. }
  TCleaningService = class
  private
    FExpander: TPathExpander;
    procedure EnumFilesSafe(const ARoot: string;
      const APatterns: TStringDynArray; const AExcluded: TExclusionRuleList;
      ARecurse: Boolean; const APrefix: string;
      AProgress: TCleanProgress; ACancel: TCleanCancelCheck;
      AOut: TStrings);
    procedure FindFiles(AFileKey: TFileKeyEntry;
      const AExcluded: TExclusionRuleList; const APrefix: string;
      AProgress: TCleanProgress; ACancel: TCleanCancelCheck; AOut: TStrings);
    procedure FindRegistryItems(ARegKey: TRegKeyEntry;
      const AExclusions: TStrings; AOut: TRegDeleteList);
    function BuildFileExclusions(AEntry: TCleanerEntry): TExclusionRuleList;
    function BuildRegistryExclusions(AEntry: TCleanerEntry): TStrings;
    function DeleteRegistryItem(AItem: TRegDeleteItem;
      const AExclusions: TStrings): Boolean;
    procedure DeleteRegistryTreeExcept(AHive: HKEY; const ASubKey,
      AKeyPath: string; AAccess: LongWord; const AExclusions: TStrings);
    procedure TryPruneEmptyDirs(const APath: string);
  public
    { Global exclusions layered on top of each entry's ExcludeKeys.
      Lines use the winapp2 ExcludeKey syntax: TYPE|path|pattern.
      Filled by the caller from settings before Analyze. }
    GlobalExclusions: TStringList;
    GlobalExclusionsEnabled: Boolean;

    { Cookie domains to keep. When assigned, recognized cookie stores in
      the deletion plan are pruned inside SQLite (kept domains survive)
      instead of the database file being deleted — port of upstream's
      TryCleanProtectedStore hand-off in Clean. Not owned by the service;
      nil → old behaviour (delete cookie DBs like any other file). }
    CookieKeepList: TStrings;

    constructor Create;
    destructor Destroy; override;
    function Analyze(AEntry: TCleanerEntry; AProgress: TCleanProgress = nil;
      ACancel: TCleanCancelCheck = nil): TCleanResult;
    { Deletes everything in the Analyze plan. Never touches anything not
      on the list; individual failures are skipped, not fatal. }
    function Clean(AResult: TCleanResult; AProgress: TCleanProgress = nil;
      ACancel: TCleanCancelCheck = nil): TCleanStats;
  end;

{ Paths never deleted no matter what the database says. }
function IsProtectedPath(const APath: string): Boolean;

implementation

uses
  Masks, Registry,
  cs.regpath, cs.registry, cs.safety, cs.utils, cs.models, cs.cookies;

const
  { Built-in safety net: browser extension databases (1Password,
    Bitwarden, uBlock lists) — chrome-extension_ storage stays off-limits. }
  ProtectedSegments: array[0..0] of string = (
    '\IndexedDB\chrome-extension_');

function IsProtectedPath(const APath: string): Boolean;
var
  I: Integer;
  L: string;
begin
  Result := False;
  L := LowerCase(APath);
  for I := Low(ProtectedSegments) to High(ProtectedSegments) do
    if Pos(LowerCase(ProtectedSegments[I]), L) > 0 then Exit(True);
end;

{ ═══════════════ Special actions ═══════════════ }

{ Minimal IPersistFile — FPC's shlobj does not ship it, but resolving a
  .lnk target needs IShellLink (GetPath) PLUS the persisted file fed in
  through IPersistFile.Load. Omitting GetCurFile (last method) keeps the
  vtable order for the ones we call. }
type
  IPersistFileX = interface(IUnknown)
    ['{0000010B-0000-0000-C000-000000000046}']
    function GetClassID(out pClassID: TGUID): HResult; stdcall;
    function IsDirty: HResult; stdcall;
    function Load(pszFileName: LPCWSTR; dwMode: LongInt): HResult; stdcall;
    function Save(pszFileName: LPCWSTR; fRemember: BOOL): HResult; stdcall;
    function SaveCompleted(pszFileName: LPCWSTR): HResult; stdcall;
  end;

const
  IID_IPersistFile: TGUID = '{0000010B-0000-0000-C000-000000000046}';

function CoInitialize(pvReserved: Pointer): HResult; stdcall;
  external 'ole32.dll' name 'CoInitialize';
procedure CoUninitialize; stdcall;
  external 'ole32.dll' name 'CoUninitialize';
function CoCreateInstance(rclsid: PGUID; pUnkOuter: Pointer;
  dwClsContext: LongInt; riid: PGUID; out ppv): HResult; stdcall;
  external 'ole32.dll' name 'CoCreateInstance';

const
  CLSCTX_INPROC_SERVER  = 1;
  STGM_READ             = 0;
  S_OK                  = 0;   // HRESULT success codes, not in Windows unit
  S_FALSE               = 1;

{ Recycle bin occupancy across all drives (pszRootPath=nil). Shapely via
  SHQUERYRBINFO: total bytes and item count. }
function RecycleBinStatus(out ABytes, AItems: Int64): Boolean;
var
  Info: SHQUERYRBINFO;
begin
  FillChar(Info, SizeOf(Info), 0);
  Info.cbSize := SizeOf(Info);
  Result := SHQueryRecycleBinW(nil, @Info) = S_OK;
  ABytes := Info.i64Size;
  AItems := Info.i64NumItems;
end;

{ Marshals the zero-terminated wide buffer GetPath wrote into a UTF-8
  string without going through the local ACP. }
function WideBufToUtf8(const ABuf: array of WideChar): string;
var
  W: WideString;
  L: Integer;
begin
  L := lstrlenW(@ABuf[0]);
  if L <= 0 then Exit('');
  SetString(W, PWideChar(@ABuf[0]), L);
  Result := UTF8Encode(W);
end;

{ True when the .lnk's resolved target no longer exists. A link that
  cannot be resolved at all (corrupt, network-only) is left alone — we
  only delete links that demonstrably point nowhere. }
function LinkTargetMissing(const ALnkPath: string;
  const ALnk: IShellLinkW; const APersist: IPersistFileX): Boolean;
var
  Buf: array[0..MAX_PATH] of WideChar;
  Target: string;
begin
  Result := False;
  if APersist.Load(PWideChar(UTF8Decode(ALnkPath)), STGM_READ) <> S_OK then Exit;
  Buf[0] := #0;
  if ALnk.GetPath(@Buf[0], MAX_PATH, nil, SLGP_RAWPATH) <> S_OK then Exit;
  Target := WideBufToUtf8(Buf);
  if Target = '' then Exit;
  Result := (not FileExists(Target)) and (not DirectoryExists(Target));
end;

{ Desktop .lnk files whose target application has been uninstalled.
  Scans the user's and the public desktop (top level only — folders are
  handled by their own rules). Adds missing-target links to AOut; the
  sizes are probed like every other FileKey so locked links are skipped. }
procedure FindDeadShortcuts(AOut: TStrings; out ACount: Int64;
  out ABytes: Int64);
var
  Dirs: array of string;
  I: Integer;
  Init: HResult;
  Lnk: IShellLinkW;
  PF: IPersistFileX;
  Dir, F: string;
  SR: TSearchRec;
  Sz: Int64;
begin
  ACount := 0;
  ABytes := 0;
  SetLength(Dirs, 0);
  F := SysUtils.GetEnvironmentVariable('USERPROFILE');
  if (F <> '') and DirectoryExists(F + '\Desktop') then
  begin
    SetLength(Dirs, Length(Dirs) + 1);
    Dirs[High(Dirs)] := F + '\Desktop';
  end;
  F := SysUtils.GetEnvironmentVariable('PUBLIC');
  if (F <> '') and DirectoryExists(F + '\Desktop') then
  begin
    SetLength(Dirs, Length(Dirs) + 1);
    Dirs[High(Dirs)] := F + '\Desktop';
  end;
  if Length(Dirs) = 0 then Exit;

  Init := CoInitialize(nil);
  if (Init <> S_OK) and (Init <> S_FALSE) then Exit;   // COM unavailable
  try
    Lnk := nil;
    PF := nil;
    if CoCreateInstance(@CLSID_ShellLink, nil, CLSCTX_INPROC_SERVER,
         @IID_IShellLinkW, Lnk) <> S_OK then Exit;
    try
      if Lnk.QueryInterface(IID_IPersistFile, PF) <> S_OK then Exit;
      try
        for I := 0 to High(Dirs) do
        begin
          Dir := Dirs[I];
          if FindFirst(Dir + '\*.lnk', faAnyFile, SR) <> 0 then Continue;
          try
            repeat
              if (SR.Attr and faDirectory) <> 0 then Continue;
              F := Dir + '\' + SR.Name;
              if IsProtectedPath(F) or (not IsPathSafeToDelete(F)) then Continue;
              if not LinkTargetMissing(F, Lnk, PF) then Continue;
              Sz := GetFileSizeBytes(F);
              if Sz < 0 then Continue;
              AOut.Add(F);
              Inc(ACount);
              ABytes := ABytes + Sz;
            until FindNext(SR) <> 0;
          finally
            SysUtils.FindClose(SR);
          end;
        end;
      finally
        PF := nil;
      end;
    finally
      Lnk := nil;
    end;
  finally
    if Init = S_OK then CoUninitialize;
  end;
end;

function ExclusionMatches(const ARule: TExclusionRule;
  const AFilePath: string): Boolean;
var
  FileName, Rel: string;
begin
  Result := False;
  if Pos(LowerCase(ARule.DirPrefix), LowerCase(AFilePath)) <> 1 then Exit;
  if ARule.Pattern = '' then Exit(True);      // whole subtree excluded

  FileName := ExtractFileName(AFilePath);
  if (Pos('*', ARule.Pattern) > 0) or (Pos('?', ARule.Pattern) > 0) then
    Exit(MatchesMask(FileName, ARule.Pattern));

  // literal → direct child of DirPrefix, not deeper
  Rel := Copy(AFilePath, Length(ARule.DirPrefix) + 1, MaxInt);
  Result := SameText(Rel, ARule.Pattern);
end;

{ True if any exclusion rule matches — short-circuits on first hit. }
function IsExcluded(const APath: string;
  const ARules: TExclusionRuleList): Boolean;
var
  I: Integer;
begin
  Result := False;
  for I := 0 to ARules.Count - 1 do
    if ExclusionMatches(ARules[I], APath) then Exit(True);
end;

{ TRegDeleteItem }

function TRegDeleteItem.IsDeleteKey: Boolean;
begin
  Result := ValueName = '';
end;

function TRegDeleteItem.DisplayName: string;
begin
  if ValueName <> '' then
    Result := KeyPath + ' → ' + ValueName
  else
    Result := KeyPath;
end;

{ TCleanResult }

constructor TCleanResult.Create;
begin
  FilesToDelete := TStringList.Create;
  RegistryToDelete := TRegDeleteList.Create(True);
  SpecialItems := TStringList.Create;
end;

destructor TCleanResult.Destroy;
begin
  FilesToDelete.Free;
  RegistryToDelete.Free;
  SpecialItems.Free;
  inherited;
end;

function TCleanResult.FormattedSize: string;
begin
  Result := FormatBytes(TotalBytes);
end;

{ TCleaningService }

constructor TCleaningService.Create;
begin
  FExpander := TPathExpander.Create;
  GlobalExclusions := TStringList.Create;
end;

destructor TCleaningService.Destroy;
begin
  GlobalExclusions.Free;
  FExpander.Free;
  inherited;
end;

procedure CheckCancelled(ACancel: TCleanCancelCheck);
begin
  if Assigned(ACancel) and ACancel() then
    raise ECleanCancelled.Create('Operation cancelled');
end;

{ Splits a FileKey pattern like '*.tmp;*.log' into trimmed non-empty
  parts. '*.*' or empty → single '*.*'. }
function SplitPatterns(const APattern: string): TStringDynArray;
var
  Parts: TStringList;
  I, N: Integer;
  P: string;
begin
  Parts := TStringList.Create;
  try
    Parts.StrictDelimiter := True;
    Parts.Delimiter := ';';
    Parts.DelimitedText := APattern;
    Result := nil;
    SetLength(Result, Parts.Count);
    N := 0;
    for I := 0 to Parts.Count - 1 do
    begin
      P := Trim(Parts[I]);
      if P <> '' then
      begin
        Result[N] := P;
        Inc(N);
      end;
    end;
    SetLength(Result, N);
  finally
    Parts.Free;
  end;
  if Length(Result) = 0 then
  begin
    SetLength(Result, 1);
    Result[0] := '*.*';
  end;
end;

{ True when the FileKey pattern explicitly targets this file's
  extension — e.g. "*.exe" or "setup.exe" covers run.exe, but "*.*"
  and "*" do not. Guards portable/installed programs against broad
  wildcard sweeps. }
function ExplicitlyTargetsExt(const APattern, AFile: string): Boolean;
var
  Pats: TStringDynArray;
  E: string;
  I: Integer;
begin
  Result := False;
  E := LowerCase(ExtractFileExt(AFile));
  if E = '' then Exit;
  Pats := SplitPatterns(APattern);
  for I := 0 to High(Pats) do
    if (ExtractFileExt(LowerCase(Pats[I])) = E) or
       ((Length(Pats[I]) > Length(E)) and
        (Pos('?', Pats[I]) = 0) and
        (CompareText(Pats[I], ExtractFileName(AFile)) = 0)) then
      Exit(True);
end;

{ Probe whether a file is deletable right now by requesting DELETE access.
  A file held open without FILE_SHARE_DELETE fails the open and is skipped;
  TOCTOU between Analyze and Clean is accepted (same as upstream). }
function TryGetDeletableSize(const APath: string): Int64;
const
  DELETE_ACCESS = $00010000;
  FILE_SHARE_ALL = $00000007;
var
  H: THandle;
begin
  H := CreateFileW(PWideChar(UTF8Decode(APath)), DELETE_ACCESS,
    FILE_SHARE_ALL, nil, OPEN_EXISTING, 0, 0);
  if H = INVALID_HANDLE_VALUE then Exit(-1);
  CloseHandle(H);
  Result := GetFileSizeBytes(APath);
end;

function TCleaningService.Analyze(AEntry: TCleanerEntry;
  AProgress: TCleanProgress; ACancel: TCleanCancelCheck): TCleanResult;
var
  FileExcl: TExclusionRuleList;
  RegExcl: TStringList;
  Seen, Found: TStringList;
  Guard: TWow64FsGuard;
  FK: TFileKeyEntry;
  RK: TRegKeyEntry;
  F: string;
  Sz: Int64;
begin
  Result := TCleanResult.Create;
  Result.Entry := AEntry;
  try
    FileExcl := BuildFileExclusions(AEntry);
    RegExcl := TStringList(BuildRegistryExclusions(AEntry));
    Seen := TStringList.Create;
    Seen.CaseSensitive := False;
    Seen.Duplicates := dupIgnore;
    Seen.Sorted := True;
    Found := TStringList.Create;
    Guard := TWow64FsGuard.Create;
    try
      for FK in AEntry.FileKeys do
      begin
        Found.Clear;
        try
          FindFiles(FK, FileExcl, AEntry.Name, AProgress, ACancel, Found);
        except
          on E: ECleanCancelled do raise;   // cancel must reach the caller
          on E: Exception do ;              // a broken FileKey kills only itself
        end;
        for F in Found do
        begin
          if Seen.IndexOf(F) >= 0 then Continue;
          Seen.Add(F);
          Sz := TryGetDeletableSize(F);
          if Sz < 0 then Continue;
          Result.FilesToDelete.Add(F);
          Result.TotalBytes := Result.TotalBytes + Sz;
        end;
      end;

      for RK in AEntry.RegKeys do
      begin
        try
          FindRegistryItems(RK, RegExcl, Result.RegistryToDelete);
        except
          on E: Exception do ;
        end;
      end;

      { Special-action entries probe live system state directly — the
        rules engine has no FileKey/RegKey for these. }
      if AEntry.Special <> '' then
      begin
        CheckCancelled(ACancel);
        if SameText(AEntry.Special, SPECIAL_RECYCLEBIN) then
        begin
          if RecycleBinStatus(Result.SpecialBytes, Result.SpecialCount) and
             (Result.SpecialCount > 0) then
          begin
            Result.SpecialItems.Add(SPECIAL_RECYCLEBIN);
            Result.TotalBytes := Result.TotalBytes + Result.SpecialBytes;
          end;
        end
        else if SameText(AEntry.Special, SPECIAL_DEADSHORTCUTS) then
        begin
          FindDeadShortcuts(Result.FilesToDelete, Result.SpecialCount,
            Result.SpecialBytes);
          if Result.SpecialCount > 0 then
          begin
            Result.SpecialItems.Add(SPECIAL_DEADSHORTCUTS);
            Result.TotalBytes := Result.TotalBytes + Result.SpecialBytes;
          end;
        end;
      end;
    finally
      Guard.Free;
      FileExcl.Free;
      RegExcl.Free;
      Seen.Free;
      Found.Free;
    end;
  except
    Result.Free;
    raise;
  end;
end;

procedure TCleaningService.FindFiles(AFileKey: TFileKeyEntry;
  const AExcluded: TExclusionRuleList; const APrefix: string;
  AProgress: TCleanProgress; ACancel: TCleanCancelCheck; AOut: TStrings);
var
  Recurse: Boolean;
  Patterns: TStringDynArray;
  Resolved, Raw: TStringList;
  Dir, F: string;
  I: Integer;
begin
  Recurse := AFileKey.Flag in [fkRecurse, fkRemoveSelf];
  Patterns := SplitPatterns(AFileKey.Pattern);
  Resolved := FExpander.ResolvePaths(AFileKey.Path);
  Raw := TStringList.Create;
  try
    for I := 0 to Resolved.Count - 1 do
    begin
      Dir := Resolved[I];
      if not DirectoryExists(Dir) then Continue;

      Raw.Clear;
      EnumFilesSafe(Dir, Patterns, AExcluded, Recurse, APrefix,
        AProgress, ACancel, Raw);
      for F in Raw do
        { Temp content is scratch by definition — a confirmed clean run
          must take .exe/.msi debris too, so the runnable-extension guard
          yields inside temp roots. Locked files still fail the
          TryGetDeletableSize probe; IsProtectedPath keeps standing. }
        if (not IsExcluded(F, AExcluded)) and (not IsProtectedPath(F)) and
           IsPathSafeToDelete(F) and
           (IsTempPath(F) or (not IsRunnableExtension(F)) or
            ExplicitlyTargetsExt(AFileKey.Pattern, F)) then
          AOut.Add(F);
    end;
  finally
    Resolved.Free;
    Raw.Free;
  end;
end;

{ Walks the tree once per root; the OS matches files per pattern
  (FindFirst knows 8.3 aliases). Reparse points are skipped —
  Windows ships traps like 'All Users' → 'ProgramData' → loop. }
procedure TCleaningService.EnumFilesSafe(const ARoot: string;
  const APatterns: TStringDynArray; const AExcluded: TExclusionRuleList;
  ARecurse: Boolean; const APrefix: string; AProgress: TCleanProgress;
  ACancel: TCleanCancelCheck; AOut: TStrings);
var
  ScanRoot, P, Sub, Full: string;
  Seen, SubDirs: TStringList;
  SR: TSearchRec;
  R, I: Integer;
begin
  // whole-root check: skip an excluded branch before touching it
  ScanRoot := IncludeTrailingPathDelimiter(ARoot);
  for I := 0 to AExcluded.Count - 1 do
    if (AExcluded[I].Pattern = '') and
       (Pos(LowerCase(AExcluded[I].DirPrefix), LowerCase(ScanRoot)) = 1) then Exit;

  if Assigned(AProgress) then
    AProgress(APrefix + '  ›  ' + ARoot);

  Seen := TStringList.Create;
  Seen.CaseSensitive := False;
  Seen.Duplicates := dupIgnore;
  Seen.Sorted := True;
  try
    for P in APatterns do
    begin
      R := FindFirst(IncludeTrailingPathDelimiter(ARoot) + P, faAnyFile, SR);
      try
        while R = 0 do
        begin
          if (SR.Name <> '.') and (SR.Name <> '..') and
             ((SR.Attr and faDirectory) = 0) then
          begin
            Full := IncludeTrailingPathDelimiter(ARoot) + SR.Name;
            if Seen.IndexOf(Full) < 0 then
            begin
              Seen.Add(Full);
              AOut.Add(Full);
            end;
          end;
          R := FindNext(SR);
        end;
      finally
        SysUtils.FindClose(SR);
      end;
    end;

    if not ARecurse then Exit;

    SubDirs := TStringList.Create;
    try
      R := FindFirst(IncludeTrailingPathDelimiter(ARoot) + '*',
        faAnyFile, SR);
      try
        while R = 0 do
        begin
          if (SR.Name <> '.') and (SR.Name <> '..') and
             ((SR.Attr and faDirectory) <> 0) and
             ((SR.Attr and FILE_ATTRIBUTE_REPARSE_POINT) = 0) then
            SubDirs.Add(IncludeTrailingPathDelimiter(ARoot) + SR.Name);
          R := FindNext(SR);
        end;
      finally
        SysUtils.FindClose(SR);
      end;

      for Sub in SubDirs do
      begin
        CheckCancelled(ACancel);   // one check per folder is enough
        EnumFilesSafe(Sub, APatterns, AExcluded, True, APrefix,
          AProgress, ACancel, AOut);
      end;
    finally
      SubDirs.Free;
    end;
  finally
    Seen.Free;
  end;
end;

{ APath is the same key as AParent or sits below it. }
function IsSameOrChild(const APath, AParent: string): Boolean;
begin
  Result := SameText(APath, AParent) or
    (Pos(LowerCase(AParent) + '\', LowerCase(APath)) = 1);
end;

{ Matches the excluded key itself and every key below it. }
function IsRegistryPathExcluded(const APath: string;
  const AExclusions: TStrings): Boolean;
var
  I: Integer;
  N: string;
begin
  Result := False;
  N := NormalizeRegistryPath(APath);
  for I := 0 to AExclusions.Count - 1 do
    if IsSameOrChild(N, AExclusions[I]) then Exit(True);
end;

{ Queues a RegKey if it exists and is not excluded. Universal bitness:
  the 64-bit view is tried first, the 32-bit view additionally on 64-bit
  OS — a 32-bit app's leftovers under WOW6432Node get found too.
  The item carries the view it was found in so Clean deletes the same key. }
procedure TCleaningService.FindRegistryItems(ARegKey: TRegKeyEntry;
  const AExclusions: TStrings; AOut: TRegDeleteList);

  procedure TryView(AAccess: LongWord);
  var
    Hive, SubKey: string;
    Key: HKEY;
    R: TRegistry;
    Item: TRegDeleteItem;
  begin
    SplitHiveSubKey(ARegKey.KeyPath, Hive, SubKey);
    Key := HiveFromString(Hive);
    if (Key = 0) or (SubKey = '') then Exit;
    R := RegOpenRead(Key, SubKey, AAccess);
    if R = nil then Exit;
    try
      Item := TRegDeleteItem.Create;
      Item.KeyPath := ARegKey.KeyPath;
      Item.ValueName := ARegKey.ValueName;
      Item.Access := AAccess;
      if ARegKey.ValueName <> '' then
      begin
        if R.ValueExists(ARegKey.ValueName) then
          AOut.Add(Item)
        else
          Item.Free;
      end
      else
        AOut.Add(Item);
    finally
      R.Free;
    end;
  end;

begin
  if IsRegistryPathExcluded(ARegKey.KeyPath, AExclusions) then Exit;
  TryView(REGVIEW_64);
  // second view only where WOW64 really splits the key into two —
  // elsewhere both flags hit the same physical key and would duplicate
  if OsIs64Bit and ViewSplitApplies(ARegKey.KeyPath) then
    TryView(REGVIEW_32);
end;

{ Does the normalized registry path exist in the given view? }
function RegPathExists(const APath: string; AAccess: LongWord): Boolean;
var
  Hive, SubKey: string;
  Key: HKEY;
begin
  SplitHiveSubKey(APath, Hive, SubKey);
  Key := HiveFromString(Hive);
  Result := (Key <> 0) and (SubKey <> '') and
    RegKeyExists(Key, SubKey, AAccess);
end;

{ Deletes a registry value or key tree. If a REG exclusion sits below the
  target, the tree is cleaned one branch at a time so the protected key
  stays intact — port of DeleteRegistryItem. }
function TCleaningService.DeleteRegistryItem(AItem: TRegDeleteItem;
  const AExclusions: TStrings): Boolean;
var
  ItemPath, HiveS, SubKey: string;
  Hive: HKEY;
  Protected: TStringList;
  I: Integer;
begin
  Result := False;
  ItemPath := NormalizeRegistryPath(AItem.KeyPath);
  if IsRegistryPathExcluded(ItemPath, AExclusions) then Exit;
  if not IsRegistryPathSafeToDelete(ItemPath) then Exit;

  SplitHiveSubKey(AItem.KeyPath, HiveS, SubKey);
  Hive := HiveFromString(HiveS);
  if (Hive = 0) or (SubKey = '') then Exit;

  if AItem.ValueName <> '' then
    Exit(RegDeleteValue(Hive, SubKey, AItem.ValueName, AItem.Access));

  if not RegKeyExists(Hive, SubKey, AItem.Access) then Exit;

  // protected branches that actually exist below the target
  Protected := TStringList.Create;
  try
    for I := 0 to AExclusions.Count - 1 do
      if IsSameOrChild(AExclusions[I], ItemPath) and
         RegPathExists(AExclusions[I], AItem.Access) then
        Protected.Add(AExclusions[I]);

    if Protected.Count = 0 then
      Result := RegDeleteTree(Hive, SubKey, AItem.Access)
    else
    begin
      DeleteRegistryTreeExcept(Hive, SubKey, ItemPath, AItem.Access, Protected);
      Result := True;
    end;
  finally
    Protected.Free;
  end;
end;

{ Removes a key's contents while leaving excluded branches and their
  parents in place — port of DeleteRegistryTreeExcept. }
procedure TCleaningService.DeleteRegistryTreeExcept(AHive: HKEY;
  const ASubKey, AKeyPath: string; AAccess: LongWord;
  const AExclusions: TStrings);
var
  Names: TStringList;
  N, ChildSub, ChildPath: string;
  I: Integer;
  HasProtectedBelow: Boolean;
begin
  Names := TStringList.Create;
  try
    RegEnumValues(AHive, ASubKey, AAccess, Names);
    for N in Names do
      RegDeleteValue(AHive, ASubKey, N, AAccess);
  finally
    Names.Free;
  end;

  Names := TStringList.Create;
  try
    RegEnumSubKeys(AHive, ASubKey, AAccess, Names);
    for N in Names do
    begin
      ChildSub := ASubKey + '\' + N;
      ChildPath := AKeyPath + '\' + N;
      if IsRegistryPathExcluded(ChildPath, AExclusions) then Continue;

      // a protected key below → clean branch-by-branch, else wipe whole tree
      HasProtectedBelow := False;
      for I := 0 to AExclusions.Count - 1 do
        if IsSameOrChild(AExclusions[I], ChildPath) then
        begin
          HasProtectedBelow := True;
          Break;
        end;
      if HasProtectedBelow then
        DeleteRegistryTreeExcept(AHive, ChildSub, ChildPath, AAccess, AExclusions)
      else
        RegDeleteTree(AHive, ChildSub, AAccess);
    end;
  finally
    Names.Free;
  end;
end;

{ Sort helper: longest path first, so children are pruned before parents. }
function DirLengthDesc(AList: TStringList; AIndex1, AIndex2: Integer): Integer;
begin
  Result := Length(AList[AIndex2]) - Length(AList[AIndex1]);
end;

{ Cleans up empty folders left behind by a REMOVESELF clean.
  Order matters: deepest first, so parents become empty before we try to
  delete them. The root folder itself is deleted last if it ends up
  empty too. Reparse points are never descended into. }
procedure TCleaningService.TryPruneEmptyDirs(const APath: string);
var
  Dirs: TStringList;
  I: Integer;

  procedure Collect(const ARoot: string);
  var
    SR: TSearchRec;
    R: Integer;
    Sub: string;
  begin
    R := FindFirst(IncludeTrailingPathDelimiter(ARoot) + '*', faAnyFile, SR);
    try
      while R = 0 do
      begin
        if (SR.Name <> '.') and (SR.Name <> '..') and
           ((SR.Attr and faDirectory) <> 0) and
           ((SR.Attr and FILE_ATTRIBUTE_REPARSE_POINT) = 0) then
        begin
          Sub := IncludeTrailingPathDelimiter(ARoot) + SR.Name;
          Dirs.Add(Sub);
          Collect(Sub);
        end;
        R := FindNext(SR);
      end;
    finally
      SysUtils.FindClose(SR);
    end;
  end;

  function DirIsEmpty(const ADir: string): Boolean;
  var
    SR: TSearchRec;
    R: Integer;
  begin
    Result := False;
    R := FindFirst(IncludeTrailingPathDelimiter(ADir) + '*', faAnyFile, SR);
    try
      while R = 0 do
      begin
        if (SR.Name <> '.') and (SR.Name <> '..') then Exit;
        R := FindNext(SR);
      end;
      Result := True;
    finally
      SysUtils.FindClose(SR);
    end;
  end;

begin
  if not DirectoryExists(APath) then Exit;
  { If APath itself must not be deleted (protected root, temp root),
    its subtree is off-limits too — otherwise a FileKey like
    '%ProgramData%|*.tmp|REMOVESELF' would prune OTHER apps' empty
    folders. }
  if IsTempRoot(APath) or (not IsPathSafeToDelete(APath)) then Exit;
  try
    Dirs := TStringList.Create;
    try
      Collect(APath);
      Dirs.CustomSort(@DirLengthDesc);
      for I := 0 to Dirs.Count - 1 do
        if DirIsEmpty(Dirs[I]) then RemoveDir(Dirs[I]);
      if DirIsEmpty(APath) then RemoveDir(APath);
    finally
      Dirs.Free;
    end;
  except
    // a pruning failure must not fail the whole clean
  end;
end;

{ Executes the Analyze plan. Direct deletion — no recycle bin, same as
  upstream. Cancellation is checked between items so we never delete half
  an entry; anything that moved or is now locked is skipped silently. }
function TCleaningService.Clean(AResult: TCleanResult;
  AProgress: TCleanProgress; ACancel: TCleanCancelCheck): TCleanStats;
var
  RegExcl: TStringList;
  Guard: TWow64FsGuard;
  Resolved: TStringList;
  F, Dir: string;
  Item: TRegDeleteItem;
  FK: TFileKeyEntry;
  Sz: Int64;
  Att: TCookieCleanAttempt;
begin
  Result.Count := 0;
  Result.Bytes := 0;
  if (AResult = nil) or (AResult.Entry = nil) then Exit;

  RegExcl := TStringList(BuildRegistryExclusions(AResult.Entry));
  Guard := TWow64FsGuard.Create;
  try
    for F in AResult.FilesToDelete do
    begin
      CheckCancelled(ACancel);   // stop between files — never half an entry
      try
        // final gate: the plan may be stale; safety lists are re-checked
        if IsProtectedPath(F) or (not IsPathSafeToDelete(F)) then Continue;

        { Cookie databases: prune rows inside the DB so keep-list domains
          survive — upstream never deletes a recognized store wholesale.
          Sidecars (Cookies-journal, …) are skipped the same way. }
        if CookieKeepList <> nil then
        begin
          Att := TryCleanProtectedStore(F, CookieKeepList);
          if Att.Handled then
          begin
            if Att.Succeeded then
            begin
              Inc(Result.Count, Att.CookiesRemoved);
              Result.Bytes := Result.Bytes + Att.BytesFreed;
              if (Att.CookiesRemoved > 0) and Assigned(AProgress) then
                AProgress('Cookies: ' + F);
            end;
            Continue;
          end;
        end;

        Sz := GetFileSizeBytes(F);
        if Sz < 0 then Continue;
        if not SysUtils.DeleteFile(F) then Continue;
        Inc(Result.Count);
        Result.Bytes := Result.Bytes + Sz;
        if Assigned(AProgress) then AProgress('Deleted: ' + F);
      except
        // in use or already gone; skip silently
      end;
    end;

    { Special actions: empty the recycle bin in one shot — no per-file
      inventory exists, so this is the whole 'clean' for that entry. }
    if AResult.SpecialItems.IndexOf(SPECIAL_RECYCLEBIN) >= 0 then
    begin
      CheckCancelled(ACancel);
      try
        if SHEmptyRecycleBinW(0, nil,
             SHERB_NOCONFIRMATION or SHERB_NOPROGRESSUI or SHERB_NOSOUND) = S_OK then
        begin
          Inc(Result.Count);
          Result.Bytes := Result.Bytes + AResult.SpecialBytes;
          if Assigned(AProgress) then AProgress('Deleted: Recycle Bin');
        end;
      except
        // already empty or silently denied — skip
      end;
    end;

    for Item in AResult.RegistryToDelete do
    begin
      CheckCancelled(ACancel);
      try
        if DeleteRegistryItem(Item, RegExcl) then
        begin
          Inc(Result.Count);
          if Assigned(AProgress) then
            AProgress('Registry: ' + Item.DisplayName);
        end;
      except
      end;
    end;

    // REMOVESELF: prune directories that are now empty
    for FK in AResult.Entry.FileKeys do
      if FK.Flag = fkRemoveSelf then
      begin
        Resolved := FExpander.ResolvePaths(FK.Path);
        try
          for Dir in Resolved do
            TryPruneEmptyDirs(Dir);
        finally
          Resolved.Free;
        end;
      end;
  finally
    Guard.Free;
    RegExcl.Free;
  end;
end;

{ ExcludeKey lines → matchable rules. REG exclusions don't apply to file
  paths; global exclusions from the caller layer on top. }
function TCleaningService.BuildFileExclusions(AEntry: TCleanerEntry): TExclusionRuleList;
var
  Rules: TExclusionRuleList;

  procedure AddRule(const AEx: TExcludeKeyEntry);
  var
    Resolved: TStringList;
    I: Integer;
    Rule: TExclusionRule;
  begin
    if AEx.ExType = etReg then Exit;
    Resolved := FExpander.ResolvePaths(AEx.Path);
    try
      for I := 0 to Resolved.Count - 1 do
      begin
        Rule := TExclusionRule.Create;
        Rule.DirPrefix := IncludeTrailingPathDelimiter(Resolved[I]);
        Rule.Pattern := AEx.Pattern;
        Rules.Add(Rule);
      end;
    finally
      Resolved.Free;
    end;
  end;

var
  Ex: TExcludeKeyEntry;
  Line: string;
begin
  Rules := TExclusionRuleList.Create;
  for Ex in AEntry.ExcludeKeys do
    AddRule(Ex);
  if GlobalExclusionsEnabled then
    for Line in GlobalExclusions do
    begin
      Ex := TExcludeKeyEntry.Parse(Line);
      try
        AddRule(Ex);
      finally
        Ex.Free;
      end;
    end;
  Result := Rules;
end;

{ REG exclusions protect key branches, not file paths — kept separate. }
function TCleaningService.BuildRegistryExclusions(AEntry: TCleanerEntry): TStrings;
var
  Paths: TStringList;
  Ex: TExcludeKeyEntry;
  Line, N: string;
begin
  Paths := TStringList.Create;
  Paths.CaseSensitive := False;
  Paths.Duplicates := dupIgnore;
  Paths.Sorted := True;
  for Ex in AEntry.ExcludeKeys do
    if Ex.ExType = etReg then
    begin
      N := NormalizeRegistryPath(Ex.Path);
      if N <> '' then Paths.Add(N);
    end;
  if GlobalExclusionsEnabled then
    for Line in GlobalExclusions do
    begin
      Ex := TExcludeKeyEntry.Parse(Line);
      try
        if Ex.ExType = etReg then
        begin
          N := NormalizeRegistryPath(Ex.Path);
          if N <> '' then Paths.Add(N);
        end;
      finally
        Ex.Free;
      end;
    end;
  Result := Paths;
end;

end.
