# Клинер: сравнение с FluentCleaner-classic и CCleaner portable

Свежий разбор 2026-09-19. Три референса:

- `FluentCleaner-classic\` — эталон (C#/.NET, WinUI 3), из которого портируется движок;
- `C:\TCPU75\Programm\CCleaner` — портативный CCleaner (Piriform), отдельный референс по форматам баз;
- `CleanSweep` Клинер — наш порт (Free Pascal).

---

## 1. Движок: CleanSweep vs FluentCleaner

Порт верный (сверено построчно по `Winapp2Parser.cs`, `PathExpander.cs`,
`DetectionService.cs`, `CleaningService.cs`). Что добавлено поверх эталона:

| Аспект | FluentCleaner | CleanSweep Клинер |
|---|---|---|
| Парсер | winapp2.ini, 4075 записей; `DetectOS` **не читает** | тот же парсер + `DetectOS`-гейт (семантика winapp2ool: min/max/диапазон, `RtlGetVersion`, fail-closed) |
| Детекция | только нативный regview (64-бит) | 64-view всегда + 32-view только где WOW64 разделяет ключ (`ViewSplitApplies`) + **кэш вердиктов** на прогон |
| Безопасность | 1 строчка: `\IndexedDB\chrome-extension_` | то же + `cs.safety` (System32/Defender/службы/ProtectedRegistryRoots…), гейт в Analyze **и** повторно в Clean |
| Формат потери базы | — | мёрдж источников с дедупом по имени, first-wins |
| Осмотр/чистка | однопоточный | до 4 воркеров (детект/анализ), чистка однопоточно; живой прогресс по строкам |
| Вкладка креденшелов | — | `IsSecurityEntryFor` — имя **и** токены FileKey/RegKey → tab «Пароли и сессии» (503 записи: 355 по имени + 148 по путям) + `SEC_EXTRA_INI` |
| Обновление баз | — | `cs.download` (WinINet), `.part`-файл |

Точные порты (без отличий): FileKey/RegKey/ExcludeKey-парсинг, `RECURSE`/
`REMOVESELF`, wildcard-резолв `%Var%` (включая `%ProgramFiles%`→x86-фолбэк),
`TryGetDeletableSize` (CreateFileW DELETE), `DeleteRegistryTreeExcept`,
`TryPruneEmptyDirs`, OR-детекция с early-out.

## 2. Формат баз

### winapp2.ini (общий для всех трёх)
CCleaner portable содержит `winapp2.ini` **v260915 (4068 секций)** — тот же
community-формат, что и `FluentCleaner-classic\Winapp2.ini` v260828 (4075).
Секции: общих 4067; в 260915 новая 1 (`Eagle Animation *`), в 260828 ушедших 8.
Форматы идентичны → **парсер CleanSweep разбирает winapp2.ini из CCleaner
без изменений** (проверено: 0 неизвестных ключей).

### winapp1.ini — встроенная база CCleaner (404 секции)
Ключи: `ID`, `LangSecRef`, `LangRef` (локализованное имя), `Default`, `Detect1..8`,
`DetectFile1..3`, `SpecialDetect`, **`SpecialKey1`** (нативный код), `FileKeyN`,
`RegKeyN`, `ExcludeKeyN`, `DetectOS`, `WarningRef`. `Section` **нет**.

Разбивка: 351 чисто data-driven (FileKey/RegKey) · 43 только `SpecialKey` ·
9 и SpecialKey и FileKey/RegKey · 1 без того и другого.

`SpecialDetect`: DET_OPERA, DET_MOZILLA, DET_THUNDERBIRD, DET_CHROME,
DET_MOZILLA_GOOGLE_TOOLBAR, DET_SAFARI_PASSWORD. Из них CleanSweep знает
DET_OPERA/THUNDERBIRD/CHROME; DET_MOZILLA и SAFARI-коды неизвестны → фолбэк
на Detect/DetectFile (в этих записях есть).

`FileKey`-флаги: только `RECURSE`(154) и `REMOVESELF`(16) — совместимо.
`DetectOS`: `6.3|6.3`, `6.0` — совместимо.

**Вывод**: raw winapp1.ini парсер не бьёт — `LangRef`/`WarningRef`/`ID`/`SpecialKey`
просто игнорируются, а записи с одним `SpecialKey` отсекаются `IsValidEntry`
(ничего чистить нельзя → корректно). Категории LangSecRef 3021–3031 в известной
карте есть (кроме 3032/3041, отсутствуют намеренно, как у орига).

### winsys1.ini — системная база CCleaner (48 секций)
`LangSecRef` = 3001–3005 (IE/Explorer/System/Advanced/Edge) — **в карту
ResolveCategory не входят** → без конвертации уехали бы в «Other Applications».
Ключи: `Detect1..3` (обычные reg-пути), `DetectFile1..3`, `FileKeyN`, `RegKeyN`,
`ExcludeKey1`, `DetectOS`, `SpecialKey1/2` (нативные N_* — N_EDGE_TEMP и т.п.).
Разбивка: 15 чисто data-driven · 25 только `SpecialKey` · 7 и SpecialKey и
FileKey/RegKey · 1 без обоих.

### winreg1.ini — «Реестр» CCleaner (15 секций)
Вся база — `SpecialKey1` R_* (R_SHARED_DLLS, R_FILE_EXTS, R_ACTIVEX, R_INTERFACE,
R_APPLICATIONS, R_FONTS, R_HELP_FILES, R_INSTALLER, R_SOUNDS, R_STARTUP,
R_UNINSTALL, R_OLD_WINDOWS_SEARCH, R_APPLICATION_PATHS, R_RUN, R_RUNONCE).
Это **нативный анализатор целостности реестра**, а не data-driven чистка —
к нашему движку неприменим (см. §4).

## 3. Миграция CCleaner → CleanSweep уже есть наполовину

`test\ССleaner.ini` (724 секции, собрана 2026-09-18):
- 360 уникальных секций из CCleaner/winapp2.ini v240505 (нет в Winapp2/Winapp3);
- 344 конвертировано из winapp1.ini (внутренние правила);
- 20 конвертировано из winsys1.ini;
- пропущено 85 (жёсткие `SpecialKey*` + winreg1-анализатор).

Состояние мигрированной базы:
- неизвестных ключей 0, `SpecialDetect` 0, `Warning` 1, `DetectOS` 4 (значения
  `6.0` и `6.3|6.3` — оба поддерживаются);
- из 724 у **всех** есть FileKey/RegKey (IsValidEntry не отсекает ничего по чистке);
- **9 записей без детекции** — отсекутся `IsValidEntry` (по-дизайну, как 9 секций
  Default.ini): Run (in Start Menu), Network Passwords, Other Explorer MRUs,
  User Assist History, Chkdsk File Fragments, Memory Dumps, Windows Log Files,
  Menu Order Cache, RegEdit.

**Обновление 2026-09-21**: файл перенесён в `data\CCleaner.ini` и
подключён как пятый источник с чекбоксом в панели баз
(Custom → CCleaner → Default → Winapp3 → Winapp2, first-wins дедуп).

## 4. Что в CCleaner есть, а у нас нет (и насколько «перенимается»)

| Фича CCleaner | Механика | Можно ли перенять |
|---|---|---|
| Реестр-анализатор (winreg1) | нативные R_* проверки целостности | нет — другой класс задач, пишется кодом, не данными |
| Спец-чистки `SpecialKey1/2` (85 шт: Chrome/Firefox/Opera/Safari/Edge/Thunderbird/Office MRU…) | нативные N_* процедуры | частично: многие уже покрыты записями winapp2; остаток — код |
| `LangRef`/`WarningRef` (локализация имён в DLL) | строковые таблицы в branding.dll | нет — у нас `Lg()` + `Warning=` текстом |
| Свои исключения (CCleaner.exclude, настройка) | постоянный скип пользователя | эквивалент — `GlobalExclusions` в движке уже есть (из настроек) |
| Cookie keep-list «не удалять» | нативное | **перенято 2026-09-21**: `cs.cookies` + `cs.winsqlite` (winsqlite3.dll), keep-list в CleanSweep.ini |
| Секции winsys1 3001–3005 | категории IE/Explorer/System/Advanced/Edge | добавить в карту `ResolveCategory` при конвертации |

## 5. Выводы / следующие шаги (все — на согласование, `AGENTS.md` п.3/п.7)

1. ~~**Подключить `ССleaner.ini`** как пятый источник~~ — **сделано
   2026-09-21**: `data\CCleaner.ini`, чекбокс «CCleaner DB» в панели баз.
2. Прогнать `winapp2test` против `ССleaner.ini` (724) и против
   `C:\TCPU75\Programm\CCleaner\winapp2.ini` (4068) — регрессия в тест.
3. Решить судьбу 9 бездетекционных записей ССleaner.ini (или `DetectOS`-гейт,
   или нативный код, или намеренный дроп, как в Default.ini).
4. winreg1 и остальные нативные SpecialKey-чистки — осознанно **не переносим**
   до отдельного решения; фиксируем в `decisions.md`.
5. Версия winapp2 у CCleaner новее на 9 записей — обновление баз идёт штатно
   через кнопку «Обновить» (тот же URL, что у `_update.bat` CCleaner).

Связанные документы: `docs/port-plan.md` (фазы), `docs/decisions.md` (решения).

---

## 6. Приложение: «последний FluentCleaner» — net48 build 1.17.227.0

`C:\Users\sa\Downloads\FluentCleaner-Classic-net48\FluentCleaner-Classic-net48` —
скомпилированная сборка Classic-ветки под .NET Framework 4.8 (WinForms,
`FluentCleaner.Classic.exe` 1.17.227.0 + `FluentCleaner.Core.dll` 1.0.0.0).

Проверено:

| Компонент | Что это | Статус для нас |
|---|---|---|
| `Winapp2.ini` | v260828, 4075 записей | **байт-в-байт равен `data\Winapp2.ini`** — нового в базе нет |
| `Winapp3.ini` | v251007, 855 записей | **байт-в-байт равен `data\Winapp3.ini`** |
| `FluentCleaner.Core.dll` | движок | та же логика, что и снапшот-исходник: `TryCheckSpecialDetect` на месте, **DetectOS в движке и тут нет** (наши `DetectOS` — наше расширение, не из орига) |
| `Custom\*.ini` (Accounting, Claude, Deep Clean, Deep Scan) | готовые пользовательские БД | весь синтаксис совместим с нашим парсером (см. §2/§3): `Section=`, `Warning=`, `Default=`, `DetectFile=`, `'?'`-маски, `;`-мульти-паттерны, pipe+`RECURSE`/`REMOVESELF`, wildcard-сегменты в середине пути (`%LocalAppData%\SKBKontur\*\Cache\|*.*`) |
| `Localization\en.json, ru.json` | строки UI (WinForms-стиль) | у нас свой `Lg()` на 4 языка — не переносим |
| Группы `[Accounting]` (дубль-заголовок) | winapp2ool-стиль группы | парсится (пустая секция-группа), имя группы берётся через `Section=` у соседей |

Бонус от Custom-БД: отличный негативный/позитивный тест-набор для нашего парсера
(`Deep Scan.ini` — полнопрофильные RECURSE-сканы `%UserProfile%|*.bak` и т.п.).

### 6.1 Найден разрыв: кодировка без BOM — **закрыт 2026-09-21**
Все БД (и net48 `Custom\`, и наши `data\`) — UTF-8 **без BOM**. Раньше
`LoadDbFile` читал через `TStringList.LoadFromFile` → байты трактовались
как ANSI → кириллица «крокозябрами». Решено: `LoadTextFile` в
`cs.utils` (BOM → UTF-8; валидный UTF-8 без BOM → UTF-8; иначе ANSI),
применён в `TWinapp2Parser.ParseFile` и загрузке/инфо баз в cleanerform.
Регрессия — тесты UTF-8 в `winapp2test.lpr`.