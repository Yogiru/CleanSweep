unit customform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, StrUtils, Forms, Controls, StdCtrls, ExtCtrls, Dialogs,
  ComCtrls, Windows, zipper,
  cs.winapp2, cs.utils, cs.lang, ruleeditform, packform;

const
  RULES_ZIP_FLAG = 'cleansweep-rules.flag';   // marker inside exported packs

{ Directory the cleaner scans at load: enabled *.ini files merge into
  the entry pool at top priority; *.ini.disabled are listed but skipped
  (upstream CustomEntryService semantics). }
function CustomDir: string;

type
  { Modal manager for the Custom\ folder: file list with entry counts,
    enable/disable by renaming to .ini.disabled, open the folder,
    create a rule skeleton, delete a file. }
  TCustomForm = class(TForm)
    lvFiles: TListView;
    lblHint: TLabel;
    lblStatus: TLabel;
    btnToggle: TButton;
    btnOpenFolder: TButton;
    btnNew: TButton;
    btnEdit: TButton;
    btnDelete: TButton;
    btnExport: TButton;
    btnImport: TButton;
    btnHelp: TButton;
    btnClose: TButton;
    procedure FormCreate(Sender: TObject);
    procedure BtnToggleClick(Sender: TObject);
    procedure BtnOpenFolderClick(Sender: TObject);
    procedure BtnNewClick(Sender: TObject);
    procedure BtnEditClick(Sender: TObject);
    procedure BtnDeleteClick(Sender: TObject);
    procedure BtnExportClick(Sender: TObject);
    procedure BtnImportClick(Sender: TObject);
    procedure BtnHelpClick(Sender: TObject);
    procedure LvFilesSelectItem(Sender: TObject; AItem: TListItem;
      ASelected: Boolean);
    procedure FormDestroy(Sender: TObject);
  private
    FNames: TStringList;             // real file names per list row
    procedure RefreshList;
    function SelectedPath: string;
  end;

function ShowCustomDialog(AOwner: TComponent): TModalResult;

implementation

{$R *.lfm}

function CustomDir: string;
begin
  Result := ExtractFilePath(ParamStr(0)) + 'Custom\';
end;

function ShowCustomDialog(AOwner: TComponent): TModalResult;
var
  F: TCustomForm;
begin
  F := TCustomForm.Create(AOwner);
  try
    Result := F.ShowModal;
  finally
    F.Free;
  end;
end;

function CustomEntryCount(const APath: string): Integer;
var
  P: TWinapp2Parser;
  L: TCleanerEntryList;
begin
  Result := 0;
  P := TWinapp2Parser.Create(True);   // permissive — same as the merge
  try
    L := P.ParseFile(APath);
    try
      Result := L.Count;
    finally
      L.Free;
    end;
  finally
    P.Free;
  end;
end;

procedure TCustomForm.RefreshList;
var
  SR: TSearchRec;
  R: Integer;
  It: TListItem;
  Full, Disp: string;
  Disabled: Boolean;
begin
  lvFiles.Items.BeginUpdate;
  try
    lvFiles.Items.Clear;
    FNames.Clear;
    if DirectoryExists(CustomDir) then
    begin
      // '*.ini*' catches both enabled .ini and toggled .ini.disabled
      R := FindFirst(CustomDir + '*.ini*', faAnyFile, SR);
      try
        while R = 0 do
        begin
          if (SR.Attr and faDirectory) <> 0 then
          begin
            R := FindNext(SR);
            Continue;
          end;
          Disabled := EndsText('.ini.disabled', SR.Name);
          if (not Disabled) and (not EndsText('.ini', SR.Name)) then
          begin
            R := FindNext(SR);
            Continue;
          end;
          Full := CustomDir + SR.Name;
          It := lvFiles.Items.Add;
          if Disabled then
            Disp := Copy(SR.Name, 1, Length(SR.Name) - 9)
          else
            Disp := SR.Name;
          It.Caption := Disp;
          It.SubItems.Add(IntToStr(CustomEntryCount(Full)));
          if Disabled then
            It.SubItems.Add(Lg('выкл.', 'выкл.', 'вимк.', 'off'))
          else
            It.SubItems.Add(Lg('вкл.', 'укл.', 'увімк.', 'on'));
          FNames.Add(SR.Name);
          // 1-based: index 0 would store nil and SelectedPath would
          // silently fail on the first file in the list
          It.Data := Pointer(PtrInt(FNames.Count));
          R := FindNext(SR);
        end;
      finally
        SysUtils.FindClose(SR);
      end;
    end;
  finally
    lvFiles.Items.EndUpdate;
  end;
  lblStatus.Caption := Format(Lg('Папка: %s', 'Папка: %s', 'Папка: %s',
    'Folder: %s'), [CustomDir]);
end;

function TCustomForm.SelectedPath: string;
var
  Idx: PtrUInt;
begin
  Result := '';
  if (lvFiles.Selected = nil) or (lvFiles.Selected.Data = nil) then Exit;
  Idx := PtrUInt(lvFiles.Selected.Data) - 1;
  if Idx < PtrUInt(FNames.Count) then
    Result := CustomDir + FNames[Idx];
end;

procedure TCustomForm.FormCreate(Sender: TObject);
begin
  Caption := Lg('Свои правила очистки', 'Свае правілы ачысткі',
                'Свої правила очищення', 'Custom cleanup rules');
  lvFiles.Columns[0].Caption := Lg('Файл', 'Файл', 'Файл', 'File');
  lvFiles.Columns[1].Caption := Lg('Записей', 'Запісаў', 'Записів',
                                   'Entries');
  lvFiles.Columns[2].Caption := Lg('Состояние', 'Стан', 'Стан', 'State');
  lblHint.Caption := Lg(
    'Файлы *.ini из этой папки добавляются в базу при загрузке.',
    'Файлы *.ini з гэтай папкі дадаюцца ў базу пры загрузцы.',
    'Файли *.ini з цієї папки додаються до бази при завантаженні.',
    '*.ini files from this folder merge into the database on load.');
  btnToggle.Caption := Lg('Вкл/выкл', 'Укл/выкл', 'Увімк/вимк',
                          'Enable/disable');
  btnOpenFolder.Caption := Lg('Открыть папку', 'Адкрыць папку',
                              'Відкрити папку', 'Open folder');
  btnNew.Caption := Lg('Новая запись…', 'Новы запіс…', 'Новий запис…',
                       'New rule…');
  btnEdit.Caption := Lg('Изменить…', 'Змяніць…', 'Змінити…', 'Edit…');
  btnDelete.Caption := Lg('Удалить', 'Выдаліць', 'Видалити', 'Delete');
  btnExport.Caption := Lg('Экспорт…', 'Экспарт…', 'Експорт…', 'Export…');
  btnImport.Caption := Lg('Импорт…', 'Імпарт…', 'Імпорт…', 'Import…');
  btnHelp.Caption := Lg('Справка', 'Даведка', 'Довідка', 'Help');
  btnClose.Caption := Lg('Закрыть', 'Закрыць', 'Закрити', 'Close');
  FNames := TStringList.Create;
  RefreshList;
end;

procedure TCustomForm.FormDestroy(Sender: TObject);
begin
  FNames.Free;
end;

procedure TCustomForm.LvFilesSelectItem(Sender: TObject; AItem: TListItem;
  ASelected: Boolean);
begin
  btnToggle.Enabled := ASelected;
  btnEdit.Enabled := ASelected and not EndsText('.disabled', SelectedPath);
  btnDelete.Enabled := ASelected;
end;

procedure TCustomForm.BtnToggleClick(Sender: TObject);
var
  P, N: string;
begin
  P := SelectedPath;
  if P = '' then Exit;
  if EndsText('.disabled', P) then
    N := Copy(P, 1, Length(P) - 9)
  else
    N := P + '.disabled';
  if not RenameFile(P, N) then
    lblStatus.Caption := Lg('Не удалось переименовать файл.',
      'Не атрымалася перайменаваць файл.',
      'Не вдалося перейменувати файл.', 'Could not rename the file.');
  RefreshList;
end;

procedure TCustomForm.BtnOpenFolderClick(Sender: TObject);
begin
  ForceDirectories(CustomDir);
  ShowInExplorer(CustomDir);
end;

{ New rule → the rule editor (fields + live preview) writes the ini. }
procedure TCustomForm.BtnNewClick(Sender: TObject);
begin
  ForceDirectories(CustomDir);
  if EditRuleDialog(Self, '') = mrOk then
    RefreshList;
end;

procedure TCustomForm.BtnEditClick(Sender: TObject);
var
  P: string;
begin
  P := SelectedPath;
  if (P = '') or EndsText('.disabled', P) then Exit;
  if EditRuleDialog(Self, P) = mrOk then
    RefreshList;
end;

{ Opens the syntax guide (docs\custom-rules.md next to the exe) in the
  associated editor; without the doc file falls back to a compact
  cheat-sheet so the help works in a bare portable install too. }
procedure TCustomForm.BtnHelpClick(Sender: TObject);
var
  Doc: string;
begin
  Doc := ExtractFilePath(ParamStr(0)) + 'docs\custom-rules.md';
  if FileExists(Doc) then
  begin
    ShellExecuteW(0, PWideChar(UTF8Decode('open')),
      PWideChar(UTF8Decode(Doc)), nil, nil, SW_SHOW);
    Exit;
  end;
  MessageDlg(
    '[Name *]' + sLineBreak +
    'Section=Custom' + sLineBreak +
    'Default=False' + sLineBreak +
    'DetectFile=%ProgramFiles%\App   ' +
      Lg('(необязательно — без детекции запись считается установленной)',
         '(неабавязкова — без детэкцыі запіс лічыцца ўсталяваным)',
         '(необов''язково — без детекції запис вважається встановленим)',
         '(optional — undetected entries count as installed)') +
      sLineBreak +
    'FileKey1=<папка>|<маски>|RECURSE|REMOVESELF' + sLineBreak +
    'RegKey1=HKCU\Software\App   ' +
      Lg('(или …|<имя значения>)', '(або …|<імя значэння>)',
         '(або …|<ім''я значення>)', '(or …|<value name>)') + sLineBreak +
    'ExcludeKey1=FILE|PATH|REG|<путь>|<маска>' + sLineBreak + sLineBreak +
    Lg('Полная справка: docs\custom-rules.md в репозитории.',
       'Поўная даведка: docs\custom-rules.md у рэпазітарыі.',
       'Повна довідка: docs\custom-rules.md у репозиторії.',
       'Full guide: docs\custom-rules.md in the repository.'),
    mtInformation, [mbOK], 0);
end;

procedure TCustomForm.BtnDeleteClick(Sender: TObject);
var
  P: string;
begin
  P := SelectedPath;
  if P = '' then Exit;
  if MessageDlg(Format(Lg('Удалить файл «%s»?', 'Выдаліць файл «%s»?',
      'Видалити файл «%s»?', 'Delete file "%s"?'), [ExtractFileName(P)]),
      mtConfirmation, [mbYes, mbNo], 0) <> mrYes then Exit;
  if SysUtils.DeleteFile(P) then
    RefreshList
  else
    lblStatus.Caption := Lg('Не удалось удалить файл.',
      'Не атрымалася выдаліць файл.', 'Не вдалося видалити файл.',
      'Could not delete the file.');
end;

{ --- rule pack export/import (zip + marker file) ---------------------- }

{ Display label for a rule file: name + first few entry titles. }
function FileLabel(const APath: string; P: TWinapp2Parser): string;
var
  EL: TCleanerEntryList;
  E: TCleanerEntry;
  S: string;
begin
  S := '';
  EL := P.ParseFile(APath);
  try
    for E in EL do
    begin
      if Length(S) > 90 then
      begin
        S := S + '…';
        Break;
      end;
      if S <> '' then S := S + ', ';
      S := S + E.Name;
    end;
  finally
    EL.Free;
  end;
  Result := ExtractFileName(APath);
  if S <> '' then Result := Result + '  —  ' + S;
end;

procedure DeleteTree(const ADir: string);
var
  SR: TSearchRec;
  R: Integer;
begin
  R := SysUtils.FindFirst(ADir + '\*', faAnyFile, SR);
  try
    while R = 0 do
    begin
      if (SR.Name <> '.') and (SR.Name <> '..') then
        if (SR.Attr and faDirectory) <> 0 then
          DeleteTree(ADir + '\' + SR.Name)
        else
          SysUtils.DeleteFile(ADir + '\' + SR.Name);
      R := SysUtils.FindNext(SR);
    end;
  finally
    SysUtils.FindClose(SR);
  end;
  RemoveDir(ADir);
end;

{ Packs picked Custom\*.ini files into a zip with a marker file.
  The selected row pre-checks its file so "export what I have selected"
  works without extra clicks; no selection → all files pre-checked. }
procedure TCustomForm.BtnExportClick(Sender: TObject);
var
  D: TSaveDialog;
  Z: TZipper;
  SR: TSearchRec;
  R, I: Integer;
  OutName, Flag, Sel: string;
  Files, Disp, Picked: TStrings;
  Checked: TStringList;
  L: TStringList;
  P: TWinapp2Parser;
begin
  Files := TStringList.Create;
  Disp := TStringList.Create;
  Checked := TStringList.Create;
  Checked.Sorted := True;
  Checked.Duplicates := dupIgnore;
  P := TWinapp2Parser.Create(True);
  try
    R := SysUtils.FindFirst(CustomDir + '*.ini', faAnyFile, SR);
    try
      while R = 0 do
      begin
        if (SR.Attr and faDirectory) = 0 then
        begin
          Files.Add(SR.Name);
          Disp.Add(FileLabel(CustomDir + SR.Name, P));
        end;
        R := SysUtils.FindNext(SR);
      end;
    finally
      SysUtils.FindClose(SR);
    end;
    if Files.Count = 0 then Exit;

    Sel := ExtractFileName(SelectedPath);
    if Sel <> '' then Checked.Add(Sel);

    Picked := PickPackItems(Self,
      Lg('Экспорт правил', 'Экспарт правілаў', 'Експорт правил',
         'Export rules'),
      Lg('Файлы в пакет:', 'Файлы ў пакет:', 'Файли в пакет:',
         'Files to pack:'),
      Disp, Files, Checked);
    try
      if (Picked = nil) or (Picked.Count = 0) then Exit;

      OutName := '';
      D := TSaveDialog.Create(Self);
      try
        D.Title := Lg('Экспорт правил', 'Экспарт правілаў',
                      'Експорт правил', 'Export rules');
        D.Filter := 'CleanSweep rules (*.zip)|*.zip';
        D.DefaultExt := 'zip';
        D.FileName := 'CleanSweep-rules.zip';
        D.Options := D.Options + [ofOverwritePrompt];
        if D.Execute then OutName := D.FileName;
      finally
        D.Free;
      end;
      if OutName = '' then Exit;

      Flag := IncludeTrailingPathDelimiter(GetTempDir(False)) +
        RULES_ZIP_FLAG;
      L := TStringList.Create;
      try
        L.Text := 'CleanSweep rules package v1';
        L.SaveToFile(Flag);
      finally
        L.Free;
      end;

      Z := TZipper.Create;
      try
        Z.FileName := OutName;
        Z.Entries.AddFileEntry(Flag, RULES_ZIP_FLAG);
        for I := 0 to Picked.Count - 1 do
          Z.Entries.AddFileEntry(CustomDir + Picked[I], Picked[I]);
        Z.ZipAllFiles;
      finally
        Z.Free;
        SysUtils.DeleteFile(Flag);
      end;
      lblStatus.Caption := Format(Lg('Экспортировано файлов: %d → %s',
                           'Экспартавана файлаў: %d → %s',
                           'Експортовано файлів: %d → %s',
                           'Exported files: %d → %s'),
                        [Picked.Count, ExtractFileName(OutName)]);
    finally
      Picked.Free;
    end;
  finally
    P.Free;
    Files.Free;
    Disp.Free;
    Checked.Free;
  end;
end;

{ Unpacks a rules zip to temp, shows a picker (each row labelled with
  the entries inside), confirms overwrites, copies to Custom\. }
procedure TCustomForm.BtnImportClick(Sender: TObject);
var
  D: TOpenDialog;
  U: TUnZipper;
  InName, Tmp, S, Src, Dst, Lbl: string;
  I, Ow: Integer;
  Found: Boolean;
  Files, Disp, Picked: TStrings;
  P: TWinapp2Parser;
begin
  InName := '';
  D := TOpenDialog.Create(Self);
  try
    D.Title := Lg('Импорт правил', 'Імпарт правілаў',
                  'Імпорт правіл', 'Import rules');
    D.Filter := 'CleanSweep rules (*.zip)|*.zip';
    D.DefaultExt := 'zip';
    if D.Execute then InName := D.FileName;
  finally
    D.Free;
  end;
  if InName = '' then Exit;

  U := TUnZipper.Create;
  Files := TStringList.Create;
  Disp := TStringList.Create;
  P := TWinapp2Parser.Create(True);
  Tmp := '';
  try
    U.FileName := InName;
    U.Examine;
    Found := False;
    for I := 0 to U.Entries.Count - 1 do
      if SameText(ExtractFileName(U.Entries[I].ArchiveFileName),
                  RULES_ZIP_FLAG) then Found := True;
    if not Found then
    begin
      MessageDlg(Lg('Это не пакет правил CleanSweep (нет файла-флага).',
                    'Гэта не пакет правілаў CleanSweep (няма файла-сцяга).',
                    'Це не пакет правил CleanSweep (немає файла-прапорця).',
                    'Not a CleanSweep rules pack (marker file missing).'),
                 mtWarning, [mbOK], 0);
      Exit;
    end;

    // unpack to a temp dir first: the user picks which inis actually
    // land in Custom\, and we can show what each file contains
    Tmp := IncludeTrailingPathDelimiter(GetTempDir(False)) +
      'csimp_' + IntToStr(GetCurrentProcessId);
    ForceDirectories(Tmp);
    U.OutputPath := Tmp;
    U.UnZipAllFiles;

    for I := 0 to U.Entries.Count - 1 do
    begin
      S := U.Entries[I].ArchiveFileName;
      if not SameText(ExtractFileExt(S), '.ini') then Continue;
      Src := Tmp + '\' + StringReplace(S, '/', '\', [rfReplaceAll]);
      if not FileExists(Src) then Continue;
      Files.Add(S);
      // keep the raw archive name for the overwrite check — reusing S
      // here (as CleanLab did) made the marker never fire, because
      // ExtractFileName of the decorated label is the label itself
      Lbl := FileLabel(Src, P);
      if FileExists(CustomDir + ExtractFileName(S)) then
        Lbl := Lbl + '   [заменит существующий]';
      Disp.Add(Lbl);
    end;
    if Files.Count = 0 then
    begin
      MessageDlg(Lg('В пакете нет ini-файлов правил.',
                    'У пакеце няма ini-файлаў правілаў.',
                    'У пакеті немає ini-файлів правил.',
                    'The pack holds no rule ini files.'),
                 mtWarning, [mbOK], 0);
      Exit;
    end;

    Picked := PickPackItems(Self,
      Lg('Импорт правил', 'Імпарт правілаў', 'Імпорт правіл',
         'Import rules'),
      Lg('Файлы из пакета:', 'Файлы з пакета:', 'Файли з пакету:',
         'Files from the pack:'),
      Disp, Files, nil);
    try
      if (Picked = nil) or (Picked.Count = 0) then Exit;

      Ow := 0;
      for I := 0 to Picked.Count - 1 do
        if FileExists(CustomDir + ExtractFileName(Picked[I])) then Inc(Ow);
      if (Ow > 0) and
         (MessageDlg(Format(Lg(
            'Файлов будет перезаписано: %d. Продолжить?',
            'Файлаў будзе перапісана: %d. Працягнуць?',
            'Файлів буде перезаписано: %d. Продовжити?',
            '%d existing file(s) will be overwritten. Continue?'),
            [Ow]), mtConfirmation, [mbYes, mbNo], 0, mbNo) <> mrYes) then
        Exit;

      for I := 0 to Picked.Count - 1 do
      begin
        Src := Tmp + '\' +
          StringReplace(Picked[I], '/', '\', [rfReplaceAll]);
        Dst := CustomDir + ExtractFileName(Picked[I]);
        Windows.CopyFile(PChar(Src), PChar(Dst), False);
      end;
    finally
      Picked.Free;
    end;
  finally
    P.Free;
    Files.Free;
    Disp.Free;
    U.Free;
    if Tmp <> '' then DeleteTree(Tmp);
  end;
  RefreshList;
end;

end.
