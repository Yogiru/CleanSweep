unit cs.scanner;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Generics.Collections, cs.winapp2;

type
  TJunkGroupKind = (jgExtMasks, jgJunkDir);

  { One suggested FileKey line: directory + masks + flag + stats. }
  TJunkGroup = class
    Kind: TJunkGroupKind;
    Dir: string;        // absolute path; caller contracts to %vars%
    Masks: string;      // '*.tmp;*.log' for jgExtMasks, '*' for jgJunkDir
    Flag: TFileKeyFlag;
    Count: Integer;     // files matched
    Bytes: Int64;
  end;

  TJunkGroupList = specialize TObjectList<TJunkGroup>;

  TJunkReport = class
  private
    FGroups: TJunkGroupList;
  public
    TotalCount: Integer;
    TotalBytes: Int64;
    Capped: Boolean;    // walk hit the entry limit — results partial
    constructor Create;
    destructor Destroy; override;
    property Groups: TJunkGroupList read FGroups;
  end;

{ Walks ARoot and groups found junk candidates into FileKey-ready
  suggestions: junk-named subdirs → RECURSE rows, junk extensions
  per directory → mask rows. Conservative signature set — the editor
  is the review step, not this list. }
function ScanForJunk(const ARoot: string;
  AMaxVisited: Integer = 200000): TJunkReport;

implementation

uses
  Windows;

const
  JUNK_EXTS: array[0..13] of string = (
    '.tmp', '.temp', '.log', '.bak', '.old', '.dmp', '.etl',
    '.chk', '.gid', '.wbk', '.swp', '.swo', '.err', '.cache'
  );
  JUNK_NAMES: array[0..3] of string = (
    'thumbs.db', 'desktop.ini', 'ehthumbs.db', '.ds_store'
  );
  JUNK_DIRS: array[0..17] of string = (
    'cache', 'caches', 'temp', 'tmp', 'log', 'logs',
    'dump', 'dumps', 'crashdumps', 'crash dumps',
    'crashreports', 'crash reports', 'crashes',
    'backup', 'backups', 'code cache', 'gpucache', 'crashpad'
  );

function StrInList(const S: string; const List: array of string): Boolean;
var
  I: Integer;
begin
  for I := 0 to High(List) do
    if SameText(S, List[I]) then Exit(True);
  Result := False;
end;

{ Returns the junk mask for a file name ('*.tmp', 'thumbs.db', '*~')
  or '' when the file matches no signature. }
function JunkMaskOf(const AName: string): string;
var
  Ext: string;
begin
  Result := '';
  if StrInList(AName, JUNK_NAMES) then
    Exit(LowerCase(AName));
  if (Length(AName) > 0) and (AName[Length(AName)] = '~') then
    Exit('*~');
  Ext := LowerCase(ExtractFileExt(AName));
  if StrInList(Ext, JUNK_EXTS) then
    Result := '*' + Ext;
end;

{ Sizes a pruned subtree (junk dirs are not descended by the walk). }
procedure CountTree(const ADir: string; var ACount: Integer;
  var ABytes: Int64; var AVisited: Integer; const AMaxVisited: Integer);
var
  SR: TSearchRec;
  R: Integer;
  Full: string;
begin
  if AVisited >= AMaxVisited then Exit;
  R := FindFirst(ADir + '\*', faAnyFile, SR);
  try
    while (R = 0) and (AVisited < AMaxVisited) do
    begin
      Inc(AVisited);
      if (SR.Name <> '.') and (SR.Name <> '..') then
      begin
        Full := ADir + '\' + SR.Name;
        if ((SR.Attr and faDirectory) <> 0) and
           ((SR.Attr and FILE_ATTRIBUTE_REPARSE_POINT) = 0) then
          CountTree(Full, ACount, ABytes, AVisited, AMaxVisited)
        else if (SR.Attr and faDirectory) = 0 then
        begin
          Inc(ACount);
          Inc(ABytes, SR.Size);
        end;
      end;
      R := FindNext(SR);
    end;
  finally
    SysUtils.FindClose(SR);
  end;
end;

procedure Walk(const ADir: string; AReport: TJunkReport;
  var AVisited: Integer; const AMaxVisited: Integer);
var
  SR: TSearchRec;
  R, I: Integer;
  Full, Mask: string;
  G: TJunkGroup;
  Masks: TStringList;
  Cnt: Integer;
  Sz: Int64;
begin
  if AVisited >= AMaxVisited then
  begin
    AReport.Capped := True;
    Exit;
  end;

  Masks := TStringList.Create;
  Masks.CaseSensitive := False;
  Masks.Duplicates := dupIgnore;
  Masks.Sorted := True;
  Cnt := 0;
  Sz := 0;
  try
    R := FindFirst(ADir + '\*', faAnyFile, SR);
    try
      while (R = 0) and (AVisited < AMaxVisited) do
      begin
        Inc(AVisited);
        if (SR.Name <> '.') and (SR.Name <> '..') then
        begin
          Full := ADir + '\' + SR.Name;
          if (SR.Attr and faDirectory) <> 0 then
          begin
            if (SR.Attr and FILE_ATTRIBUTE_REPARSE_POINT) = 0 then
              if StrInList(SR.Name, JUNK_DIRS) then
              begin
                G := TJunkGroup.Create;
                G.Kind := jgJunkDir;
                G.Dir := Full;
                G.Masks := '*';
                G.Flag := fkRecurse;
                CountTree(Full, G.Count, G.Bytes, AVisited, AMaxVisited);
                AReport.FGroups.Add(G);
                Inc(AReport.TotalCount, G.Count);
                Inc(AReport.TotalBytes, G.Bytes);
              end
              else
                Walk(Full, AReport, AVisited, AMaxVisited);
          end
          else
          begin
            Mask := JunkMaskOf(SR.Name);
            if Mask <> '' then
            begin
              Masks.Add(Mask);
              Inc(Cnt);
              Inc(Sz, SR.Size);
            end;
          end;
        end;
        R := FindNext(SR);
      end;
      if R = 0 then AReport.Capped := AVisited >= AMaxVisited;
    finally
      SysUtils.FindClose(SR);
    end;

    if Masks.Count > 0 then
    begin
      G := TJunkGroup.Create;
      G.Kind := jgExtMasks;
      G.Dir := ADir;
      G.Flag := fkNone;
      for I := 0 to Masks.Count - 1 do
      begin
        if I > 0 then G.Masks := G.Masks + ';';
        G.Masks := G.Masks + Masks[I];
      end;
      G.Count := Cnt;
      G.Bytes := Sz;
      AReport.FGroups.Add(G);
      Inc(AReport.TotalCount, Cnt);
      Inc(AReport.TotalBytes, Sz);
    end;
  finally
    Masks.Free;
  end;
end;

function ScanForJunk(const ARoot: string;
  AMaxVisited: Integer): TJunkReport;
var
  Visited: Integer;
begin
  Result := TJunkReport.Create;
  Visited := 0;
  Walk(ExcludeTrailingPathDelimiter(ARoot), Result, Visited, AMaxVisited);
end;

constructor TJunkReport.Create;
begin
  FGroups := TJunkGroupList.Create(True);
end;

destructor TJunkReport.Destroy;
begin
  FGroups.Free;
  inherited;
end;

end.
