unit cs.winapp2;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, fgl;

type
  { How a FileKey directory is scanned. }
  TFileKeyFlag = (fkNone,        // top-level files only
                  fkRecurse,     // all subdirectories
                  fkRemoveSelf); // recurse + prune empty dirs afterwards

  { What kind of resource an ExcludeKey protects. }
  TExcludeType = (etFile,  // file or filename pattern inside a directory
                  etPath,  // entire directory subtree
                  etReg);  // registry key or value

  { Parsed FileKeyN= line: <path>|<pattern(s)>[|RECURSE|REMOVESELF|UNSAFE]
    Example: FileKey1=%LocalAppData%\Temp|*.tmp;*.log|RECURSE
    UNSAFE (CleanLab extension) lifts only the runnable-extension gate
    for this key's files — protected paths, exclusions and the locked-
    file probe still apply. }
  TFileKeyEntry = class
    Path: string;              // may contain %EnvVar% and * wildcards
    Pattern: string;           // ';'-separated filters, default '*.*'
    Flag: TFileKeyFlag;
    Unsafe: Boolean;
    class function Parse(const AValue: string): TFileKeyEntry; static;
  end;

  { Parsed RegKeyN= line: <HIVE\SubKey>[|ValueName]
    Without ValueName the whole key tree is deleted. }
  TRegKeyEntry = class
    KeyPath: string;           // full path incl. hive, e.g. HKCU\Software\Foo
    ValueName: string;         // '' = delete key tree
    class function Parse(const AValue: string): TRegKeyEntry; static;
  end;

  { Parsed ExcludeKeyN= line: <TYPE>|<path>[|<filename pattern>]
    Example: ExcludeKey1=FILE|%AppData%\Firefox\Profiles|places.sqlite }
  TExcludeKeyEntry = class
    ExType: TExcludeType;
    Path: string;              // may contain %EnvVar%
    Pattern: string;           // '' = whole subtree (PATH behaviour)
    class function Parse(const AValue: string): TExcludeKeyEntry; static;
  end;

  TFileKeyList = specialize TFPGObjectList<TFileKeyEntry>;
  TRegKeyList = specialize TFPGObjectList<TRegKeyEntry>;
  TExcludeKeyList = specialize TFPGObjectList<TExcludeKeyEntry>;

  { One [Section] from winapp2.ini — port of FluentCleaner CleanerEntry.
    Holds detection criteria and everything to clean. }
  TCleanerEntry = class
    Name: string;              // display name, e.g. 'Microsoft Edge'
    Section: string;           // free-form Section= from the ini
    LangSecRef: Integer;       // category code (3025 = Windows); -1 = absent
    SpecialDetect: string;     // named code e.g. 'DET_CHROME'; '' = none
    Special: string;           // built-in action ('RecycleBin', 'DeadShortcuts'); '' = none
    Warning: string;           // winapp2 warning text
    Default: Boolean;          // checked by default in the UI
    IsCustom: Boolean;         // entry from the user's Custom folder
    SourceFile: string;        // Custom\<file>.ini it came from ('' = bundled DB)
    Detected: Boolean;         // runtime: detection found it installed
    RawText: string;           // verbatim ini block for 'Show source'
    DetectOSUsed: Boolean;     // DetectOS= line present (singleton, first wins)
    DetectOSMin: Integer;      // OS gate, scaled major*100+minor; -1 = open
    DetectOSMax: Integer;      // OS gate, scaled major*100+minor; -1 = open
    DetectKeys: TStringList;   // registry paths, OR logic
    DetectFiles: TStringList;  // file/folder paths, OR logic
    FileKeys: TFileKeyList;
    RegKeys: TRegKeyList;
    ExcludeKeys: TExcludeKeyList;
    constructor Create;
    destructor Destroy; override;
  end;

  TCleanerEntryList = specialize TFPGObjectList<TCleanerEntry>;

  { winapp2.ini parser — port of Winapp2Parser.
    INI-like format with numbered multi-value keys:
    FileKey1=..., RegKey1=..., Detect, Detect1, DetectFile2, ...
    AAllowUndetected loosens entry validation for the Custom folder:
    user rules may omit Detect*/DetectFile entirely — upstream keeps
    them and simply skips the detection probe. }
  TWinapp2Parser = class
  private
    FAllowUndetected: Boolean;
  public
    constructor Create(AAllowUndetected: Boolean = False);
    function Parse(const AContent: string): TCleanerEntryList;
    function ParseFile(const AFileName: string): TCleanerEntryList;
  end;

{ Entry carries any detection criterion (Detect/DetectFile/
  SpecialDetect/DetectOS). Custom-folder rules may have none — then
  'installed' is assumed and no probe runs. }
function EntryHasDetection(const AEntry: TCleanerEntry): Boolean;

{ Serializes an entry back into ini lines (the inverse of Parse —
  used by the rule editor for open/save). Comments and original
  formatting are NOT preserved; the block is regenerated canonically.
  Caller owns the result. }
function EntryToIni(const AEntry: TCleanerEntry): TStringList;

{ DetectOS= value per the Winapp2 spec: 'num' minimum, 'min|max' range;
  a bare number also reads as minimum. Exposed for the rule editor. }
procedure ParseDetectOS(const AValue: string; AEntry: TCleanerEntry);

  { LangSecRef code → UI category name + sort order.
    Port of CategoryResolver: known code, else Section, else 'Other'. }
  procedure ResolveCategory(const AEntry: TCleanerEntry;
    out AName: string; out AOrder: Integer);

  { True when the entry wipes credentials — passwords, saved logins,
    sessions, cookies, tokens, autofill. Such entries go to the
    separate 'security' tab so the user can nuke them deliberately.
    Keyword heuristic over the entry name; known false positives
    (password-recovery tools etc.) are excluded first. }
  function IsSecurityEntry(const AName: string): Boolean;

  { Entry-aware variant: name keywords OR any FileKey/RegKey path that
    touches credential stores (Login Data, cookies, session storage,
    Web Data, autofill, password manager, keychain …). An entry that
    merely *cleans the traces of* a password-recovery tool stays out
    (SKIP list beats path evidence too). }
  function IsSecurityEntryFor(const AEntry: TCleanerEntry): Boolean;

  { Preset axis classifiers. Purpose = one stable key the modal preset
    form knows; the keys partition the pool (each entry lands in exactly
    one bucket, complementary not overlapping). Safety = risk of running
    the rule: Safe / Caution / Risky. }
  type
    TSafetyLevel = (slSafe, slCaution, slRisky);

  function PresetPurposeOf(const AEntry: TCleanerEntry): string;
  function PresetSafetyOf(const AEntry: TCleanerEntry): TSafetyLevel;

  { Keys PresetPurposeOf can return, in checkbox order for the preset
    form. Partition of the pool — each entry lands in exactly one. }
  const
    PresetPurposeKeys: array[0..8] of string = (
      'Windows', 'Browsers', 'Multimedia', 'Games', 'Utilities',
      'Applications', 'Messaging', 'Languages', 'Other');

implementation

uses
  cs.utils;

{ FileKey\d+ / RegKey\d+ / ExcludeKey\d+ (number required);
  Detect\d* / DetectFile\d* (number optional). }
function IsNumberedKey(const AKey, APrefix: string;
  ANumberRequired: Boolean): Boolean;
var
  I, P: Integer;
begin
  Result := False;
  if not SameText(Copy(AKey, 1, Length(APrefix)), APrefix) then Exit;
  P := Length(APrefix) + 1;
  if P > Length(AKey) then Exit(not ANumberRequired);
  for I := P to Length(AKey) do
    if not (AKey[I] in ['0'..'9']) then Exit;
  Result := True;
end;

{ Split AContent on #13 and #10 like the C# version
  (WinUI TextBox saves lone \r). Empty lines are dropped. }
procedure SplitLines(const AContent: string; AOut: TStrings);
var
  Start, I: Integer;
begin
  Start := 1;
  for I := 1 to Length(AContent) do
    if (AContent[I] = #13) or (AContent[I] = #10) then
    begin
      if I > Start then
        AOut.Add(Copy(AContent, Start, I - Start));
      Start := I + 1;
    end;
  if Length(AContent) >= Start then
    AOut.Add(Copy(AContent, Start, Length(AContent) - Start + 1));
end;

{ Entry is useful only if it can be detected AND has something to clean.
  DetectOS counts as a detection criterion — entries gated by OS version
  alone (e.g. 'Search Charm History') must survive the filter. }
function IsValidEntry(const AEntry: TCleanerEntry): Boolean;
begin
  Result := ((AEntry.DetectKeys.Count > 0) or
             (AEntry.DetectFiles.Count > 0) or
             (AEntry.SpecialDetect <> '') or
             AEntry.DetectOSUsed or
             (AEntry.Special <> '')) and
            ((AEntry.FileKeys.Count > 0) or
             (AEntry.RegKeys.Count > 0) or
             (AEntry.Special <> ''));
end;

{ Cleanup content without detection — accepted only in permissive mode
  (Custom folder): upstream keeps such rules and skips the probe. }
function EntryHasContent(const AEntry: TCleanerEntry): Boolean;
begin
  Result := (AEntry.FileKeys.Count > 0) or
            (AEntry.RegKeys.Count > 0) or
            (AEntry.Special <> '');
end;

function EntryHasDetection(const AEntry: TCleanerEntry): Boolean;
begin
  Result := (AEntry.DetectKeys.Count > 0) or
            (AEntry.DetectFiles.Count > 0) or
            (AEntry.SpecialDetect <> '') or
            AEntry.DetectOSUsed;
end;

{ scaled major*100+minor → 'maj' or 'maj.min' (drops '.0'). }
function OsVer100ToStr(const AV: Integer): string;
begin
  if (AV mod 100) = 0 then
    Result := IntToStr(AV div 100)
  else
    Result := IntToStr(AV div 100) + '.' + IntToStr(AV mod 100);
end;

function EntryToIni(const AEntry: TCleanerEntry): TStringList;
var
  I: Integer;
  FK: TFileKeyEntry;
  RK: TRegKeyEntry;
  XK: TExcludeKeyEntry;
  S, T: string;
begin
  Result := TStringList.Create;
  Result.Add('[' + AEntry.Name + ' *]');
  if AEntry.LangSecRef >= 0 then
    Result.Add('LangSecRef=' + IntToStr(AEntry.LangSecRef));
  if AEntry.Section <> '' then
    Result.Add('Section=' + AEntry.Section);
  if AEntry.SpecialDetect <> '' then
    Result.Add('SpecialDetect=' + AEntry.SpecialDetect);
  if AEntry.DetectOSUsed then
  begin
    S := '';
    if AEntry.DetectOSMin >= 0 then
      S := OsVer100ToStr(AEntry.DetectOSMin);
    if AEntry.DetectOSMax >= 0 then
      S := S + '|' + OsVer100ToStr(AEntry.DetectOSMax);
    Result.Add('DetectOS=' + S);
  end;
  for I := 0 to AEntry.DetectKeys.Count - 1 do
    Result.Add('Detect' + IntToStr(I + 1) + '=' + AEntry.DetectKeys[I]);
  for I := 0 to AEntry.DetectFiles.Count - 1 do
    Result.Add('DetectFile' + IntToStr(I + 1) + '=' + AEntry.DetectFiles[I]);
  if AEntry.Default then Result.Add('Default=True')
  else Result.Add('Default=False');
  if AEntry.Warning <> '' then
    Result.Add('Warning=' + AEntry.Warning);
  if AEntry.Special <> '' then
    Result.Add('Special=' + AEntry.Special);
  for I := 0 to AEntry.FileKeys.Count - 1 do
  begin
    FK := AEntry.FileKeys[I];
    S := FK.Path;
    case FK.Flag of
      fkRecurse:    T := 'RECURSE';
      fkRemoveSelf: T := 'REMOVESELF';
    else
      T := '';
    end;
    if FK.Unsafe then
      if T = '' then T := 'UNSAFE' else T := T + '|UNSAFE';
    // flags sit after the pattern slot — emit '*' when it is empty
    if FK.Pattern <> '' then
      S := S + '|' + FK.Pattern
    else if T <> '' then
      S := S + '|*';
    if T <> '' then
      S := S + '|' + T;
    Result.Add('FileKey' + IntToStr(I + 1) + '=' + S);
  end;
  for I := 0 to AEntry.RegKeys.Count - 1 do
  begin
    RK := AEntry.RegKeys[I];
    S := RK.KeyPath;
    if RK.ValueName <> '' then
      S := S + '|' + RK.ValueName;
    Result.Add('RegKey' + IntToStr(I + 1) + '=' + S);
  end;
  for I := 0 to AEntry.ExcludeKeys.Count - 1 do
  begin
    XK := AEntry.ExcludeKeys[I];
    case XK.ExType of
      etPath: T := 'PATH';
      etReg:  T := 'REG';
    else
      T := 'FILE';
    end;
    S := T + '|' + XK.Path;
    if XK.Pattern <> '' then
      S := S + '|' + XK.Pattern;
    Result.Add('ExcludeKey' + IntToStr(I + 1) + '=' + S);
  end;
end;

constructor TWinapp2Parser.Create(AAllowUndetected: Boolean);
begin
  inherited Create;
  FAllowUndetected := AAllowUndetected;
end;

{ Parses the leading 'X.Y' of AToken into X*100+Y (10.0 → 1000).
  Reading stops at a second '.' or a non-digit, like Val() in the
  upstream tool. Returns False for empty or garbage tokens. }
function ParseOsVersion100(const AToken: string; out AVer: Integer): Boolean;
var
  P, I, Major, Minor: Integer;
  MajorS, MinorS: string;
begin
  Result := False;
  if AToken = '' then Exit;
  P := Pos('.', AToken);
  if P = 0 then
  begin
    MajorS := AToken;
    MinorS := '0';
  end
  else
  begin
    MajorS := Copy(AToken, 1, P - 1);
    MinorS := '';
    I := P + 1;
    while (I <= Length(AToken)) and (AToken[I] in ['0'..'9']) do
    begin
      MinorS := MinorS + AToken[I];
      Inc(I);
    end;
    if MinorS = '' then MinorS := '0';
  end;
  if not TryStrToInt(MajorS, Major) then Exit;
  if not TryStrToInt(MinorS, Minor) then Exit;
  AVer := Major * 100 + Minor;
  Result := True;
end;

{ DetectOS= value per the Winapp2 spec:
    num|      minimum,     |num      maximum,
    num1|num2 range (equal bounds = that exact version).
  A value without '|' is read as a minimum — the lenient reading of
  legacy entries like 'DetectOS=6.0'. Unparsable bounds stay open.
  Order of keys in the ini decides; the caller guards the singleton. }
procedure ParseDetectOS(const AValue: string; AEntry: TCleanerEntry);
var
  P: Integer;
  MinS, MaxS: string;
  V: Integer;
begin
  AEntry.DetectOSUsed := True;
  P := Pos('|', AValue);
  if P = 0 then
  begin
    if ParseOsVersion100(Trim(AValue), V) then AEntry.DetectOSMin := V;
    Exit;
  end;
  MinS := Trim(Copy(AValue, 1, P - 1));
  MaxS := Trim(Copy(AValue, P + 1, MaxInt));
  if (MinS <> '') and ParseOsVersion100(MinS, V) then AEntry.DetectOSMin := V;
  if (MaxS <> '') and ParseOsVersion100(MaxS, V) then AEntry.DetectOSMax := V;
end;

{ TFileKeyEntry }

class function TFileKeyEntry.Parse(const AValue: string): TFileKeyEntry;
var
  Parts: TStringList;
  P: string;
  I: Integer;
begin
  Parts := TStringList.Create;
  try
    Parts.StrictDelimiter := True;
    Parts.Delimiter := '|';
    Parts.DelimitedText := AValue;
    Result := TFileKeyEntry.Create;
    Result.Path := Trim(Parts[0]);

    { After the path every part is either a flag or the pattern slot —
      order-free, so 'path|RECURSE|UNSAFE' and 'path|*.tmp|UNSAFE|RECURSE'
      both parse. First non-flag token wins the pattern, the rest drop. }
    for I := 1 to Parts.Count - 1 do
    begin
      P := UpperCase(Trim(Parts[I]));
      if P = 'RECURSE' then Result.Flag := fkRecurse
      else if P = 'REMOVESELF' then Result.Flag := fkRemoveSelf
      else if P = 'UNSAFE' then Result.Unsafe := True
      else if Result.Pattern = '' then Result.Pattern := Trim(Parts[I]);
    end;
  finally
    Parts.Free;
  end;
end;

{ TRegKeyEntry }

class function TRegKeyEntry.Parse(const AValue: string): TRegKeyEntry;
var
  I: Integer;
begin
  Result := TRegKeyEntry.Create;
  I := Pos('|', AValue);
  if I > 0 then
  begin
    Result.KeyPath := Trim(Copy(AValue, 1, I - 1));
    Result.ValueName := Trim(Copy(AValue, I + 1, MaxInt));
  end
  else
    Result.KeyPath := Trim(AValue);
end;

{ TExcludeKeyEntry }

class function TExcludeKeyEntry.Parse(const AValue: string): TExcludeKeyEntry;
var
  Parts: TStringList;
begin
  Parts := TStringList.Create;
  try
    Parts.StrictDelimiter := True;
    Parts.Delimiter := '|';
    Parts.DelimitedText := AValue;
    Result := TExcludeKeyEntry.Create;
    if Parts.Count > 0 then
      if SameText(Trim(Parts[0]), 'PATH') then Result.ExType := etPath
      else if SameText(Trim(Parts[0]), 'REG') then Result.ExType := etReg
      else Result.ExType := etFile;
    if Parts.Count > 1 then Result.Path := Trim(Parts[1]);
    if Parts.Count > 2 then Result.Pattern := Trim(Parts[2]);
  finally
    Parts.Free;
  end;
end;

{ TCleanerEntry }

constructor TCleanerEntry.Create;
begin
  LangSecRef := -1;
  Default := True;
  DetectOSMin := -1;
  DetectOSMax := -1;
  DetectKeys := TStringList.Create;
  DetectFiles := TStringList.Create;
  FileKeys := TFileKeyList.Create(True);
  RegKeys := TRegKeyList.Create(True);
  ExcludeKeys := TExcludeKeyList.Create(True);
end;

destructor TCleanerEntry.Destroy;
begin
  DetectKeys.Free;
  DetectFiles.Free;
  FileKeys.Free;
  RegKeys.Free;
  ExcludeKeys.Free;
  inherited;
end;

{ TWinapp2Parser }

function TWinapp2Parser.Parse(const AContent: string): TCleanerEntryList;
var
  Lines: TStringList;
  Raw: TStringList;          // verbatim block of the current entry
  Current: TCleanerEntry;
  Line, Key, Value, EntryName: string;
  Eq, I, N: Integer;

  procedure FlushCurrent;
  begin
    if (Current <> nil) and
       (IsValidEntry(Current) or
        (FAllowUndetected and EntryHasContent(Current))) then
    begin
      Current.RawText := TrimRight(Raw.Text);
      Result.Add(Current);
    end
    else
      Current.Free;
    Current := nil;
  end;

begin
  Result := TCleanerEntryList.Create(True);
  Current := nil;
  Lines := TStringList.Create;
  Raw := TStringList.Create;
  try
    SplitLines(AContent, Lines);
    for I := 0 to Lines.Count - 1 do
    begin
      Line := Trim(Lines[I]);
      if (Line = '') or (Line[1] = ';') or (Line[1] = '#') then Continue;

      if (Line[1] = '[') and (Line[Length(Line)] = ']') then
      begin
        FlushCurrent;
        Raw.Clear;
        Raw.Add(Line);

        EntryName := Trim(Copy(Line, 2, Length(Line) - 2));
        // skip the file's own header block
        if (Pos('winapp2', LowerCase(EntryName)) = 1) or
           (Pos('version', LowerCase(EntryName)) = 1) then
          Continue;

        // trailing ' *' marks community entries
        while (Length(EntryName) > 0) and (EntryName[Length(EntryName)] = '*') do
          SetLength(EntryName, Length(EntryName) - 1);
        EntryName := TrimRight(EntryName);
        Current := TCleanerEntry.Create;
        Current.Name := EntryName;
        Continue;
      end;

      if Current = nil then Continue;
      Raw.Add(Line);

      Eq := Pos('=', Line);
      if Eq = 0 then Continue;
      Key := Trim(Copy(Line, 1, Eq - 1));
      Value := Trim(Copy(Line, Eq + 1, MaxInt));
      if Value = '' then Continue;

      if SameText(Key, 'LangSecRef') then
      begin
        if TryStrToInt(Value, N) then Current.LangSecRef := N;
      end
      else if SameText(Key, 'Section') then Current.Section := Value
      else if SameText(Key, 'SpecialDetect') then Current.SpecialDetect := Value
      else if SameText(Key, 'Special') then Current.Special := Value
      else if SameText(Key, 'Warning') then Current.Warning := Value
      else if SameText(Key, 'Default') then Current.Default := SameText(Value, 'True')
      else if SameText(Key, 'DetectOS') and (not Current.DetectOSUsed) then
        ParseDetectOS(Value, Current)
      else if IsNumberedKey(Key, 'Detect', False) then Current.DetectKeys.Add(Value)
      else if IsNumberedKey(Key, 'DetectFile', False) then Current.DetectFiles.Add(Value)
      else if IsNumberedKey(Key, 'FileKey', True) then Current.FileKeys.Add(TFileKeyEntry.Parse(Value))
      else if IsNumberedKey(Key, 'RegKey', True) then Current.RegKeys.Add(TRegKeyEntry.Parse(Value))
      else if IsNumberedKey(Key, 'ExcludeKey', True) then Current.ExcludeKeys.Add(TExcludeKeyEntry.Parse(Value));
    end;
    FlushCurrent;
  finally
    Lines.Free;
    Raw.Free;
  end;
end;

function TWinapp2Parser.ParseFile(const AFileName: string): TCleanerEntryList;
begin
  // databases ship as UTF-8 (usually without BOM) — LoadTextFile decodes
  // explicitly instead of trusting the runtime codepage
  Result := Parse(LoadTextFile(AFileName));
end;

{ LangSecRef → category. Port of CategoryResolver's map;
  codes 3032/3041 intentionally absent, as upstream. }
procedure ResolveCategory(const AEntry: TCleanerEntry;
  out AName: string; out AOrder: Integer);
const
  Map: array[0..22] of record Code: Integer; Name: string; Order: Integer end = (
    (Code: 3006; Name: 'Microsoft Edge'; Order: 5),
    (Code: 3021; Name: 'Applications'; Order: 10),
    (Code: 3022; Name: 'Internet'; Order: 20),
    (Code: 3023; Name: 'Multimedia'; Order: 30),
    (Code: 3024; Name: 'Utilities'; Order: 40),
    (Code: 3025; Name: 'Windows'; Order: 50),
    (Code: 3026; Name: 'Firefox'; Order: 60),
    (Code: 3027; Name: 'Opera'; Order: 70),
    (Code: 3028; Name: 'Safari'; Order: 80),
    (Code: 3029; Name: 'Google Chrome'; Order: 90),
    (Code: 3030; Name: 'Thunderbird'; Order: 100),
    (Code: 3031; Name: 'Microsoft Store'; Order: 110),
    (Code: 3033; Name: 'Vivaldi'; Order: 130),
    (Code: 3034; Name: 'Brave'; Order: 140),
    (Code: 3035; Name: 'Opera GX'; Order: 150),
    (Code: 3036; Name: 'Spotify'; Order: 160),
    (Code: 3037; Name: 'Avast Secure Browser'; Order: 170),
    (Code: 3038; Name: 'AVG Secure Browser'; Order: 180),
    (Code: 3039; Name: 'Arc Browser'; Order: 190),
    (Code: 3040; Name: 'iTunes'; Order: 200),
    (Code: 3042; Name: 'WhatsApp'; Order: 210),
    (Code: 3043; Name: 'Norton Private Browser'; Order: 220),
    (Code: 3044; Name: 'Avira Secure Browser'; Order: 230));
var
  I: Integer;
begin
  for I := Low(Map) to High(Map) do
    if (Map[I].Name <> '') and (AEntry.LangSecRef = Map[I].Code) then
    begin
      AName := Map[I].Name;
      AOrder := Map[I].Order;
      Exit;
    end;
  if AEntry.Section <> '' then
  begin
    AName := AEntry.Section;
    AOrder := 1000;   // after all known LangSecRef categories
    Exit;
  end;
  AName := 'Other Applications';
  AOrder := 2000;
end;

{ Name heuristics shared by both security classifiers. }
const
  // tools whose *traces* are cleaned, not credentials themselves
  SecuritySkipList: array[0..11] of string = (
    'recovery', 'reset', 'kracker', 'cracker', 'sniffer', 'auditor',
    'digger', 'kernel', 'monitor', 'drivers', 'accounting', 'who''s on my');
  SecurityNameKeys: array[0..9] of string = (
    'password', 'credential', 'login', 'session', 'cookie', 'cookies',
    'autolog', 'autofill', 'token', 'account');
  // FileKey/RegKey path evidence for the entry-aware classifier
  SecurityPathKeys: array[0..8] of string = (
    'login data', 'cookies', 'session storage', 'web data',
    'autofill', 'passwords', 'password manager', 'keychain',
    'credential');

{ True when S contains any of the tokens. }
function ContainsAny(const S: string; const Tokens: array of string): Boolean;
var
  I: Integer;
begin
  Result := False;
  for I := Low(Tokens) to High(Tokens) do
    if Pos(Tokens[I], S) > 0 then Exit(True);
end;

function IsSecurityEntry(const AName: string): Boolean;
var
  S: string;
begin
  S := LowerCase(AName);
  Result := (not ContainsAny(S, SecuritySkipList)) and
            ContainsAny(S, SecurityNameKeys);
end;

function IsSecurityEntryFor(const AEntry: TCleanerEntry): Boolean;
var
  S: string;
  I: Integer;
begin
  Result := False;
  if AEntry = nil then Exit;
  S := LowerCase(AEntry.Name);
  if ContainsAny(S, SecuritySkipList) then Exit;
  if ContainsAny(S, SecurityNameKeys) then Exit(True);
  for I := 0 to AEntry.FileKeys.Count - 1 do
  begin
    S := LowerCase(AEntry.FileKeys[I].Path + '|' + AEntry.FileKeys[I].Pattern);
    if ContainsAny(S, SecurityPathKeys) then Exit(True);
  end;
  for I := 0 to AEntry.RegKeys.Count - 1 do
  begin
    S := LowerCase(AEntry.RegKeys[I].KeyPath + '|' + AEntry.RegKeys[I].ValueName);
    if ContainsAny(S, SecurityPathKeys) then Exit(True);
  end;
end;

{ Predefined tags the modal preset form exposes.
  Keys are declared in the interface next to the classifiers. }

function PresetPurposeOf(const AEntry: TCleanerEntry): string;
const
  LangTokens: array[0..1] of string = ('language', 'locale');
  GameTokens: array[0..1] of string = ('game', 'gaming');
  BrowserTokens: array[0..14] of string = (
    'browser', 'browsing', 'chrome', 'firefox', 'edge', 'opera', 'safari',
    'vivaldi', 'brave', 'arc', 'internet', 'avast', 'avg', 'norton', 'avira');
  MessengerTokens: array[0..10] of string = (
    'thunderbird', 'whatsapp', 'telegram', 'skype', 'discord', 'viber',
    'messenger', 'slack', 'signal', 'hipchat', 'mail');
  MediaTokens: array[0..13] of string = (
    'multimedia', 'media', 'music', 'audio', 'video', 'sound', 'spotify',
    'itunes', 'podcast', 'player', 'codec', 'streaming', 'song', 'playlist');
  WindowsTokens: array[0..5] of string = (
    'windows', 'system', 'microsoft', 'directx', 'office', 'bitlocker');
  UtilityTokens: array[0..5] of string = (
    'utility', 'tool', 'driver', 'archiver', 'compressor', 'optimizer');
var
  Cat: string;
  Order: Integer;
  S: string;
begin
  ResolveCategory(AEntry, Cat, Order);
  // Whole-class rules ('Language Files', '* Games' sections) override the
  // generic LangSecRef codes those entries often carry (3021 etc.).
  S := LowerCase(AEntry.Name + '|' + AEntry.Section);
  if ContainsAny(S, LangTokens) then Exit('Languages');
  if ContainsAny(S, GameTokens) then Exit('Games');
  case AEntry.LangSecRef of
    3006, 3022, 3026, 3027, 3028, 3029, 3033, 3034, 3035,
    3037, 3038, 3039, 3043, 3044: Exit('Browsers');
    3030, 3042:           Exit('Messaging');
    3023, 3036, 3040:     Exit('Multimedia');
    3024:                 Exit('Utilities');
    3025:                 Exit('Windows');
    3021, 3031:           Exit('Applications');
  end;
  // No known category code: guess from name/category/section text.
  S := LowerCase(AEntry.Name + '|' + Cat + '|' + AEntry.Section);
  if ContainsAny(S, BrowserTokens) then Exit('Browsers');
  if ContainsAny(S, MessengerTokens) then Exit('Messaging');
  if ContainsAny(S, MediaTokens) then Exit('Multimedia');
  if ContainsAny(S, WindowsTokens) then Exit('Windows');
  if ContainsAny(S, UtilityTokens) then Exit('Utilities');
  Result := 'Other';
end;

function PresetSafetyOf(const AEntry: TCleanerEntry): TSafetyLevel;
var
  S: string;
begin
  Result := slSafe;
  S := LowerCase(AEntry.Section);
  if (Pos('dangerous', S) > 0) or (PresetPurposeOf(AEntry) = 'Languages') then
    Exit(slRisky);
  if AEntry.Warning <> '' then
  begin
    if AEntry.Default then Exit(slCaution)
    else Exit(slRisky);
  end;
  if not AEntry.Default then Exit(slCaution);
end;

end.
