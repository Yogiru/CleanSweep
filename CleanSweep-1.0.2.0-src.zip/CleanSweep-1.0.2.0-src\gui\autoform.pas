unit autoform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, StdCtrls, ExtCtrls,
  ComCtrls, Menus, cs.winapp2, cs.cleaner;

type
  { -auto worker: analyzes every armed rule and cleans each non-empty
    plan on the spot. No review step — unattended runs trust the ini
    files (Warning= entries never reach the pool). }
  TAutoThread = class(TThread)
  private
    FEntries: TCleanerEntryList;   // not owned
    FQueue: TStringList;
    FLock: TRTLCriticalSection;
    FDoneCount: Integer;
    FTotalBytes: Int64;
    procedure EngineStatus(const AMsg: string);
    function EngineCancel: Boolean;
    procedure DoFlush;
  protected
    procedure Execute; override;
  public
    constructor Create(AEntries: TCleanerEntryList);
    destructor Destroy; override;
    property DoneCount: Integer read FDoneCount;
    property TotalBytes: Int64 read FTotalBytes;
  end;

  { -auto toast: slim translucent stay-on-top strip near the tray.
    Reports the rule being worked on while cleaning runs and the freed
    total afterwards; auto-closes a few seconds after the result.
    Control lives in the tray icon menu (cancel / exit); clicking the
    toast itself also closes it. }
  TAutoForm = class(TForm)
    pnlMain: TPanel;
    lblStatus: TLabel;
    barWork: TProgressBar;
    tmrDone: TTimer;
    trayIcon: TTrayIcon;
    mnuTray: TPopupMenu;
    miCancel: TMenuItem;
    miSep: TMenuItem;
    miExit: TMenuItem;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure MiCancelClick(Sender: TObject);
    procedure MiExitClick(Sender: TObject);
    procedure ToastClick(Sender: TObject);
    procedure TmrDoneTimer(Sender: TObject);
  private
    FEntries: TCleanerEntryList;
    FThread: TAutoThread;
    FStarted: Boolean;
    procedure LabDone(Sender: TObject);
    procedure ApplySavedSelection;
  public
    procedure ShowStatus(const AMsg: string);
  end;

var
  AutoFormWnd: TAutoForm;

implementation

uses
  Windows, IniFiles, cs.lang, cs.safety, cs.models, cs.rulesload,
  cookieform;

{$R *.lfm}

{ ═══════════════ TAutoThread ═══════════════ }

constructor TAutoThread.Create(AEntries: TCleanerEntryList);
begin
  inherited Create(True);          // caller assigns OnTerminate, then Start
  FreeOnTerminate := False;
  FEntries := AEntries;
  FQueue := TStringList.Create;
  InitCriticalSection(FLock);
end;

destructor TAutoThread.Destroy;
begin
  FQueue.Free;
  DoneCriticalSection(FLock);
  inherited;
end;

procedure TAutoThread.EngineStatus(const AMsg: string);
begin
  if Trim(AMsg) = '' then Exit;
  EnterCriticalSection(FLock);
  try
    if FQueue.Count < 100 then
      FQueue.Add(AMsg);
  finally
    LeaveCriticalSection(FLock);
  end;
  Queue(@DoFlush);
end;

function TAutoThread.EngineCancel: Boolean;
begin
  Result := Terminated;
end;

procedure TAutoThread.DoFlush;
var
  S: string;
begin
  repeat
    EnterCriticalSection(FLock);
    try
      if FQueue.Count = 0 then
        S := ''
      else
      begin
        S := FQueue[0];
        FQueue.Delete(0);
      end;
    finally
      LeaveCriticalSection(FLock);
    end;
    if S = '' then Break;
    if AutoFormWnd <> nil then AutoFormWnd.ShowStatus(S);
  until False;
end;

procedure TAutoThread.Execute;
var
  Svc: TCleaningService;
  Keep: TStringList;
  I: Integer;
  R: TCleanResult;
  St: TCleanStats;
begin
  Svc := TCleaningService.Create;
  Keep := TStringList.Create;
  try
    // kept domains survive inside pruned cookie DBs — same keep list
    // the GUI cleaner applies (cookieform persists it in the ini)
    LoadCookieKeepList(SettingsPath, Keep);
    Svc.CookieKeepList := Keep;
    for I := 0 to FEntries.Count - 1 do
    begin
      if Terminated then Break;
      EngineStatus(FEntries[I].Name);
      R := nil;
      try
        R := Svc.Analyze(FEntries[I], nil, @EngineCancel);
      except
        on ECleanCancelled do Break;
      end;
      if R = nil then Continue;
      try
        if (R.FilesToDelete.Count > 0) or
           (R.RegistryToDelete.Count > 0) or
           (R.SpecialItems.Count > 0) then
        begin
          St := Svc.Clean(R, nil, @EngineCancel);
          Inc(FDoneCount, St.Count);
          Inc(FTotalBytes, St.Bytes);
        end;
      except
        on ECleanCancelled do
        begin
          R.Free;
          Break;
        end;
      end;
      R.Free;
    end;
  finally
    Keep.Free;
    Svc.Free;
  end;
end;

{ ═══════════════ TAutoForm ═══════════════ }

procedure TAutoForm.FormCreate(Sender: TObject);
begin
  lblStatus.Caption := Lg('CleanSweep — загрузка базы…',
    'CleanSweep — загрузка базы…', 'CleanSweep — завантаження бази…',
    'CleanSweep — loading database…');
  barWork.Style := pbstMarquee;
  trayIcon.Hint := 'CleanSweep';
  trayIcon.Icon.Handle := LoadIcon(HInstance, 'MAINICON');
  trayIcon.Visible := True;
  miCancel.Caption := Lg('Отменить очистку', 'Адмяніць ачыстку',
    'Скасувати очищення', 'Cancel cleaning');
  miExit.Caption := Lg('Выход', 'Выхад', 'Вихід', 'Exit');
  miCancel.Enabled := False;
  InitSafetyRoots;   // required before any engine call
  // enabled DBs + Custom\, minus Warning= and undetected entries
  FEntries := LoadCleanerPool(True);
  ApplySavedSelection;   // clean only what the user ticks in the GUI
  FThread := nil;
  FStarted := False;
  with Screen.WorkAreaRect do
  begin
    Left := Right - Width - 12;
    Top := Bottom - Height - 12;
  end;
end;

{ Drops entries the user would not have checked: the GUI's initial
  state is 'Default and Detected' adjusted by the saved Selection /
  Unchecked lists — -auto reproduces exactly that set. }
procedure TAutoForm.ApplySavedSelection;
var
  Ini: TIniFile;
  Sel, Unc: TStringList;
  I, N: Integer;
  E: TCleanerEntry;
  Keep: Boolean;
begin
  Sel := TStringList.Create;
  Unc := TStringList.Create;
  try
    Sel.CaseSensitive := False;
    Sel.Sorted := True;
    Sel.Duplicates := dupIgnore;
    Unc.CaseSensitive := False;
    Unc.Sorted := True;
    Unc.Duplicates := dupIgnore;
    Ini := TIniFile.Create(SettingsPath);
    try
      N := Ini.ReadInteger('Selection', 'Count', 0);
      for I := 0 to N - 1 do
        Sel.Add(Ini.ReadString('Selection', 'Entry' + IntToStr(I), ''));
      N := Ini.ReadInteger('Unchecked', 'Count', 0);
      for I := 0 to N - 1 do
        Unc.Add(Ini.ReadString('Unchecked', 'Entry' + IntToStr(I), ''));
    finally
      Ini.Free;
    end;
    for I := FEntries.Count - 1 downto 0 do
    begin
      E := FEntries[I];
      Keep := E.Default and E.Detected;
      if Sel.IndexOf(E.Name) >= 0 then Keep := True;
      if Unc.IndexOf(E.Name) >= 0 then Keep := False;
      if not Keep then FEntries.Delete(I);
    end;
  finally
    Sel.Free;
    Unc.Free;
  end;
end;

procedure TAutoForm.FormShow(Sender: TObject);
begin
  if FStarted then Exit;
  FStarted := True;
  FThread := TAutoThread.Create(FEntries);
  FThread.OnTerminate := @LabDone;
  miCancel.Enabled := True;
  FThread.Start;
end;

procedure TAutoForm.FormDestroy(Sender: TObject);
begin
  if FThread <> nil then
  begin
    FThread.OnTerminate := nil;   // would fire inside WaitFor and
    FThread.Terminate;            // free the thread under its own stack
    FThread.WaitFor;
    FThread.Free;
  end;
  FEntries.Free;
end;

procedure TAutoForm.ShowStatus(const AMsg: string);
begin
  lblStatus.Caption := 'CleanSweep — ' + AMsg;
end;

procedure TAutoForm.MiCancelClick(Sender: TObject);
begin
  if FThread <> nil then
  begin
    miCancel.Enabled := False;
    FThread.Terminate;   // engine aborts via EngineCancel → LabDone
  end;
end;

procedure TAutoForm.MiExitClick(Sender: TObject);
begin
  Close;
end;

procedure TAutoForm.ToastClick(Sender: TObject);
begin
  Close;
end;

procedure TAutoForm.TmrDoneTimer(Sender: TObject);
begin
  Close;
end;

procedure TAutoForm.LabDone(Sender: TObject);
var
  ND: Integer;
  Bytes: Int64;
  St: string;
  WasCancelled: Boolean;
begin
  WasCancelled := FThread.Terminated;
  ND := FThread.DoneCount;
  Bytes := FThread.TotalBytes;
  FThread.Free;
  FThread := nil;
  miCancel.Enabled := False;
  barWork.Visible := False;
  if WasCancelled then
    St := Format(Lg('прервано · удалено %d · %s',
      'перарвана · выдалена %d · %s', 'перервано · видалено %d · %s',
      'cancelled · %d removed · %s'), [ND, FormatBytes(Bytes)])
  else if ND > 0 then
    St := Format(Lg(
      'очищено %d элементов · %s',
      'ачышчана %d элементаў · %s',
      'очищено %d елементів · %s',
      'cleaned %d items · %s'), [ND, FormatBytes(Bytes)])
  else
    St := Lg('чисто — мусор не найден', 'чыста — смецце не знойдзена',
      'чисто — сміття не знайдено', 'clean — nothing found');
  ShowStatus(St);
  tmrDone.Enabled := True;
end;

end.
