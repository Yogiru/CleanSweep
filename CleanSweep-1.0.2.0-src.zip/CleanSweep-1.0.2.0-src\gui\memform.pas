unit memform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, StdCtrls, ExtCtrls,
  ComCtrls;

type
  { One-shot worker: snapshots free RAM, runs CleanSystemMemory,
    snapshots again. Non-empty work takes a couple of seconds under
    the per-process fallback, hence a thread and not a main-thread
    call. }
  TMemThread = class(TThread)
  private
    FBefore, FAfter: Int64;
  protected
    procedure Execute; override;
  public
    property Before: Int64 read FBefore;
    property After: Int64 read FAfter;
  end;

  { MemCleaner-style report toast: slim translucent stay-on-top strip
    near the tray. Shows "cleaning…", then the before/after/free delta;
    auto-closes a few seconds later or immediately on click. }
  TMemForm = class(TForm)
    pnlMain: TPanel;
    lblStatus: TLabel;
    barWork: TProgressBar;
    tmrDone: TTimer;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure ToastClick(Sender: TObject);
    procedure TmrDoneTimer(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
  private
    FThread: TMemThread;
    FStarted: Boolean;
    procedure LabDone(Sender: TObject);
  end;

var
  MemFormWnd: TMemForm;

{ Kicks off a manual memory clean: creates the toast, which starts its
  worker on show. Modeless — caller keeps running. }
procedure RunMemoryClean(AOwner: TComponent);

implementation

uses
  Windows, cs.lang, cs.memclean;

{$R *.lfm}

procedure RunMemoryClean(AOwner: TComponent);
var
  F: TMemForm;
begin
  F := TMemForm.Create(AOwner);   // frees itself — OnClose = caFree
  F.Show;
end;

procedure TMemThread.Execute;
begin
  FBefore := FreeMemoryMB;
  CleanSystemMemory;
  FAfter := FreeMemoryMB;
end;

procedure TMemForm.FormCreate(Sender: TObject);
begin
  try
    Icon.LoadFromResourceName(HInstance, 'MEM');
  except
  end;
  lblStatus.Caption := Lg('Очистка памяти…', 'Ачыстка памяці…',
    'Очищення пам''яті…', 'Cleaning memory…');
  barWork.Style := pbstMarquee;
  FThread := nil;
  FStarted := False;
  with Screen.WorkAreaRect do
  begin
    Left := Right - Width - 12;
    Top := Bottom - Height - 12;
  end;
end;

procedure TMemForm.FormShow(Sender: TObject);
begin
  if FStarted then Exit;
  FStarted := True;
  FThread := TMemThread.Create(True);
  FThread.FreeOnTerminate := False;
  FThread.OnTerminate := @LabDone;
  FThread.Start;
end;

procedure TMemForm.FormDestroy(Sender: TObject);
begin
  if FThread <> nil then
  begin
    FThread.OnTerminate := nil;
    FThread.Terminate;
    FThread.WaitFor;
    FThread.Free;
  end;
end;

procedure TMemForm.FormClose(Sender: TObject;
  var CloseAction: TCloseAction);
begin
  { Standalone (-mem): the toast is the main form — tell the app to
    quit; spawned from the main window it just frees itself. }
  if Self = Application.MainForm then Application.Terminate;
  CloseAction := caFree;
end;

procedure TMemForm.ToastClick(Sender: TObject);
begin
  Close;
end;

procedure TMemForm.TmrDoneTimer(Sender: TObject);
begin
  Close;
end;

procedure TMemForm.LabDone(Sender: TObject);
var
  B, A, Diff: Int64;
  Sign, S: string;
begin
  B := FThread.Before;
  A := FThread.After;
  FThread.Free;
  FThread := nil;
  barWork.Visible := False;
  Diff := A - B;
  if Diff >= 0 then Sign := '+' else Sign := '';
  S := Format(Lg('%d → %d МБ  (%s%d МБ)', '%d → %d МБ  (%s%d МБ)',
    '%d → %d МБ  (%s%d МБ)', '%d → %d MB  (%s%d MB)'),
    [B, A, Sign, Diff]);
  lblStatus.Caption := S;
  tmrDone.Enabled := True;
end;

end.
