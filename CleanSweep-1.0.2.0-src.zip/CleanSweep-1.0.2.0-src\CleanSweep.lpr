program CleanSweep;

{$mode objfpc}{$H+}

uses
  {$IFDEF UNIX}
  cthreads,
  {$ENDIF}
  Interfaces, // LCL widgetset
  Forms, SysUtils,
  cs.utils,
  mainform, autoform, cleanerform, netform, memform, aboutform;

{$R *.res} // includes CleanSweep.res with the manifest

{ Command line: a flag launches that tool AS the application — the
  requested form becomes the main form, so closing it exits; no
  uninstaller window lingers behind. No flag → the uninstaller.
  -auto — unattended clean in a tray toast (armed cleaner entries,
          Warning= rules never run unattended)
  -c    — cleaner   -e/-net — network reset   -m/-mem — memory toast
  -h/-? — about box }
function WantsFlag(const AFlags: array of string): Boolean;
var
  I, K: Integer;
  P: string;
begin
  Result := False;
  for I := 1 to ParamCount do
  begin
    P := LowerCase(ParamStr(I));
    while (P <> '') and (P[1] in ['-', '/']) do Delete(P, 1, 1);
    for K := 0 to High(AFlags) do
      if P = AFlags[K] then Exit(True);
  end;
end;

begin
  DisablePowerThrottling;   // keep background scans off EcoQoS
  RequireDerivedFormResource := True;
  Application.Scaled := True;
  Application.Initialize;
  if WantsFlag(['auto']) then
    Application.CreateForm(TAutoForm, AutoFormWnd)
  else if WantsFlag(['c']) then
    Application.CreateForm(TCleanerForm, CleanerFormWnd)
  else if WantsFlag(['e', 'net']) then
    Application.CreateForm(TNetForm, NetFormWnd)
  else if WantsFlag(['m', 'mem']) then
    Application.CreateForm(TMemForm, MemFormWnd)
  else if WantsFlag(['h', '?']) then
    Application.CreateForm(TAboutForm, AboutFormWnd)
  else
    Application.CreateForm(TMainForm, MainFormWnd);
  Application.Run;
end.
