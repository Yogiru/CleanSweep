unit mainform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ComCtrls, StdCtrls,
  ExtCtrls, ImgList, Menus, Clipbrd, cs.models, cs.uninstall;

type
  TScanThread = class(TThread)
  private
    FList: TProgramList;
    FIncludeSystem: Boolean;
  protected
    procedure Execute; override;
  public
    destructor Destroy; override;
    property List: TProgramList read FList write FList;
    property IncludeSystem: Boolean read FIncludeSystem write FIncludeSystem;
  end;

  TUninstallThread = class(TThread)
  private
    FProgram: TInstalledProgram;
    FMode: TScanMode;
    FSilent: Boolean;
    FEngine: TUninstallEngine;
    FResult: TUninstallResult;
    FStatusQueue: TStringList;
    FStatusLock: TRTLCriticalSection;
    FProgressPct: Integer;
    FMainForm: TObject;
    FScanOnly: Boolean;
    procedure DoStatus;
    procedure DoProgress;
    procedure EngineStatus(const AMsg: string);
    procedure EngineProgress(APct: Integer);
  protected
    procedure Execute; override;
  public
    constructor Create(AProg: TInstalledProgram; AMode: TScanMode;
      ASilent: Boolean; AMainForm: TObject);
    property ScanOnly: Boolean read FScanOnly write FScanOnly;
    destructor Destroy; override;
    property ResultObj: TUninstallResult read FResult write FResult;
    property MainForm: TObject read FMainForm write FMainForm;
  end;

  TMainForm = class(TForm)
    edFilter: TEdit;
    ilMenu: TImageList;
    ilPrograms: TImageList;
    lvPrograms: TListView;
    MainMenu1: TMainMenu;
    miAction: TMenuItem;
    miCard: TMenuItem;
    miCleaner: TMenuItem;
    miCopyUninstall: TMenuItem;
    miExit: TMenuItem;
    miHelp: TMenuItem;
    miModeDeep: TMenuItem;
    miModeFast: TMenuItem;
    miModeStandard: TMenuItem;
    miMemory: TMenuItem;
    miNetwork: TMenuItem;
    miOnTop: TMenuItem;
    miOpenLocation: TMenuItem;
    miOpenRegedit: TMenuItem;
    miPopCopy: TMenuItem;
    miPopLocation: TMenuItem;
    miPopRegedit: TMenuItem;
    miPopScanLeft: TMenuItem;
    miPopSep: TMenuItem;
    miPopUninstall: TMenuItem;
    miRefresh: TMenuItem;
    miScanMode: TMenuItem;
    miSep1: TMenuItem;
    miSep2: TMenuItem;
    miSep3: TMenuItem;
    miSilent: TMenuItem;
    miSystem: TMenuItem;
    miAppX: TMenuItem;
    miUninstall: TMenuItem;
    mmLog: TMemo;
    pbProgress: TProgressBar;
    pmPrograms: TPopupMenu;
    pnlSearch: TPanel;
    sbStatus: TStatusBar;
    spLog: TSplitter;
    procedure FilterChange(Sender: TObject);
    procedure MenuAboutClick(Sender: TObject);
    procedure MenuCleanerClick(Sender: TObject);
    procedure MenuCopyUninstallClick(Sender: TObject);
    procedure MenuExitClick(Sender: TObject);
    procedure MenuModeClick(Sender: TObject);
    procedure MenuMemoryClick(Sender: TObject);
    procedure MenuNetworkClick(Sender: TObject);
    procedure MenuOpenLocationClick(Sender: TObject);
    procedure MenuOnTopClick(Sender: TObject);
    procedure MenuOpenRegeditClick(Sender: TObject);
    procedure MenuRefreshClick(Sender: TObject);
    procedure MenuSystemClick(Sender: TObject);
    procedure MenuAppXClick(Sender: TObject);
    procedure MenuUninstallClick(Sender: TObject);
    procedure MenuScanLeftoversClick(Sender: TObject);
    procedure ProgramColumnClick(Sender: TObject; Column: TListColumn);
    procedure ProgramDblClick(Sender: TObject);
  private
    FPrograms: TProgramList;
    FScanThread: TScanThread;
    FUninstallThread: TUninstallThread;
    FLastScan: TScanResult;
    FIconMap: TStringList;
    FSortCol: Integer;
    FSortAsc: Boolean;
    procedure ApplyLanguage;
    procedure EngineLog(const AMsg: string);
    procedure StartInventory;
    procedure InventoryDone(Sender: TObject);
    procedure PopulatePrograms;
    procedure UninstallDone(Sender: TObject);
    function SelectedProgram: TInstalledProgram;
    function CurrentScanMode: TScanMode;
    procedure StartUninstall(P: TInstalledProgram);
    function IconIndexFor(P: TInstalledProgram): Integer;
    procedure LoadToolIcons;

  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
    procedure Log(const AMsg: string);
    procedure LogDisplay(const AMsg: string);
  end;

var
  MainFormWnd: TMainForm;

implementation

{$R *.lfm}

uses
  Windows, ShellApi, Math, cs.utils, cs.safety, cs.registry, cs.signatures,
  cs.lang, leftoverform, progcard, aboutform, cleanerform, appxform,
  netform, memform;

{ ═══════════════ Threads ═══════════════ }

procedure TScanThread.Execute;
begin
  FList := TProgramList.Create(True);
  try
    ScanInstalledPrograms(FList, FIncludeSystem, False);
    FList.Sort(@CompareProgramsByName);
  except
    on E: Exception do
      LogToFile('Inventory scan failed: ' + E.ClassName + ': ' + E.Message);
  end;
end;

destructor TScanThread.Destroy;
begin
  FList.Free;
  inherited;
end;

procedure TUninstallThread.DoStatus;
var
  S: string;
  F: TMainForm;
begin
  F := TMainForm(FMainForm);
  repeat
    EnterCriticalSection(FStatusLock);
    try
      if FStatusQueue.Count = 0 then
        S := ''
      else
      begin
        S := FStatusQueue[0];
        FStatusQueue.Delete(0);
      end;
    finally
      LeaveCriticalSection(FStatusLock);
    end;
    if S = '' then Break;
    if F <> nil then F.LogDisplay(S);
  until False;
end;

procedure TUninstallThread.DoProgress;
begin
  if FMainForm = nil then Exit;
  TMainForm(FMainForm).pbProgress.Position := FProgressPct;
end;

procedure TUninstallThread.EngineStatus(const AMsg: string);
begin
  if Trim(AMsg) = '' then Exit;
  LogToFile(AMsg); // file gets lines in engine call order
  EnterCriticalSection(FStatusLock);
  try
    FStatusQueue.Add(AMsg);
  finally
    LeaveCriticalSection(FStatusLock);
  end;
  Queue(@DoStatus);
end;

procedure TUninstallThread.EngineProgress(APct: Integer);
begin
  FProgressPct := APct;
  Queue(@DoProgress);
end;

constructor TUninstallThread.Create(AProg: TInstalledProgram;
  AMode: TScanMode; ASilent: Boolean; AMainForm: TObject);
begin
  inherited Create(True);
  FreeOnTerminate := False;
  FProgram := AProg;
  FMode := AMode;
  FSilent := ASilent;
  FMainForm := AMainForm;
  FStatusQueue := TStringList.Create;
  InitCriticalSection(FStatusLock);
end;

procedure TUninstallThread.Execute;
var
  Scan: TScanResult;
begin
  Scan := nil;
  FEngine := TUninstallEngine.Create;
  FEngine.OnStatus := @EngineStatus;
  FEngine.OnProgress := @EngineProgress;
  try
    if FScanOnly then
      FResult := FEngine.ScanOnly(FProgram, FMode, Scan)
    else
      FResult := FEngine.Uninstall(FProgram, FMode, FSilent, False, Scan);
  except
    on E: Exception do
      // without this the failure dies silently inside FatalException —
      // the user would just see a quiet 'finished' with no cause
      EngineStatus('ERROR: ' + E.ClassName + ': ' + E.Message);
  end;
end;

destructor TUninstallThread.Destroy;
begin
  FEngine.Free;
  FStatusQueue.Free;
  DoneCriticalSection(FStatusLock);
  inherited;
end;

{ ═══════════════ Form ═══════════════ }

constructor TMainForm.Create(AOwner: TComponent);
var
  DataPath: string;
begin
  inherited Create(AOwner); // loads mainform.lfm
  try
    Icon.LoadFromResourceName(HInstance, 'UNI');   // uninstaller tool
    Application.Icon.Assign(Icon);
  except
  end;
  LoadToolIcons;

  InitSafetyRoots;
  // External JSON wins when present (user-editable); otherwise the
  // copy embedded as the LEFTOVERSIG resource keeps it one file.
  DataPath := ExtractFilePath(ParamStr(0)) + 'data\leftover-signatures.json';
  if not FileExists(DataPath) then
    DataPath := ExtractFilePath(ParamStr(0)) + 'leftover-signatures.json';
  if FileExists(DataPath) then
    LoadSignatures(DataPath)
  else
    LoadSignaturesFromResource('LEFTOVERSIG');

  FPrograms := TProgramList.Create(True);
  FIconMap := TStringList.Create;
  FLastScan := nil;
  FSortCol := -1;
  FSortAsc := True;
  FScanThread := nil;
  FUninstallThread := nil;
  ApplyLanguage;
  StartInventory;
end;

{ Menu-bar glyphs: 0-3 — embedded tool icons from icons.icl
  (UNI «Меню», CLE «Очистка», MEM «Память», NET «Сеть»);
  4-7 — system icons extracted at run time: refresh (imageres:228),
  open folder (shell32:4), regedit (regedit.exe:0), exit/power
  (shell32:112). Missing icons just leave the item glyphless. }
procedure TMainForm.LoadToolIcons;
const
  Names: array[0..3] of string = ('UNI', 'CLE', 'MEM', 'NET');
var
  I: Integer;
  Ico: TIcon;
  Sm: HICON;
  SysDir: string;

  procedure AddDllIcon(const APath: string; AIndex: Integer);
  var
    S: string;
  begin
    S := StringReplace(APath, '%windir%', SysDir, [rfIgnoreCase]);
    Sm := 0;
    if ExtractIconExW(PWideChar(UTF8Decode(S)), AIndex, nil, @Sm, 1) <> 1 then Exit;
    if Sm = 0 then Exit;
    Ico.Handle := Sm;         // TIcon takes ownership of the handle
    ilMenu.AddIcon(Ico);
  end;

begin
  Ico := TIcon.Create;
  try
    for I := 0 to High(Names) do
      try
        Ico.LoadFromResourceName(HInstance, Names[I]);
        ilMenu.AddIcon(Ico);
      except
      end;
    SysDir := SysUtils.GetEnvironmentVariable('SystemRoot');
    if SysDir = '' then SysDir := 'C:\Windows';
    AddDllIcon('%windir%\System32\imageres.dll', 228);
    AddDllIcon('%windir%\System32\shell32.dll', 4);
    AddDllIcon('%windir%\regedit.exe', 0);
    AddDllIcon('%windir%\System32\shell32.dll', 112);
  finally
    Ico.Free;
  end;
end;

destructor TMainForm.Destroy;
begin
  // Detach, never WaitFor: a worker may be inside WaitForSingleObject
  // on a vendor uninstaller — blocking the main thread here would
  // freeze the UI while closing. Queued callbacks are dropped when
  // the thread is freed (TThread.Destroy removes them).
  if FUninstallThread <> nil then
  begin
    FUninstallThread.OnTerminate := nil;
    FUninstallThread.MainForm := nil;
    if FUninstallThread.Finished then
      FUninstallThread.Free
    else
      FUninstallThread.FreeOnTerminate := True;
    FUninstallThread := nil;
  end;
  if FScanThread <> nil then
  begin
    FScanThread.OnTerminate := nil;
    if FScanThread.Finished then
      FScanThread.Free
    else
      FScanThread.FreeOnTerminate := True;
    FScanThread := nil;
  end;
  FLastScan.Free;
  FIconMap.Free;
  FPrograms.Free;
  inherited;
end;

procedure TMainForm.Log(const AMsg: string);
begin
  if Trim(AMsg) = '' then Exit;
  LogDisplay(AMsg);
  LogToFile(AMsg);
end;

procedure TMainForm.LogDisplay(const AMsg: string);
begin
  mmLog.Lines.Add(FormatDateTime('hh:nn:ss', Now) + '  ' + AMsg);
  sbStatus.SimpleText := AMsg;
end;

procedure TMainForm.EngineLog(const AMsg: string);
begin
  Log(AMsg);
end;

procedure TMainForm.ApplyLanguage;
var
  S: string;
begin
  miExit.Caption      := Lg('Выход', 'Выхад', 'Вихід', 'Exit');
  miAction.Caption    := Lg('Меню', 'Меню', 'Меню', 'Menu');
  S := Lg('Деинсталлировать', 'Дэінсталяваць', 'Деінсталювати', 'Uninstall');
  miUninstall.Caption    := S;
  miPopUninstall.Caption := S;
  miCleaner.Caption   := Lg('Очистка', 'Ачыстка', 'Очищення', 'Cleanup');
  miMemory.Caption    := Lg('Память', 'Памяць', 'Пам''ять', 'Memory');
  miNetwork.Caption   := Lg('Сеть', 'Сетка', 'Мережа', 'Network');
  miRefresh.Caption   := Lg('Обновить', 'Абнавіць', 'Оновити', 'Refresh');
  S := Lg('Открыть каталог установки', 'Адкрыць каталог усталёўкі',
          'Відкрити каталог установки', 'Open install folder');
  miOpenLocation.Caption := S;
  miPopLocation.Caption  := S;
  S := Lg('Открыть в реестре', 'Адкрыць у рэестры',
          'Відкрити в реєстрі', 'Open in registry');
  miOpenRegedit.Caption := S;
  miPopRegedit.Caption  := S;
  S := Lg('Копировать строку деинсталляции', 'Капіраваць радок дэінсталяцыі',
          'Копіювати рядок деінсталяції', 'Copy uninstall string');
  miCopyUninstall.Caption := S;
  miPopCopy.Caption       := S;
  miSilent.Caption    := Lg('Тихий режим', 'Ціхі рэжым', 'Тихий режим', 'Silent mode');
  miSystem.Caption    := Lg('Системные', 'Сістэмныя', 'Системні', 'System components');
  miAppX.Caption      := 'AppX';
  miOnTop.Caption     := Lg('Поверх всех окон', 'Паўерх усіх вокнаў',
                            'Понад усіма вікнами', 'Always on top');
  miPopScanLeft.Caption := Lg('Найти остатки (без удаления)…',
    'Знайсці рэшткі (без выдалення)…',
    'Знайти залишки (без видалення)…',
    'Find leftovers (no uninstall)…');
  miScanMode.Caption  := Lg('Глубина поиска остатков',
                            'Глыбіня пошуку рэшткаў',
                            'Глибина пошуку залишків',
                            'Leftover scan depth');
  miModeFast.Caption     := Lg('Быстрый', 'Хуткі', 'Швидкий', 'Fast');
  miModeStandard.Caption := Lg('Стандартный', 'Стандартны', 'Стандартний', 'Standard');
  miModeDeep.Caption     := Lg('Глубокий', 'Глыбокі', 'Глибокий', 'Deep');
  miHelp.Caption      := '?';
  miCard.Caption      := Lg('Карточка программы', 'Картка праграмы',
                            'Картка програми', 'Program card');
  lvPrograms.Columns[0].Caption := Lg('Программа', 'Праграма', 'Програма', 'Program');
  lvPrograms.Columns[1].Caption := Lg('Размер', 'Памер', 'Розмір', 'Size');
  lvPrograms.Columns[2].Caption := Lg('Установлено', 'Усталявана', 'Встановлено', 'Installed');
  edFilter.TextHint := Lg('Введите слово для поиска', 'Увядзіце слова для пошуку',
                          'Введіть слово для пошуку', 'Type to search');
  sbStatus.SimpleText := Lg('Готов', 'Гатова', 'Готово', 'Ready');
end;

procedure TMainForm.StartInventory;
begin
  if FScanThread <> nil then Exit;
  sbStatus.SimpleText := Lg('Сканирование программ...', 'Сканіраванне праграм...',
                            'Сканування програм...', 'Scanning programs...');
  FScanThread := TScanThread.Create(True);
  FScanThread.FreeOnTerminate := False;
  // system components are always scanned — the view filter in
  // PopulatePrograms decides what to show (normal / only system),
  // so toggling «Системные» needs no rescan
  FScanThread.IncludeSystem := True;
  FScanThread.OnTerminate := @InventoryDone;
  FScanThread.Start;
end;

procedure TMainForm.InventoryDone(Sender: TObject);
begin
  if FScanThread.List <> nil then
  begin
    FPrograms.Free;
    FPrograms := FScanThread.List;
    FScanThread.List := nil; // ownership transferred
  end;
  FScanThread.Free;
  FScanThread := nil;
  PopulatePrograms;
  Log(Format(Lg('Инвентаризация: %d', 'Інвентарызацыя: %d',
                'Інвентаризація: %d', 'Inventory: %d'), [FPrograms.Count]));
end;

procedure TMainForm.PopulatePrograms;
var
  I: Integer;
  P: TInstalledProgram;
  Filter, SName: string;
  It: TListItem;
  TotalKB: Int64;
begin
  Filter := LowerCase(Trim(edFilter.Text));
  TotalKB := 0;
  lvPrograms.Items.BeginUpdate;
  try
    lvPrograms.Items.Clear;
    for I := 0 to FPrograms.Count - 1 do
    begin
      P := FPrograms[I];
      Inc(TotalKB, P.EstimatedSizeKB);
      // view filter: «Системные» → only system components,
      // otherwise only normal programs
      if P.IsSystem <> miSystem.Checked then Continue;
      if (Filter <> '') and
         (Pos(Filter, LowerCase(P.DisplayName)) = 0) and
         (Pos(Filter, LowerCase(P.Publisher)) = 0) then
        Continue;
      SName := P.DisplayName;
      if P.Source = rsHKLM_WOW64 then
        SName := SName + Lg(' (32-бита)', ' (32-біт)', ' (32-біт)', ' (32-bit)');
      It := lvPrograms.Items.Add;
      It.Caption := SName;
      It.SubItems.Add(P.SizeDisplay);
      It.SubItems.Add(NormalizeInstallDate(P.InstallDate));
      It.Data := P;
      It.ImageIndex := IconIndexFor(P);
    end;
  finally
    lvPrograms.Items.EndUpdate;
  end;
  sbStatus.SimpleText := Format('%d %s, %s — %s',
    [FPrograms.Count,
     PluralForm(FPrograms.Count,
       Lg('программа', 'праграма', 'програма', 'program'),
       Lg('программы', 'праграмы', 'програми', 'programs'),
       Lg('программ', 'праграм', 'програм', 'programs')),
     Lg('полный размер', 'поўны памер', 'повний розмір', 'total size'),
     FormatBytes(TotalKB * 1024)]);
end;

procedure TMainForm.MenuExitClick(Sender: TObject);
begin
  Close;
end;

procedure TMainForm.MenuAboutClick(Sender: TObject);
begin
  ShowAboutDialog(Self);
end;

procedure TMainForm.MenuCleanerClick(Sender: TObject);
begin
  ShowCleanerDialog(Self);
end;

procedure TMainForm.MenuMemoryClick(Sender: TObject);
begin
  RunMemoryClean(Self);
end;

procedure TMainForm.MenuNetworkClick(Sender: TObject);
begin
  ShowNetworkDialog(Self);
end;

function TMainForm.SelectedProgram: TInstalledProgram;
begin
  Result := nil;
  if lvPrograms.Selected <> nil then
    Result := TInstalledProgram(lvPrograms.Selected.Data);
end;

function TMainForm.CurrentScanMode: TScanMode;
begin
  if miModeFast.Checked then Result := smSafe
  else if miModeDeep.Checked then Result := smAdvanced
  else Result := smModerate;
end;

procedure TMainForm.FilterChange(Sender: TObject);
begin
  PopulatePrograms;
end;

procedure TMainForm.StartUninstall(P: TInstalledProgram);
begin
  if P = nil then
  begin
    Log(Lg('Сначала выберите программу.', 'Спачатку выберыце праграму.',
           'Спочатку виберіть програму.', 'Select a program first.'));
    Exit;
  end;
  if FUninstallThread <> nil then
  begin
    Log(Lg('Деинсталляция уже выполняется.', 'Дэінсталяцыя ўжо выконваецца.',
           'Деінсталяція вже виконується.', 'Uninstall already in progress.'));
    Exit;
  end;

  if (P.UninstallString = '') then
    if MessageDlg(Format(Lg('Деинсталлятор не зарегистрирован для "%s". ' +
        'Искать остатки вручную?',
        'Дэінсталятар не зарэгістраваны для "%s". Шукаць рэшткі ўручную?',
        'Деінсталятор не зареєстрований для "%s". Шукати залишки вручну?',
        'No uninstaller registered for "%s". Scan for leftovers anyway?'),
        [P.DisplayName]), mtConfirmation,
        [mbYes, mbNo], 0) <> mrYes then Exit;

  FUninstallThread := TUninstallThread.Create(P, CurrentScanMode,
                                            miSilent.Checked, Self);
  FUninstallThread.OnTerminate := @UninstallDone;
  FUninstallThread.Start;
end;

procedure TMainForm.UninstallDone(Sender: TObject);
var
  WasScanOnly: Boolean;
begin
  WasScanOnly := FUninstallThread.ScanOnly;
  if FUninstallThread.ResultObj <> nil then
  begin
    if FUninstallThread.ResultObj.Scan <> nil then
    begin
      // Keep scan objects alive — the dialog references the items.
      FLastScan.Free;
      FLastScan := FUninstallThread.ResultObj.Scan;
      FUninstallThread.ResultObj.Scan := nil;
      if (FLastScan.RegistryLeftovers.Count > 0) or
         (FLastScan.FileLeftovers.Count > 0) then
        ShowLeftoverDialog(Self, FLastScan, False, @EngineLog)
      else
        Log(Lg('Остатки не найдены.', 'Рэшткі не знойдзены.',
               'Залишки не знайдено.', 'No leftovers found.'));
    end;
    if WasScanOnly then
    begin
      if Trim(FUninstallThread.ResultObj.Output) <> '' then
        Log(Lg('Поиск остатков завершён: ', 'Пошук рэшткаў завершаны: ',
               'Пошук залишків завершено: ', 'Leftover scan finished: ') +
            FUninstallThread.ResultObj.Output);
      // nothing was uninstalled — no inventory refresh needed
    end
    else if Trim(FUninstallThread.ResultObj.Output) <> '' then
      Log(Lg('Деинсталляция завершена: ', 'Дэінсталяцыя завершана: ',
             'Деінсталяцію завершено: ', 'Uninstall finished: ') +
          FUninstallThread.ResultObj.Output)
    else
      Log(Lg('Деинсталляция завершена', 'Дэінсталяцыя завершана',
             'Деінсталяцію завершено', 'Uninstall finished'));
    FUninstallThread.ResultObj.Free;
    FUninstallThread.ResultObj := nil;
  end;
  // OnTerminate already implies the thread is finished — never
  // WaitFor here (the thread is blocked inside DoTerminate while
  // this handler runs: WaitFor would deadlock the main loop).
  FUninstallThread.Free;
  FUninstallThread := nil;
  if not WasScanOnly then
    StartInventory; // refresh list
end;

var
  GSortCol: Integer = -1;
  GSortAsc: Boolean = True;

function CompareProgramsDyn(const A, B: TInstalledProgram): Integer;
begin
  case GSortCol of
    0: Result := CompareText(A.DisplayName, B.DisplayName);
    1: Result := Sign(A.EstimatedSizeKB - B.EstimatedSizeKB);
    2: Result := CompareText(A.InstallDate, B.InstallDate);
  else
    Result := 0;
  end;
  if not GSortAsc then Result := -Result;
end;

procedure TMainForm.ProgramColumnClick(Sender: TObject; Column: TListColumn);
begin
  if FSortCol = Column.Index then
    FSortAsc := not FSortAsc
  else
  begin
    FSortCol := Column.Index;
    FSortAsc := True;
  end;
  GSortCol := FSortCol;
  GSortAsc := FSortAsc;
  FPrograms.Sort(@CompareProgramsDyn);
  PopulatePrograms;
end;

function TMainForm.IconIndexFor(P: TInstalledProgram): Integer;
var
  S: string;
  Idx: Integer;
  H: HICON;
  Ico: TIcon;
begin
  Idx := ProgramIconSource(P, S);
  Result := FIconMap.IndexOf(S);
  if Result >= 0 then Exit(PtrInt(FIconMap.Objects[Result]));
  H := GetShellIconPx(S, Idx, 48);   // enough headroom for 300% scaling
  if H = 0 then Exit(-1);
  Ico := TIcon.Create;
  try
    Ico.Handle := H;
    Result := ilPrograms.AddIcon(Ico);
  finally
    Ico.Free; // also destroys H (handle adopted)
  end;
  FIconMap.AddObject(S, TObject(PtrInt(Result)));
end;

procedure TMainForm.MenuUninstallClick(Sender: TObject);
begin
  StartUninstall(SelectedProgram);
end;

{ Leftover scan for the selected program WITHOUT running its
  uninstaller — a preview of what removal would leave behind.
  Uses the depth chosen under «Глубина поиска остатков». }
procedure TMainForm.MenuScanLeftoversClick(Sender: TObject);
var
  P: TInstalledProgram;
begin
  P := SelectedProgram;
  if P = nil then
  begin
    Log(Lg('Сначала выберите программу.', 'Спачатку выберыце праграму.',
           'Спочатку виберіть програму.', 'Select a program first.'));
    Exit;
  end;
  if FUninstallThread <> nil then
  begin
    Log(Lg('Деинсталляция уже выполняется.', 'Дэінсталяцыя ўжо выконваецца.',
           'Деінсталяція вже виконується.', 'Uninstall already in progress.'));
    Exit;
  end;
  FUninstallThread := TUninstallThread.Create(P, CurrentScanMode,
                                            False, Self);
  FUninstallThread.ScanOnly := True;
  FUninstallThread.OnTerminate := @UninstallDone;
  FUninstallThread.Start;
end;

procedure TMainForm.MenuRefreshClick(Sender: TObject);
begin
  StartInventory;
end;

procedure TMainForm.ProgramDblClick(Sender: TObject);
var
  P: TInstalledProgram;
begin
  P := SelectedProgram;
  if P = nil then Exit;
  if ShowProgramCard(Self, P) = mrYes then
    StartUninstall(P);
end;

{ «Системные» инвертировано: галка показывает ТОЛЬКО системные
  компоненты, без неё — обычные программы. }
procedure TMainForm.MenuSystemClick(Sender: TObject);
begin
  PopulatePrograms;
end;

{ AppX-деблоатер живёт в своей форме — общий список ей не трогаем. }
procedure TMainForm.MenuAppXClick(Sender: TObject);
begin
  ShowAppxDialog(Self);
end;

procedure TMainForm.MenuOnTopClick(Sender: TObject);
begin
  if miOnTop.Checked then FormStyle := fsStayOnTop
                     else FormStyle := fsNormal;
end;

procedure TMainForm.MenuModeClick(Sender: TObject);
begin
  TMenuItem(Sender).Checked := True; // radio group does the rest
end;

procedure TMainForm.MenuOpenLocationClick(Sender: TObject);
var
  P: TInstalledProgram;
begin
  P := SelectedProgram;
  if (P <> nil) and (P.InstallLocation <> '') then
    ShowInExplorer(P.InstallLocation);
end;

procedure TMainForm.MenuOpenRegeditClick(Sender: TObject);
var
  P: TInstalledProgram;
begin
  P := SelectedProgram;
  if (P <> nil) and (P.RegistryPath <> '') then
    ShowInRegedit(P.RegistryPath);
end;

procedure TMainForm.MenuCopyUninstallClick(Sender: TObject);
var
  P: TInstalledProgram;
begin
  P := SelectedProgram;
  if P <> nil then Clipboard.AsText := P.UninstallString;
end;

end.
