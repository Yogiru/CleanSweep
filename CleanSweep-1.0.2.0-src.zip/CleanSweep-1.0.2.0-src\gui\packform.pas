unit packform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, Dialogs, CheckLst, cs.lang;

{ Checklist picker for rule-pack operations. AItems — display labels,
  AValues — parallel technical values; checked items' values are
  returned. AChecked lists values to pre-check (nil/empty → all). }
function PickPackItems(AOwner: TComponent; const ATitle, APrompt: string;
  AItems, AValues, AChecked: TStrings): TStringList;

type
  TPackForm = class(TForm)
    lblPrompt: TLabel;
    clbItems: TCheckListBox;
    btnAll: TButton;
    btnNone: TButton;
    btnOk: TButton;
    btnCancel: TButton;
    procedure BtnAllClick(Sender: TObject);
    procedure BtnNoneClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  end;

implementation

{$R *.lfm}

function PickPackItems(AOwner: TComponent; const ATitle, APrompt: string;
  AItems, AValues, AChecked: TStrings): TStringList;
var
  F: TPackForm;
  I: Integer;
begin
  Result := nil;
  F := TPackForm.Create(AOwner);
  try
    F.Caption := ATitle;
    F.lblPrompt.Caption := APrompt;
    F.clbItems.Items.Assign(AItems);
    for I := 0 to F.clbItems.Items.Count - 1 do
      F.clbItems.Checked[I] := (AChecked = nil) or (AChecked.Count = 0) or
        (AChecked.IndexOf(AValues[I]) >= 0);
    if F.ShowModal <> mrOk then Exit;
    Result := TStringList.Create;
    for I := 0 to F.clbItems.Items.Count - 1 do
      if F.clbItems.Checked[I] then Result.Add(AValues[I]);
  finally
    F.Free;
  end;
end;

procedure TPackForm.FormCreate(Sender: TObject);
begin
  btnAll.Caption := Lg('Все', 'Усе', 'Усі', 'All');
  btnNone.Caption := Lg('Ничего', 'Нічога', 'Нічого', 'None');
  btnOk.Caption := 'OK';
  btnCancel.Caption := Lg('Отмена', 'Адмена', 'Скасувати', 'Cancel');
end;

procedure TPackForm.BtnAllClick(Sender: TObject);
begin
  clbItems.CheckAll(cbChecked);
end;

procedure TPackForm.BtnNoneClick(Sender: TObject);
begin
  clbItems.CheckAll(cbUnchecked);
end;

end.
