unit cs.memclean;

{$mode objfpc}{$H+}

interface

uses
  Windows;

{ Frees physical RAM, the MemCleaner way:
    1. EmptyAllWorkingSets — system-wide working-set trim via
       NtSetSystemInformation (needs SeProfileSingleProcessPrivilege);
       on failure falls back to per-process EmptyWorkingSet.
    2. PurgeStandbyLists — standby + low-priority standby pages.
    3. FlushSystemFileCache — min/max cache WS clamped to SIZE_T max.
  Use FreeMemoryMB before/after for the report. Safe to call from a
  worker thread; costs a few seconds under the per-process fallback. }
procedure CleanSystemMemory;

{ Currently available physical memory, MB (GlobalMemoryStatusEx). }
function FreeMemoryMB: Int64;

implementation

uses
  SysUtils;

const
  SystemFileCacheInformation = 21;
  SystemMemoryListInformation = 80;
  MemoryEmptyWorkingSets = 2;
  MemoryPurgeStandbyList = 4;
  MemoryPurgeLowPriorityStandbyList = 5;

  PROCESS_SET_QUOTA = $0100;
  PID_BUF_COUNT = 1024;
  PROCESSES_LOOP_DELAY = 5;   // ms — keeps the sweep polite

type
  NTSTATUS = LONG;

  TMemoryStatusEx = record
    dwLength: DWORD;
    dwMemoryLoad: DWORD;
    ullTotalPhys: ULONGLONG;
    ullAvailPhys: ULONGLONG;
    ullTotalPageFile: ULONGLONG;
    ullAvailPageFile: ULONGLONG;
    ullTotalVirtual: ULONGLONG;
    ullAvailVirtual: ULONGLONG;
    ullAvailExtendedVirtual: ULONGLONG;
  end;

  TSystemFileCacheInfo = record
    CurrentSize: SIZE_T;
    PeakSize: SIZE_T;
    PageFaultCount: ULONG;
    MinimumWorkingSet: SIZE_T;
    MaximumWorkingSet: SIZE_T;
    CurrentSizeIncludingTransitionInPages: SIZE_T;
    PeakSizeIncludingTransitionInPages: SIZE_T;
    TransitionRePurposeCount: ULONG;
    Flags: ULONG;
  end;

function NtSetSystemInformation(SystemInformationClass: DWORD;
  SystemInformation: Pointer; SystemInformationLength: ULONG): NTSTATUS;
  stdcall; external 'ntdll.dll' name 'NtSetSystemInformation';
function EmptyWorkingSet(hProcess: HANDLE): BOOL;
  stdcall; external 'psapi.dll' name 'EmptyWorkingSet';
function EnumProcesses(lpidProcess: PLongWord; cb: LongWord;
  out cbNeeded: DWORD): BOOL;
  stdcall; external 'psapi.dll' name 'EnumProcesses';
function GlobalMemoryStatusEx(var lpBuffer: TMemoryStatusEx): BOOL;
  stdcall; external 'kernel32' name 'GlobalMemoryStatusEx';

function FreeMemoryMB: Int64;
var
  MemInfo: TMemoryStatusEx;
begin
  MemInfo.dwLength := SizeOf(MemInfo);
  if GlobalMemoryStatusEx(MemInfo) then
    Result := MemInfo.ullAvailPhys div (1024 * 1024)
  else
    Result := 0;
end;

function SetPrivilege(const Name: string): Boolean;
var
  hToken: HANDLE;
  tkp, Prev: TOKEN_PRIVILEGES;
  Luid: TLargeInteger;
  ReturnLen: DWORD;
begin
  Result := False;
  if not OpenProcessToken(GetCurrentProcess,
      TOKEN_ADJUST_PRIVILEGES or TOKEN_QUERY, hToken) then
    Exit;
  try
    if not LookupPrivilegeValue(nil, PChar(Name), Luid) then Exit;
    tkp.PrivilegeCount := 1;
    tkp.Privileges[0].Luid := Luid;
    tkp.Privileges[0].Attributes := SE_PRIVILEGE_ENABLED;
    if AdjustTokenPrivileges(hToken, LongBool(False), tkp, SizeOf(tkp),
        Prev, ReturnLen) then
      Result := GetLastError = ERROR_SUCCESS;
  finally
    CloseHandle(hToken);
  end;
end;

function EmptyAllWorkingSets: Boolean;
var
  Cmd: DWORD;
begin
  Result := False;
  if not SetPrivilege('SeProfileSingleProcessPrivilege') then Exit;
  Cmd := MemoryEmptyWorkingSets;
  Result := NtSetSystemInformation(SystemMemoryListInformation,
    @Cmd, SizeOf(Cmd)) >= 0;
end;

function PurgeStandbyLists: Boolean;
var
  Cmd: DWORD;
begin
  Result := False;
  if not SetPrivilege('SeProfileSingleProcessPrivilege') then Exit;
  Cmd := MemoryPurgeStandbyList;
  Result := NtSetSystemInformation(SystemMemoryListInformation,
    @Cmd, SizeOf(Cmd)) >= 0;
  Cmd := MemoryPurgeLowPriorityStandbyList;
  NtSetSystemInformation(SystemMemoryListInformation,
    @Cmd, SizeOf(Cmd));
end;

function FlushSystemFileCache: Boolean;
var
  Info: TSystemFileCacheInfo;
begin
  Result := False;
  if not SetPrivilege('SeIncreaseQuotaPrivilege') then Exit;
  FillChar(Info, SizeOf(Info), 0);
  Info.MinimumWorkingSet := High(SIZE_T);
  Info.MaximumWorkingSet := High(SIZE_T);
  Result := NtSetSystemInformation(SystemFileCacheInformation,
    @Info, SizeOf(Info)) >= 0;
end;

procedure TrimProcesses;
var
  Pids: array[0..PID_BUF_COUNT - 1] of DWORD;
  cbNeeded, cProcesses, I: DWORD;
  hProcess: HANDLE;
begin
  if not EnumProcesses(@Pids[0], SizeOf(Pids), cbNeeded) then Exit;
  cProcesses := cbNeeded div SizeOf(DWORD);
  for I := 0 to cProcesses - 1 do
  begin
    if Pids[I] = 0 then Continue;
    hProcess := OpenProcess(PROCESS_SET_QUOTA, False, Pids[I]);
    if hProcess = 0 then Continue;
    EmptyWorkingSet(hProcess);
    CloseHandle(hProcess);
    Sleep(PROCESSES_LOOP_DELAY);
  end;
end;

procedure CleanSystemMemory;
begin
  if not EmptyAllWorkingSets then
    TrimProcesses;
  PurgeStandbyLists;
  FlushSystemFileCache;
end;

end.
