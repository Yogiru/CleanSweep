unit aboutform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, StdCtrls, ExtCtrls, Graphics,
  Buttons;

type
  TAboutForm = class(TForm)
    btnOK: TBitBtn;
    imgIcon: TImage;
    lblAuthor: TLabel;
    lblCleaner: TLabel;
    lblCmd: TLabel;
    lblDesc: TLabel;
    lblFluent: TLabel;
    lblGeek: TLabel;
    lblLicense: TLabel;
    lblMail: TLabel;
    lblName: TLabel;
    lblNet: TLabel;
    lblRepo: TLabel;
    lblUninst: TLabel;
    lblVersion: TLabel;
    sepAbout: TBevel;
    procedure MailClick(Sender: TObject);
    procedure FluentClick(Sender: TObject);
    procedure GeekClick(Sender: TObject);
    procedure RepoClick(Sender: TObject);
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  AboutFormWnd: TAboutForm;

procedure ShowAboutDialog(AOwner: TComponent);

implementation

{$R *.lfm}

uses
  Windows, ShellApi, cs.lang;

procedure ShowAboutDialog(AOwner: TComponent);
var
  F: TAboutForm;
begin
  F := TAboutForm.Create(AOwner);
  try
    F.ShowModal;
  finally
    F.Free;
  end;
end;

procedure TAboutForm.MailClick(Sender: TObject);
begin
  ShellExecuteW(Handle, 'open', 'mailto:Freetm@my.com', nil, nil, SW_SHOWNORMAL);
end;

procedure TAboutForm.FluentClick(Sender: TObject);
begin
  ShellExecuteW(Handle, 'open',
    'https://github.com/builtbybel/FluentCleaner/tree/main', nil, nil,
    SW_SHOWNORMAL);
end;

procedure TAboutForm.GeekClick(Sender: TObject);
begin
  ShellExecuteW(Handle, 'open', 'https://geekuninstaller.com', nil, nil,
    SW_SHOWNORMAL);
end;

procedure TAboutForm.RepoClick(Sender: TObject);
begin
  ShellExecuteW(Handle, 'open', 'https://github.com/Yogiru/CleanSweep',
    nil, nil, SW_SHOWNORMAL);
end;

constructor TAboutForm.Create(AOwner: TComponent);
begin
  inherited Create(AOwner); // loads aboutform.lfm
  try
    Icon.LoadFromResourceName(HInstance, 'MAINICON');
    imgIcon.Picture.Icon.Assign(Icon);
  except
  end;
  Caption := Lg('О программе', 'Аб праграме', 'Про програму', 'About');
  lblVersion.Caption := Lg('Версия 1.0.2.0', 'Версія 1.0.2.0',
                           'Версія 1.0.2.0', 'Version 1.0.2.0');
  lblDesc.Caption := Lg(
    'Портабельный деинсталлятор и клинер Windows. Один exe, без ' +
    'установки и без .NET — всё встроено.',
    'Партатыўны дэінсталятар і клінер Windows. Адзін exe, без ' +
    'ўстаноўкі і без .NET — усё ўбудавана.',
    'Портативний деінсталятор і клінер Windows. Один exe, без ' +
    'інсталяції та без .NET — усе вбудовано.',
    'Portable Windows uninstaller & cleaner. Single exe, no install, ' +
    'no .NET — everything built in.');
  lblUninst.Caption := Lg(
    'Деинсталлятор — по мотивам Geek Uninstaller: запуск штатного ' +
    'деинсталлятора, затем поиск и зачистка остатков (файлы, реестр, ' +
    'задачи, службы) после ручной проверки.',
    'Дэінсталятар — па матывах Geek Uninstaller: запуск штатнага ' +
    'дэінсталятара, затым пошук і зачыстка рэшткаў (файлы, рэестр, ' +
    'задачы, службы) пасля ручной праверкі.',
    'Деінсталятор — за мотивами Geek Uninstaller: запуск штатного ' +
    'деінсталятора, потім пошук і зачищення залишків (файли, реєстр, ' +
    'задачі, служби) після ручної перевірки.',
    'Uninstaller — inspired by Geek Uninstaller: runs the vendor ' +
    'uninstaller, then finds and removes leftovers (files, registry, ' +
    'tasks, services) after manual review.');
  lblCleaner.Caption := Lg(
    'Клинер — движок по мотивам FluentCleaner Classic: базы ' +
    'Winapp2/Winapp3/CCleaner, две фазы «анализ → очистка», ' +
    'редактор пользовательских правил.',
    'Клінер — рухавік па матывах FluentCleaner Classic: базы ' +
    'Winapp2/Winapp3/CCleaner, дзве фазы «аналіз → ачыстка», ' +
    'рэдактар карыстальніцкіх правілаў.',
    'Клінер — рушій за мотивами FluentCleaner Classic: бази ' +
    'Winapp2/Winapp3/CCleaner, дві фази «аналіз → очищення», ' +
    'редактор користувацьких правил.',
    'Cleaner — engine inspired by FluentCleaner Classic: ' +
    'Winapp2/Winapp3/CCleaner bases, two-phase analyze → clean, ' +
    'custom rule editor.');
  lblNet.Caption := Lg(
    'Сеть — сброс Winsock и стека TCP/IP, очистка кэшей DNS/NetBIOS/' +
    'ARP, обновление IP-конфигурации, перезапуск адаптеров.',
    'Сетка — скід Winsock і стэка TCP/IP, ачыстка кэшаў DNS/NetBIOS/' +
    'ARP, абнаўленне IP-канфігурацыі, перазапуск адаптараў.',
    'Мережа — скидання Winsock і стека TCP/IP, очищення кешів ' +
    'DNS/NetBIOS/ARP, оновлення IP-конфігурації, перезапуск адаптерів.',
    'Network — Winsock and TCP/IP stack reset, DNS/NetBIOS/ARP ' +
    'cache flush, IP renewal, adapter restart.');
  lblCmd.Caption := Lg(
    'Параметры: -c — клинер · -m (-mem) — память · -e (-net) — сеть · ' +
    '-auto — автоочистка в трее · -h — эта справка · F1 — справка',
    'Параметры: -c — клінер · -m (-mem) — памяць · -e (-net) — сетка · ' +
    '-auto — аўтаачыстка ў трэі · -h — гэта даведка · F1 — даведка',
    'Параметри: -c — клінер · -m (-mem) — пам''ять · -e (-net) — мережа · ' +
    '-auto — автоочищення в треї · -h — ця довідка · F1 — довідка',
    'Params: -c — cleaner · -m (-mem) — memory · -e (-net) — network · ' +
    '-auto — unattended clean in tray · -h — this help · F1 — help');
  lblAuthor.Caption := Lg('Автор: FreeTm', 'Аўтар: FreeTm',
                          'Автор: FreeTm', 'Author: FreeTm');
  lblLicense.Caption := Lg('Лицензия: FreeForAll', 'Ліцэнзія: FreeForAll',
                           'Ліцензія: FreeForAll', 'License: FreeForAll');
end;

end.
