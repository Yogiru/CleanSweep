program winapp2test;

{$mode objfpc}{$H+}

uses
  Classes, SysUtils, Registry, cs.winapp2, cs.pathexpand, cs.utils,
  cs.safety, cs.detect, cs.cleaner, cs.cookies, cs.winsqlite, cs.appx;

var
  IniPath: string;
  Parser: TWinapp2Parser;
  Entries: TCleanerEntryList;
  TestEntries: TCleanerEntryList;
  Expander: TPathExpander;
  Resolved: TStringList;
  I, FileKeys, RegKeys, ExKeys, Detects, Installed, Installed2: Integer;
  E: TCleanerEntry;
  CatName: string;
  CatOrder: Integer;
  Expanded: string;
  Failures: Integer;
  Detect: TDetectionService;
  Cleaner: TCleaningService;
  Res: TCleanResult;
  Stats: TCleanStats;
  TestDir: string;
  RTDir: string;
  Reg: TRegistry;
  F: TextFile;
  Merged23: TCleanerEntryList;
  Seen: TStringList;
  SingleW2, M22, M23: Integer;
  RawBytes: RawByteString;
  FS: TFileStream;
  Entries2: TCleanerEntryList;
  CParser: TWinapp2Parser;
  AxList: TAppxEntryList;
  AxOk: Boolean;
  IniLines: TStringList;
  RtEntry: TCleanerEntry;
  RtList: TCleanerEntryList;
  RtOk: Boolean;

procedure Check(ACond: Boolean; const AMsg: string);
begin
  if ACond then
    WriteLn('  [ok] ', AMsg)
  else
  begin
    Inc(Failures);
    WriteLn('  [FAIL] ', AMsg);
  end;
end;

{ small builders for the EntryToIni round-trip fixture }
function NewFileKey(const APath, APattern: string;
  AFlag: TFileKeyFlag): TFileKeyEntry;
begin
  Result := TFileKeyEntry.Create;
  Result.Path := APath;
  Result.Pattern := APattern;
  Result.Flag := AFlag;
end;

function NewRegKey(const AKeyPath, AValueName: string): TRegKeyEntry;
begin
  Result := TRegKeyEntry.Create;
  Result.KeyPath := AKeyPath;
  Result.ValueName := AValueName;
end;

function NewExKey(AType: TExcludeType; const APath,
  APattern: string): TExcludeKeyEntry;
begin
  Result := TExcludeKeyEntry.Create;
  Result.ExType := AType;
  Result.Path := APath;
  Result.Pattern := APattern;
end;

begin
  Failures := 0;
  InitSafetyRoots;   // cs.safety gates need the global root lists
  IniPath := ExtractFilePath(ParamStr(0)) + '..\data\Winapp2.ini';
  if ParamStr(1) <> '' then IniPath := ParamStr(1);
  WriteLn('winapp2 engine smoke test');
  WriteLn('Database: ', IniPath);
  Check(FileExists(IniPath), 'database file exists');

  { --- parser --- }
  Parser := TWinapp2Parser.Create;
  try
    Entries := Parser.ParseFile(IniPath);
    WriteLn('Entries parsed: ', Entries.Count);
    Check(Entries.Count > 3000, 'entry count looks sane (>3000)');

    FileKeys := 0; RegKeys := 0; ExKeys := 0; Detects := 0;
    for I := 0 to Entries.Count - 1 do
    begin
      E := Entries[I];
      if E.Name = '' then
      begin
        Inc(Failures);
        WriteLn('  [FAIL] entry #', I, ' has empty name');
      end;
      Inc(FileKeys, E.FileKeys.Count);
      Inc(RegKeys, E.RegKeys.Count);
      Inc(ExKeys, E.ExcludeKeys.Count);
      if E.DetectKeys.Count + E.DetectFiles.Count > 0 then Inc(Detects);
      if E.RawText = '' then
      begin
        Inc(Failures);
        WriteLn('  [FAIL] entry ', E.Name, ' has empty RawText');
      end;
    end;
    WriteLn('FileKeys: ', FileKeys, '  RegKeys: ', RegKeys,
            '  ExcludeKeys: ', ExKeys, '  with Detect*: ', Detects);
    Check(FileKeys > 5000, 'FileKey count looks sane');
    Check(RegKeys > 100, 'RegKey count looks sane');
  finally
    Parser.Free;
  end;

  { --- DetectOS parsing & gating --- }
  WriteLn('--- DetectOS ---');
  Parser := TWinapp2Parser.Create;
  try
    TestEntries := Parser.Parse(
      '[Exact8_1]'#13#10 +
      'DetectOS=6.3|6.3'#13#10 +
      'FileKey1=%Temp%\x'#13#10 +
      '[MinOnly]'#13#10 +
      'DetectOS=6.0|'#13#10 +
      'FileKey1=%Temp%\x'#13#10 +
      '[MaxOnly]'#13#10 +
      'DetectOS=|10.0'#13#10 +
      'FileKey1=%Temp%\x'#13#10 +
      '[LegacyNoPipe]'#13#10 +
      'DetectOS=6.0'#13#10 +
      'FileKey1=%Temp%\x'#13#10 +
      '[MultiPart]'#13#10 +
      'DetectOS=6.2.9200'#13#10 +
      'FileKey1=%Temp%\x'#13#10 +
      '[OnlyOs]'#13#10 +
      'DetectOS=10.0'#13#10 +
      'FileKey1=%Temp%\x');
    Check(TestEntries.Count = 6, 'DetectOS parse keeps all entries');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'Exact8_1' then E := TestEntries[I];
    Check(E <> nil, '  Exact8_1 present');
    if E <> nil then
      Check(E.DetectOSUsed and (E.DetectOSMin = 603) and
            (E.DetectOSMax = 603), '  6.3|6.3 -> strict 603');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'MinOnly' then E := TestEntries[I];
    Check(E <> nil, '  MinOnly present');
    if E <> nil then
      Check(E.DetectOSUsed and (E.DetectOSMin = 600) and
            (E.DetectOSMax = -1), '  6.0| -> min 600 only');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'MaxOnly' then E := TestEntries[I];
    Check(E <> nil, '  MaxOnly present');
    if E <> nil then
      Check(E.DetectOSUsed and (E.DetectOSMin = -1) and
            (E.DetectOSMax = 1000), '  |10.0 -> max 1000 only');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'LegacyNoPipe' then E := TestEntries[I];
    Check(E <> nil, '  LegacyNoPipe present');
    if E <> nil then
      Check(E.DetectOSUsed and (E.DetectOSMin = 600) and
            (E.DetectOSMax = -1), '  6.0 (no pipe) -> lenient min 600');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'MultiPart' then E := TestEntries[I];
    Check(E <> nil, '  MultiPart present');
    if E <> nil then
      Check(E.DetectOSMin = 602, '  6.2.9200 -> 602 (extra part cut)');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'OnlyOs' then E := TestEntries[I];
    Check(E <> nil, '  OnlyOs present');
    if (E <> nil) and (E.DetectOSMin = 1000) then
      WriteLn('  OnlyOs parsed as min 1000');
  finally
    TestEntries.Free;
    Parser.Free;
  end;

  { --- merge regression: forward Extract while iterating shrank the
        list mid-loop, silently dropping half the database (2038/4075)
        or crashing with EListError; the fix iterates backwards --- }
  WriteLn('--- Merge regression ---');
  Parser := TWinapp2Parser.Create;
  try
    Seen := TStringList.Create;
    try
      Seen.CaseSensitive := False;
      Seen.Sorted := True;
      Seen.Duplicates := dupIgnore;

      TestEntries := Parser.ParseFile(IniPath);
      SingleW2 := TestEntries.Count;
      Merged23 := TCleanerEntryList.Create(True);
      try
        for I := TestEntries.Count - 1 downto 0 do
          if Seen.IndexOf(TestEntries[I].Name) < 0 then
          begin
            Seen.Add(TestEntries[I].Name);
            Merged23.Add(TestEntries.Extract(TestEntries[I]));
          end
          else
            TestEntries.Delete(I);
      finally
        TestEntries.Free;
      end;
      M22 := Merged23.Count;
      Check(M22 = SingleW2, Format('single source keeps every entry '
        + '(%d/%d, not half)', [M22, SingleW2]));

      TestEntries := Parser.ParseFile(ExtractFilePath(ParamStr(0))
        + '..\data\Winapp3.ini');
      try
        for I := TestEntries.Count - 1 downto 0 do
          if Seen.IndexOf(TestEntries[I].Name) < 0 then
          begin
            Seen.Add(TestEntries[I].Name);
            Merged23.Add(TestEntries.Extract(TestEntries[I]));
          end
          else
            TestEntries.Delete(I);
      finally
        TestEntries.Free;
      end;
      M23 := Merged23.Count;
      WriteLn(Format('merge W2+W3: %d, W2 alone: %d', [M23, M22]));
      Check(M23 > M22, 'second source adds unique entries (no loss)');
      Merged23.Free;
    finally
      Seen.Free;
    end;
  finally
    Parser.Free;
  end;

  { --- custom DB (WinappCS.ini) parse & integrity --- }
  WriteLn('--- Custom DB (WinappCS.ini) ---');
  Parser := TWinapp2Parser.Create;
  try
    TestEntries := Parser.ParseFile(ExtractFilePath(ParamStr(0))
      + 'WinappCS.ini');
    WriteLn('Custom DB parsed: ', TestEntries.Count);
    Check(TestEntries.Count = 1275, 'custom DB parses to expected entries');
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = '' then
      begin
        Inc(Failures);
        WriteLn('  [FAIL] custom entry #', I, ' has empty name');
      end;
  finally
    TestEntries.Free;
    Parser.Free;
  end;

  // gate evaluation against the live OS version
  Detect := TDetectionService.Create;
  try
    E := TCleanerEntry.Create;
    try
      E.DetectOSUsed := True;
      E.DetectOSMin := 0;
      E.DetectOSMax := MaxInt;
      Check(Detect.IsInstalled(E), 'DetectOS-only entry with open bounds');

      E.DetectOSMin := 90000;
      E.DetectOSMax := -1;
      Check(not Detect.IsInstalled(E), 'impossible minimum hides entry');

      E.DetectOSMin := -1;
      E.DetectOSMax := 1;
      Check(not Detect.IsInstalled(E), 'impossible maximum hides entry');

      // DetectOS failure supersedes a live Detect hit
      E.DetectOSMin := 90000;
      E.DetectOSMax := -1;
      E.DetectKeys.Add('HKCU\Software');
      Check(not Detect.IsInstalled(E),
            'failed DetectOS beats existing registry Detect');
    finally
      E.Free;
    end;
  finally
    Detect.Free;
  end;

  { spot-check a known entry }
  E := nil;
  for I := 0 to Entries.Count - 1 do
    if Entries[I].Name = 'Google Chrome Caches' then
    begin
      E := Entries[I];
      Break;
    end;
  Check(E <> nil, '"Google Chrome Caches" entry exists');
  if E <> nil then
  begin
    Check(E.FileKeys.Count > 0, '  has FileKeys');
    Check(E.LangSecRef = 3029, '  LangSecRef = 3029');
    if E.FileKeys.Count > 0 then
      Check(Pos('%LocalAppData%', E.FileKeys[0].Path) > 0,
            '  FileKey path uses %LocalAppData%');
    ResolveCategory(E, CatName, CatOrder);
    Check(CatName = 'Google Chrome', '  category = Google Chrome');
  end;

  { --- path expander --- }
  Expander := TPathExpander.Create;
  try
    WriteLn('--- PathExpander ---');

    Expanded := Expander.ExpandVariables('%WinDir%');
    WriteLn('%WinDir% -> ', Expanded);
    Check(CompareText(Expanded, 'C:\Windows') = 0, '%WinDir% resolves');

    Expanded := Expander.ExpandVariables('%SystemDrive%');
    WriteLn('%SystemDrive% -> ', Expanded);
    Check((Length(Expanded) = 3) and (Expanded[2] = ':') and
          (Expanded[3] = '\'), '%SystemDrive% gets trailing backslash');

    Expanded := Expander.ExpandVariables('%Temp%\foo.log');
    WriteLn('%Temp%\foo.log -> ', Expanded);
    Check((Pos('%', Expanded) = 0) and (Length(Expanded) > 4),
          '%Temp% resolves');

    Expanded := Expander.ExpandVariables('%NoSuchToken%\x');
    WriteLn('%NoSuchToken%\x -> ', Expanded);
    Check(Pos('%NoSuchToken%', Expanded) > 0,
          'unknown token passes through');

    Resolved := Expander.ResolvePaths('%ProgramFiles%\*');
    try
      WriteLn('%ProgramFiles%\* -> ', Resolved.Count, ' entries');
      Check(Resolved.Count > 3, 'wildcard under Program Files resolves');
    finally
      Resolved.Free;
    end;

    Resolved := Expander.ResolvePaths('%WinDir%\Temp');
    try
      WriteLn('%WinDir%\Temp -> ', Resolved.Count, ' entries');
      Check(Resolved.Count >= 1, 'literal path resolves');
    finally
      Resolved.Free;
    end;

    // both Program Files roots must be reachable through %ProgramFiles%
    Resolved := Expander.ResolvePaths('%ProgramFiles%\Common Files');
    try
      WriteLn('%ProgramFiles%\Common Files -> ', Resolved.Count);
      Check(Resolved.Count >= 1, 'x86 fallback produces results');
    finally
      Resolved.Free;
    end;

    Expanded := Expander.ExpandVariables('%LocalLowAppData%');
    WriteLn('%LocalLowAppData% -> ', Expanded);
    Check((Expanded <> '') and (Pos('..', Expanded) = 0) and
          DirectoryExists(Expanded), '%LocalLowAppData% expands to a real dir');
  finally
    Expander.Free;
  end;

  { --- detection --- }
  WriteLn('--- Detection ---');
  Detect := TDetectionService.Create;
  try
    Installed := 0;
    for I := 0 to Entries.Count - 1 do
      if Detect.IsInstalled(Entries[I]) then Inc(Installed);
    WriteLn('Installed entries detected: ', Installed, '/', Entries.Count);
    Check(Installed > 20, 'detection finds installed apps (>20)');
    Check(Installed < Entries.Count, 'detection filters missing apps');

    // existence cache: a repeat pass through the same service must
    // return exactly the same verdicts (and is ~all-cache hits)
    Installed2 := 0;
    for I := 0 to Entries.Count - 1 do
      if Detect.IsInstalled(Entries[I]) then Inc(Installed2);
    Check(Installed = Installed2,
          Format('cached repeat scan agrees (%d=%d)',
                 [Installed, Installed2]));
  finally
    Detect.Free;
  end;

  { --- analyze on a controlled temp tree --- }
  WriteLn('--- Analyze (controlled temp tree) ---');
  TestDir := IncludeTrailingPathDelimiter(GetTempDir(False)) + 'cs_w2t';
  ForceDirectories(TestDir + '\sub');
  AssignFile(F, TestDir + '\a.tmp'); Rewrite(F); Write(F, StringOfChar('x', 100)); CloseFile(F);
  AssignFile(F, TestDir + '\b.log'); Rewrite(F); Write(F, StringOfChar('y', 50)); CloseFile(F);
  AssignFile(F, TestDir + '\sub\c.tmp'); Rewrite(F); Write(F, StringOfChar('z', 25)); CloseFile(F);

  Cleaner := TCleaningService.Create;
  try
    // flat *.tmp → a.tmp only (b.log skipped, sub\c.tmp not recursed)
    E := TCleanerEntry.Create;
    try
      E.Name := 'TestEntry';
      E.FileKeys.Add(TFileKeyEntry.Parse(TestDir + '|*.tmp'));
      Res := Cleaner.Analyze(E);
      try
        WriteLn('flat *.tmp -> ', Res.FilesToDelete.Count, ' files, ',
                Res.TotalBytes, ' bytes');
        Check(Res.FilesToDelete.Count = 1, 'flat scan finds 1 file');
        Check(Res.TotalBytes = 100, 'size sums correctly');
      finally
        Res.Free;
      end;

      // RECURSE *.tmp → a.tmp + sub\c.tmp
      E.FileKeys.Clear;
      E.FileKeys.Add(TFileKeyEntry.Parse(TestDir + '|*.tmp|RECURSE'));
      Res := Cleaner.Analyze(E);
      try
        WriteLn('recurse *.tmp -> ', Res.FilesToDelete.Count, ' files');
        Check(Res.FilesToDelete.Count = 2, 'recurse finds 2 files');
        Check(Res.TotalBytes = 125, 'recurse size = 125');
      finally
        Res.Free;
      end;

      // RECURSE + ExcludeKey PATH → sub\ skipped
      E.ExcludeKeys.Add(TExcludeKeyEntry.Parse('PATH|' + TestDir + '\sub'));
      Res := Cleaner.Analyze(E);
      try
        WriteLn('recurse + PATH exclusion -> ', Res.FilesToDelete.Count);
        Check(Res.FilesToDelete.Count = 1, 'PATH exclusion skips subtree');
      finally
        Res.Free;
      end;
      E.ExcludeKeys.Clear;

      // FILE exclusion by wildcard → *.tmp under sub gone, a.tmp stays
      E.ExcludeKeys.Add(TExcludeKeyEntry.Parse('FILE|' + TestDir + '\sub|*.tmp'));
      Res := Cleaner.Analyze(E);
      try
        Check(Res.FilesToDelete.Count = 1, 'FILE exclusion filters by mask');
      finally
        Res.Free;
      end;
      E.ExcludeKeys.Clear;

      // runnable-file guard: broad '*.*' must spare executables/scripts,
      // an explicit '*.exe' pattern still takes them. Outside temp
      // roots only — inside %TEMP% the guard yields by policy.
      RTDir := ExtractFilePath(ParamStr(0)) + '_rt';
      ForceDirectories(RTDir);
      AssignFile(F, RTDir + '\keep.exe'); Rewrite(F); Write(F, 'MZ'); CloseFile(F);
      AssignFile(F, RTDir + '\note.txt'); Rewrite(F); Write(F, 'n'); CloseFile(F);
      E.FileKeys.Clear;
      E.FileKeys.Add(TFileKeyEntry.Parse(RTDir + '|*.*'));
      Res := Cleaner.Analyze(E);
      try
        Check(Res.FilesToDelete.IndexOf(RTDir + '\keep.exe') < 0,
              '*.* never stages a runnable file');
        Check(Res.FilesToDelete.IndexOf(RTDir + '\note.txt') >= 0,
              '*.* still stages plain files');
      finally
        Res.Free;
      end;
      E.FileKeys.Clear;
      E.FileKeys.Add(TFileKeyEntry.Parse(RTDir + '|*.exe'));
      Res := Cleaner.Analyze(E);
      try
        Check(Res.FilesToDelete.IndexOf(RTDir + '\keep.exe') >= 0,
              'explicit *.exe pattern is honored');
      finally
        Res.Free;
      end;
      // UNSAFE flag: same broad mask, but the rule author opted in —
      // the runnable gate lifts for this key only
      E.FileKeys.Clear;
      E.FileKeys.Add(TFileKeyEntry.Parse(RTDir + '|*.*|UNSAFE'));
      Check(E.FileKeys[0].Unsafe, 'UNSAFE parses from FileKey tail');
      Res := Cleaner.Analyze(E);
      try
        Check(Res.FilesToDelete.IndexOf(RTDir + '\keep.exe') >= 0,
              'UNSAFE lifts the runnable gate for this key');
      finally
        Res.Free;
      end;
      // flags are order-free: UNSAFE before the pattern parses too
      E.FileKeys.Clear;
      E.FileKeys.Add(TFileKeyEntry.Parse(RTDir + '|UNSAFE|*.exe'));
      Check((E.FileKeys[0].Pattern = '*.exe') and E.FileKeys[0].Unsafe,
            'flag-before-pattern order parses');
      DeleteFile(RTDir + '\keep.exe');
      DeleteFile(RTDir + '\note.txt');
      RemoveDir(RTDir);

      // registry probe: HKCU\Software always exists
      E.RegKeys.Add(TRegKeyEntry.Parse('HKCU\Software'));
      Res := Cleaner.Analyze(E);
      try
        WriteLn('HKCU\Software regkey -> ', Res.RegistryToDelete.Count);
        Check(Res.RegistryToDelete.Count = 1, 'existing regkey queued');
      finally
        Res.Free;
      end;

      // REG exclusion removes it again
      Cleaner.GlobalExclusionsEnabled := True;
      Cleaner.GlobalExclusions.Add('REG|HKCU\Software');
      Res := Cleaner.Analyze(E);
      try
        Check(Res.RegistryToDelete.Count = 0, 'REG exclusion protects key');
      finally
        Res.Free;
      end;
    finally
      E.Free;
    end;
  finally
    Cleaner.Free;
  end;

  { --- clean on the same controlled temp tree --- }
  WriteLn('--- Clean (controlled temp tree) ---');
  Cleaner := TCleaningService.Create;
  try
    E := TCleanerEntry.Create;
    try
      E.Name := 'TestClean';
      E.FileKeys.Add(TFileKeyEntry.Parse(TestDir + '|*.tmp|RECURSE'));
      Res := Cleaner.Analyze(E);
      try
        Stats := Cleaner.Clean(Res);
        WriteLn('clean -> ', Stats.Count, ' items, ', Stats.Bytes, ' bytes');
        Check(Stats.Count = 2, 'clean deletes 2 files');
        Check(Stats.Bytes = 125, 'clean reports 125 bytes');
        Check(not FileExists(TestDir + '\a.tmp'), 'a.tmp deleted');
        Check(not FileExists(TestDir + '\sub\c.tmp'), 'sub\c.tmp deleted');
        Check(FileExists(TestDir + '\b.log'), 'b.log untouched');
      finally
        Res.Free;
      end;

      // REMOVESELF: sub\ ends up empty → pruned; root kept (b.log remains)
      E.FileKeys.Clear;
      E.FileKeys.Add(TFileKeyEntry.Parse(TestDir + '|*.tmp|REMOVESELF'));
      AssignFile(F, TestDir + '\sub\d.tmp'); Rewrite(F);
      Write(F, 'q'); CloseFile(F);
      Res := Cleaner.Analyze(E);
      try
        Stats := Cleaner.Clean(Res);
        Check(Stats.Count = 1, 'REMOVESELF deletes its file');
        Check(not DirectoryExists(TestDir + '\sub'),
              'empty subdir pruned');
        Check(DirectoryExists(TestDir),
              'non-empty root kept');
      finally
        Res.Free;
      end;

      // now the root is empty-able too: delete b.log, clean again
      DeleteFile(TestDir + '\b.log');
      Res := Cleaner.Analyze(E);
      try
        Cleaner.Clean(Res);
        Check(not DirectoryExists(TestDir), 'empty root pruned');
      finally
        Res.Free;
      end;

      // registry: create a throwaway key, clean deletes it back
      Reg := TRegistry.Create;
      try
        Reg.RootKey := HKEY_CURRENT_USER;
        Check(Reg.OpenKey('Software\CSWinapp2Test\Sub', True),
              'test regkey created');
      finally
        Reg.Free;
      end;
      E.RegKeys.Add(TRegKeyEntry.Parse('HKCU\Software\CSWinapp2Test'));
      Res := Cleaner.Analyze(E);
      try
        Check(Res.RegistryToDelete.Count = 1, 'test regkey analyzed');
        Stats := Cleaner.Clean(Res);
        Check(Stats.Count = 1, 'regkey deleted');
        Reg := TRegistry.Create;
        try
          Reg.RootKey := HKEY_CURRENT_USER;
          Check(not Reg.KeyExists('Software\CSWinapp2Test'),
                'regkey really gone');
        finally
          Reg.Free;
        end;
      finally
        Res.Free;
      end;
    finally
      E.Free;
    end;
  finally
    Cleaner.Free;
  end;

  // cleanup test files (in case a check above failed mid-way)
  DeleteFile(TestDir + '\a.tmp');
  DeleteFile(TestDir + '\b.log');
  DeleteFile(TestDir + '\sub\c.tmp');
  DeleteFile(TestDir + '\sub\d.tmp');
  RemoveDir(TestDir + '\sub');
  RemoveDir(TestDir);

  // security classifier: credentials to the separate tab, no false
  // positives on password-recovery tools
  WriteLn('--- Security classifier ---');
  Check(IsSecurityEntry('Chrome Saved Usernames & Passwords *'),
        'passwords -> security tab');
  Check(IsSecurityEntry('Firefox Web Browsing Session *'),
        'session -> security tab');
  Check(IsSecurityEntry('Edge Web Browsing Cookies *'),
        'cookies -> security tab');
  Check(IsSecurityEntry('Windows Credential Manager Saved Credentials *'),
        'credential manager -> security tab');
  Check(IsSecurityEntry('Chrome Autofill Data & Search Engine Preferences *'),
        'autofill -> security tab');
  Check(not IsSecurityEntry('Elcomsoft Password Recovery *'),
        'recovery tool stays out');
  Check(not IsSecurityEntry('Intel Wireless Wi-Fi Drivers *'),
        'wifi drivers stay out');
  Check(not IsSecurityEntry('Sage Simply Accounting *'),
        'accounting stays out');
  Check(not IsSecurityEntry('Windows Disk Cleanup *'),
        'plain entry stays out');

  { --- security classifier: FileKey/RegKey paths --- }
  WriteLn('--- Security classifier (paths + preset axes) ---');
  Parser := TWinapp2Parser.Create;
  try
    TestEntries := Parser.Parse(
      '[WebStorageN]'#13#10 +
      'DetectFile=%LocalAppData%\Test'#13#10 +
      'FileKey1=%LocalAppData%\Google\Chrome\User Data\Default|Session Storage|RECURSE'#13#10 +
      '[LoginDataN]'#13#10 +
      'DetectFile=%LocalAppData%\Test'#13#10 +
      'FileKey1=%LocalAppData%\Google\Chrome\User Data\Default|Login Data'#13#10 +
      '[RegCredsN]'#13#10 +
      'DetectFile=%LocalAppData%\Test'#13#10 +
      'RegKey1=HKCU\Software\Test\Credential Manager'#13#10 +
      '[CleanCacheN]'#13#10 +
      'DetectFile=%LocalAppData%\Test'#13#10 +
      'FileKey1=%LocalAppData%\Google\Chrome\User Data\Default\Cache|*.*|RECURSE'#13#10 +
      '[RecoveryTool]'#13#10 +
      'DetectFile=%LocalAppData%\Test'#13#10 +
      'FileKey1=%AppData%\Elcomsoft\Password Recovery|cache.dat'#13#10 +
      '[LangRule]'#13#10 +
      'Section=Language Files'#13#10 +
      'LangSecRef=3021'#13#10 +
      'DetectFile=%LocalAppData%\Test'#13#10 +
      'FileKey1=%WinDir%\Lang|*.*'#13#10 +
      '[DangerWin]'#13#10 +
      'Section=Dangerous Windows'#13#10 +
      'LangSecRef=3025'#13#10 +
      'DetectFile=%LocalAppData%\Test'#13#10 +
      'FileKey1=%WinDir%\Temp|*.*'#13#10 +
      '[SafeRule]'#13#10 +
      'LangSecRef=3025'#13#10 +
      'DetectFile=%LocalAppData%\Test'#13#10 +
      'FileKey1=%Temp%\x|*.*'#13#10 +
      '[GameTrack]'#13#10 +
      'Section=Games'#13#10 +
      'DetectFile=%LocalAppData%\Test'#13#10 +
      'FileKey1=%AppData%\Game|save.dat');
    Check(TestEntries.Count = 9, 'preset test pool parses fully');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'WebStorageN' then E := TestEntries[I];
    Check((E <> nil) and IsSecurityEntryFor(E),
          'session storage path -> security tab');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'LoginDataN' then E := TestEntries[I];
    Check((E <> nil) and IsSecurityEntryFor(E),
          'login data path -> security tab');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'RegCredsN' then E := TestEntries[I];
    Check((E <> nil) and IsSecurityEntryFor(E),
          'credential registry path -> security tab');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'CleanCacheN' then E := TestEntries[I];
    Check((E <> nil) and (not IsSecurityEntryFor(E)),
          'plain cache path stays out');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'RecoveryTool' then E := TestEntries[I];
    Check((E <> nil) and (not IsSecurityEntryFor(E)),
          'recovery tool stays out despite password path');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'LangRule' then E := TestEntries[I];
    Check((E <> nil) and (PresetPurposeOf(E) = 'Languages') and
          (PresetSafetyOf(E) = slRisky),
          'language rule -> Languages / risky');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'DangerWin' then E := TestEntries[I];
    Check((E <> nil) and (PresetPurposeOf(E) = 'Windows') and
          (PresetSafetyOf(E) = slRisky),
          'Dangerous Windows -> Windows / risky');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'SafeRule' then E := TestEntries[I];
    Check((E <> nil) and (PresetSafetyOf(E) = slSafe),
          'plain rule -> safe');

    E := nil;
    for I := 0 to TestEntries.Count - 1 do
      if TestEntries[I].Name = 'GameTrack' then E := TestEntries[I];
    Check((E <> nil) and (PresetPurposeOf(E) = 'Games'),
          'game section -> Games');
  finally
    TestEntries.Free;
    Parser.Free;
  end;

  { --- UTF-8 database loading (LoadTextFile / ParseFile) --- }
  WriteLn('--- UTF-8 loading ---');
  TestDir := IncludeTrailingPathDelimiter(GetTempDir(False)) + 'cs_utf8t';
  ForceDirectories(TestDir);
  // this .lpr is UTF-8: string literals already hold UTF-8 bytes,
  // assigning to RawByteString copies them verbatim — no UTF8Encode
  RawBytes := '[Браузер Кэш *]'#10 +
    'DetectFile=%Temp%\x'#10 +
    'Warning=Удалит кэш браузера.'#10 +
    'FileKey1=%Temp%\x|*.*'#10;
  FS := TFileStream.Create(TestDir + '\u8.ini', fmCreate);
  try
    FS.WriteBuffer(RawBytes[1], Length(RawBytes));
  finally
    FS.Free;
  end;
  Check(Pos('Браузер Кэш', LoadTextFile(TestDir + '\u8.ini')) > 0,
        'UTF-8 no-BOM text decodes');

  Entries2 := Parser.ParseFile(TestDir + '\u8.ini');
  try
    Check((Entries2.Count = 1) and
          (Entries2[0].Name = 'Браузер Кэш'),   // parser trims ' *'
          'UTF-8 no-BOM entry name decodes (not mojibake)');
    Check((Entries2.Count = 1) and
          (Pos('кэш', Entries2[0].Warning) > 0),
          'UTF-8 warning text decodes');
  finally
    Entries2.Free;
  end;

  // UTF-8 with BOM
  FS := TFileStream.Create(TestDir + '\u8b.ini', fmCreate);
  try
    RawBytes := #$EF#$BB#$BF +
      '[Тест *]'#10'DetectFile=%Temp%\x'#10'FileKey1=%Temp%\x|*.*';
    FS.WriteBuffer(RawBytes[1], Length(RawBytes));
  finally
    FS.Free;
  end;
  Check(Pos('Тест', LoadTextFile(TestDir + '\u8b.ini')) > 0,
        'UTF-8 BOM entry name decodes');

  // ANSI fallback — meaningful only on a CP1251 system
  if DefaultSystemCodePage = 1251 then
  begin
    FS := TFileStream.Create(TestDir + '\ansi.ini', fmCreate);
    try
      // literal is UTF-8 bytes; Utf8ToAnsi converts to CP_ACP (1251)
      RawBytes := Utf8ToAnsi('[Русский *]'#10'DetectFile=%Temp%\x'#10 +
        'FileKey1=%Temp%\x|*.*');
      FS.WriteBuffer(RawBytes[1], Length(RawBytes));
    finally
      FS.Free;
    end;
    Check(Pos('Русский', LoadTextFile(TestDir + '\ansi.ini')) > 0,
          'ANSI (CP1251) entry name decodes');
  end;
  DeleteFile(TestDir + '\u8.ini');
  DeleteFile(TestDir + '\u8b.ini');
  DeleteFile(TestDir + '\ansi.ini');
  RemoveDir(TestDir);

  { --- permissive parse: Custom-folder rules may omit detection --- }
  WriteLn('--- Permissive parser (Custom folder) ---');
  CParser := TWinapp2Parser.Create(True);
  try
    TestEntries := CParser.Parse(
      '[NoDetect *]'#13#10 +
      'FileKey1=%Temp%\x|*.*'#13#10 +
      '[WithDetect *]'#13#10 +
      'DetectFile=%Temp%\x'#13#10 +
      'FileKey1=%Temp%\x|*.*');
    Check(TestEntries.Count = 2,
          'permissive parse keeps rules without detection');
  finally
    TestEntries.Free;
    CParser.Free;
  end;
  Parser := TWinapp2Parser.Create;
  try
    TestEntries := Parser.Parse(
      '[NoDetect *]'#13#10 +
      'FileKey1=%Temp%\x|*.*'#13#10 +
      '[WithDetect *]'#13#10 +
      'DetectFile=%Temp%\x'#13#10 +
      'FileKey1=%Temp%\x|*.*');
    Check(TestEntries.Count = 1,
          'strict parse still drops detection-less rules');
  finally
    TestEntries.Free;
    Parser.Free;
  end;

  { --- cookie domain normalization (upstream NormalizeDomain) --- }
  WriteLn('--- Cookie domain normalization ---');
  Check(NormalizeCookieDomain('HTTPS://*.Example.COM/path') = 'example.com',
        'scheme+wildcard+port strip');
  Check(NormalizeCookieDomain('.mail.ru.') = 'mail.ru',
        'leading/trailing dots stripped');
  Check(NormalizeCookieDomain('user@host:8080/x') = 'host',
        'userinfo and port stripped');
  Check(NormalizeCookieDomain('not a domain!!') = '',
        'invalid chars rejected');
  Check(NormalizeCookieDomain('') = '', 'empty stays empty');
  WriteLn('winsqlite3 available: ', WinSqliteAvailable);

  { --- Winappx parser --- }
  WriteLn('--- Winappx ---');
  AxList := ParseAppxDatabase(LoadTextFile(
    ExtractFilePath(ParamStr(0)) + '..\data\Winappx.ini'));
  try
    WriteLn('Winappx entries: ', AxList.Count);
    Check(AxList.Count = 46, 'winappx parses all 46 entries');
    AxOk := True;
    for I := 0 to AxList.Count - 1 do
      if (AxList[I].Name = '') or (AxList[I].PackageName = '') then
        AxOk := False;
    Check(AxOk, 'every winappx entry has name + PackageName');
  finally
    AxList.Free;
  end;

  { --- EntryToIni round-trip: serialize → re-parse → fields equal --- }
  WriteLn('--- EntryToIni round-trip ---');
  RtEntry := TCleanerEntry.Create;
  RtEntry.Name := 'RT Sample';
  RtEntry.Section := 'Custom';
  RtEntry.Default := False;
  RtEntry.Warning := 'watch out';
  RtEntry.SpecialDetect := 'DET_CHROME';
  RtEntry.DetectFiles.Add('%ProgramFiles%\Sample');
  RtEntry.DetectKeys.Add('HKCU\Software\Sample');
  RtEntry.FileKeys.Add(NewFileKey('%LocalAppData%\Sample\Cache',
    '*.tmp;*.log', fkRecurse));
  RtEntry.FileKeys.Add(NewFileKey('%Temp%\Sample', '', fkRemoveSelf));
  RtEntry.RegKeys.Add(NewRegKey('HKCU\Software\Sample\Cache', ''));
  RtEntry.RegKeys.Add(NewRegKey('HKCU\Software\Sample', 'LastRun'));
  RtEntry.ExcludeKeys.Add(NewExKey(etPath,
    '%LocalAppData%\Sample\Cache\keep', ''));
  ParseDetectOS('6.1|10', RtEntry);
  IniLines := EntryToIni(RtEntry);
  try
    CParser := TWinapp2Parser.Create(True);
    try
      RtList := CParser.Parse(IniLines.Text);
    finally
      CParser.Free;
    end;
  finally
    IniLines.Free;
  end;
  RtOk := (RtList <> nil) and (RtList.Count = 1);
  Check(RtOk, 'round-trip parses back to 1 entry');
  if RtOk then
  begin
    E := RtList[0];
    Check(E.Name = 'RT Sample', 'name survives');
    Check(E.Section = 'Custom', 'section survives');
    Check(E.Default = False, 'Default=False survives');
    Check(E.Warning = 'watch out', 'warning survives');
    Check(E.SpecialDetect = 'DET_CHROME', 'SpecialDetect survives');
    Check((E.DetectFiles.Count = 1) and
          (E.DetectFiles[0] = '%ProgramFiles%\Sample'),
          'DetectFile survives');
    Check((E.DetectKeys.Count = 1) and
          (E.DetectKeys[0] = 'HKCU\Software\Sample'),
          'Detect survives');
    Check((E.FileKeys.Count = 2) and
          (E.FileKeys[0].Path = '%LocalAppData%\Sample\Cache') and
          (E.FileKeys[0].Pattern = '*.tmp;*.log') and
          (E.FileKeys[0].Flag = fkRecurse) and
          (E.FileKeys[1].Flag = fkRemoveSelf),
          'FileKeys with flags survive');
    Check((E.RegKeys.Count = 2) and
          (E.RegKeys[1].ValueName = 'LastRun'),
          'RegKeys incl. value name survive');
    Check((E.ExcludeKeys.Count = 1) and
          (E.ExcludeKeys[0].ExType = etPath),
          'ExcludeKey type survives');
    Check(E.DetectOSUsed and (E.DetectOSMin = 601) and
          (E.DetectOSMax = 1000), 'DetectOS range survives');
  end;
  RtList.Free;
  RtEntry.Free;

  Entries.Free;

  WriteLn('---');
  if Failures = 0 then
    WriteLn('ALL CHECKS PASSED')
  else
    WriteLn(Failures, ' CHECK(S) FAILED');
  if Failures > 0 then Halt(1);
end.
