unit cs.rulesload;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, cs.winapp2;

{ Loads every <ARulesDir>\*.ini into one deduplicated entry pool:
  permissive parse, entries whose Detect/DetectFile failed on this PC
  are dropped, first-wins on entry names across files.
  ASkipWarnings additionally drops entries carrying a Warning= line —
  for unattended (-auto) runs where nobody reads the caution.
  Caller owns the returned list. }
function LoadRuleEntries(const ARulesDir: string;
  ASkipWarnings: Boolean = False): TCleanerEntryList;

{ <dir>\_vars.ini — user-defined %Var% aliases. Reads the [Vars]
  section and registers each name via RegisterPathVar; must run before
  any FileKey in the same folder is expanded. Missing file → no-op. }
procedure LoadExtraVars(const ARulesDir: string);

{ Database file helpers shared by the cleaner window and the -auto
  runner. LoadDbText prefers <exe>\data\<AName> and falls back to the
  embedded RCDATA resource; RestoreDbFromResource materializes the
  embedded copy to disk when it is missing. }
function DataDir: string;
function SettingsPath: string;
function LoadDbFile(const APath: string): string;
function LoadDbText(const AName, AResName: string): string;
function RestoreDbFromResource(const AName, AResName: string): Boolean;

{ Always-merged security entries (winapp2 covers browser credentials
  but not these Windows stores; the DPAPI master-key dir is
  deliberately excluded — deleting it would brick all encrypted data).
  Both carry Warning=, so unattended runs never touch them. }
const
  SEC_EXTRA_INI =
    '[Windows Saved Credentials *]' + sLineBreak +
    'Section=Security' + sLineBreak +
    'DetectFile=%AppData%\Microsoft\Credentials' + sLineBreak +
    'Default=False' + sLineBreak +
    'Warning=Wipes every saved Windows credential (network shares, RDP, mapped drives).' + sLineBreak +
    'FileKey1=%AppData%\Microsoft\Credentials|*.*|REMOVESELF' + sLineBreak +
    'FileKey2=%LocalAppData%\Microsoft\Credentials|*.*|REMOVESELF' + sLineBreak +
    'FileKey3=%AppData%\Microsoft\Vault|*.*|REMOVESELF' + sLineBreak +
    sLineBreak +
    '[Wi-Fi Profiles *]' + sLineBreak +
    'Section=Security' + sLineBreak +
    'DetectFile=%ProgramData%\Microsoft\Wlansvc\Profiles' + sLineBreak +
    'Default=False' + sLineBreak +
    'Warning=Wipes all saved Wi-Fi networks and their passwords.' + sLineBreak +
    'FileKey1=%ProgramData%\Microsoft\Wlansvc\Profiles|*.xml|RECURSE';

  { Always-on system entries, independent of which bases are enabled:
    winapp2 has no %Temp% rules at all (CCleaner cleans it natively,
    not data-driven), and the Recycle Bin entry only ships inside
    Default.ini — which Winapp3 excludes mutually. Same names merge
    harmlessly via first-wins dedup when Default.ini is loaded. }
  SYS_EXTRA_INI =
    '[Recycle Bin *]' + sLineBreak +
    'LangSecRef=3025' + sLineBreak +
    'Section=Windows' + sLineBreak +
    'Special=RecycleBin' + sLineBreak +
    sLineBreak +
    '[User Temp Files *]' + sLineBreak +
    'Section=Windows' + sLineBreak +
    'DetectFile=%Temp%' + sLineBreak +
    'Default=True' + sLineBreak +
    'FileKey1=%Temp%|*|RECURSE' + sLineBreak +
    sLineBreak +
    '[Windows Temp Files *]' + sLineBreak +
    'Section=Windows' + sLineBreak +
    'DetectFile=%WinDir%\Temp' + sLineBreak +
    'Default=True' + sLineBreak +
    'FileKey1=%WinDir%\Temp|*|RECURSE';

{ Builds the full cleaner pool exactly like the GUI load pipeline:
  enabled databases per CleanSweep.ini [Cleaner] merged first-wins,
  SEC_/SYS_EXTRA on top, then <exe>\Custom\*.ini overriding same-name
  entries. Sets E.Detected for every entry (a custom rule without
  detection counts as installed). ASkipWarnings drops Warning= entries
  — mandatory for unattended runs. Caller owns the returned list. }
function LoadCleanerPool(ASkipWarnings: Boolean = False): TCleanerEntryList;

implementation

uses
  Windows, IniFiles, cs.detect, cs.pathexpand, cs.utils;

procedure LoadExtraVars(const ARulesDir: string);
var
  Ini: TIniFile;
  Vals: TStringList;
  I: Integer;
  F: string;
begin
  F := ARulesDir + '_vars.ini';
  if not FileExists(F) then Exit;
  Ini := TIniFile.Create(F);
  Vals := TStringList.Create;
  try
    Ini.ReadSectionValues('Vars', Vals);
    for I := 0 to Vals.Count - 1 do
      RegisterPathVar(Vals.Names[I], Vals.ValueFromIndex[I]);
  finally
    Vals.Free;
    Ini.Free;
  end;
end;

function LoadRuleEntries(const ARulesDir: string;
  ASkipWarnings: Boolean): TCleanerEntryList;
var
  Parser: TWinapp2Parser;
  Det: TDetectionService;
  Part: TCleanerEntryList;
  Seen: TStringList;
  SR: TSearchRec;
  R, J: Integer;
  E: TCleanerEntry;
begin
  Result := TCleanerEntryList.Create(True);
  Seen := TStringList.Create;
  Seen.CaseSensitive := False;
  Seen.Sorted := True;
  Seen.Duplicates := dupIgnore;
  LoadExtraVars(ARulesDir);   // custom %vars% must exist before parsing
  Parser := TWinapp2Parser.Create(True);   // permissive: detection optional
  Det := TDetectionService.Create;
  try
    R := SysUtils.FindFirst(ARulesDir + '*.ini', faAnyFile, SR);
    try
      while R = 0 do
      begin
        if (SR.Attr and faDirectory) = 0 then
        begin
          Part := Parser.ParseFile(ARulesDir + SR.Name);
          try
            for J := Part.Count - 1 downto 0 do
            begin
              E := Part[J];
              E.IsCustom := True;
              E.SourceFile := ARulesDir + SR.Name;
              if (EntryHasDetection(E) and (not Det.IsInstalled(E))) or
                 (ASkipWarnings and (E.Warning <> '')) or
                 (Seen.IndexOf(E.Name) >= 0) then
              begin
                Part.Delete(J);
                Continue;
              end;
              Seen.Add(E.Name);
              Result.Add(Part.Extract(E));
            end;
          finally
            Part.Free;
          end;
        end;
        R := SysUtils.FindNext(SR);
      end;
    finally
      SysUtils.FindClose(SR);
    end;
  finally
    Parser.Free;
    Det.Free;
    Seen.Free;
  end;
end;

{ --- database file helpers (shared with the cleaner window) --------- }

function DataDir: string;
begin
  Result := ExtractFilePath(ParamStr(0)) + 'data\';
end;

function SettingsPath: string;
begin
  Result := ExtractFilePath(ParamStr(0)) + 'CleanSweep.ini';
end;

function LoadDbFile(const APath: string): string;
begin
  Result := LoadTextFile(APath);   // UTF-8 aware, ANSI fallback
end;

{ File copy wins, embedded resource is the fallback (RCDATA). }
function LoadDbText(const AName, AResName: string): string;
var
  RS: TResourceStream;
  SS: TStringStream;
begin
  Result := LoadDbFile(DataDir + AName);
  if Result = '' then
    Result := LoadDbFile(ExtractFilePath(ParamStr(0)) + AName);
  if Result <> '' then Exit;
  if FindResource(HInstance, PChar(AResName), Windows.RT_RCDATA) = 0 then Exit;
  RS := TResourceStream.Create(HInstance, AResName, Windows.RT_RCDATA);
  try
    SS := TStringStream.Create('');
    try
      SS.CopyFrom(RS, RS.Size);
      Result := SS.DataString;
    finally
      SS.Free;
    end;
  finally
    RS.Free;
  end;
end;

{ Writes the embedded RCDATA copy over data\AName (UTF-8). }
function RestoreDbFromResource(const AName, AResName: string): Boolean;
var
  RS: TResourceStream;
  FS: TFileStream;
begin
  Result := False;
  if FindResource(HInstance, PChar(AResName), Windows.RT_RCDATA) = 0
    then Exit;
  ForceDirectories(DataDir);
  RS := TResourceStream.Create(HInstance, AResName, Windows.RT_RCDATA);
  try
    FS := TFileStream.Create(DataDir + AName, fmCreate);
    try
      FS.CopyFrom(RS, RS.Size);
      Result := True;
    finally
      FS.Free;
    end;
  finally
    RS.Free;
  end;
end;

{ --- full pool (GUI parity) ------------------------------------------ }

function LoadCleanerPool(ASkipWarnings: Boolean): TCleanerEntryList;
var
  Ini: TIniFile;
  Texts: TStringList;
  Parser: TWinapp2Parser;
  Det: TDetectionService;
  Seen: TStringList;
  Part, Cust: TCleanerEntryList;
  I, J, K: Integer;
  E: TCleanerEntry;
  S: string;
begin
  Result := TCleanerEntryList.Create(True);
  Texts := TStringList.Create;
  Parser := TWinapp2Parser.Create;
  Seen := TStringList.Create;
  Det := TDetectionService.Create;
  try
    Seen.CaseSensitive := False;
    Seen.Sorted := True;
    Seen.Duplicates := dupIgnore;

    Ini := TIniFile.Create(SettingsPath);
    try
      // same keys/defaults as TCleanerForm.LoadSettings
      if Ini.ReadBool('Cleaner', 'EnableCustom', True) then
      begin
        S := Ini.ReadString('Cleaner', 'CustomPath', '');
        if S <> '' then
        begin
          S := LoadDbFile(S);
          if S <> '' then Texts.Add(S);
        end;
      end;
      if Ini.ReadBool('Cleaner', 'EnableCCleaner', True) then
      begin
        S := LoadDbFile(DataDir + 'CCleaner.ini');
        if S <> '' then Texts.Add(S);
      end;
      if Ini.ReadBool('Cleaner', 'EnableDefault', True) then
      begin
        if not FileExists(DataDir + 'Default.ini') then
          RestoreDbFromResource('Default.ini', 'DEFAULTDB');
        S := LoadDbText('Default.ini', 'DEFAULTDB');
        if S <> '' then Texts.Add(S);
      end;
      if Ini.ReadBool('Cleaner', 'EnableWinapp3', False) then
      begin
        S := LoadDbFile(DataDir + 'Winapp3.ini');
        if S <> '' then Texts.Add(S);
      end;
      if Ini.ReadBool('Cleaner', 'EnableWinapp2', True) then
      begin
        S := LoadDbText('Winapp2.ini', 'WINAPP2');
        if S <> '' then Texts.Add(S);
      end;
    finally
      Ini.Free;
    end;
    Texts.Add(SEC_EXTRA_INI);
    Texts.Add(SYS_EXTRA_INI);

    // first-wins merge, same order/priority as TCleanerThread.wmLoad
    for I := 0 to Texts.Count - 1 do
    begin
      Part := Parser.Parse(Texts[I]);
      try
        for J := Part.Count - 1 downto 0 do
          if Seen.IndexOf(Part[J].Name) < 0 then
          begin
            Seen.Add(Part[J].Name);
            Result.Add(Part.Extract(Part[J]));
          end
          else
            Part.Delete(J);
      finally
        Part.Free;
      end;
    end;

    // Custom\*.ini rides on top and replaces same-name entries
    Cust := LoadRuleEntries(ExtractFilePath(ParamStr(0)) + 'Custom\',
      ASkipWarnings);
    try
      for I := 0 to Cust.Count - 1 do
      begin
        E := Cust[I];
        if Seen.IndexOf(E.Name) >= 0 then
        begin
          for K := 0 to Result.Count - 1 do
            if SameText(Result[K].Name, E.Name) then
            begin
              Result.Delete(K);
              Break;
            end;
        end
        else
          Seen.Add(E.Name);
        Result.Add(Cust.Extract(E));
      end;
    finally
      Cust.Free;
    end;

    // detection pass: every entry gets its flag up front so the caller
    // (auto run) can filter without a second service instance
    for I := Result.Count - 1 downto 0 do
    begin
      E := Result[I];
      try
        E.Detected := Det.IsInstalled(E) or
          (E.IsCustom and not EntryHasDetection(E));
      except
        E.Detected := False;   // broken criteria → not installed
      end;
      if (ASkipWarnings and (E.Warning <> '')) or not E.Detected then
        Result.Delete(I);
    end;
  finally
    Det.Free;
    Seen.Free;
    Parser.Free;
    Texts.Free;
  end;
end;

end.
