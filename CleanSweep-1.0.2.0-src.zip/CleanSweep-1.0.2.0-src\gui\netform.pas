unit netform;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, StdCtrls, ExtCtrls,
  Dialogs, laz.virtualtrees,
  cs.netfix, cs.lang;

type
  { Runs the selected network ops sequentially off the UI thread —
    release/renew and adapter restarts take seconds. Log entries go to
    a queue flushed on the main thread per command; each queued line
    carries its colour in the object payload (bold flag in bit 24). }
  TNetThread = class(TThread)
  private
    FIndices: array of Integer;
    FQueue: TStringList;
    FLock: TRTLCriticalSection;
    FNeedReboot: Boolean;
    FForm: TObject;        // TNetForm — forward decl keeps it TObject
    procedure DoFlush;
    procedure QLine(const AMsg: string; const AColor: TColor;
      const ABold: Boolean = False);
  protected
    procedure Execute; override;
  public
    constructor Create(const AIndices: array of Integer; AForm: TObject);
    destructor Destroy; override;
    property NeedReboot: Boolean read FNeedReboot;
  end;

  { Network maintenance dialog — coloured VST checklist of the classic
    repair set (cs.netfix), executed in a worker thread with a
    colour-coded owner-drawn log. }
  TNetForm = class(TForm)
    btnAll: TButton;
    btnClose: TButton;
    btnInvert: TButton;
    btnNone: TButton;
    btnRun: TButton;
    lblLogHead: TLabel;
    lblStatus: TLabel;
    lvOps: TLazVirtualStringTree;
    lbLog: TListBox;
    pnlLog: TPanel;
    pnlBottom: TPanel;
    spMain: TSplitter;
    procedure BtnAllClick(Sender: TObject);
    procedure BtnInvertClick(Sender: TObject);
    procedure BtnNoneClick(Sender: TObject);
    procedure BtnRunClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure LbLogDrawItem(Control: TWinControl; Index: Integer;
      ARect: TRect; State: TOwnerDrawState);
    procedure OpsChecked(Sender: TBaseVirtualTree; Node: PVirtualNode);
    procedure OpsInitNode(Sender: TBaseVirtualTree; ParentNode,
      Node: PVirtualNode; var InitialStates: TVirtualNodeInitStates);
    procedure OpsGetText(Sender: TBaseVirtualTree; Node: PVirtualNode;
      Column: TColumnIndex; TextType: TVSTTextType; var CellText: String);
    procedure OpsPaintText(Sender: TBaseVirtualTree;
      const TargetCanvas: TCanvas; Node: PVirtualNode;
      Column: TColumnIndex; TextType: TVSTTextType);
  private
    FThread: TNetThread;
    function OpCaption(const AIndex: Integer): string;
    function OpColor(const AIndex: Integer): TColor;
    function OpRisk(const AIndex: Integer): string;
    procedure NetDone(Sender: TObject);
    procedure SetRunning(const ARunning: Boolean);
    procedure UpdateRunButton;
  end;

var
  NetFormWnd: TNetForm;

function ShowNetworkDialog(AOwner: TComponent): TModalResult;

implementation

{$R *.lfm}

const
  { Muted palette — semantic colours without primary-colour glare:
    brick = consequence (link drops / error), amber = reboot needed,
    steel = needs admin, dark grey = neutral log noise. }
  COL_DANGER  = TColor($5050C4);     // muted brick red
  COL_REBOOT  = TColor($288CB0);     // muted amber
  COL_ADMIN   = TColor($AA7850);     // muted steel blue
  COL_SAFE    = TColor($3E7A3E);     // muted green — harmless
  COL_NORMAL  = clWindowText;
  COL_LOGINFO = TColor($5A5A5A);     // neutral log text

function ShowNetworkDialog(AOwner: TComponent): TModalResult;
var
  F: TNetForm;
begin
  F := TNetForm.Create(AOwner);
  try
    Result := F.ShowModal;
  finally
    F.Free;
  end;
end;

{ ═══════════════ TNetThread ═══════════════ }

constructor TNetThread.Create(const AIndices: array of Integer;
  AForm: TObject);
var
  I: Integer;
begin
  inherited Create(False);
  FreeOnTerminate := False;
  FForm := AForm;
  SetLength(FIndices, Length(AIndices));
  for I := 0 to High(AIndices) do
    FIndices[I] := AIndices[I];
  FQueue := TStringList.Create;
  InitCriticalSection(FLock);
end;

destructor TNetThread.Destroy;
begin
  FQueue.Free;
  DoneCriticalSection(FLock);
  inherited;
end;

{ Colour + bold flag packed into the object payload. }
procedure TNetThread.QLine(const AMsg: string; const AColor: TColor;
  const ABold: Boolean);
var
  V: PtrInt;
begin
  V := PtrInt(AColor);
  if ABold then V := V or $1000000;
  EnterCriticalSection(FLock);
  try
    FQueue.AddObject(AMsg, TObject(V));
  finally
    LeaveCriticalSection(FLock);
  end;
end;

procedure TNetThread.DoFlush;
var
  S: TStringList;
  I: Integer;
  LB: TListBox;
begin
  S := TStringList.Create;
  EnterCriticalSection(FLock);
  try
    S.Assign(FQueue);
    FQueue.Clear;
  finally
    LeaveCriticalSection(FLock);
  end;
  try
    if FForm = nil then Exit;
    LB := TNetForm(FForm).lbLog;
    if LB = nil then Exit;
    for I := 0 to S.Count - 1 do
      LB.Items.AddObject(S[I], S.Objects[I]);
    LB.TopIndex := LB.Items.Count - 1;
  finally
    S.Free;
  end;
end;

procedure TNetThread.Execute;
var
  Op, R, I: Integer;
  Cmds: TStringList;
  Out_: string;
  OpCol: TColor;
begin
  Cmds := TStringList.Create;
  try
    for Op in FIndices do
    begin
      if Terminated then Break;
      Cmds.Clear;
      NetOpCommands(Op, Cmds);
      // reboot ops get the whole block in dark yellow
      if nfReboot in NetOpFlags(Op) then OpCol := COL_REBOOT
      else OpCol := COL_LOGINFO;
      QLine('═══ ' + TNetForm(FForm).OpCaption(Op) + ' ═══', OpCol, True);
      for I := 0 to Cmds.Count - 1 do
      begin
        QLine('> ' + Cmds[I], OpCol);
        Synchronize(@DoFlush);
        R := RunNetCommand(Cmds[I], Out_);
        if Trim(Out_) <> '' then
          QLine(TrimRight(Out_), OpCol);
        if R = 0 then
          QLine('  exit code: 0', OpCol)
        else
        begin
          QLine('  exit code: ' + IntToStr(R), COL_DANGER);
          if R < 0 then
            QLine('  (!) ' + Lg('команда не запустилась или превысила таймаут',
              'каманда не запусцілася або перавысіла тайм-аўт',
              'команда не запустилася або перевищила тайм-аут',
              'command failed to start or timed out'), COL_DANGER);
        end;
        Synchronize(@DoFlush);
      end;
      if nfReboot in NetOpFlags(Op) then FNeedReboot := True;
    end;
  finally
    Cmds.Free;
  end;
end;

{ ═══════════════ TNetForm ═══════════════ }

{ English key → localized caption; flagged ops get a marker suffix. }
function TNetForm.OpCaption(const AIndex: Integer): string;
begin
  case AIndex of
    NETOP_DNS:       Result := Lg('Очистка кэша DNS', 'Ачыстка кэша DNS', 'Очищення кешу DNS', 'Flush DNS cache');
    NETOP_NETBIOS:   Result := Lg('Очистка кэша NetBIOS', 'Ачыстка кэша NetBIOS', 'Очищення кешу NetBIOS', 'Flush NetBIOS cache');
    NETOP_ARP:       Result := Lg('Очистка ARP-кэша', 'Ачыстка ARP-кэша', 'Очищення ARP-кешу', 'Flush ARP cache');
    NETOP_BRANCH:    Result := Lg('Очистка BranchCache', 'Ачыстка BranchCache', 'Очищення BranchCache', 'Flush BranchCache');
    NETOP_WINHTTP:   Result := Lg('Сброс прокси WinHTTP', 'Скід проксі WinHTTP', 'Скидання проксі WinHTTP', 'Reset WinHTTP proxy');
    NETOP_TCPGLOBAL: Result := Lg('Сброс глобальных настроек TCP', 'Скід глабальных налад TCP', 'Скидання глобальних налаштувань TCP', 'Reset TCP global settings');
    NETOP_WINSOCK:   Result := Lg('Сброс каталога Winsock', 'Скід каталога Winsock', 'Скидання каталогу Winsock', 'Reset Winsock catalog');
    NETOP_TCPIP:     Result := Lg('Сброс стека TCP/IP', 'Скід стэка TCP/IP', 'Скидання стека TCP/IP', 'Reset TCP/IP stack');
    NETOP_ROUTES:    Result := Lg('Очистка таблицы маршрутизации', 'Ачыстка табліцы маршрутызацыі', 'Очищення таблиці маршрутизації', 'Flush routing table');
    NETOP_RENEW:     Result := Lg('Обновление IP-конфигурации', 'Абнаўленне IP-канфігурацыі', 'Оновлення IP-конфігурації', 'Renew IP configuration');
    NETOP_ADAPTERS:  Result := Lg('Перезапуск сетевых адаптеров', 'Перазапуск сеткавых адаптараў', 'Перезапуск мережевих адаптерів', 'Restart network adapters');
  else
    Result := NetOpKey(AIndex);
  end;
end;

{ Consequence text for the second column — strict labels, no glyphs. }
function TNetForm.OpRisk(const AIndex: Integer): string;
var
  Fl: TNetOpFlags;
begin
  Fl := NetOpFlags(AIndex);
  Result := '';
  if nfDropsLink in Fl then
    Result := Result + '· ' + Lg('прерывает связь', 'парушае сувязь',
      'перериває зв''язок', 'drops link') + ' ';
  if nfReboot in Fl then
    Result := Result + '· ' + Lg('перезагрузка', 'перазапуск',
      'перезавантаження', 'reboot') + ' ';
  if nfAdmin in Fl then
    Result := Result + '· ' + Lg('нужен админ', 'патрэбен адмін',
      'потрібен адмін', 'needs admin') + ' ';
  Result := Trim(Result);
  if Result = '' then
    Result := Lg('безопасно', 'бяспечна', 'безпечно', 'safe');
end;

{ Row colour by worst flag: danger > reboot > admin > normal. }
function TNetForm.OpColor(const AIndex: Integer): TColor;
var
  Fl: TNetOpFlags;
begin
  Fl := NetOpFlags(AIndex);
  if nfDropsLink in Fl then Exit(COL_DANGER);
  if nfReboot in Fl then Exit(COL_REBOOT);
  if nfAdmin in Fl then Exit(COL_ADMIN);
  Result := COL_SAFE;
end;

procedure TNetForm.OpsGetText(Sender: TBaseVirtualTree; Node: PVirtualNode;
  Column: TColumnIndex; TextType: TVSTTextType; var CellText: String);
begin
  if Column = 1 then
    CellText := OpRisk(PInteger(Sender.GetNodeData(Node))^)
  else
    CellText := OpCaption(PInteger(Sender.GetNodeData(Node))^);
end;

{ Selected row must invert to clHighlightText; otherwise the name
  column stays plain text and only the consequence column is tinted. }
procedure TNetForm.OpsPaintText(Sender: TBaseVirtualTree;
  const TargetCanvas: TCanvas; Node: PVirtualNode;
  Column: TColumnIndex; TextType: TVSTTextType);
begin
  if vsSelected in Node^.States then
    TargetCanvas.Font.Color := clHighlightText
  else if Column = 1 then
    TargetCanvas.Font.Color := OpColor(PInteger(Sender.GetNodeData(Node))^)
  else
    TargetCanvas.Font.Color := clWindowText;
end;

{ Nodes init lazily — CheckType must be set here: it defaults to
  ctNone, which is why the checkbox column renders empty without it. }
procedure TNetForm.OpsInitNode(Sender: TBaseVirtualTree; ParentNode,
  Node: PVirtualNode; var InitialStates: TVirtualNodeInitStates);
begin
  PInteger(Sender.GetNodeData(Node))^ := Node^.Index;
  Sender.CheckType[Node] := ctCheckBox;
end;

procedure TNetForm.OpsChecked(Sender: TBaseVirtualTree; Node: PVirtualNode);
begin
  UpdateRunButton;
end;

procedure TNetForm.UpdateRunButton;
begin
  btnRun.Enabled := (lvOps.GetFirstChecked <> nil) and (FThread = nil);
end;

procedure TNetForm.LbLogDrawItem(Control: TWinControl; Index: Integer;
  ARect: TRect; State: TOwnerDrawState);
var
  V: PtrInt;
begin
  V := PtrInt(lbLog.Items.Objects[Index]);
  with lbLog.Canvas do
  begin
    FillRect(ARect);
    Font.Color := TColor(V and $FFFFFF);
    if (V and $1000000) <> 0 then
      Font.Style := Font.Style + [fsBold]
    else
      Font.Style := Font.Style - [fsBold];
    TextOut(ARect.Left + 2, ARect.Top + 1, lbLog.Items[Index]);
  end;
end;

procedure TNetForm.FormCreate(Sender: TObject);
var
  N: PVirtualNode;
begin
  try
    Icon.LoadFromResourceName(HInstance, 'NET');
  except
  end;
  Caption := Lg('Сеть — сброс и очистка', 'Сетка — скід і ачыстка',
                'Мережа — скидання й очищення', 'Network — reset and cleanup');
  btnAll.Caption := Lg('Отметить всё', 'Адзначыць усё', 'Відзначити все', 'Check all');
  btnNone.Caption := Lg('Снять все', 'Зняць усё', 'Зняти все', 'Uncheck all');
  btnInvert.Caption := Lg('Инвертировать', 'Інвертаваць', 'Інвертувати', 'Invert');
  btnRun.Caption := Lg('Выполнить', 'Выканаць', 'Виконати', 'Run');
  btnClose.Caption := Lg('Закрыть', 'Закрыць', 'Закрити', 'Close');
  lvOps.Header.Columns[0].Text := Lg('Операция', 'Аперацыя', 'Операція', 'Operation');
  lvOps.Header.Columns[1].Text := Lg('Последствия', 'Наступствы', 'Наслідки', 'Consequences');
  lblStatus.Caption := Lg(
    'Отмечены безопасные операции. Тяжёлые (сброс стека, маршруты, адаптеры) выполняйте осознанно.',
    'Адзначаны бяспечныя аперацыі. Цяжкія (скід стэка, маршруты, адаптары) выконвайце асвядомлена.',
    'Позначено безпечні операції. Важкі (скидання стека, маршрути, адаптери) виконуйте усвідомлено.',
    'Safe ops are pre-checked. Run the heavy ones (stack reset, routes, adapters) deliberately.');
  lblStatus.Font.Color := clDkGray;
  lblLogHead.Caption := '  ' + Lg('Журнал', 'Часопіс', 'Журнал', 'Log');
  lblLogHead.Font.Style := lblLogHead.Font.Style + [fsBold];
  lblLogHead.Font.Color := clDkGray;

  lvOps.NodeDataSize := SizeOf(Integer);
  lvOps.RootNodeCount := NETOP_COUNT;   // lazy: OpsInitNode fills data
  // safe cache flushes pre-checked — no link drop, no reboot
  N := lvOps.GetFirst;
  while N <> nil do
  begin
    if PInteger(lvOps.GetNodeData(N))^ in [NETOP_DNS, NETOP_NETBIOS] then
      lvOps.CheckState[N] := csCheckedNormal;
    N := lvOps.GetNext(N);
  end;
  UpdateRunButton;
  lbLog.Clear;
end;

procedure TNetForm.FormDestroy(Sender: TObject);
begin
  // the worker touches lbLog only via Synchronize — wait for it so a
  // late flush can't hit a freed form
  if FThread <> nil then
  begin
    FThread.WaitFor;
    FThread.Free;
  end;
end;

procedure TNetForm.BtnAllClick(Sender: TObject);
var
  N: PVirtualNode;
begin
  N := lvOps.GetFirst;
  while N <> nil do
  begin
    lvOps.CheckState[N] := csCheckedNormal;
    N := lvOps.GetNext(N);
  end;
  UpdateRunButton;
end;

procedure TNetForm.BtnNoneClick(Sender: TObject);
var
  N: PVirtualNode;
begin
  N := lvOps.GetFirst;
  while N <> nil do
  begin
    lvOps.CheckState[N] := csUncheckedNormal;
    N := lvOps.GetNext(N);
  end;
  UpdateRunButton;
end;

procedure TNetForm.BtnInvertClick(Sender: TObject);
var
  N: PVirtualNode;
begin
  N := lvOps.GetFirst;
  while N <> nil do
  begin
    if lvOps.CheckState[N] = csCheckedNormal then
      lvOps.CheckState[N] := csUncheckedNormal
    else
      lvOps.CheckState[N] := csCheckedNormal;
    N := lvOps.GetNext(N);
  end;
  UpdateRunButton;
end;

procedure TNetForm.SetRunning(const ARunning: Boolean);
begin
  btnAll.Enabled := not ARunning;
  btnNone.Enabled := not ARunning;
  btnInvert.Enabled := not ARunning;
  lvOps.Enabled := not ARunning;
  UpdateRunButton;
end;

procedure TNetForm.BtnRunClick(Sender: TObject);
var
  Idx: array of Integer;
  N: PVirtualNode;
  Cnt, I: Integer;
  Warn: string;
  Fl: TNetOpFlags;
begin
  if FThread <> nil then Exit;
  Cnt := 0;
  N := lvOps.GetFirstChecked;
  while N <> nil do
  begin
    Inc(Cnt);
    N := lvOps.GetNextChecked(N);
  end;
  if Cnt = 0 then Exit;
  SetLength(Idx, Cnt);
  Cnt := 0;
  N := lvOps.GetFirstChecked;
  while N <> nil do
  begin
    Idx[Cnt] := PInteger(lvOps.GetNodeData(N))^;
    Inc(Cnt);
    N := lvOps.GetNextChecked(N);
  end;

  // surface the heavy-op consequences once, before anything runs
  Warn := '';
  for I := 0 to High(Idx) do
  begin
    Fl := NetOpFlags(Idx[I]);
    if nfReboot in Fl then
      Warn := Warn + '• ' + OpCaption(Idx[I]) + ' — ' +
        Lg('потребуется перезагрузка', 'спатрэбіцца перазапуск',
           'знадобиться перезавантаження', 'restart required') + sLineBreak;
    if nfDropsLink in Fl then
      Warn := Warn + '• ' + OpCaption(Idx[I]) + ' — ' +
        Lg('сетевое соединение прервётся', 'сеткавае злучэнне перарвецца',
           'мережеве з''єднання перервється', 'connectivity will drop') + sLineBreak;
  end;
  if Warn <> '' then
    if MessageDlg(
        Lg('Отмечены операции с последствиями:' + sLineBreak + sLineBreak +
           '%s' + sLineBreak + 'Продолжить?',
           'Адзначаны аперацыі з наступствамі:' + sLineBreak + sLineBreak +
           '%s' + sLineBreak + 'Працягнуць?',
           'Позначено операції з наслідками:' + sLineBreak + sLineBreak +
           '%s' + sLineBreak + 'Продовжити?',
           'Operations with consequences are checked:' + sLineBreak +
           sLineBreak + '%s' + sLineBreak + 'Continue?'),
        mtWarning, [mbYes, mbNo], 0, mbNo) <> mrYes then Exit;

  SetRunning(True);
  lblStatus.Caption := Lg('Выполнение…', 'Выкананне…', 'Виконання…',
                          'Running…');
  FThread := TNetThread.Create(Idx, Self);
  FThread.OnTerminate := @NetDone;
end;

procedure TNetForm.NetDone(Sender: TObject);
var
  Reboot: Boolean;
begin
  Reboot := FThread.NeedReboot;
  FThread.Free;
  FThread := nil;
  SetRunning(False);
  UpdateRunButton;
  if Reboot then
    lblStatus.Caption := Lg(
      'Готово. Для применения части изменений требуется перезагрузка.',
      'Гатова. Для прымянення часткі змяненняў патрэбны перазапуск.',
      'Готово. Для застосування частини змін потрібне перезавантаження.',
      'Done. A restart is required for some changes to apply.')
  else
    lblStatus.Caption := Lg('Готово.', 'Гатова.', 'Готово.', 'Done.');
end;

end.
